"""Memory-bounded preprocessing of six public 10x libraries; no patient data."""
from pathlib import Path
import os,sys,json,gzip,tarfile,gc,time,importlib.metadata
BASE=Path(__file__).resolve().parent
OUT=BASE/'论文推进_2026-10-30/单细胞定位'
RUNTIME=OUT/'runtime';sys.path.insert(0,str(RUNTIME))
os.environ['NUMBA_CACHE_DIR']=str(OUT/'cache/numba')
os.environ['JOBLIB_TEMP_FOLDER']=str(OUT/'cache/joblib')
os.environ['OMP_NUM_THREADS']='2';os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['MKL_NUM_THREADS']='2';os.environ['NUMBA_NUM_THREADS']='2'
for d in ['cache/numba','cache/joblib','预处理','结果表','科研图','科研图/质量核验']:(OUT/d).mkdir(parents=True,exist_ok=True)
import numpy as np,pandas as pd,scanpy as sc
from scipy import sparse
from scipy.io import mmread
from threadpoolctl import threadpool_limits
SRC=BASE/'GEO表达核验_2026-10-29/独立队列_GSE211783'
PRE=OUT/'预处理';RES=OUT/'结果表'
sc.settings.n_jobs=2;sc.settings.verbosity=2
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def prepare():
    versions={k:importlib.metadata.version(k) for k in ['numpy','scipy','pandas','scanpy','anndata','scikit-learn','umap-learn','igraph','leidenalg']}
    feat=pd.read_csv(SRC/'预处理/人类基因特征.csv');features=feat.source_symbol.to_numpy();n_genes=len(feat)
    marker_groups={
        'T cells':['CD3D','CD3E','TRAC','CD247'],
        'Naive T':['CCR7','IL7R','TCF7','LEF1'],
        'Cytotoxic T':['CD8A','CD8B','CCL5','GZMK'],
        'NK':['GNLY','NKG7','KLRD1','PRF1','FCGR3A'],
        'B cells':['MS4A1','CD79A','CD79B','CD74','CD37'],
        'Plasma':['MZB1','JCHAIN','SDC1','IGHG1'],
        'Monocytes':['LYZ','LST1','CTSS','FCN1','CD14','S100A8','S100A9'],
        'CD16 monocytes':['FCGR3A','MS4A7','LILRB1','IFITM3','LST1'],
        'cDC':['FCER1A','CD1C','CLEC10A','CST3'],
        'pDC':['GZMB','TCF4','IL3RA','CLEC4C','LILRA4'],
        'Platelets':['PPBP','PF4','NRGN','GP9'],
        'Erythroid':['HBB','HBA1','HBA2','ALAS2'],
        'Cycling':['MKI67','TOP2A','STMN1','TYMS'],
    }
    targets=['NLRP3','CASP1','IL1B','XDH','SLC22A12','ABCG2','SLC2A9','TLR4','RELA','NFKB1','TNF','AKT1']
    modules={
        'Inflammasome':['NLRP3','PYCARD','CASP1','IL1B','IL18','GSDMD'],
        'NF-kB response':['NFKB1','RELA','NFKBIA','TNFAIP3','TNF','IL6','CCL2','CXCL8'],
        'Myeloid inflammatory':['S100A8','S100A9','FCN1','IL1B','LYZ','CTSS'],
        'Type I interferon':['ISG15','IFIT1','IFIT2','IFIT3','MX1','IFI6','IFITM3'],
    }
    # All marker/target/module genes are retained even if excluded from HVG selection.
    selected=sorted(set(sum(marker_groups.values(),[])+targets+sum(modules.values(),[])))
    sel_indices=np.flatnonzero(np.isin(features,selected));selected_actual=feat.iloc[sel_indices].copy()
    selected_actual.to_csv(RES/'预定义定位基因.csv',index=False)
    dump(OUT/'预定义分析与绘图合同.json',{'dataset':'GSE211783','question':'Which major PBMC lineages carry the frozen candidate-target expression?','claim':'Conservative marker-based lineage annotation provides cellular context for candidate targets; no formula intervention is present.','backend':'python','archetype':'quantitative grid','biological_replicates':3,'libraries':6,'pairing_crosswalk_verified':False,'baseline_cell_QC':{'min_genes':200,'max_genes':6000,'min_UMI':500,'max_mito_fraction':0.2},'HVG':{'per_library':2000,'flavor':'seurat','exclude_mito_ribo_hemoglobin_from_HVG':True,'consensus_top':2500,'criterion':'number of libraries highly-variable, then median normalized-dispersion rank'},'embedding':{'PCA_components':50,'neighbors':20,'n_pcs':30,'leiden_resolution':0.6,'random_state':20261030,'UMAP_min_dist':0.35},'marker_groups':marker_groups,'priority12':targets,'modules':modules,'limitations':['No independent donor pairing crosswalk; all 6 pairings for inferential analyses.','No ambient-RNA correction or validated doublet classification; mixed-marker clusters retained as ambiguous.','Cell means and detection rates are descriptive, not biological replicate tests.','No formula treatment in this cohort.','Unintegrated and library-adjusted embeddings used only for visualization/annotation, never to adjust raw pseudobulk counts.'],'source':'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE211783','methods':'https://scanpy.readthedocs.io/en/stable/tutorials/basics/clustering.html','versions':versions})
    hvgstats=[];allobs=[];all_expr=[];qclist=[]
    for p in sorted((SRC/'原始来源').glob('GSM*_*.tar.gz')):
        sample=p.name.split('_')[1].split('.')[0];path=PRE/(sample+'_QC_counts.npz');t=time.time()
        oldqc=pd.read_csv(SRC/'预处理'/f'{sample}_细胞QC.csv.gz')
        if not path.exists():
            with tarfile.open(p,'r:gz') as tar:
                files={Path(x.name).name:x for x in tar.getmembers() if x.isfile()}
                with threadpool_limits(limits=2):
                    mat=mmread(gzip.GzipFile(fileobj=tar.extractfile(files['matrix.mtx.gz']))).astype(np.int32).tocsc()
            assert mat.shape==(n_genes,len(oldqc))
            totals=np.asarray(mat.sum(axis=0)).ravel();ng=np.diff(mat.indptr)
            mito=features.astype(str);mi=np.char.startswith(mito.astype(str),'MT-')
            frac=np.asarray(mat[mi].sum(axis=0)).ravel()/np.maximum(totals,1)
            keep=(ng>=200)&(ng<=6000)&(totals>=500)&(frac<=.2)
            assert np.array_equal(keep,oldqc.retained.astype(bool))
            mat=mat[:,keep].T.tocsr()
            assert np.array_equal(np.asarray(mat.sum(axis=1)).ravel(),oldqc.loc[keep,'UMI'].to_numpy())
            sparse.save_npz(path,mat,compressed=True)
        else:mat=sparse.load_npz(path)
        ob=oldqc.loc[oldqc.retained.astype(bool)].copy();ob['sample_id']=sample;ob['phase']='Acute' if sample.startswith('A') else 'Remission';ob['cell_id']=sample+'_'+ob.barcode
        ob.index=ob.cell_id
        assert mat.shape==(len(ob),n_genes)
        cnttotal=np.asarray(mat.sum(axis=1)).ravel()
        # Retain raw integer counts on disk. Compute log(CP10k+1) in one copy.
        logmat=mat.astype(np.float32);del mat;gc.collect()
        sparsefunc=__import__('sklearn.utils.sparsefuncs',fromlist=['inplace_row_scale']);sparsefunc.inplace_row_scale(logmat,(10000/cnttotal).astype(np.float32));np.log1p(logmat.data,out=logmat.data)
        expr=logmat[:,sel_indices].toarray().astype(np.float32);all_expr.append(expr);allobs.append(ob)
        v=sparse.csr_matrix(logmat.shape,dtype=np.float32)
        ad=sc.AnnData(logmat,var=pd.DataFrame(index=feat.gene_id));
        sc.pp.highly_variable_genes(ad,flavor='seurat',n_top_genes=2000,inplace=True)
        hv=ad.var.copy();hv['gene_id']=hv.index;hv['sample_id']=sample;hvgstats.append(hv)
        qclist.append({'sample_id':sample,'cells_input':len(oldqc),'cells_QC_retained':len(ob),'nonzero_UMIs':int(ad.X.nnz),'total_UMI':int(cnttotal.sum())})
        del ad,logmat,v;gc.collect();print('PREPARED',sample,len(ob),'seconds',round(time.time()-t,1),flush=True)
    pd.concat(allobs).to_csv(PRE/'全部QC细胞_元数据.csv.gz',index=False,compression='gzip')
    np.save(PRE/'全部QC细胞_预定义基因_logCP10k.npy',np.vstack(all_expr));del all_expr
    pd.DataFrame(qclist).to_csv(RES/'六文库_QC核验.csv',index=False)
    hvg=pd.concat(hvgstats);hvg.to_csv(PRE/'六文库_高变基因统计.csv.gz',index=False,compression='gzip')
    finalize_hvg(feat,hvg,pd.concat(allobs))
def finalize_hvg(feat,hvg,obs):
    hvg=hvg.reset_index(drop=True)
    hvg['disp_rank']=hvg.groupby('sample_id').dispersions_norm.rank(ascending=False,na_option='bottom')
    summary=hvg.groupby('gene_id').agg(n_libraries_highly_variable=('highly_variable','sum'),median_dispersion_rank=('disp_rank','median'),mean_expression=('means','mean')).reset_index().merge(feat,on='gene_id',how='left')
    summary['excluded_from_embedding_HVG']=summary.source_symbol.str.match(r'^(MT-|RPS|RPL|HBA|HBB)',na=False)
    choice=summary.loc[~summary.excluded_from_embedding_HVG & (summary.n_libraries_highly_variable>=1)].sort_values(['n_libraries_highly_variable','median_dispersion_rank'],ascending=[False,True]).head(2500).gene_id.tolist()
    assert len(choice)>=1000
    summary['selected_consensus_HVG']=summary.gene_id.isin(choice);summary.to_csv(RES/'跨文库共识高变基因.csv',index=False)
    ix=np.flatnonzero(feat.gene_id.isin(choice));blocks=[]
    for sample in ['A1','A2','A3','B1','B2','B3']:
        mat=sparse.load_npz(PRE/(sample+'_QC_counts.npz'));tot=np.asarray(mat.sum(axis=1)).ravel();b=mat[:,ix].astype(np.float32);del mat;gc.collect()
        sparsefunc=__import__('sklearn.utils.sparsefuncs',fromlist=['inplace_row_scale']);sparsefunc.inplace_row_scale(b,(10000/tot).astype(np.float32));np.log1p(b.data,out=b.data);blocks.append(b)
    hvmat=sparse.vstack(blocks,format='csr');del blocks;gc.collect()
    var=feat.iloc[ix].copy();var.index=var.gene_id
    ad=sc.AnnData(hvmat,obs=obs,var=var);ad.write_h5ad(PRE/'HVG_未整合_logCP10k.h5ad',compression='gzip')
    dump(OUT/'预处理完成.json',{'cells':ad.n_obs,'HVG_genes':ad.n_vars,'selected_locator_features':len(pd.read_csv(RES/'预定义定位基因.csv'))})
    print('PREPROCESS_COMPLETE',ad.shape,flush=True)
if __name__=='__main__':
    if '--finish' in sys.argv:
        feat=pd.read_csv(SRC/'预处理/人类基因特征.csv');hvg=pd.read_csv(PRE/'六文库_高变基因统计.csv.gz');obs=pd.read_csv(PRE/'全部QC细胞_元数据.csv.gz');obs.index=obs.cell_id
        finalize_hvg(feat,hvg,obs)
    else:prepare()
