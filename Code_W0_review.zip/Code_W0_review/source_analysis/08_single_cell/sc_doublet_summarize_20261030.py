"""Descriptive Scrublet audit. Six captures are not six independent patients."""
from pathlib import Path
import sys,json,hashlib,itertools,shutil
BASE=Path(__file__).resolve().parent;SC=BASE/'论文推进_2026-10-30/单细胞定位';OUT=BASE/'论文推进_2026-10-30/单细胞稳健性_第二轮'
sys.path.insert(0,str(SC/'runtime'));sys.path.insert(0,str(OUT/'runtime'))
import numpy as np,pandas as pd
from scipy.stats import spearmanr
R=OUT/'结果表';SRC=OUT/'源数据';LIBS=['A1','A2','A3','B1','B2','B3']
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str)+'\n',encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 models=[json.loads((OUT/'模型日志'/(s+'_模型与输入.json')).read_text(encoding='utf8')) for s in LIBS]
 for m in models:
  sims=pd.read_csv(SRC/(m['sample_id']+'_模拟双细胞分数.csv.gz')).simulated_doublet_score
  m['simulated_detectable_fraction']=float((sims>m['automatic_threshold']).mean()) if m['threshold_identified'] else None
  m['low_detectability_warning']=m['simulated_detectable_fraction'] is not None and m['simulated_detectable_fraction']<.05
  m['low_detectability_rule']='Exploratory warning if <5% of simulated doublets exceed automatic cutoff; not a validated pass/fail threshold.'
 model=pd.DataFrame([{k:v for k,v in m.items() if not isinstance(v,(dict,list))} for m in models]);model.to_csv(R/'六文库_模型阈值与预测率.csv',index=False)
 obs=pd.read_csv(SC/'结果表/全部QC细胞_最终保守注释.csv.gz');parts=[pd.read_csv(R/(s+'_Scrublet细胞分数.csv.gz')) for s in LIBS];flags=pd.concat(parts,ignore_index=True)
 assert np.array_equal(flags.cell_id,obs.cell_id) and flags.cell_id.is_unique and len(flags)==53940
 assert flags.classification_available.all(),'At least one automatic threshold failed. Preserve scores but do not treat missing classifications as singlets.'
 assert flags.predicted_doublet.dtype==bool
 x=obs.copy();x['doublet_score']=flags.doublet_score;x['predicted_doublet']=flags.predicted_doublet;x['automatic_threshold']=flags.automatic_threshold
 x.to_csv(SRC/'全部53940细胞_冻结注释与独立预测.csv.gz',index=False,compression='gzip')
 rows=[]
 for (s,t),v in x.groupby(['sample_id','cell_type'],sort=False):
  rows.append({'sample_id':s,'phase':v.phase.iloc[0],'cell_type':t,'n_cells':len(v),'n_predicted':int(v.predicted_doublet.sum()),'predicted_fraction':v.predicted_doublet.mean(),'median_score':v.doublet_score.median(),'mean_score':v.doublet_score.mean()})
 rates=pd.DataFrame(rows);rates.to_csv(R/'13类细胞_逐文库双细胞预测分布.csv',index=False)
 alltypes=[]
 for t,v in x.groupby('cell_type',sort=False):alltypes.append({'cell_type':t,'n_cells':len(v),'n_predicted':int(v.predicted_doublet.sum()),'predicted_fraction':v.predicted_doublet.mean(),'median_score':v.doublet_score.median(),'n_libraries':v.sample_id.nunique()})
 pooled_rates=pd.DataFrame(alltypes);pooled_rates.to_csv(R/'13类细胞_合并预测分布_仅描述.csv',index=False)
 cov=[]
 for s,v in x.groupby('sample_id',sort=False):
  row={'sample_id':s,'phase':v.phase.iloc[0],'n_cells':len(v),'flagged_fraction':v.predicted_doublet.mean()}
  for flag in [False,True]:
   f=v[v.predicted_doublet.eq(flag)];tag='flagged' if flag else 'unflagged'
   for col in ['UMI','genes','mito_fraction']:row[f'{tag}_{col}_median']=f[col].median()
  for col in ['UMI','genes','mito_fraction']:row['descriptive_rho_score_'+col]=spearmanr(v.doublet_score,v[col]).statistic
  cov.append(row)
 pd.DataFrame(cov).to_csv(R/'文库QC与分数关系_描述统计.csv',index=False)
 table=rates.pivot(index='cell_type',columns='sample_id',values='n_cells').reindex(columns=LIBS).fillna(0)
 eligible=table.index[(table>=30).all(axis=1)].tolist();weights=x[x.cell_type.isin(eligible)].cell_type.value_counts(normalize=True)
 std=[]
 for s in LIBS:
  fr=rates[rates.sample_id.eq(s)].set_index('cell_type').predicted_fraction
  std.append({'sample_id':s,'phase':'Acute' if s.startswith('A') else 'Remission','observed_flagged_fraction':float(x.loc[x.sample_id.eq(s),'predicted_doublet'].mean()),'same_celltype_weight_flagged_fraction':float((fr.reindex(eligible)*weights.reindex(eligible)).sum()),'n_celltypes_standardized':len(eligible)})
 standard=pd.DataFrame(std);standard.to_csv(R/'文库预测率_固定细胞组成标准化.csv',index=False)
 dump(R/'组成标准化_固定权重.json',{'eligible_min_cells_per_library':30,'celltypes':eligible,'pooled_type_weights':weights.to_dict(),'rule':'Exactly the same pooled type weights in every library. Excludes rare types failing >=30 cells in any library. Descriptive, no cell-level hypothesis test.'})
 expr=np.load(SC/'预处理/全部QC细胞_扩展注释基因_logCP10k.npy',mmap_mode='r');features=pd.read_csv(SC/'结果表/完整定位与扩展注释基因.csv');genes=['NLRP3','IL1B'];positions={g:np.flatnonzero(features.source_symbol.eq(g)).item() for g in genes};target=[]
 for (s,t),ids in x.groupby(['sample_id','cell_type'],sort=False).groups.items():
  ix=np.asarray(list(ids));unflagged=ix[~x.iloc[ix].predicted_doublet.to_numpy()]
  for state,indices in [('All fixed QC cells',ix),('Predicted flags excluded',unflagged)]:
   for g,j in positions.items():
    z=expr[indices,j];target.append({'sample_id':s,'phase':'Acute' if s.startswith('A') else 'Remission','cell_type':t,'subset':state,'gene':g,'n_cells':len(z),'mean_logCP10k':float(z.mean()) if len(z) else np.nan,'fraction_detected':float((z>0).mean()) if len(z) else np.nan})
 targets=pd.DataFrame(target);targets.to_csv(R/'NLRP3_IL1B_逐文库细胞类型_敏感性表达.csv',index=False)
 pooled=[]
 for t,ids in x.groupby('cell_type',sort=False).groups.items():
  ix=np.asarray(list(ids))
  for state,indices in [('All fixed QC cells',ix),('Predicted flags excluded',ix[~x.iloc[ix].predicted_doublet.to_numpy()])]:
   for g,j in positions.items():
    z=expr[indices,j];pooled.append({'cell_type':t,'subset':state,'gene':g,'n_cells':len(z),'mean_logCP10k':float(z.mean()) if len(z) else np.nan,'fraction_detected':float((z>0).mean()) if len(z) else np.nan})
 pooled=pd.DataFrame(pooled);pooled.to_csv(R/'NLRP3_IL1B_合并细胞定位_仅描述.csv',index=False)
 # Equal-library summaries require >=30 cells in BOTH hypothetical subsets per type/library.
 counts=targets.pivot_table(index=['sample_id','cell_type','gene'],columns='subset',values='n_cells');good=counts.index[(counts>=30).all(axis=1)]
 targ=targets.set_index(['sample_id','cell_type','gene']).loc[good].reset_index()
 equal=targ.groupby(['cell_type','gene','subset'],as_index=False).agg(n_libraries=('sample_id','nunique'),mean_logCP10k=('mean_logCP10k','mean'),fraction_detected=('fraction_detected','mean'),min_cells=('n_cells','min'))
 equal.to_csv(R/'NLRP3_IL1B_等文库权重定位_每子集至少30细胞.csv',index=False)
 loo=[]
 for omit in ['None']+LIBS:
  z=targ if omit=='None' else targ[~targ.sample_id.eq(omit)]
  for (g,state),v in z.groupby(['gene','subset']):
   avg=v.groupby('cell_type').agg(mean=('mean_logCP10k','mean'),n=('sample_id','nunique'));avg=avg[avg.n.eq(6 if omit=='None' else 5)].sort_values('mean',ascending=False)
   rank=avg['mean'].rank(ascending=False,method='min');loo.append({'omitted_library':omit,'gene':g,'subset':state,'n_celltypes_compared':len(avg),'highest_celltype':avg.index[0] if len(avg) else None,'highest_mean_logCP10k':float(avg['mean'].iloc[0]) if len(avg) else None,'CD14_monocyte_rank':int(rank.get('CD14 monocytes',0)),'CD14_monocyte_mean_logCP10k':float(avg.loc['CD14 monocytes','mean']) if 'CD14 monocytes' in avg.index else None})
 pd.DataFrame(loo).to_csv(R/'定位稳定性_逐文库留一_非供者检验.csv',index=False)
 # Exploratory cutoff grid declared after detecting a near-zero detectable simulated fraction in A3.
 # Every cutoff and every library is retained. These are score thresholds, not validated true-doublet labels.
 grid_rates=[];grid_expr=[];grid_ranks=[]
 schemes={'Automatic':x.predicted_doublet.to_numpy()}
 for cutoff in [.15,.20,.25,.30]:schemes[f'Score >= {cutoff:.2f}']=x.doublet_score.to_numpy()>=cutoff
 for scheme,flag in schemes.items():
  for (s,t),ids in x.groupby(['sample_id','cell_type'],sort=False).groups.items():
   ix=np.asarray(list(ids));keep=ix[~flag[ix]]
   grid_rates.append({'scheme':scheme,'sample_id':s,'cell_type':t,'n_cells':len(ix),'n_predicted':int(flag[ix].sum()),'predicted_fraction':float(flag[ix].mean())})
   for g,j in positions.items():
    z=expr[keep,j];grid_expr.append({'scheme':scheme,'sample_id':s,'cell_type':t,'gene':g,'n_cells_original':len(ix),'n_cells_after_hypothetical_exclusion':len(keep),'mean_logCP10k':float(z.mean()) if len(z) else np.nan,'fraction_detected':float((z>0).mean()) if len(z) else np.nan})
 ge=pd.DataFrame(grid_expr);pd.DataFrame(grid_rates).to_csv(R/'完整阈值网格_13类逐文库预测率.csv',index=False);ge.to_csv(R/'完整阈值网格_NLRP3_IL1B逐文库定位.csv',index=False)
 for (scheme,g),z in ge.groupby(['scheme','gene']):
  for omit in ['None']+LIBS:
   v=z if omit=='None' else z[~z.sample_id.eq(omit)];n_expected=6 if omit=='None' else 5
   valid=v[(v.n_cells_original>=30)&(v.n_cells_after_hypothetical_exclusion>=30)]
   avg=valid.groupby('cell_type').agg(mean=('mean_logCP10k','mean'),n=('sample_id','nunique'));avg=avg[avg.n.eq(n_expected)].sort_values('mean',ascending=False);rank=avg['mean'].rank(ascending=False,method='min')
   grid_ranks.append({'scheme':scheme,'gene':g,'omitted_library':omit,'n_celltypes_compared':len(avg),'highest_celltype':avg.index[0] if len(avg) else None,'CD14_monocyte_rank':int(rank.get('CD14 monocytes',0)),'CD14_monocyte_mean_logCP10k':float(avg.loc['CD14 monocytes','mean']) if 'CD14 monocytes' in avg.index else None})
 pd.DataFrame(grid_ranks).to_csv(R/'完整阈值网格_全部定位排名与逐文库留一.csv',index=False)
 phase=standard.groupby('phase').mean(numeric_only=True).to_dict();qa={'cell_count':len(x),'unique_cell_ids':x.cell_id.nunique(),'input_rows_match_frozen_order':True,'all_six_automatic_thresholds_identified':all(m['threshold_identified'] for m in models),'n_libraries':6,'n_biological_patients':3,'n_celltypes':x.cell_type.nunique(),'total_predicted_flags':int(x.predicted_doublet.sum()),'total_predicted_fraction':float(x.predicted_doublet.mean()),'mixed_type_not_dropped_from_core':True,'core_annotation_SHA256_unchanged':sha(SC/'结果表/全部QC细胞_最终保守注释.csv.gz')==json.loads((OUT/'分析合同与精确参数.json').read_text(encoding='utf8'))['frozen_annotation_SHA256'],'standardized_types':eligible,'phase_library_mean_rates_descriptive_only':phase,'inferential_p_values_computed':False}
 dump(OUT/'数据核验与核心冻结验证.json',qa);print('SUMMARY_READY',json.dumps(qa,ensure_ascii=False),flush=True)
 for name in ['sc_doublet_setup_20261030.py','sc_doublet_fit_20261030.py','sc_doublet_summarize_20261030.py']:shutil.copy2(BASE/name,OUT/'复现代码'/name)
if __name__=='__main__':main()
