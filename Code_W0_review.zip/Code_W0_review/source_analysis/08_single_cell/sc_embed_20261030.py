"""Fixed-parameter PCA, neighbor graph, Leiden and UMAP on every QC cell."""
from pathlib import Path
import os,sys,json,gc,time
BASE=Path(__file__).resolve().parent;OUT=BASE/'论文推进_2026-10-30/单细胞定位';PRE=OUT/'预处理';RES=OUT/'结果表'
sys.path.insert(0,str(OUT/'runtime'))
os.environ['NUMBA_CACHE_DIR']=str(OUT/'cache/numba');os.environ['JOBLIB_TEMP_FOLDER']=str(OUT/'cache/joblib')
os.environ['OMP_NUM_THREADS']='2';os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['MKL_NUM_THREADS']='2';os.environ['NUMBA_NUM_THREADS']='2'
import numpy as np,pandas as pd,scanpy as sc
from threadpoolctl import threadpool_limits
sc.settings.n_jobs=2;sc.settings.verbosity=2
def main():
    t=time.time()
    import anndata as an
    if '--from-pca' in sys.argv:
        obs=pd.read_csv(PRE/'全部QC细胞_元数据.csv.gz');obs.index=obs.cell_id;pc=pd.read_csv(PRE/'全部QC细胞_PCA50.csv.gz',index_col=0);assert np.array_equal(obs.index,pc.index)
        small=an.AnnData(obs=obs);small.obsm['X_pca']=pc.to_numpy(dtype=np.float32);print('PCA_CHECKPOINT_LOADED',small.n_obs,flush=True)
    else:
        ad=sc.read_h5ad(PRE/'HVG_未整合_logCP10k.h5ad');print('LOADED',ad.shape,flush=True)
        # Unit variance, no dense centering. Sparse ARPACK PCA performs implicit centering.
        sc.pp.scale(ad,zero_center=False,max_value=10)
        with threadpool_limits(limits=2):sc.pp.pca(ad,n_comps=50,zero_center=True,svd_solver='arpack',random_state=20261030)
        pd.DataFrame(ad.obsm['X_pca'],index=ad.obs_names,columns=[f'PC{i+1}' for i in range(50)]).to_csv(PRE/'全部QC细胞_PCA50.csv.gz',compression='gzip')
        pd.DataFrame({'PC':np.arange(1,51),'variance_ratio':ad.uns['pca']['variance_ratio']}).to_csv(RES/'PCA解释方差.csv',index=False)
        print('PCA_COMPLETE','seconds',round(time.time()-t,1),flush=True)
        small=an.AnnData(obs=ad.obs.copy());small.obsm['X_pca']=ad.obsm['X_pca'].copy();small.uns['pca']=ad.uns['pca'];del ad;gc.collect()
    from sklearn.neighbors import KNeighborsTransformer
    knn=KNeighborsTransformer(n_neighbors=20,algorithm='brute',metric='euclidean',mode='distance',n_jobs=2)
    with threadpool_limits(limits=2):sc.pp.neighbors(small,n_neighbors=20,n_pcs=30,use_rep='X_pca',random_state=20261030,method='umap',transformer=knn)
    print('NEIGHBORS_COMPLETE','seconds',round(time.time()-t,1),flush=True)
    sc.tl.leiden(small,resolution=.6,flavor='igraph',n_iterations=2,directed=False,random_state=20261030,key_added='leiden_0_6')
    small.write_h5ad(PRE/'全部QC细胞_近邻与Leiden检查点.h5ad',compression='gzip')
    print('LEIDEN_COMPLETE',small.obs.leiden_0_6.value_counts().to_dict(),flush=True)
    sc.tl.umap(small,min_dist=.35,spread=1.0,random_state=20261030,maxiter=300)
    small.obs['UMAP1']=small.obsm['X_umap'][:,0];small.obs['UMAP2']=small.obsm['X_umap'][:,1]
    small.obs.to_csv(RES/'全部QC细胞_聚类与UMAP.csv.gz',index=False,compression='gzip')
    small.write_h5ad(PRE/'全部QC细胞_图与嵌入.h5ad',compression='gzip')
    # Cluster expression uses original log-normalized marker expression, not scaled PCA values.
    expr=np.load(PRE/'全部QC细胞_预定义基因_logCP10k.npy',mmap_mode='r');genes=pd.read_csv(RES/'预定义定位基因.csv');clusters=small.obs.leiden_0_6.astype(str).to_numpy()
    result=[]
    for cl in sorted(np.unique(clusters),key=int):
        mask=clusters==cl;means=np.mean(expr[mask],axis=0);detect=np.mean(expr[mask]>0,axis=0)
        for j,g in genes.iterrows():result.append({'cluster':cl,'n_cells':int(mask.sum()),'gene_id':g.gene_id,'gene_symbol':g.source_symbol,'mean_logCP10k':float(means[j]),'fraction_detected':float(detect[j])})
    pd.DataFrame(result).to_csv(RES/'聚类_预定义marker与靶点表达.csv',index=False)
    pd.crosstab(small.obs.leiden_0_6,small.obs.sample_id).to_csv(RES/'聚类_文库构成.csv')
    cont=json.loads((OUT/'预定义分析与绘图合同.json').read_text(encoding='utf8'))
    df=pd.DataFrame(result);wide=df.pivot_table(index='cluster',columns='gene_symbol',values='mean_logCP10k',aggfunc='sum')
    z=(wide-wide.mean(axis=0))/wide.std(axis=0).replace(0,1)
    scores=pd.DataFrame(index=wide.index)
    for k,gs in cont['marker_groups'].items():scores[k]=z.reindex(columns=gs).mean(axis=1)
    scores['highest_marker_group']=scores.idxmax(axis=1);scores['n_cells']=small.obs.leiden_0_6.value_counts().reindex(scores.index).values
    scores.to_csv(RES/'聚类_marker组描述性标准分.csv')
    print(scores.to_string(),flush=True)
    print('EMBEDDING_COMPLETE','cells',small.n_obs,'clusters',len(scores),'seconds',round(time.time()-t,1),flush=True)
if __name__=='__main__':main()
