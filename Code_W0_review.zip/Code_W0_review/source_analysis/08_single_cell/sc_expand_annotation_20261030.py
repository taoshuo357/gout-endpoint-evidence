"""Post-clustering canonical annotation refinement, explicitly documented."""
from pathlib import Path
import sys,json
BASE=Path(__file__).resolve().parent;OUT=BASE/'论文推进_2026-10-30/单细胞定位';PRE=OUT/'预处理';RES=OUT/'结果表';sys.path.insert(0,str(OUT/'runtime'))
import numpy as np,pandas as pd,anndata as an
extra=['FCGR3B','CSF3R','CEACAM8','HDC','MS4A2','CLC','SPINK2','SOX4']
a=an.read_h5ad(PRE/'HVG_未整合_logCP10k.h5ad');g=pd.read_csv(RES/'预定义定位基因.csv');old=np.load(PRE/'全部QC细胞_预定义基因_logCP10k.npy',mmap_mode='r')
ix=a.var.source_symbol.isin(extra).to_numpy();found=set(a.var.loc[ix,'source_symbol']);assert set(extra)<=found
genes=pd.concat([g,a.var.loc[ix,['gene_id','source_symbol','feature_type']].reset_index(drop=True)],ignore_index=True);new=np.hstack([old,a.X[:,ix].toarray()]);np.save(PRE/'全部QC细胞_扩展注释基因_logCP10k.npy',new);genes.to_csv(RES/'完整定位与扩展注释基因.csv',index=False)
graph=an.read_h5ad(PRE/'全部QC细胞_近邻与Leiden检查点.h5ad');rows=[]
for cl,ids in graph.obs.groupby('leiden_0_6',observed=True).indices.items():
 means=new[ids].mean(axis=0);d={'cluster':str(cl),'n_cells':len(ids)};d.update({v:round(float(means[j]),3) for j,v in enumerate(genes.source_symbol)});rows.append(d)
df=pd.DataFrame(rows).sort_values('cluster',key=lambda s:s.astype(int));df.to_csv(RES/'聚类_完整注释marker快速审阅.csv',index=False)
print(df[['cluster','n_cells',*extra,'MZB1','JCHAIN','LILRA4','CLEC4C','PYCARD','IL1B','NLRP3']].to_string(index=False))
(OUT/'注释marker扩展说明.json').write_text(json.dumps({'reason':'Unexpected granulocyte/basophil-like HVG profiles and a weakly resolved rare cluster prompted canonical-marker refinement after clustering.','added_markers':extra,'source':'Unscaled full-cell logCP10k HVG checkpoint; no altered normalization or cell exclusion.','exploratory_annotation_refinement':True,'no_disease_comparison_test':True,'no_reference_label_transfer_or_doublet_classification_claim':True},ensure_ascii=False,indent=2),encoding='utf8')
