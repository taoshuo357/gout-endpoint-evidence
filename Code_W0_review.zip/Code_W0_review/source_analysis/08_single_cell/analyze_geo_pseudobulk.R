# Count analysis only: no R graphics devices. Unknown pairing explicitly enumerated.
library(edgeR)
out <- 'GEO表达核验_2026-10-29/独立队列_GSE211783';pre<-file.path(out,'预处理');res<-file.path(out,'表达结果');dir.create(res,showWarnings=FALSE)
rd<-function(p,sep=',')read.table(p,header=TRUE,sep=sep,quote='"',comment.char='',check.names=FALSE,fileEncoding='UTF-8-BOM',stringsAsFactors=FALSE)
wr<-function(x,n)write.csv(x,file.path(res,n),row.names=FALSE,fileEncoding='UTF-8',na='')
counts<-rd(file.path(pre,'6文库_QC后供者汇总计数.tsv'),'\t');rownames(counts)<-counts$gene_id;counts$gene_id<-NULL;counts<-as.matrix(counts[,c('A1','A2','A3','B1','B2','B3')])
phase<-factor(c(rep('Acute',3),rep('Remission',3)),levels=c('Remission','Acute'))
y0<-DGEList(counts=counts,group=phase)
keep<-filterByExpr(y0,group=phase,min.count=10,min.total.count=15)
y<-calcNormFactors(y0[keep,,keep.lib.sizes=FALSE],method='TMM')
perm<-rbind(c(1,2,3),c(1,3,2),c(2,1,3),c(2,3,1),c(3,1,2),c(3,2,1))
stats<-list();models<-list();pathstats<-list()
features<-rd(file.path(pre,'人类基因特征.csv'))
gmap<-rd('下一步_PPI与富集_2026-10-29/富集分析/背景与映射/官方gConvert_符号到ENSG_逐基因审计.csv')
good<-!is.na(gmap$ensembl_gene_id) & nzchar(gmap$ensembl_gene_id) & gmap$official_name_exactly_matches_input=='true'
gmap<-gmap[good,]; gmap<-gmap[!duplicated(gmap$ensembl_gene_id) & !duplicated(gmap$ensembl_gene_id,fromLast=TRUE),]
symbols<-gmap$input_gene_symbol[match(rownames(y),gmap$ensembl_gene_id)]
symbols[is.na(symbols)]<-features$source_symbol[match(rownames(y)[is.na(symbols)],features$gene_id)]
members<-rd('GEO表达核验_2026-10-29/预处理/KEGG九通路_完整成员.csv')
indices<-lapply(split(members$gene_symbol,members$term_id),function(s)which(symbols %in% s))
for(i in seq_len(nrow(perm))) {
 donor<-factor(c(1,2,3,perm[i,]));design<-model.matrix(~donor+phase)
 yy<-estimateDisp(y,design=design,robust=TRUE)
 fit<-glmQLFit(yy,design=design,robust=TRUE)
 test<-glmQLFTest(fit,coef=ncol(design))
 tt<-topTags(test,n=Inf,sort.by='none')$table;tt$gene_id<-rownames(tt);tt$pairing_id<-paste(perm[i,],collapse='')
 tt$pairing_description<-paste(paste0('B',1:3,'-A',perm[i,]),collapse=';')
 tt<-tt[,c('gene_id','pairing_id','pairing_description','logFC','logCPM','F','PValue','FDR')]
 stats[[i]]<-tt;models[[i]]<-list(design=design,fit=fit,test=test)
 cc<-camera(yy,index=indices,design=design,contrast=ncol(design),inter.gene.cor=.01,sort=FALSE)
 cc$term_id<-rownames(cc);cc$pairing_id<-paste(perm[i,],collapse='');pathstats[[i]]<-cc
}
long<-do.call(rbind,stats);wr(long,'六种可能配对_全基因QL结果.csv')
p<-sapply(stats,function(x)x$PValue);fc<-sapply(stats,function(x)x$logFC)
summ<-data.frame(gene_id=rownames(y),numbering_assumed_logFC=fc[,1],numbering_assumed_P=p[,1],numbering_assumed_q=stats[[1]]$FDR,worst_pairing_P=apply(p,1,max),best_pairing_P=apply(p,1,min),logFC_min=apply(fc,1,min),logFC_max=apply(fc,1,max),mean_logFC=rowMeans(fc),direction_same_all6=apply(fc,1,function(x)all(x>0)||all(x<0)),min_abs_logFC=apply(abs(fc),1,min))
summ$worst_pairing_q_all_genes<-p.adjust(summ$worst_pairing_P,'BH')
summ$conservative_DEG<-summ$worst_pairing_q_all_genes<.05 & summ$direction_same_all6 & summ$min_abs_logFC>=1
wr(summ,'配对身份未确证_保守全基因汇总.csv')
ps<-do.call(rbind,pathstats);wr(ps,'六种可能配对_通路CAMERA.csv')
ids<-names(indices);pt<-data.frame(term_id=ids,worst_pairing_P=vapply(ids,function(id)max(ps$PValue[ps$term_id==id]),numeric(1)),direction_same_all6=vapply(ids,function(id)length(unique(ps$Direction[ps$term_id==id]))==1,logical(1)),direction=vapply(ids,function(id)paste(unique(ps$Direction[ps$term_id==id]),collapse=';'),character(1)),measured_genes=lengths(indices))
pt$primary5<-members$primary5[match(pt$term_id,members$term_id)]
pt$q_nine<-p.adjust(pt$worst_pairing_P,'BH');pt$q_five<-NA_real_;pt$q_five[pt$primary5==1]<-p.adjust(pt$worst_pairing_P[pt$primary5==1],'BH')
wr(pt,'配对身份未确证_通路保守汇总.csv')
wr(data.frame(gene_id=rownames(y0),tested=keep,total_count=rowSums(y0$counts)),'全部特征_计数过滤状态.csv')
lcpm<-cpm(y,log=TRUE,prior.count=2);wr(data.frame(gene_id=rownames(lcpm),lcpm,check.names=FALSE),'供者汇总_TMM_logCPM.csv')
wr(data.frame(sample_id=rownames(y$samples),y$samples,check.names=FALSE),'文库TMM因子.csv')
saveRDS(list(y=y,filter=keep,phase=phase,pairings=perm,models=models),file.path(res,'配对敏感性_edgeR模型.rds'))
writeLines(c(capture.output(sessionInfo()),paste('Tested genes',nrow(y)),'Three patients, two phases, no healthy controls. Donor pairing identity not publicly verified.','All6 possible pairing mappings fit with donor+phase edgeR QL, robust dispersion.','ConservativeP=max of6 nominal geneP, then BH across all assayed genes; this does not verify pairing.','Primary conservative decision also requires same direction and abslogFC>=1 under all6 mappings.','Per-sample cellQC and TMM gene filtering frozen before outcomes; cells not replicates.','COX2 inhibitors/urate treatment and bulkcellcomposition confound phase association.'),file.path(res,'edgeR方法与版本.txt'))
cat('PSEUDOBULK FIT READY',nrow(y),'genes',sum(summ$conservative_DEG),'conservativeDEG','\n')
