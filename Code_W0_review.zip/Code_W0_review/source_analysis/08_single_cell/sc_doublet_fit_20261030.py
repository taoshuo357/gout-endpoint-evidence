"""Independent, resumable Scrublet sensitivity on each fixed QC raw-count library."""
from pathlib import Path
import os,sys,json,time,gc,hashlib,warnings,traceback
BASE=Path(__file__).resolve().parent;SC=BASE/'论文推进_2026-10-30/单细胞定位';OUT=BASE/'论文推进_2026-10-30/单细胞稳健性_第二轮'
sys.path.insert(0,str(SC/'runtime'));sys.path.insert(0,str(OUT/'runtime'));sys.path.append(str(BASE/'runtime/ppi_analysis_libraries'))
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS']:os.environ[k]='2'
import numpy as np,pandas as pd,scanpy as sc,anndata as ad,skimage,scipy,sklearn,psutil
from scipy import sparse
from threadpoolctl import threadpool_limits
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str)+'\n',encoding='utf8')
def main():
 obs=pd.read_csv(SC/'结果表/全部QC细胞_最终保守注释.csv.gz')
 features=pd.read_csv(BASE/'GEO表达核验_2026-10-29/独立队列_GSE211783/预处理/人类基因特征.csv')
 parameters=dict(sim_doublet_ratio=2.,expected_doublet_rate=.05,stdev_doublet_rate=.02,synthetic_doublet_umi_subsampling=1.,knn_dist_metric='euclidean',normalize_variance=True,log_transform=False,mean_center=False,n_prin_comps=30,use_approx_neighbors=False,get_doublet_neighbor_parents=False,n_neighbors=None,threshold=None,random_state=20261030)
 contract={'purpose':'Independent doublet prediction sensitivity; no reannotation or core-data removal.','input':'Unnormalized integer counts from the fixed QC population, run independently per 10x capture. Not the complete unfiltered droplet matrix.','parameters':parameters,'n_biological_patients':3,'n_libraries':6,'donor_A_to_B_crosswalk':'unknown; no pairing inferred','memory_aware_deviation':'mean_center=False uses variance-normalized sparse TruncatedSVD rather than centered PCA.','automatic_threshold':'skimage.filters.threshold_minimum on simulated scores; threshold failure yields unclassified status, not a singlet call.','versions':{'scanpy':sc.__version__,'anndata':ad.__version__,'numpy':np.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__,'skimage':skimage.__version__},'frozen_annotation_SHA256':sha(SC/'结果表/全部QC细胞_最终保守注释.csv.gz'),'official_documentation':'https://scanpy.readthedocs.io/en/stable/api/generated/scanpy.pp.scrublet.html'}
 dump(OUT/'分析合同与精确参数.json',contract)
 requested=sys.argv[1:] or ['A1','A2','A3','B1','B2','B3']
 sc.settings.verbosity=2;sc.settings.n_jobs=2
 for sample in requested:
  result=OUT/'结果表'/(sample+'_Scrublet细胞分数.csv.gz');metaout=OUT/'模型日志'/(sample+'_模型与输入.json')
  if result.exists() and metaout.exists():print('ALREADY_COMPLETE',sample,flush=True);continue
  start=time.time();p=SC/'预处理'/(sample+'_QC_counts.npz');x=sparse.load_npz(p);sub=obs[obs.sample_id.eq(sample)].copy()
  assert x.shape==(len(sub),len(features)) and x.dtype.kind in 'iu' and x.data.min()>=0 and sub.cell_id.is_unique
  assert np.array_equal(np.asarray(x.sum(axis=1)).ravel(),sub.UMI.to_numpy())
  a=ad.AnnData(x,obs=pd.DataFrame(index=sub.cell_id.astype(str)),var=pd.DataFrame(index=features.gene_id.astype(str)));del x;gc.collect()
  print('START',sample,a.shape,'memory_available',psutil.virtual_memory().available,flush=True)
  with warnings.catch_warnings(record=True) as ws,threadpool_limits(limits=2):
   warnings.simplefilter('always');sc.pp.scrublet(a,**parameters,verbose=True)
  u=a.uns['scrublet'];threshold=u.get('threshold');valid=threshold is not None and np.isfinite(threshold)
  out=sub[['cell_id','sample_id','phase','cell_type','broad_lineage','UMI','genes','mito_fraction']].copy()
  out['doublet_score']=a.obs.doublet_score.to_numpy();out['automatic_threshold']=threshold if valid else np.nan;out['classification_available']=valid
  out['predicted_doublet']=a.obs.predicted_doublet.to_numpy() if valid else pd.NA
  assert np.isfinite(out.doublet_score).all() and len(out)==len(sub)
  out.to_csv(result,index=False,compression='gzip')
  sim=np.asarray(u['doublet_scores_sim']);pd.DataFrame({'simulated_doublet_score':sim}).to_csv(OUT/'源数据'/(sample+'_模拟双细胞分数.csv.gz'),index=False,compression='gzip')
  meta={'sample_id':sample,'phase':'Acute' if sample.startswith('A') else 'Remission','raw_count_path':str(p),'raw_count_SHA256':sha(p),'n_cells':len(out),'n_features_input':len(features),'input_integer_counts':True,'input_row_sums_equal_frozen_UMI':True,'n_simulated':len(sim),'threshold_identified':bool(valid),'automatic_threshold':float(threshold) if valid else None,'n_predicted_doublet':int(out.predicted_doublet.sum()) if valid else None,'predicted_fraction':float(out.predicted_doublet.mean()) if valid else None,'score_min':float(out.doublet_score.min()),'score_max':float(out.doublet_score.max()),'elapsed_seconds':round(time.time()-start,3),'scrublet_recorded_parameters':u['parameters'],'warnings':[str(w.message) for w in ws],'available_memory_after':psutil.virtual_memory().available}
  dump(metaout,meta);print('COMPLETE',json.dumps(meta,ensure_ascii=False,default=str),flush=True);del a,out,sub,sim;gc.collect()
if __name__=='__main__':main()
