"""Explicit conservative marker-based labels, frozen before celltype comparisons."""
from pathlib import Path
import sys,json
BASE=Path(__file__).resolve().parent;OUT=BASE/'论文推进_2026-10-30/单细胞定位';RES=OUT/'结果表';sys.path.insert(0,str(OUT/'runtime'))
import pandas as pd
groups=[
 ('IL7R+ T',[4,5,6,12,13],'Lymphoid','high','#789CB8','CD3D/CD3E/TRAC with IL7R; no definitive CD4/naive/memory call.'),
 ('Cytotoxic T',[7,15],'Lymphoid','high','#436F93','CD3D/TRAC plus NKG7/CCL5 and CD8A; cytotoxic T-like, no terminal-state claim.'),
 ('Cycling T/NK',[18],'Lymphoid','moderate','#A8BCCF','MKI67/TOP2A with T and cytotoxic markers; rare cycling lymphoid class.'),
 ('NK',[2,16,19],'Lymphoid','high','#9485AC','GNLY/NKG7/KLRD1 with weak CD3D/TRAC; no NK subtype claim.'),
 ('B',[10],'Lymphoid','high','#C1A086','MS4A1/CD79A/CD79B and CD74.'),
 ('Plasma',[17],'Lymphoid','high','#D5BDA8','JCHAIN/MZB1/immunoglobulin genes with low MS4A1.'),
 ('CD14 monocytes',[1,11,20],'Myeloid','high','#689C88','LYZ/FCN1/CD14/CTSS/S100A8/S100A9. Minor cross-lineage signal retained without doublet exclusion.'),
 ('CD16 monocytes',[0],'Myeloid','high','#A2C2AE','LST1/AIF1/FCGR3A/MS4A7/CTSS; FCGR3A alone not used to distinguish NK.'),
 ('Neutrophil-like',[8,9],'Myeloid','high','#B4B578','FCGR3B/CSF3R/CXCL8 or DEFA3/LTF/CEACAM8/MMP8 plus S100A8/A9; no maturation subtype claim.'),
 ('DC-like',[14],'Myeloid','moderate','#C5B36B','HLA-DRA/CD74/CST3/FCER1A/CLEC10A/CD1C with some CLEC4C/LILRA4; no forced cDC/pDC subtype.'),
 ('Basophil-like',[22],'Myeloid','moderate','#C5A0AE','CLC/HDC/MS4A2/FCER1A/GATA2; rare type, no lineage-purity claim.'),
 ('Platelet mixed',[3],'Ambiguous','uncertain','#B1ABB3','PPBP/PF4 with T-cell transcripts; platelet-associated mixed signature, not a verified doublet label.'),
 ('Unresolved',[21],'Ambiguous','uncertain','#C6C9CD','Rare SOX4/SPINK2-rich cluster without a confident mature lineage assignment; retained in all-cell summaries.')]
rows=[]
for order,(typ,clusters,lineage,confidence,color,note) in enumerate(groups):
 for cl in clusters:rows.append({'cluster':str(cl),'cell_type':typ,'broad_lineage':lineage,'annotation_confidence':confidence,'annotation_rationale':note,'plot_color':color,'plot_order':order})
df=pd.DataFrame(rows);assert len(df)==23 and df.cluster.nunique()==23;df.to_csv(RES/'保守细胞类型注释.csv',index=False)
review=pd.read_csv(RES/'聚类_marker快速审阅.csv',dtype={'cluster':str});counts=review[['cluster','n_cells']].merge(df,on='cluster',validate='one_to_one');types=counts.groupby(['cell_type','broad_lineage','annotation_confidence','plot_order'],as_index=False).n_cells.sum().sort_values('plot_order');types.to_csv(RES/'保守细胞类型_总细胞数.csv',index=False);assert int(types.n_cells.sum())==53940
print(types[['cell_type','n_cells','annotation_confidence']].to_string(index=False))
(OUT/'注释判断记录.json').write_text(json.dumps({'manual_marker_review':True,'number_of_Leiden_clusters':23,'conservative_cell_groups':13,'all_fixed_QC_cells_retained':53940,'no_CD4naive_or_reference_transfer_claim':True,'no_validated_doublet_removal':True,'no_trajectory_or_lineage_differentiation_inference':True,'neutrophils_and_basophils_in_submitted_PBMC_capture_are_retained':True,'frozen_before_celltype_phase_statistics':True},ensure_ascii=False,indent=2),encoding='utf8')
