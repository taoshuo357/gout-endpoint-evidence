# Count-only R statistics. Figures use the established Python backend.
suppressPackageStartupMessages(library(edgeR))
out <- '论文推进_2026-10-30/单细胞定位'
res <- file.path(out,'结果表','细胞类型pseudobulk');dir.create(res,recursive=TRUE,showWarnings=FALSE)
rd<-function(p,sep=',')read.table(p,header=TRUE,sep=sep,quote='"',comment.char='',check.names=FALSE,fileEncoding='UTF-8-BOM',stringsAsFactors=FALSE)
wr<-function(x,n)write.csv(x,file.path(res,n),row.names=FALSE,fileEncoding='UTF-8',na='')
manifest<-rd(file.path(out,'结果表','细胞类型pseudobulk输入清单.csv'))
manifest$eligible_all6_ge30_cells<-tolower(as.character(manifest$eligible_all6_ge30_cells))=='true'
members<-rd('GEO表达核验_2026-10-29/预处理/KEGG九通路_完整成员.csv')
features<-rd('GEO表达核验_2026-10-29/独立队列_GSE211783/预处理/人类基因特征.csv')
perm<-rbind(c(1,2,3),c(1,3,2),c(2,1,3),c(2,3,1),c(3,1,2),c(3,2,1))
phase<-factor(c(rep('Acute',3),rep('Remission',3)),levels=c('Remission','Acute'))
allgenes<-list();allpaths<-list();meta<-list()
for(k in seq_len(nrow(manifest))) {
  typ<-manifest$cell_type[k]
  if(!manifest$eligible_all6_ge30_cells[k] || grepl('mixed|Unresolved',typ))next
  dd<-rd(manifest$counts_path[k],'\t');rownames(dd)<-dd$gene_id;dd$gene_id<-NULL;counts<-as.matrix(dd[,c('A1','A2','A3','B1','B2','B3')])
  y0<-DGEList(counts=counts,group=phase);keep<-filterByExpr(y0,group=phase,min.count=10,min.total.count=15)
  y<-calcNormFactors(y0[keep,,keep.lib.sizes=FALSE],method='TMM')
  symbols<-features$source_symbol[match(rownames(y),features$gene_id)]
  indices<-lapply(split(members$gene_symbol,members$term_id),function(s)which(symbols %in% s))
  stats<-list();ps<-list()
  for(i in seq_len(nrow(perm))) {
    donor<-factor(c(1,2,3,perm[i,]));design<-model.matrix(~donor+phase)
    yy<-estimateDisp(y,design=design,robust=TRUE);fit<-glmQLFit(yy,design=design,robust=TRUE);test<-glmQLFTest(fit,coef=ncol(design))
    tt<-topTags(test,n=Inf,sort.by='none')$table;tt$gene_id<-rownames(tt);tt$gene_symbol<-symbols;tt$cell_type<-typ;tt$pairing_id<-paste(perm[i,],collapse='');stats[[i]]<-tt
    cc<-camera(yy,index=indices,design=design,contrast=ncol(design),inter.gene.cor=.01,sort=FALSE)
    cc$term_id<-rownames(cc);cc$pairing_id<-paste(perm[i,],collapse='');cc$cell_type<-typ;ps[[i]]<-cc
  }
  long<-do.call(rbind,stats);write.csv(long,gzfile(file.path(res,paste0(manifest$file_stem[k],'_six_pairings_gene_tests.csv.gz'))),row.names=FALSE)
  p<-sapply(stats,function(x)x$PValue);fc<-sapply(stats,function(x)x$logFC)
  ss<-data.frame(cell_type=typ,gene_id=rownames(y),gene_symbol=symbols,tested_genes=nrow(y),worst_pairing_P=apply(p,1,max),best_pairing_P=apply(p,1,min),mean_logFC=rowMeans(fc),logFC_min=apply(fc,1,min),logFC_max=apply(fc,1,max),direction_same_all6=apply(fc,1,function(x)all(x>0)||all(x<0)),min_abs_logFC=apply(abs(fc),1,min))
  ss$q_within_celltype<-p.adjust(ss$worst_pairing_P,'BH');allgenes[[length(allgenes)+1]]<-ss
  paths<-do.call(rbind,ps);wr(paths,paste0(manifest$file_stem[k],'_six_pairings_CAMERA.csv'))
  ids<-names(indices);pt<-data.frame(cell_type=typ,term_id=ids,worst_pairing_P=vapply(ids,function(id)max(paths$PValue[paths$term_id==id]),numeric(1)),direction_same_all6=vapply(ids,function(id)length(unique(paths$Direction[paths$term_id==id]))==1,logical(1)),direction=vapply(ids,function(id)paste(unique(paths$Direction[paths$term_id==id]),collapse=';'),character(1)),measured_genes=lengths(indices))
  pt$primary5<-members$primary5[match(pt$term_id,members$term_id)];pt$q_nine_within_celltype<-p.adjust(pt$worst_pairing_P,'BH');allpaths[[length(allpaths)+1]]<-pt
  lcpm<-cpm(y,log=TRUE,prior.count=2);wr(data.frame(gene_id=rownames(lcpm),gene_symbol=symbols,lcpm,check.names=FALSE),paste0(manifest$file_stem[k],'_TMM_logCPM.csv'))
  meta[[length(meta)+1]]<-data.frame(cell_type=typ,tested_genes=nrow(y),minimum_library_cells=manifest$minimum_library_cells[k],raw_count_UMI=sum(counts))
  cat('CELLTYPE_QL_READY',typ,nrow(y),'genes\n');gc()
}
if(length(allgenes)) {
  ss<-do.call(rbind,allgenes);ss$q_all_tested_gene_celltype_pairs<-p.adjust(ss$worst_pairing_P,'BH');ss$conservative_DEG<-ss$q_all_tested_gene_celltype_pairs<.05 & ss$direction_same_all6 & ss$min_abs_logFC>=1
  wr(ss,'all_celltypes_conservative_gene_results.csv')
  paths<-do.call(rbind,allpaths);paths$q_nine_across_celltypes<-p.adjust(paths$worst_pairing_P,'BH');paths$q_primary5_across_celltypes<-NA_real_;ix<-paths$primary5==1;paths$q_primary5_across_celltypes[ix]<-p.adjust(paths$worst_pairing_P[ix],'BH')
  wr(paths,'all_celltypes_conservative_CAMERA.csv');wr(do.call(rbind,meta),'celltype_QL_coverage.csv')
  cat('GLOBAL_CONSERVATIVE_DEG',sum(ss$conservative_DEG),'gene_type_pairs\n')
}
writeLines(c(capture.output(sessionInfo()),'Exploratory, conservatively annotated broad cell types; eligible when all six libraries have >=30 cells, excluding explicitly mixed/Unresolved groups from phase inference. These groups remain in all descriptive plots.','Same three donors, two phases; six possible matching permutations. Unknown pairing is never replaced by cell-level pseudoreplication.','Cell-type raw integer UMI sums analyzed by edgeR TMM; filterByExpr; donor+phase robust QL.','Worst nominal P across all six donor-pairing maps followed by BH across every tested gene-celltype pair.','Nine CAMERA pathways: worst P across six maps, then BH across all pathway-celltype tests; a separate pre-existing primary-five family is reported.','Cell annotation/selection was not specified before the original bulk outcomes, so celltype analyses are exploratory.','No formula treatment; ambient RNA/doublet/batch and medication limitations persist.'),file.path(res,'method_and_session.txt'))
