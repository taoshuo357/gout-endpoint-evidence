"""Annotated cell-level summaries, library-level pseudobulk, and rank signatures."""
from pathlib import Path
import os,sys,json,gc,time
BASE=Path(__file__).resolve().parent;OUT=BASE/'论文推进_2026-10-30/单细胞定位';PRE=OUT/'预处理';RES=OUT/'结果表'
sys.path.insert(0,str(OUT/'runtime'))
os.environ['OMP_NUM_THREADS']='2';os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['MKL_NUM_THREADS']='2'
import numpy as np,pandas as pd
import anndata as an,pyucell as uc,importlib.metadata
from scipy import sparse
from scipy.stats import rankdata
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def main():
    obs=pd.read_csv(RES/'全部QC细胞_聚类与UMAP.csv.gz',dtype={'leiden_0_6':str})
    ann=pd.read_csv(RES/'保守细胞类型注释.csv',dtype={'cluster':str})
    assert obs.leiden_0_6.isin(ann.cluster).all()
    obs=obs.merge(ann,left_on='leiden_0_6',right_on='cluster',how='left',validate='many_to_one',sort=False)
    old=pd.read_csv(PRE/'全部QC细胞_元数据.csv.gz');assert np.array_equal(obs.cell_id,old.cell_id)
    obs.to_csv(RES/'全部QC细胞_最终保守注释.csv.gz',index=False,compression='gzip')
    expr=np.load(PRE/'全部QC细胞_扩展注释基因_logCP10k.npy',mmap_mode='r');gen=pd.read_csv(RES/'完整定位与扩展注释基因.csv')
    summary=[]
    for (sample,typ),ids in obs.groupby(['sample_id','cell_type'],sort=True).groups.items():
        ids=np.array(list(ids));x=expr[ids];mean=x.mean(axis=0);detect=(x>0).mean(axis=0)
        for j,g in gen.iterrows():summary.append({'sample_id':sample,'phase':'Acute' if sample.startswith('A') else 'Remission','cell_type':typ,'n_cells':len(ids),'gene_id':g.gene_id,'gene_symbol':g.source_symbol,'mean_logCP10k':float(mean[j]),'fraction_detected':float(detect[j])})
    pd.DataFrame(summary).to_csv(RES/'细胞类型_逐文库marker与12靶点表达.csv',index=False)
    # Full pooled summaries are descriptive, while group summaries weight libraries equally.
    pooled=[]
    for typ,ids in obs.groupby('cell_type',sort=True).groups.items():
        ids=np.array(list(ids));x=expr[ids];mean=x.mean(axis=0);detect=(x>0).mean(axis=0)
        for j,g in gen.iterrows():pooled.append({'cell_type':typ,'n_cells':len(ids),'gene_id':g.gene_id,'gene_symbol':g.source_symbol,'mean_logCP10k':float(mean[j]),'fraction_detected':float(detect[j])})
    pd.DataFrame(pooled).to_csv(RES/'细胞类型_合并细胞marker与12靶点表达.csv',index=False)
    props=pd.crosstab(obs.sample_id,obs.cell_type).reindex(['A1','A2','A3','B1','B2','B3']).stack().reset_index(name='n_cells');props['library_cells']=props.sample_id.map(obs.sample_id.value_counts());props['fraction']=props.n_cells/props.library_cells;props['phase']=np.where(props.sample_id.str.startswith('A'),'Acute','Remission');props.to_csv(RES/'细胞类型_逐文库构成比例.csv',index=False)
    feat=pd.read_csv(BASE/'GEO表达核验_2026-10-29/独立队列_GSE211783/预处理/人类基因特征.csv')
    members=pd.read_csv(BASE/'GEO表达核验_2026-10-29/预处理/KEGG九通路_完整成员.csv')
    signatures={k:set(v.gene_symbol) for k,v in members.groupby('term_id')}
    contract=json.loads((OUT/'预定义分析与绘图合同.json').read_text(encoding='utf8'))
    for k,gs in contract['modules'].items():signatures[k]=set(gs)
    names=list(signatures);mem=np.zeros((len(feat),len(names)),dtype=np.float32);coverage=[]
    for j,k in enumerate(names):
        # Gene symbols with more than one feature ID are all retained and reported.
        ix=feat.source_symbol.isin(signatures[k]);mem[ix,j]=1
        coverage.append({'signature':k,'input_unique_symbols':len(signatures[k]),'matched_unique_symbols':feat.loc[ix,'source_symbol'].nunique(),'matched_feature_IDs':int(ix.sum()),'missing_symbols':';'.join(sorted(signatures[k]-set(feat.loc[ix,'source_symbol'])))})
    pd.DataFrame(coverage).to_csv(RES/'秩评分_完整基因集覆盖.csv',index=False)
    m=mem.sum(axis=0);assert (m>0).all() and (m<1500).all();minimum=m*(m+1)/2;den=m*1500-minimum
    signatures_by_id={k:feat.loc[mem[:,j]>0,'gene_id'].tolist() for j,k in enumerate(names)}
    # Explicitly verify sparse nonzero rank evaluation against a dense reference.
    # The formula follows the current primary UCell implementation; no claim of package execution.
    rng=np.random.default_rng(20261030);toy=rng.integers(0,5,(17,1));toy[2:11]=0;r=rankdata(-toy[:,0],method='average');clip=np.minimum(r,12)
    sig=np.array([1,2,7,10,11]);dense=1-(clip[sig].sum()-len(sig)*(len(sig)+1)/2)/(len(sig)*12-len(sig)*(len(sig)+1)/2)
    nz=np.flatnonzero(toy[:,0]);rr=np.minimum(rankdata(-toy[nz,0],method='average'),12);rankmap=np.full(17,12.);rankmap[nz]=rr;spscore=1-(rankmap[sig].sum()-len(sig)*(len(sig)+1)/2)/(len(sig)*12-len(sig)*(len(sig)+1)/2)
    assert abs(dense-spscore)<1e-12
    PB=RES/'细胞类型pseudobulk输入';PB.mkdir(exist_ok=True)
    types=sorted(obs.cell_type.unique());vectors={typ:{} for typ in types};uscores=np.zeros((len(obs),len(names)),np.float32);detectfrac=np.zeros_like(uscores);package_errors=[]
    existing_pb=pd.read_csv(BASE/'GEO表达核验_2026-10-29/独立队列_GSE211783/预处理/6文库_QC后供者汇总计数.tsv',sep='\t')
    assert np.array_equal(existing_pb.gene_id,feat.gene_id)
    for sample in ['A1','A2','A3','B1','B2','B3']:
        t=time.time();mat=sparse.load_npz(PRE/(sample+'_QC_counts.npz'));ix=np.flatnonzero(obs.sample_id.eq(sample));subset=obs.iloc[ix];assert mat.shape[0]==len(subset)
        assert np.array_equal(np.asarray(mat.sum(axis=0)).ravel(),existing_pb[sample].to_numpy())
        for typ in types:
            keep=subset.cell_type.eq(typ).to_numpy();vectors[typ][sample]=np.asarray(mat[keep].sum(axis=0)).ravel().astype(np.int64)
        a=an.AnnData(mat,obs=pd.DataFrame(index=subset.cell_id),var=pd.DataFrame(index=feat.gene_id))
        uc.compute_ucell_scores(a,signatures=signatures_by_id,max_rank=1500,ties_method='average',missing_genes='skip',chunk_size=500,n_jobs=1,device=None)
        uscores[ix]=a.obs[[k+'_UCell' for k in names]].to_numpy(dtype=np.float32)
        del a;gc.collect()
        for row in range(mat.shape[0]):
            lo,hi=mat.indptr[row:row+2];indices=mat.indices[lo:hi];counts=mat.data[lo:hi]
            sg=mem[indices];detectfrac[ix[row]]=sg.sum(axis=0)/m
            if row<10:
                ranks=np.minimum(rankdata(-counts,method='average'),1500);improvement=(1500-ranks)@sg;rank_sum=m*1500-improvement;independent=1-(rank_sum-minimum)/den;package_errors.append(float(np.max(np.abs(independent-uscores[ix[row]]))))
        del mat;gc.collect();print('TYPE_PB_AND_RANKS',sample,'seconds',round(time.time()-t,1),flush=True)
    assert np.isfinite(uscores).all() and (uscores>=-1e-7).all() and (uscores<=1+1e-7).all()
    assert max(package_errors)<1e-6
    np.save(PRE/'全部QC细胞_pyUCell秩评分.npy',uscores);np.save(PRE/'全部QC细胞_签名检出基因比例.npy',detectfrac)
    pd.DataFrame({'signature':names}).to_csv(PRE/'秩评分_列名.csv',index=False)
    score_summary=[]
    for (sample,typ),ids in obs.groupby(['sample_id','cell_type'],sort=True).groups.items():
        ids=np.array(list(ids));means=uscores[ids].mean(axis=0);dc=detectfrac[ids].mean(axis=0)
        for j,k in enumerate(names):score_summary.append({'sample_id':sample,'phase':'Acute' if sample.startswith('A') else 'Remission','cell_type':typ,'n_cells':len(ids),'signature':k,'mean_UCell_score':float(means[j]),'mean_fraction_signature_genes_detected':float(dc[j])})
    pd.DataFrame(score_summary).to_csv(RES/'细胞类型_逐文库完整通路秩评分.csv',index=False)
    manifest=[]
    for i,typ in enumerate(types):
        stem=f'celltype_{i+1:02d}';path=PB/(stem+'_rawcounts.tsv');d=pd.DataFrame(vectors[typ],index=feat.gene_id);d.to_csv(path,sep='\t',index_label='gene_id')
        nc=props.loc[props.cell_type.eq(typ)].set_index('sample_id').n_cells.reindex(['A1','A2','A3','B1','B2','B3'],fill_value=0);manifest.append({'cell_type':typ,'file_stem':stem,'counts_path':str(path.relative_to(BASE)).replace('\\','/'),'minimum_library_cells':int(nc.min()),'eligible_all6_ge30_cells':bool(nc.min()>=30)})
    pd.DataFrame(manifest).to_csv(RES/'细胞类型pseudobulk输入清单.csv',index=False)
    dump(OUT/'细胞定位与秩评分方法.json',{'algorithm':'Official pyUCell package','package_version':importlib.metadata.version('pyucell'),'maxRank':1500,'ties':'average','n_jobs':1,'chunk_size':500,'device':'CPU','missing_genes':'skip; annotation-matched feature IDs; explicit coverage table','Uscore':'1 - (sum(ranks) - m*(m+1)/2)/(m*maxRank - m*(m+1)/2)','primary_source':'https://doi.org/10.1093/bioinformatics/btag055','signatures':names,'equal_library_weights_in_plots':True,'no_cell_level_p_values':True,'rank_unit_test_max_abs_error':float(abs(dense-spscore)),'package_vs_independent_formula_60cells_max_abs_error':max(package_errors),'cells':len(obs),'celltypes':len(types),'celltypes_all6ge30':sum(x['eligible_all6_ge30_cells'] for x in manifest),'limits':'Signature expression is not biochemical pathway activation, causal mechanism, or formula treatment validation. No batch integration was applied; all library-specific raw counts retained.'})
    print('AGGREGATION_COMPLETE',len(obs),len(types),'types',flush=True)
if __name__=='__main__':main()
