"""Aggregate independent 10x count libraries at donor-phase level after fixed cell QC."""
from pathlib import Path
import gzip,hashlib,io,json,sys,tarfile,time
BASE=Path(__file__).resolve().parent;OUT=BASE/'GEO表达核验_2026-10-29/独立队列_GSE211783';RAW=OUT/'原始来源';PRE=OUT/'预处理';PRE.mkdir(exist_ok=True)
sys.path.insert(0,str(BASE/'runtime/ppi_analysis_libraries'))
sys.path.insert(0,str(BASE/'runtime/geo_mapping_libraries'))
import numpy as np
import pandas as pd
from scipy.io import mmread
from threadpoolctl import threadpool_limits
qc=[];vectors={};feat_master=None;rawvectors={}
for p in sorted(RAW.glob('GSM*_*.tar.gz')):
 t=time.time();sample=p.name.split('_',1)[1].split('.')[0]
 with tarfile.open(p,'r:gz') as tar:
  members=tar.getmembers();files={Path(x.name).name:x for x in members if x.isfile()}
  feat=pd.read_csv(gzip.GzipFile(fileobj=tar.extractfile(files['features.tsv.gz'])),sep='\t',header=None,dtype=str)
  barcodes=pd.read_csv(gzip.GzipFile(fileobj=tar.extractfile(files['barcodes.tsv.gz'])),sep='\t',header=None,dtype=str)
  assert feat[0].str.startswith('ENSG').all() and not feat[0].str.startswith('ENSMUSG').any()
  if feat_master is None:feat_master=feat.copy()
  else:assert feat.equals(feat_master)
  with threadpool_limits(limits=2):
   mat=mmread(gzip.GzipFile(fileobj=tar.extractfile(files['matrix.mtx.gz']))).tocsr()
 assert mat.shape==(len(feat),len(barcodes)) and np.all(mat.data>=0) and np.all(mat.data==np.floor(mat.data))
 totals=np.asarray(mat.sum(axis=0)).ravel();ngenes=np.asarray((mat>0).sum(axis=0)).ravel()
 mito=feat[1].str.upper().str.startswith('MT-').to_numpy()
 mt=np.asarray(mat[mito,:].sum(axis=0)).ravel();frac=np.divide(mt,totals,out=np.zeros_like(mt,dtype=float),where=totals>0)
 keep=(ngenes>=200)&(ngenes<=6000)&(totals>=500)&(frac<=.20)
 v=np.asarray(mat[:,keep].sum(axis=1)).ravel().astype(np.int64);vectors[sample]=v
 rawvectors[sample]=np.asarray(mat.sum(axis=1)).ravel().astype(np.int64)
 qc.append({'sample_id':sample,'geo_sample':p.name.split('_')[0],'phase':'Acute' if sample.startswith('A') else 'Remission','cells_input':mat.shape[1],'cells_retained':int(keep.sum()),'cells_removed':int((~keep).sum()),'low_genes':int((ngenes<200).sum()),'high_genes':int((ngenes>6000).sum()),'low_UMI':int((totals<500).sum()),'high_mito':int((frac>.2).sum()),'retained_UMI':int(v.sum()),'retained_median_UMI':float(np.median(totals[keep])),'retained_median_genes':float(np.median(ngenes[keep])),'retained_median_mito_fraction':float(np.median(frac[keep])),'human_ENSG_features':len(feat),'mouse_ENSMUSG_features':0,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 pd.DataFrame({'barcode':barcodes[0],'UMI':totals,'genes':ngenes,'mito_fraction':frac,'retained':keep}).to_csv(PRE/(sample+'_细胞QC.csv.gz'),index=False,compression='gzip')
 print('PSEUDOBULK',sample,'cells',mat.shape[1],'retained',int(keep.sum()),'UMI',int(v.sum()),'seconds',round(time.time()-t,1),flush=True)
 del mat
assert set(vectors)==set(['A1','A2','A3','B1','B2','B3'])
counts=pd.DataFrame(vectors,index=feat_master[0]);counts.index.name='gene_id'
counts.to_csv(PRE/'6文库_QC后供者汇总计数.tsv',sep='\t',encoding='utf-8-sig')
pd.DataFrame(rawvectors,index=feat_master[0]).to_csv(PRE/'6文库_未过滤细胞汇总计数.tsv',sep='\t',index_label='gene_id',encoding='utf-8-sig')
pd.DataFrame(qc).to_csv(PRE/'6文库_细胞QC与测序深度.csv',index=False,encoding='utf-8-sig')
feat_master.columns=['gene_id','source_symbol','feature_type'];feat_master.to_csv(PRE/'人类基因特征.csv',index=False,encoding='utf-8-sig')
print('PSEUDOBULK_READY',counts.shape,flush=True)
