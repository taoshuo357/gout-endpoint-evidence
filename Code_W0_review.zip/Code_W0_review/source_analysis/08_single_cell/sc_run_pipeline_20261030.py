"""Reproduce the completed public single-cell module, with a label-fingerprint gate."""
from pathlib import Path
import subprocess,sys,os,json,csv,time
BASE=Path(__file__).resolve().parent;OUT=BASE/'论文推进_2026-10-30/单细胞定位';LOG=OUT/'复跑日志';LOG.mkdir(exist_ok=True)
assert BASE.drive.upper()=='G:' and Path(os.environ['TEMP']).drive.upper()=='G:'
def run(script,args=()):
 name=Path(script).stem;t=time.time()
 with (LOG/(name+'.log')).open('w',encoding='utf8') as f:r=subprocess.run([sys.executable,str(BASE/script),*args],cwd=BASE,env=os.environ,stdout=f,stderr=subprocess.STDOUT)
 print(name,'exit',r.returncode,'seconds',round(time.time()-t,1),flush=True)
 if r.returncode:raise RuntimeError('Processing failed; inspect the G-drive reproduction log: '+name)
old=OUT/'结果表/聚类_marker快速审阅.csv';expected={r['cluster']:int(r['n_cells']) for r in csv.DictReader(old.open(encoding='utf8-sig'))} if old.exists() else None
for script in ['sc_plot_qc_20261030.py','sc_prepare_20261030.py','sc_embed_20261030.py','sc_review_annotation_20261030.py','sc_review_top_hvg_20261030.py','sc_expand_annotation_20261030.py']:run(script)
actual={r['cluster']:int(r['n_cells']) for r in csv.DictReader(old.open(encoding='utf8-sig'))}
if expected is not None and actual!=expected:
 (OUT/'重跑后注释需复核.json').write_text(json.dumps({'expected_cluster_sizes':expected,'observed_cluster_sizes':actual,'action':'Do not reuse fixed cluster labels until marker-based review confirms their identities.'},ensure_ascii=False,indent=2),encoding='utf8')
 raise RuntimeError('Cluster fingerprints changed; preserve counts and review canonical-marker labels before continuing.')
for script in ['sc_finalize_annotations_20261030.py','sc_aggregate_20261030.py','sc_plot_results_20261030.py','sc_plot_library_mixing_20261030.py','sc_write_results_20261030.py','sc_seal_core_20261030.py']:run(script)
if '--include-celltype-phase' in sys.argv:run('run_geo_r.py',['sc_celltype_pseudobulk_20261030.R'])
print('PUBLIC_SINGLE_CELL_PIPELINE_COMPLETE',flush=True)
