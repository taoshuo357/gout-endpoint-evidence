from pathlib import Path
import sys,json,re,hashlib,datetime,itertools
O=Path(__file__).resolve().parent
G=Path('G:/痛风/第二步_靶点预测与疾病交集')
sys.path[:0]=[str(G/'runtime/ppi_analysis_libraries'),str(G/'论文推进_2026-10-30/单细胞定位/runtime')]
import numpy as np,pandas as pd
from scipy.spatial.distance import cdist
F=O/'3nvy.cif';P=O/'3nvy.pdb'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
contract={'frozen_before_contact_calculation':datetime.datetime.now().astimezone().isoformat(),'PDB':'3NVY','ligand':'QUE','all_deposited_QUE_sites':True,'distance_cutoff_A':4.0,'heavy_atoms':'nonH/nonD, all positive deposited occupancies; all alternate conformers retained and labeled, no highest-occupancy selection','contact':'Euclidean heavy-atom pair distance <=4.000A, no chemistry label assigned by distance alone','crystal_neighbors':'all PDB REMARK290 SMTRY operations with lattice translations -2..2 in each axis; retain complete deposited AU and all neighbor contacts; confirm -1..1 agrees for contacts','symmetry_unit':'each central deposited QUE instance; equivalent crystal copies are not independent biological observations','classification':'polymer protein / water / cofactor / other; metal atoms separately flagged even when part of cofactor','no_refinement_or_docking_or_MD':True,'raw_files_unchanged':True,'mmCIF_SHA256':sha(F),'PDB_SHA256':sha(P)}
(O/'接触计算前固定规则.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
# Minimal CIF1 tokenizer; quoted values close only when followed by whitespace/end.
def tokenize(text):
 ls=iter(text.splitlines())
 for line in ls:
  if line.startswith(';'):
   ss=[line[1:]]
   for line in ls:
    if line.startswith(';'):break
    ss.append(line)
   else:raise ValueError('unclosed semicolon CIF string')
   yield '\x00'+'\n'.join(ss);continue
  i=0
  while i<len(line):
   if line[i].isspace():i+=1;continue
   if line[i]=='#':break
   if line[i] in "\"'":
    q=line[i];j=i+1
    while j<len(line) and not (line[j]==q and (j+1==len(line) or line[j+1].isspace())):j+=1
    if j==len(line):raise ValueError('unclosed CIF quote')
    yield '\x00'+line[i+1:j];i=j+1
   else:
    j=i
    while j<len(line) and not line[j].isspace():j+=1
    yield line[i:j];i=j
T=list(tokenize(F.read_text(encoding='utf-8')));D={};i=0
while i<len(T):
 t=T[i]
 if t=='loop_':
  i+=1;keys=[]
  while i<len(T) and T[i].startswith('_'):keys.append(T[i]);i+=1
  vals=[]
  while i<len(T) and not (T[i].startswith('_') or T[i] in ['loop_','stop_'] or T[i].startswith('data_') or T[i].startswith('save_')):vals.append(T[i]);i+=1
  assert keys and len(vals)%len(keys)==0,(keys[:2],len(vals))
  for k,key in enumerate(keys):D[key]=[x.lstrip('\x00') for x in vals[k::len(keys)]]
 elif t.startswith('_'):D[t]=[T[i+1].lstrip('\x00')];i+=2
 else:i+=1
names=[k for k in D if k.startswith('_atom_site.')];A=pd.DataFrame({k.split('.',1)[1]:D[k] for k in names})
for col in ['Cartn_x','Cartn_y','Cartn_z','occupancy','B_iso_or_equiv']:A[col]=pd.to_numeric(A[col])
assert set(A.pdbx_PDB_model_num)=={'1'}
# Independent PDB fixed-column parsing verifies atom count, identity and coordinates.
px=[]
for ln in P.read_text().splitlines():
 if ln[:6] not in ['ATOM  ','HETATM']:continue
 px.append(dict(auth_asym_id=ln[21],auth_seq_id=ln[22:26].strip(),auth_comp_id=ln[17:20].strip(),auth_atom_id=ln[12:16].strip(),label_alt_id=ln[16].strip() or '.',x=float(ln[30:38]),y=float(ln[38:46]),z=float(ln[46:54]),occupancy=float(ln[54:60]),element=ln[76:78].strip()))
B=pd.DataFrame(px);assert len(A)==len(B)
for k in ['auth_asym_id','auth_seq_id','auth_comp_id','auth_atom_id','label_alt_id']:assert A[k].tolist()==B[k].tolist(),k
assert np.max(np.abs(A[['Cartn_x','Cartn_y','Cartn_z']].to_numpy()-B[['x','y','z']].to_numpy()))<1e-9
assert np.max(np.abs(A.occupancy.to_numpy()-B.occupancy.to_numpy()))<1e-9
entity=dict(zip(D['_entity.id'],D['_entity.type']));A['entity_type']=A.label_entity_id.map(entity)
metals={'LI','NA','K','RB','CS','MG','CA','SR','BA','AL','MN','FE','CO','NI','CU','ZN','CD','HG','V','CR','MO','W','Y','ZR','AG','AU','PT','PD','RU','OS'}
A['is_metal_atom']=A.type_symbol.str.upper().isin(metals)
A['is_water']=A.label_comp_id.isin(['HOH','DOD','WAT'])
A['is_cofactor']=A.label_comp_id.isin(['FAD','FES','ZXF'])
A['category']=np.where(A.entity_type.eq('polymer'),'protein',np.where(A.is_water,'water',np.where(A.is_cofactor,'cofactor',np.where(A.is_metal_atom,'free_metal','other_nonpolymer'))))
A['heavy']=~A.type_symbol.str.upper().isin(['H','D'])
A.to_csv(O/'3NVY_全部沉积原子_含occupancy与分类.tsv',sep='\t',index=False)
H=A[A.heavy&A.occupancy.gt(0)].reset_index(drop=True).copy();xyz=H[['Cartn_x','Cartn_y','Cartn_z']].to_numpy()
L=H[H.label_comp_id.eq('QUE')].copy();assert len(L)==44
skeys=['pdbx_PDB_model_num','label_asym_id','auth_asym_id','auth_seq_id','pdbx_PDB_ins_code']
sites=list(L.groupby(skeys,sort=True));assert len(sites)==2
# Exact ligand chemical identity from official CCD API.
cc=json.loads((O/'QUE_chemcomp.json').read_text(encoding='utf-8-sig'));desc=cc.get('pdbx_chem_comp_descriptor',[])
key=cc.get('rcsb_chem_comp_descriptor',{}).get('InChIKey') or next((v.get('descriptor') for v in desc if v.get('type')=='InChIKey'),None)
assert key=='REFJWTPEDVJJIY-UHFFFAOYSA-N',key
(O/'QUE_身份精确核对.json').write_text(json.dumps({'PDB_ligand':'QUE','CCD_InChIKey':key,'original_formula_reference_PubChem_CID':'5280343','same_key_as_frozen_formula_reference':True,'CCD_formula':cc.get('chem_comp',{}).get('formula'),'CCD_nonH_atom_count':cc.get('rcsb_chem_comp_info',{}).get('atom_count_heavy'),'deposited_per_site_elements':{str(k):v.type_symbol.value_counts().to_dict() for k,v in sites},'no_analogue_substitution':True},ensure_ascii=False,indent=2),encoding='utf-8')
# Crystallographic operators from official PDB are Cartesian operations.
ops={}
for ln in P.read_text().splitlines():
 m=re.match(r'REMARK 290\s+SMTRY([123])\s+(\d+)\s+([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)',ln)
 if m:
  row,op=int(m[1])-1,int(m[2]);ops.setdefault(op,np.zeros((3,4)));ops[op][row]=list(map(float,m.groups()[2:]))
assert set(ops)=={1,2}
a,b,c=[float(D['_cell.length_'+k][0]) for k in 'abc'];al,be,ga=np.deg2rad([float(D['_cell.angle_'+k][0]) for k in ['alpha','beta','gamma']])
va=np.array([a,0,0]);vb=np.array([b*np.cos(ga),b*np.sin(ga),0]);vcx=c*np.cos(be);vcy=c*(np.cos(al)-np.cos(be)*np.cos(ga))/np.sin(ga);vc=np.array([vcx,vcy,np.sqrt(c*c-vcx*vcx-vcy*vcy)]);cell=np.column_stack([va,vb,vc])
contact=[];summary=[];near=[]
cols_keep=['id','type_symbol','label_atom_id','label_alt_id','label_comp_id','label_asym_id','label_entity_id','label_seq_id','auth_atom_id','auth_comp_id','auth_asym_id','auth_seq_id','pdbx_PDB_ins_code','occupancy','B_iso_or_equiv','entity_type','category','is_water','is_cofactor','is_metal_atom']
for sk,z in sites:
 sid=f'QUE_label{sk[1]}_auth{sk[2]}_{sk[3]}';lx=z[['Cartn_x','Cartn_y','Cartn_z']].to_numpy();lig_indices=set(z.index)
 summary.append({'site_id':sid,'model':sk[0],'ligand_label_asym_id':sk[1],'ligand_auth_chain':sk[2],'ligand_auth_seq_id':sk[3],'heavy_atoms':len(z),'elements':';'.join(f'{x}:{y}' for x,y in z.type_symbol.value_counts().sort_index().items()),'occupancy_min':z.occupancy.min(),'occupancy_max':z.occupancy.max(),'Bfactor_mean_A2':z.B_iso_or_equiv.mean(),'altlocs':'|'.join(sorted(set(z.label_alt_id))),'InChIKey':key})
 # Baseline nearest heterocomponents, even when outside the4A contact threshold.
 for hk,zz in H[H.category.ne('protein')&~H.index.isin(lig_indices)].groupby(['category','label_comp_id','label_asym_id','auth_asym_id','auth_seq_id'],sort=True):
  ds=cdist(lx,zz[['Cartn_x','Cartn_y','Cartn_z']].to_numpy());ii,jj=np.unravel_index(np.argmin(ds),ds.shape);r=zz.iloc[jj]
  near.append({'site_id':sid,'partner_category':hk[0],'partner_comp_id':hk[1],'partner_label_asym_id':hk[2],'partner_auth_chain':hk[3],'partner_auth_seq_id':hk[4],'minimum_distance_A':float(ds[ii,jj]),'ligand_atom':z.iloc[ii].auth_atom_id,'partner_atom':r.auth_atom_id,'partner_is_metal_atom':bool(r.is_metal_atom),'scope':'depositedAU;nearestdistance is not a <=4A contact unless <=4'})
 for op,mat in sorted(ops.items()):
  base=xyz@mat[:,:3].T+mat[:,3]
  for shift in itertools.product(range(-2,3),repeat=3):
   central=op==1 and shift==(0,0,0);xx=base+cell@np.array(shift)
   mask=np.all((xx>=lx.min(axis=0)-4)&(xx<=lx.max(axis=0)+4),axis=1)
   if central:mask[list(lig_indices)]=False
   ix=np.flatnonzero(mask)
   if not len(ix):continue
   ds=cdist(lx,xx[ix]);ii,jj=np.where(ds<=4+1e-10)
   for q,w in zip(ii,jj):
    lar=z.iloc[q];par=H.iloc[ix[w]];v={'site_id':sid,'distance_A':float(ds[q,w]),'partner_symmetry_operation':op,'partner_lattice_a':shift[0],'partner_lattice_b':shift[1],'partner_lattice_c':shift[2],'partner_is_deposited_AU':central}
    for prefix,atom in [('ligand',lar),('partner',par)]:
     for k in cols_keep:v[prefix+'_'+k]=atom[k]
    contact.append(v)
C=pd.DataFrame(contact);assert len(C)>0
C=C.sort_values(['site_id','partner_category','partner_is_deposited_AU','partner_auth_asym_id','partner_auth_seq_id','distance_A']).reset_index(drop=True)
assert C[['partner_lattice_a','partner_lattice_b','partner_lattice_c']].abs().max().max()<=1,'neighbors outside-1..1need wider convergence audit'
C['distance_interpretation']='geometric heavyatom contact only; not hydrogenbond/bindingenergy'
C.to_csv(O/'全部两位点_重原子4A_逐原子接触.tsv',sep='\t',index=False)
C[C.partner_category.eq('protein')].to_csv(O/'全部两位点_蛋白重原子4A_接触.tsv',sep='\t',index=False)
C[C.partner_is_water].to_csv(O/'全部两位点_水4A_接触.tsv',sep='\t',index=False)
C[C.partner_is_cofactor].to_csv(O/'全部两位点_辅因子4A_接触.tsv',sep='\t',index=False)
C[C.partner_is_metal_atom].to_csv(O/'全部两位点_金属原子4A_接触.tsv',sep='\t',index=False)
C[~C.partner_is_deposited_AU].to_csv(O/'全部两位点_晶体邻居4A_接触.tsv',sep='\t',index=False)
R=C.groupby(['site_id','partner_category','partner_label_comp_id','partner_label_asym_id','partner_auth_asym_id','partner_auth_seq_id','partner_pdbx_PDB_ins_code','partner_symmetry_operation','partner_lattice_a','partner_lattice_b','partner_lattice_c','partner_is_deposited_AU'],dropna=False).agg(minimum_distance_A=('distance_A','min'),atom_pair_count=('distance_A','size'),ligand_atoms=('ligand_auth_atom_id',lambda x:'|'.join(sorted(set(x)))),partner_atoms=('partner_auth_atom_id',lambda x:'|'.join(sorted(set(x))))).reset_index()
R.to_csv(O/'全部两位点_按残基组分最短接触.tsv',sep='\t',index=False)
pd.DataFrame(summary).to_csv(O/'全部两位点_配体占有率与重原子.tsv',sep='\t',index=False)
pd.DataFrame(near).to_csv(O/'全部两位点_沉积辅因子水金属最近距离_含4A外.tsv',sep='\t',index=False)
# Metal-specific nearest distances never confused with nearest cofactor nonmetal atom.
metal=[]
for sk,z in sites:
 sid=f'QUE_label{sk[1]}_auth{sk[2]}_{sk[3]}'
 for _,rr in H[H.is_metal_atom].iterrows():
  ds=cdist(z[['Cartn_x','Cartn_y','Cartn_z']],rr[['Cartn_x','Cartn_y','Cartn_z']].to_numpy(float).reshape(1,3));i=int(ds.argmin());metal.append({'site_id':sid,'metal_element':rr.type_symbol,'metal_atom_id':rr.auth_atom_id,'cofactor':rr.label_comp_id,'auth_chain':rr.auth_asym_id,'auth_seq_id':rr.auth_seq_id,'minimum_distance_A':float(ds.min()),'nearest_ligand_atom':z.iloc[i].auth_atom_id,'within4A':bool(ds.min()<=4),'scope':'depositedAU'})
pd.DataFrame(metal).to_csv(O/'全部两位点_金属最近距离_独立明细.tsv',sep='\t',index=False)
# Crystallographic metadata from raw CIF preserved without inventing missing conditions.
meta={k:v for k,v in D.items() if k.startswith(('_entry.','_struct.','_entity_src_nat.','_entity_poly.','_struct_asym.','_symmetry.','_cell.','_exptl.','_exptl_crystal_grow.','_refine.','_pdbx_audit_revision_history.','_pdbx_struct_assembly.','_pdbx_struct_assembly_gen.','_pdbx_struct_oper_list.','_citation.'))}
meta.update({'PDB':'3NVY','ligand':'QUE','ligand_key':key,'crystallographic_SMTRY_Cartesian':{k:v.tolist() for k,v in ops.items()},'contact_counts_by_site_category':C.groupby(['site_id','partner_category']).size().to_dict().__str__(),'species':'Bos taurus','primary_PMID':'25060641','primary_DOI':'10.1021/np500320g','primary_fulltext_status':'notOA in EuropePMC; PubMed abstract andofficialstructurecitationverified; no claimed subscription fulltextdownload'})
(O/'3NVY_官方结构与晶体条件元数据.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
counts=C.groupby(['site_id','partner_category']).size().rename('atom_pair_count').reset_index();counts.to_csv(O/'全部两位点_接触类别计数.tsv',sep='\t',index=False)
qa={'completed':datetime.datetime.now().astimezone().isoformat(),'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,'atoms_total':len(A),'positive_occupancy_heavy_atoms':len(H),'QUE_sites':len(sites),'QUE_heavy_atoms_total':len(L),'PDB_mmCIF_atom_identity_and_coordinate_agreement':True,'protein_atom_pair_contacts':int(C.partner_category.eq('protein').sum()),'water_atom_pair_contacts':int(C.partner_is_water.sum()),'cofactor_atom_pair_contacts':int(C.partner_is_cofactor.sum()),'metal_atom_pair_contacts':int(C.partner_is_metal_atom.sum()),'crystal_neighbor_contacts':int((~C.partner_is_deposited_AU).sum()),'crystal_translation_minus2to2_same_contactset_as_minus1to1':True,'max_distance_A':float(C.distance_A.max()),'no_docking_no_MD':True,'source_hashes_unchanged':sha(F)==contract['mmCIF_SHA256'] and sha(P)==contract['PDB_SHA256'],'script_SHA256':sha(Path(__file__))}
(O/'接触计算_实际完成与核验.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(qa,ensure_ascii=False,indent=2),flush=True);print(pd.DataFrame(summary).to_string(index=False),flush=True);print(R[R.partner_category.eq('protein')][['site_id','partner_label_comp_id','partner_auth_asym_id','partner_auth_seq_id','minimum_distance_A','atom_pair_count']].to_string(index=False),flush=True)

