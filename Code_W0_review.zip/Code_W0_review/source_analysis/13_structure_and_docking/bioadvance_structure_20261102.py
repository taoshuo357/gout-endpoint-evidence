from bioadvance_common_20261102 import *
import requests,time,threading
from concurrent.futures import ThreadPoolExecutor,as_completed
import numpy as np
rows=read(BASE/'合并交集_2026-10-29'/'痛风交集_候选基因.csv')
mapping={r['gene_symbol']:r['uniprot_accessions'] for r in rows if r['gene_symbol'] in GENES}
logs=json.loads((OUT/'结构获取日志.json').read_text(encoding='utf-8')) if (OUT/'结构获取日志.json').exists() else []
lock=threading.Lock()
def fetch(url,p):
    if p.exists():return p.read_bytes()
    for attempt in range(3):
        try:
            r=requests.get(url,timeout=50);r.raise_for_status();b=r.content
            p.write_bytes(b)
            with lock:logs.append({'url':url,'file':str(p.relative_to(OUT)),'http_status':r.status_code,'bytes':len(b),'sha256':sha(p),'retrieved_utc':r.headers.get('Date','')})
            return b
        except Exception:
            if attempt==2:raise
            time.sleep(1)
def worker(g):
    accs=mapping[g].split(';');assert len(accs)==1,(g,accs)
    acc=accs[0]
    un=json.loads(fetch(f'https://rest.uniprot.org/uniprotkb/{acc}.json',RAW/f'{g}_UniProt.json'))
    assert un['organism']['taxonId']==9606
    assert un['genes'][0]['geneName']['value']==g,(g,un['genes'])
    assert 'reviewed' in un['entryType'].lower()
    seq=un['sequence']['value'];L=len(seq)
    af=json.loads(fetch(f'https://alphafold.ebi.ac.uk/api/prediction/{acc}',RAW/f'{g}_AF_metadata.json'))
    # Full canonical monomer only; never select fragments/isoforms by truncated names.
    candidates=[a for a in af if a.get('uniprotAccession')==acc and a.get('uniprotStart')==1 and a.get('uniprotEnd')==L]
    assert len(candidates)==1,(g,L,[(a.get('uniprotStart'),a.get('uniprotEnd')) for a in af])
    a=candidates[0];pdb=fetch(a['pdbUrl'],RAW/f'{g}_AF_model.pdb').decode()
    aa={'ALA':'A','ARG':'R','ASN':'N','ASP':'D','CYS':'C','GLU':'E','GLN':'Q','GLY':'G','HIS':'H','ILE':'I','LEU':'L','LYS':'K','MET':'M','PHE':'F','PRO':'P','SER':'S','THR':'T','TRP':'W','TYR':'Y','VAL':'V'}
    ca=[]
    for line in pdb.splitlines():
        if line.startswith('ATOM  ') and line[12:16].strip()=='CA':
            ca.append({'gene':g,'accession':acc,'residue':int(line[22:26]),'AA':aa[line[17:20]],'x':float(line[30:38]),'y':float(line[38:46]),'z':float(line[46:54]),'pLDDT':float(line[60:66])})
    assert ''.join(r['AA'] for r in ca)==seq and len(ca)==L
    assert all(0<=r['pLDDT']<=100 for r in ca)
    pdbs=[];covered=set()
    for cross in un.get('uniProtKBCrossReferences',[]):
        if cross['database']!='PDB':continue
        prop={p['key']:p['value'] for p in cross.get('properties',[])}
        import re
        ranges=re.findall(r'=(\d+)-(\d+)',prop.get('Chains',''))
        pos=set()
        for start,stop in ranges:pos.update(range(max(1,int(start)),min(L,int(stop))+1))
        covered.update(pos)
        pdbs.append({'gene':g,'accession':acc,'pdb_id':cross['id'],'method':prop.get('Method',''),'resolution':prop.get('Resolution',''),'chain_spans':prop.get('Chains',''),'annotated_span_residues':len(pos),'annotated_span_fraction':len(pos)/L})
    for r in ca:r['within_UniProt_PDB_chain_span']=int(r['residue'] in covered)
    features=[]
    for f in un.get('features',[]):
        if f['type'] in ['Domain','Region','Transmembrane','Topological domain','Active site','Binding site','Disulfide bond','Signal','Propeptide','Chain']:
            features.append({'gene':g,'type':f['type'],'description':f.get('description',''),'start':f.get('location',{}).get('start',{}).get('value',''),'end':f.get('location',{}).get('end',{}).get('value','')})
    scores=np.array([r['pLDDT'] for r in ca])
    summary={'gene':g,'accession':acc,'sequence_length':L,'AF_entry':a.get('entryId'),'AF_version':a.get('latestVersion'),'AF_date':a.get('modelCreatedDate'),'AF_mean_pLDDT':float(scores.mean()),'pLDDT_ge90_fraction':float(np.mean(scores>=90)),'pLDDT_70to90_fraction':float(np.mean((scores>=70)&(scores<90))),'pLDDT_50to70_fraction':float(np.mean((scores>=50)&(scores<70))),'pLDDT_lt50_fraction':float(np.mean(scores<50)),'PDB_crossrefs':len(pdbs),'PDB_chain_span_union_fraction':len(covered)/L,'sequence_sha256':hashlib.sha256(seq.encode()).hexdigest()}
    return summary,ca,pdbs,features
summ=[];res=[];pdbs=[];features=[];errors=[]
with ThreadPoolExecutor(max_workers=3) as ex:
    fut={ex.submit(worker,g):g for g in GENES}
    for f in as_completed(fut):
        g=fut[f]
        try:
            s,r,p,d=f.result();summ.append(s);res.extend(r);pdbs.extend(p);features.extend(d);print(f'{g}: length={s["sequence_length"]}, PDB={s["PDB_crossrefs"]}',flush=True)
        except Exception as e:errors.append({'gene':g,'error':str(e)});print(f'{g}: ERROR {e}',flush=True)
write('Protein_12靶点结构汇总.tsv',sorted(summ,key=lambda r:GENES.index(r['gene'])))
write('Protein_全部残基置信度与坐标.tsv',res);write('Protein_全部UniProt实验结构关联.tsv',pdbs);write('Protein_UniProt功能区域.tsv',features)
dump(OUT/'结构获取日志.json',logs);dump(OUT/'结构获取错误.json',errors)
dump(OUT/'结构结果摘要.json',{'success':len(summ),'errors':errors,'residues':len(res),'PDB_records':len(pdbs),'method_boundary':'UniProt annotated PDB chain spans are not resolved atomic coverage; pLDDT is local model confidence, not binding confidence. AlphaFold DB retrieval, not a new AlphaFold run.'})
