from pathlib import Path
import os,sys,json,time,csv,traceback,shutil,hashlib
BASE=Path(__file__).resolve().parent;OUT=BASE/'全面验证_2026-11-02'/'06_对接与MD'
(OUT/'md/kernel_cache').mkdir(exist_ok=True)
os.environ['CUDA_CACHE_PATH']=str(OUT/'md/kernel_cache');os.environ['CUDA_CACHE_DISABLE']='1'
sys.path.insert(0,str(OUT/'deps'));sys.path.insert(0,str(BASE/'runtime/ppi_analysis_libraries'))
import numpy as np
import openmm as mm
from openmm import app,unit
lib=OUT/'deps/OpenMM.libs/lib';os.chdir(lib)
dll_handles=[os.add_dll_directory(str(lib)),os.add_dll_directory(str(lib/'plugins'))]
mm.Platform.loadPluginsFromDirectory('plugins');os.chdir(OUT)
def dump(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2),encoding='utf-8')
platform=mm.Platform.getPlatformByName('OpenCL');properties={'OpenCLPrecision':'mixed'}
ff=app.ForceField('amber14-all.xml','implicit/gbn2.xml')
source=BASE/'生信扩展_2026-11-02/公开结构原始/AKT1_AF_model.pdb'
shutil.copyfile(source,OUT/'raw/AKT1_AF_model.pdb')
pdb=app.PDBFile(source.open());mod=app.Modeller(pdb.topology,pdb.positions)
print('adding hydrogen to canonical 480 residue apo model',flush=True)
mod.addHydrogens(ff,pH=7.4,platform=platform)
system=ff.createSystem(mod.topology,nonbondedMethod=app.NoCutoff,constraints=app.HBonds,soluteDielectric=1.0,solventDielectric=78.5,implicitSolventKappa=1.25/unit.nanometer)
(OUT/'md/system.xml').write_text(mm.XmlSerializer.serialize(system))
with (OUT/'md/apo_prepared.pdb').open('w') as f:app.PDBFile.writeFile(mod.topology,mod.positions,f)
ca_idx=[a.index for a in mod.topology.atoms() if a.name=='CA']
assert len(ca_idx)==480
plddt=np.array([float(l[60:66]) for l in source.read_text().splitlines() if l.startswith('ATOM') and l[12:16].strip()=='CA'])
integ=mm.LangevinMiddleIntegrator(300*unit.kelvin,1/unit.picosecond,.002*unit.picoseconds)
sim=app.Simulation(mod.topology,system,integ,platform,properties);sim.context.setPositions(mod.positions)
energy0=sim.context.getState(getEnergy=True).getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)
print('minimizing',len(list(mod.topology.atoms())),'atoms E',energy0,flush=True)
sim.minimizeEnergy(tolerance=10*unit.kilojoule_per_mole/unit.nanometer,maxIterations=1500)
minstate=sim.context.getState(getPositions=True,getEnergy=True);start=minstate.getPositions()
energymin=minstate.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)
with (OUT/'md/apo_minimized.pdb').open('w') as f:app.PDBFile.writeFile(mod.topology,start,f)
integ.setRandomNumberSeed(20261101);sim.context.setVelocitiesToTemperature(300*unit.kelvin,20261101)
t0=time.perf_counter();sim.step(1000);benchmark=time.perf_counter()-t0
# Duration is selected ONLY from speed, before inspection of trajectory outcomes.
# This remains a short exploratory structural check, not convergence or binding validation.
production_ps=200 if benchmark<12 else (100 if benchmark<30 else 20)
equilibration_ps=10;seeds=[20261102,20261103,20261104];steps_per_frame=500
contract={'system':'apo AlphaFold canonical AKT1 480 residues, no ligand; no ATP/phosphorylation/membrane','input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'forcefield':'amber14-all.xml + implicit/gbn2.xml','solvent':'implicit GBn2/ACE; dielectric 1/78.5; kappa1.25 nm^-1 approximately physiological salt, no explicit ions/water','constraints':'H-bonds','temperature_K':300,'friction_ps^-1':1,'timestep_ps':.002,'platform':platform.getName(),'platform_properties':properties,'atoms':system.getNumParticles(),'minimization_max_iterations':1500,'initial_energy_kJ_mol':energy0,'minimized_energy_kJ_mol':energymin,'benchmark_steps':1000,'benchmark_wall_seconds':benchmark,'duration_rule':'200ps if 1000steps <12s; 100ps if <30s; else20ps, fixed before outcomes','equilibration_ps_each':equilibration_ps,'production_ps_each':production_ps,'production_frames_interval_ps':1,'seeds':seeds,'scope':'three independent velocities from same minimized apo model; not ligand stability, not equilibrium convergence; no binding affinity claim'}
dump('md/md_contract.json',contract);print(json.dumps(contract),flush=True)
del sim,integ
for seed in seeds:
    if (OUT/f'md/seed{seed}_complete.json').exists():continue
    integ=mm.LangevinMiddleIntegrator(300*unit.kelvin,1/unit.picosecond,.002*unit.picoseconds);integ.setRandomNumberSeed(seed)
    sim=app.Simulation(mod.topology,system,integ,platform,properties);sim.context.setPositions(start);sim.context.setVelocitiesToTemperature(300*unit.kelvin,seed)
    sim.step(round(equilibration_ps/.002));sim.context.setTime(0*unit.picosecond);sim.currentStep=0
    sim.reporters.append(app.DCDReporter(str(OUT/f'md/seed{seed}.dcd'),5000))
    ca=[];records=[];tstart=time.perf_counter()
    for frame in range(production_ps+1):
        if frame:sim.step(steps_per_frame)
        state=sim.context.getState(getPositions=True,getEnergy=True)
        xyz=state.getPositions(asNumpy=True).value_in_unit(unit.nanometer);ca.append(np.asarray(xyz[ca_idx],dtype=np.float32))
        kinetic=state.getKineticEnergy().value_in_unit(unit.kilojoule_per_mole)
        dof=3*system.getNumParticles()-system.getNumConstraints()-3
        temperature=2*kinetic/(dof*.00831446261815324)
        records.append({'seed':seed,'production_time_ps':frame,'potential_energy_kJ_mol':state.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole),'temperature_K':temperature})
        if frame%20==0:print('MD',seed,'time_ps',frame,'wall_s',round(time.perf_counter()-tstart,1),flush=True)
    np.savez_compressed(OUT/f'md/seed{seed}_CA.npz',xyz_nm=np.array(ca),time_ps=np.arange(production_ps+1),initial_ca_nm=np.asarray(start.value_in_unit(unit.nanometer))[ca_idx],plddt=plddt)
    with (OUT/f'md/seed{seed}_state.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    sim.saveCheckpoint(str(OUT/f'md/seed{seed}.chk'))
    with (OUT/f'md/seed{seed}_final.pdb').open('w') as f:app.PDBFile.writeFile(mod.topology,state.getPositions(),f)
    dump(f'md/seed{seed}_complete.json',{'seed':seed,'equilibration_ps':equilibration_ps,'production_ps':production_ps,'frames':len(ca),'production_wall_seconds':time.perf_counter()-tstart})
    del sim,integ
print('ALL THREE APO MD REPLICATES COMPLETE',flush=True)
