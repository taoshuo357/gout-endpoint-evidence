from pathlib import Path
import sys,os,json,csv,subprocess,hashlib,io
BASE=Path(__file__).resolve().parent
OUT=BASE/'全面验证_2026-11-02'/'06_对接与MD'
sys.path.insert(0,str(BASE/'runtime/ppi_analysis_libraries'));sys.path.append(str(BASE/'rdkit_runtime'));sys.path.insert(0,str(OUT/'deps'))
import numpy as np
from rdkit import Chem,DataStructs
from rdkit.Chem import AllChem,Descriptors,Crippen,rdFingerprintGenerator
from meeko import MoleculePreparation,PDBQTWriterLegacy
import openmm
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def sdf(p,mol):
    with p.open('w',encoding='utf-8') as f:
        with Chem.SDWriter(f) as w:w.write(mol)
def prep_lig(name,mol):
    p=OUT/'prepared'/(name+'.sdf');sdf(p,mol)
    setup=MoleculePreparation().prepare(mol)[0];pdbqt,success,error=PDBQTWriterLegacy.write_string(setup)
    assert success,error;(OUT/'prepared'/(name+'.pdbqt')).write_text(pdbqt,encoding='utf-8')
raw=(OUT/'raw'/'3O96.pdb').read_text()
rec=[l for l in raw.splitlines() if l.startswith('ATOM  ') and l[16] in ' A' and l[21]=='A']
lig=[l for l in raw.splitlines() if l.startswith('HETATM') and l[17:20]=='IQO']
assert rec and lig
lig_serials={int(l[6:11]) for l in lig};connect=[l for l in raw.splitlines() if l.startswith('CONECT') and int(l[6:11]) in lig_serials]
ligblock='\n'.join(lig+connect+['END'])+'\n'
(OUT/'prepared'/'IQO_crystal.pdb').write_text(ligblock)
template=next(Chem.ForwardSDMolSupplier(io.BytesIO((OUT/'raw'/'IQO_ideal.sdf').read_bytes()),removeHs=True));assert template is not None
pdbmol=Chem.MolFromPDBBlock(ligblock,sanitize=False,removeHs=True,proximityBonding=False);assert pdbmol is not None
ref=AllChem.AssignBondOrdersFromTemplate(template,pdbmol);Chem.SanitizeMol(ref)
assert Chem.MolToSmiles(ref)==Chem.MolToSmiles(template)
sdf(OUT/'prepared'/'IQO_crystal_reference.sdf',ref)
# Reference input conformation is separately generated and minimized; crystal coordinates are never the docking input.
ref_input=Chem.AddHs(Chem.MolFromSmiles(Chem.MolToSmiles(ref)))
params=AllChem.ETKDGv3();params.randomSeed=20261102
assert AllChem.EmbedMolecule(ref_input,params)==0
AllChem.MMFFOptimizeMolecule(ref_input,maxIters=1000)
prep_lig('reference_IQO',ref_input)
(OUT/'prepared'/'receptor_heavy.pdb').write_text('\n'.join(rec+['TER','END'])+'\n')
obabel=BASE/'runtime'/'bin'/'obabel.exe'
cmd=[str(obabel),'-ipdb','prepared/receptor_heavy.pdb','-opdbqt','-O','prepared/receptor.pdbqt','-xr','-p','7.4','--partialcharge','gasteiger']
env=os.environ.copy();env['PYTHONPATH']=str(BASE/'runtime')+os.pathsep+env.get('PYTHONPATH','')
r=subprocess.run(cmd,cwd=OUT,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
(OUT/'qa'/'receptor_preparation.txt').write_text(r.stdout+'\n'+r.stderr,encoding='utf-8');assert r.returncode==0
pqt=(OUT/'prepared'/'receptor.pdbqt').read_text();assert 'ROOT' not in pqt and 'TORSDOF' not in pqt
xyz=ref.GetConformer().GetPositions();center=xyz.mean(0);size=np.maximum(np.ptp(xyz,axis=0)+10,20)
config='\n'.join([f'center_{a} = {v:.4f}' for a,v in zip('xyz',center)]+[f'size_{a} = {v:.4f}' for a,v in zip('xyz',size)]+['exhaustiveness = 32','num_modes = 9','energy_range = 5','cpu = 4'])+'\n'
(OUT/'docking'/'config.txt').write_text(config)
qual=[r for r in read(BASE/'关键靶点与通路筛选_2026-10-29'/'优先12靶点_合格成分关联.csv') if r['gene_symbol']=='AKT1']
qual.sort(key=lambda r:(-int(r['source_count']),int(r['pubchem_cid'])))
queue=read(BASE/'Swiss分批提交队列.csv');qd={r['预测CID']:r for r in queue}
chosen=qual[:3];models=[]
for r in chosen:
    q=qd[r['pubchem_cid']];mol=Chem.AddHs(Chem.MolFromSmiles(q['SMILES']))
    params=AllChem.ETKDGv3();params.randomSeed=20261102;assert AllChem.EmbedMolecule(mol,params)==0
    AllChem.MMFFOptimizeMolecule(mol,maxIters=1000);name='candidate_CID'+r['pubchem_cid'];prep_lig(name,mol)
    models.append({'id':name,'cid':r['pubchem_cid'],'name':q['预测结构'],'role':'qualified candidate association; site unknown','qualified_sources':r['qualified_sources'],'source_count':int(r['source_count'])})
baseMol=Chem.MolFromSmiles(qd[chosen[0]['pubchem_cid']]['SMILES']);mw=Descriptors.MolWt(baseMol);lp=Crippen.MolLogP(baseMol)
known={r['pubchem_cid'] for r in qual};control=[]
fpgen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048);basefp=fpgen.GetFingerprint(baseMol)
for q in queue:
    if q['预测CID'] in known:continue
    mol=Chem.MolFromSmiles(q['SMILES']);sim=DataStructs.TanimotoSimilarity(basefp,fpgen.GetFingerprint(mol))
    distance=((Descriptors.MolWt(mol)-mw)/100)**2+((Crippen.MolLogP(mol)-lp)/2)**2
    control.append((distance,q,mol,sim))
control.sort(key=lambda x:(x[0],int(x[1]['预测CID'])))
distance,q,mol,sim=control[0];mol=Chem.AddHs(mol);params=AllChem.ETKDGv3();params.randomSeed=20261102;assert AllChem.EmbedMolecule(mol,params)==0
AllChem.MMFFOptimizeMolecule(mol,maxIters=1000);name='unlabelled_control_CID'+q['预测CID'];prep_lig(name,mol)
models.append({'id':name,'cid':q['预测CID'],'name':q['预测结构'],'role':'MW/logP matched from input compounds without recorded AKT1 association; NOT experimentally established inactive','qualified_sources':'none for AKT1 in current qualified collection','source_count':0,'matching_distance':distance,'Tanimoto_to_primary_candidate':sim})
contract={'target':'AKT1','accession':'P31749','pdb':'3O96','reference_ligand':'IQO','resolution_A':2.7,'receptor':'human chain A, no mutations, 367 modeled / 446 deposited residues; unresolved segments not rebuilt for rigid docking','receptor_preparation':'remove water/heteroatoms, OpenBabel pH7.4/Gasteiger charges, rigid PDBQT; defaults and warnings saved','reference_input':'bond-order assigned from CCD ideal SDF to crystal ligand only for reference RMSD; independent ETKDG/MMFF conformation used for docking','box_center':center.tolist(),'box_size':size.tolist(),'seeds':[20261102,20261103,20261104],'Vina_exhaustiveness':32,'Vina_cpu':4,'num_modes':9,'redocking_gate':'top-ranked pose heavy-atom in-place symmetry-corrected RMSD <=2.0 Å in all three seeds; also retain all nine poses','candidate_rule':'top3 prior-qualified AKT1 edges by source_count descending then CID ascending, fixed before docking','control_rule':'closest MW/logP input compound without prior qualified AKT1 association; unlabelled not inactive','candidate_selection':models,'MD_scope':'apo canonical AlphaFold AKT1 model; three velocity seeds, explicit actual exploratory duration; no ligand-complex stability/affinity claim','clinical_data_used':False}
dump(OUT/'analysis_contract.json',contract)
platforms=[{'index':i,'name':openmm.Platform.getPlatform(i).getName()} for i in range(openmm.Platform.getNumPlatforms())]
dump(OUT/'qa'/'openmm_platforms.json',platforms)
dump(OUT/'tables'/'ligand_registry.json',[{'id':'reference_IQO','role':'co-crystal positive reference','name':'IQO'}]+models)
print(json.dumps({'reference_heavy_atoms':ref.GetNumAtoms(),'AKT1_prior_candidates':len(qual),'selected':models,'box_center':center.tolist(),'box_size':size.tolist(),'openmm_platforms':platforms},ensure_ascii=False,indent=2))
