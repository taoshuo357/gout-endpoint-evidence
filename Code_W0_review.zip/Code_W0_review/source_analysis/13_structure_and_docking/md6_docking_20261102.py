from pathlib import Path
import os,sys,json,subprocess,io,csv,time,re,threading
from concurrent.futures import ThreadPoolExecutor
BASE=Path(__file__).resolve().parent;OUT=BASE/'全面验证_2026-11-02'/'06_对接与MD'
sys.path.insert(0,str(BASE/'runtime/ppi_analysis_libraries'));sys.path.append(str(BASE/'rdkit_runtime'));sys.path.insert(0,str(OUT/'deps'))
from rdkit import Chem
from rdkit.Chem import rdMolAlign
from meeko import PDBQTMolecule,RDKitMolCreate
contract=json.loads((OUT/'analysis_contract.json').read_text(encoding='utf-8'))
ref=next(Chem.ForwardSDMolSupplier(io.BytesIO((OUT/'prepared/IQO_crystal_reference.sdf').read_bytes()),removeHs=True))
registry=json.loads((OUT/'tables/ligand_registry.json').read_text(encoding='utf-8'))
rows=[];lock=threading.Lock()
def run(lig,seed):
    name=lig['id'];op=f'docking/{name}_seed{seed}.pdbqt';log=OUT/'docking'/f'{name}_seed{seed}.txt'
    if not (OUT/op).exists():
        cmd=[str(OUT/'bin/vina.exe'),'--receptor','prepared/receptor.pdbqt','--ligand',f'prepared/{name}.pdbqt','--config','docking/config.txt','--seed',str(seed),'--out',op]
        t=time.perf_counter();r=subprocess.run(cmd,cwd=OUT,capture_output=True,text=True,encoding='utf-8',errors='replace')
        log.write_text('COMMAND '+json.dumps(cmd)+'\nSECONDS '+str(time.perf_counter()-t)+'\n'+r.stdout+'\n'+r.stderr,encoding='utf-8')
        assert r.returncode==0,log.read_text()
    pqt=PDBQTMolecule((OUT/op).read_text(),skip_typing=True)
    mols=RDKitMolCreate.from_pdbqt_mol(pqt);assert len(mols)==1 and mols[0] is not None
    mol=Chem.RemoveHs(mols[0]);scores=[float(x) for x in re.findall(r'REMARK VINA RESULT:\s+([-\d.]+)',(OUT/op).read_text())]
    assert len(scores)==mol.GetNumConformers()
    local=[]
    with (OUT/'docking'/f'{name}_seed{seed}.sdf').open('w') as f:
        writer=Chem.SDWriter(f)
        for i,score in enumerate(scores):
            mol.SetProp('Vina_score_kcal_mol',str(score));mol.SetProp('rank',str(i+1));writer.write(mol,confId=i)
            rms=rdMolAlign.CalcRMS(mol,ref,prbId=i,refId=0,maxMatches=100000) if name=='reference_IQO' else None
            local.append({'ligand_id':name,'name':lig.get('name',name),'seed':seed,'rank':i+1,'score_kcal_mol':score,'reference_RMSD_A_fixed_frame_symmetry':rms})
        writer.close()
    with lock:rows.extend(local)
    print(name,seed,'top score',scores[0],'RMSD',local[0]['reference_RMSD_A_fixed_frame_symmetry'],flush=True)
for seed in contract['seeds']:run(registry[0],seed)
gate=all(r['reference_RMSD_A_fixed_frame_symmetry']<=2 for r in rows if r['rank']==1)
(OUT/'qa/redocking_gate.json').write_text(json.dumps({'passed':gate,'criterion':contract['redocking_gate'],'top_poses':[r for r in rows if r['rank']==1]},indent=2))
if gate:
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(run,lig,seed) for lig in registry[1:] for seed in contract['seeds']]
        for future in futures:future.result()
rows.sort(key=lambda r:(r['ligand_id'],r['seed'],r['rank']))
with (OUT/'tables/docking_all_poses.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps({'redocking_passed':gate,'n_poses':len(rows),'candidate_docking_performed':gate}),flush=True)
