# Disease-associated PBMC expression corroboration. No graphics devices opened.
library(limma)
options(stringsAsFactors=FALSE)
out <- 'GEO表达核验_2026-10-29'; pre <- file.path(out,'预处理'); res <- file.path(out,'表达结果')
dir.create(res,showWarnings=FALSE)
rd <- function(p,sep=',') read.table(p,header=TRUE,sep=sep,quote='"',comment.char='',check.names=FALSE,fileEncoding='UTF-8-BOM',stringsAsFactors=FALSE)
wr <- function(x,name) write.csv(x,file.path(res,name),row.names=FALSE,fileEncoding='UTF-8',na='')
em <- rd(file.path(pre,'编码基因_log2表达矩阵.tsv'),'\t'); rownames(em)<-em$gene_id; em$gene_id<-NULL; em<-as.matrix(em)
meta <- rd(file.path(pre,'编码基因与探针.csv')); sm <- rd(file.path(pre,'样本分组.csv'))
stopifnot(identical(colnames(em),sm$sample_id),!anyNA(em),all(is.finite(em)))
gr <- factor(sm$group,levels=c('HC','IG','AG')); design <- model.matrix(~0+gr);colnames(design)<-levels(gr)
con <- makeContrasts(AG_HC=AG-HC,IG_HC=IG-HC,AG_IG=AG-IG,pooledGout_HC=(AG+IG)/2-HC,levels=design)
fit0 <- lmFit(em,design); fit <- eBayes(contrasts.fit(fit0,con),trend=TRUE,robust=TRUE)
fit_plain <- eBayes(contrasts.fit(fit0,con),trend=FALSE,robust=FALSE)
all3 <- matrix(p.adjust(fit$p.value[,1:3],method='BH'),nrow=nrow(em),ncol=3)
tables <- list()
for(k in seq_len(ncol(con))) {
 tab <- topTable(fit,coef=k,number=Inf,sort.by='none',adjust.method='BH',confint=TRUE)
 tab$gene_id <- rownames(tab)
 tab$gene_symbol<-meta$gene_symbol[match(tab$gene_id,meta$gene_id)]
 tab$probe_count<-meta$probe_count[match(tab$gene_id,meta$gene_id)]
 tab$q_all_three_contrasts <- if(k<=3) all3[,k] else NA_real_
 tab$plain_ebayes_P <- fit_plain$p.value[,k];tab$plain_ebayes_q<-p.adjust(tab$plain_ebayes_P,'BH')
 tab$primary_DEG<-tab$adj.P.Val<.05 & abs(tab$logFC)>=1
 tab<-tab[,c('gene_id','gene_symbol','probe_count','logFC','CI.L','CI.R','AveExpr','t','P.Value','adj.P.Val','q_all_three_contrasts','plain_ebayes_P','plain_ebayes_q','B','primary_DEG')]
 wr(tab,paste0(colnames(con)[k],'_全部编码基因.csv'));tables[[colnames(con)[k]]]<-tab
}
# Additional outcome-blind sensitivities from sample and RAW metadata.
age <- sm$age-mean(sm$age); d_age<-cbind(design,age=age)
c_age<-c(con[,1],age=0); f_age<-eBayes(contrasts.fit(lmFit(em,d_age),c_age),trend=TRUE,robust=TRUE)
ix <- gr %in% c('HC','AG'); d2<-model.matrix(~0+droplevels(gr[ix]));colnames(d2)<-c('HC','AG')
f2<-eBayes(contrasts.fit(lmFit(em[,ix],d2),c(-1,1)),trend=TRUE,robust=TRUE)
det <- rd(file.path(pre,'编码基因_高于背景标志.tsv'),'\t'); rownames(det)<-det$gene_id;det$gene_id<-NULL;det<-as.matrix(det)[rownames(em),colnames(em)]
det_n<-rowSums(det);keep<-det_n>=3
f_detect<-eBayes(contrasts.fit(lmFit(em[keep,],design),con[,1]),trend=TRUE,robust=TRUE)
sens<-data.frame(gene_id=rownames(em),age_adjusted_logFC=f_age$coefficients[,1],age_adjusted_P=f_age$p.value[,1],age_adjusted_q=p.adjust(f_age$p.value[,1],'BH'),two_group_logFC=f2$coefficients[,1],two_group_P=f2$p.value[,1],two_group_q=p.adjust(f2$p.value[,1],'BH'),detect_n_all12=det_n,detect_n_HC=rowSums(det[,gr=='HC',drop=FALSE]),detect_n_IG=rowSums(det[,gr=='IG',drop=FALSE]),detect_n_AG=rowSums(det[,gr=='AG',drop=FALSE]),detected3_filter_q=NA_real_)
sens$detected3_filter_q[keep]<-p.adjust(f_detect$p.value[,1],'BH');wr(sens,'主对比_年龄双组与背景检测敏感性.csv')
rawmeta<-rd(file.path(pre,'原始芯片_扫描与提取元数据.csv'))
rawmeta<-rawmeta[match(sm$sample_id,rawmeta$sample_id),]
date<-factor(substr(rawmeta$scan_date,1,10));session<-factor(rawmeta$scan_date)
d_date<-cbind(design,model.matrix(~date)[,-1,drop=FALSE]);c_date<-c(con[,1],rep(0,ncol(d_date)-3))
names(c_date)<-colnames(d_date)
d_session<-cbind(design,model.matrix(~session)[,-1,drop=FALSE])
stopifnot(qr(d_date)$rank==ncol(d_date))
f_date<-eBayes(contrasts.fit(lmFit(em,d_date),c_date),trend=TRUE,robust=TRUE)
jan<-substr(rawmeta$scan_date,1,10)=='01-19-2018';stopifnot(sum(jan&gr=='HC')==3,sum(jan&gr=='AG')==3)
f_jan<-eBayes(contrasts.fit(lmFit(em[,jan],design[jan,]),con[,1]),trend=TRUE,robust=TRUE)
wr(data.frame(gene_id=rownames(em),scan_date_adjusted_logFC=f_date$coefficients[,1],scan_date_adjusted_P=f_date$p.value[,1],scan_date_adjusted_q=p.adjust(f_date$p.value[,1],'BH'),same_day_HC3_AG3_logFC=f_jan$coefficients[,1],same_day_HC3_AG3_P=f_jan$p.value[,1],same_day_HC3_AG3_q=p.adjust(f_jan$p.value[,1],'BH')),'扫描日期与同日子集_敏感性.csv')
wr(data.frame(model=c('group','group_plus_scan_date','group_plus_scan_session'),columns=c(ncol(design),ncol(d_date),ncol(d_session)),rank=c(qr(design)$rank,qr(d_date)$rank,qr(d_session)$rank),estimable_full_rank=c(TRUE,TRUE,qr(d_session)$rank==ncol(d_session))),'扫描批次_设计秩核验.csv')
loo<-list()
for(i in which(gr=='AG')) {
 dl<-design[-i,,drop=FALSE];fl<-eBayes(contrasts.fit(lmFit(em[,-i,drop=FALSE],dl),con[,1]),trend=TRUE,robust=TRUE)
 loo[[length(loo)+1]]<-data.frame(gene_id=rownames(em),omitted_sample=sm$sample_id[i],logFC=fl$coefficients[,1],P.Value=fl$p.value[,1],q=p.adjust(fl$p.value[,1],'BH'))
}
wr(do.call(rbind,loo),'逐个急性样本剔除_全部编码基因.csv')
# CAMERA uses complete KEGG membership and the assayed coding-gene background.
members<-rd(file.path(pre,'KEGG九通路_完整成员.csv'))
gene_symbols<-meta$gene_symbol[match(rownames(em),meta$gene_id)]
sets<-lapply(split(members$gene_symbol,members$term_id),unique)
indices<-lapply(sets,function(s) which(gene_symbols %in% s))
stopifnot(all(lengths(indices)>=5))
cam<-camera(em,index=indices,design=design,contrast=con[,1],inter.gene.cor=.01,trend.var=TRUE,sort=FALSE)
cam$term_id<-rownames(cam);cam$primary5<-members$primary5[match(cam$term_id,members$term_id)]
cam$q_nine<-cam$FDR;cam$q_five<-NA_real_;cam$q_five[cam$primary5==1]<-p.adjust(cam$PValue[cam$primary5==1],'BH')
cam$pathway_name<-members$pathway_name[match(cam$term_id,members$term_id)]
cam$measured_gene_symbols<-vapply(cam$term_id,function(id)paste(gene_symbols[indices[[id]]],collapse=';'),character(1))
cam_date<-camera(em,index=indices,design=d_date,contrast=c_date,inter.gene.cor=.01,trend.var=TRUE,sort=FALSE)
cam$date_adjusted_direction<-cam_date$Direction[match(cam$term_id,rownames(cam_date))]
cam$date_adjusted_P<-cam_date$PValue[match(cam$term_id,rownames(cam_date))]
cam$date_adjusted_q_nine<-p.adjust(cam$date_adjusted_P,'BH');cam$date_adjusted_q_five<-NA_real_
cam$date_adjusted_q_five[cam$primary5==1]<-p.adjust(cam$date_adjusted_P[cam$primary5==1],'BH')
wr(cam,'预设通路_CAMERA竞争检验.csv')
pc<-prcomp(t(em),center=TRUE,scale.=FALSE);pcdf<-data.frame(sample_id=rownames(pc$x),pc$x[,1:5]);pcdf$group<-sm$group[match(pcdf$sample_id,sm$sample_id)];wr(pcdf,'PCA_样本坐标.csv')
wr(data.frame(component=seq_along(pc$sdev),variance_fraction=pc$sdev^2/sum(pc$sdev^2)),'PCA_解释方差.csv')
wr(data.frame(sample_id=colnames(em),cor(em),check.names=FALSE),'样本相关矩阵.csv')
wr(data.frame(contrast=names(tables),tested_genes=nrow(em),BH05=vapply(tables,function(x)sum(x$adj.P.Val<.05),integer(1)),BH05_FC2=vapply(tables,function(x)sum(x$primary_DEG),integer(1)),up=vapply(tables,function(x)sum(x$primary_DEG & x$logFC>0),integer(1)),down=vapply(tables,function(x)sum(x$primary_DEG & x$logFC<0),integer(1))),'差异分析计数.csv')
wr(data.frame(gene_id=rownames(em),residual_df=fit$df.residual,moderated_total_df=fit$df.total,unmoderated_sigma=fit$sigma,posterior_variance=fit$s2.post,prior_variance=fit$s2.prior,prior_df=fit$df.prior,stdev_unscaled_AG_HC=fit$stdev.unscaled[,1]),'limma_方差与自由度审计.csv')
saveRDS(list(em=em,meta=meta,samples=sm,design=design,contrasts=con,fit=fit,fit_plain=fit_plain,fit_age=f_age,fit_two_group=f2,fit_date=f_date,fit_jan=f_jan),file.path(res,'limma模型与输入.rds'))
writeLines(c(capture.output(sessionInfo()),'Primary: limma eBayes trend=TRUE robust=TRUE; BH within transcriptome AG-HC; FC2 threshold.','Secondary contrasts separately BH; 3-contrast combinedBH sensitivity.','Additional sensitivity age (metadata age available), AGHC-only fit, label-blind detected>=3/12; LOO AG.','RAW scanning sessions discovered before fitting: AG completely confounded with exact scan session. Date adjustment estimable, exact-session adjustment NOT estimable; date-adjusted and same-day HC3/AG3 provided, neither removes session confounding. No ComBat used.','No additional quantile normalization or log2 transformation.'),file.path(res,'分析方法与软件版本.txt'))
print(rd(file.path(res,'差异分析计数.csv')))
cat('FIT_COMPLETE',nrow(em),'coding genes',ncol(em),'independent samples\n')
