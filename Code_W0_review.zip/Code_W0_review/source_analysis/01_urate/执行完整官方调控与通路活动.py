from pathlib import Path
import sys,json,hashlib,datetime,importlib.metadata
P=Path(__file__).resolve().parent;E=P.parents[1];G=Path('G:/痛风/第二步_靶点预测与疾病交集')
for p in reversed([E/'runtime/decoupler_libraries',G/'runtime/ppi_analysis_libraries',G/'论文推进_2026-10-30/单细胞定位/runtime']):sys.path.insert(0,str(p))
import numpy as np,pandas as pd,decoupler as dc
O=P/'实际模型结果';A=P/'完整调控与通路活动';A.mkdir(exist_ok=True)
expr=pd.read_csv(O/'全合格symbol_归一化log2表达.tsv',sep='\t',index_col=0)
meta=pd.read_csv(P/'输入与来源QC/20样本_官方供体与处理design.tsv',sep='\t');meta=meta[meta.condition!='T0'];assert expr.columns.tolist()==meta.sample_id.tolist()
X=expr.sub(expr.mean(axis=1),axis=0).T
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths={'CollecTRI':E/'02_decoupler官方方法/冻结CollecTRI_monoTF网络.tsv','PROGENy':E/'02_decoupler官方方法/PROGENy_次级通路足迹/PROGENy_官方默认完整网络.tsv'}
contract={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before_all_activity_outcomes':True,'method':'Official decoupler2.3.1 mt.ulm on within-gene centered normalized log2MMSEQ expression, one activity estimate per sample','features':len(expr),'samples':16,'tmin':5,'full_TF_source_not_forced_to_previous_dataset_548':True,'PROGENy_all_edges_no_top500_or_padj_weight_filter':True,'patient_level_model':'Same donor-blocked factorial design, limma eBayes robust TRUE trend FALSE for activity feature families. Complete percontrast BH and all4contrast BH retained; gene-level ULM P is not donor-level evidence.','families':'All eligible sources per network, no outcome-based source filtering; source eligibility remains reported for full resource.','files':[{'path':str(p),'sha256':sha(p)} for p in paths.values()]}
cf=A/'活动评分与推断_结果前协议.json'
if not cf.exists():cf.write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
assert importlib.metadata.version('decoupler')=='2.3.1'
summaries=[]
for name,path in paths.items():
 net=pd.read_csv(path,sep='\t')[['source','target','weight']];assert not net.duplicated(['source','target']).any()
 covered=net.assign(present=net.target.isin(X.columns)).groupby('source',sort=True).agg(network_targets=('target','nunique'),present_targets=('present','sum')).reset_index();covered['eligible_tmin5']=covered.present_targets>=5;covered.to_csv(A/f'{name}_完整资源目标覆盖与资格.tsv',sep='\t',index=False)
 es,conditionalq=dc.mt.ulm(data=X,net=net,tmin=5,verbose=False);assert es.index.tolist()==X.index.tolist();assert set(es.columns)==set(covered.loc[covered.eligible_tmin5,'source'])
 es.T.rename_axis('feature_id').to_csv(A/f'{name}_16样本_官方ULM活动.tsv',sep='\t')
 conditionalq.T.rename_axis('feature_id').to_csv(A/f'{name}_条件性基因回归BH_不作供体检验.tsv',sep='\t')
 summaries.append({'network':name,'full_sources':len(covered),'eligible_sources':es.shape[1],'target_edges':len(net),'input_features_all_retained':len(X.columns),'activity_finite':bool(np.isfinite(es.to_numpy()).all())})
# Fixed12 per-sample source, preserving low-information/absent entries.
cand=pd.read_csv(P/'输入与来源QC/冻结12candidate.tsv',sep='\t').gene_symbol.tolist();rows=[]
for gene in cand:
 for r in meta.itertuples():rows.append({'gene_symbol':gene,'sample_id':r.sample_id,'donor':r.donor,'condition':r.condition,'UA':r.UA,'LPS':r.LPS,'log2_normalized_MMSEQ_expression':float(expr.loc[gene,r.sample_id]) if gene in expr.index else np.nan,'eligible_expression_gene':gene in expr.index})
pd.DataFrame(rows).to_csv(O/'固定12_每供体四条件_成图source.tsv',sep='\t',index=False)
(A/'官方活动计算_实际完成状态.json').write_text(json.dumps({'status':'ACTUAL_OFFICIAL_ACTIVITY_SCORES_COMPLETE','version':importlib.metadata.version('decoupler'),'input_expression_sha256':sha(O/'全合格symbol_归一化log2表达.tsv'),'networks':summaries},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summaries,ensure_ascii=False),flush=True)
