options(stringsAsFactors=FALSE)
P <- normalizePath('E:/痛风/研究深化_2026-11-02/07_实测药物与功能验证/01_尿酸刺激独立数据',winslash='/')
.libPaths(c('G:/痛风/第二步_靶点预测与疾病交集/runtime/R_geo_libraries',.libPaths()))
library(limma)
library(statmod)
O <- file.path(P,'实际模型结果');dir.create(O,showWarnings=FALSE)
writeTSV <- function(x,p)write.table(x,p,sep='\t',quote=FALSE,row.names=FALSE,na='NA')
meta <- read.delim(file.path(P,'输入与来源QC/20样本_官方供体与处理design.tsv'),check.names=FALSE)
m <- meta[meta$condition!='T0',];stopifnot(nrow(m)==16,length(unique(m$donor))==4)
m$condition <- factor(m$condition,levels=c('RPMI','UA','RPMI_LPS','UA_LPS'));m$donor <- factor(m$donor,levels=paste0('Donor_',1:4))
stopifnot(all(table(m$donor,m$condition)==1))
design <- model.matrix(~0+condition+donor,m);colnames(design)<-sub('condition','',colnames(design));stopifnot(qr(design)$rank==7,nrow(design)-qr(design)$rank==9)
C<-makeContrasts(UAxLPS=UA_LPS-UA-RPMI_LPS+RPMI,UA_without_LPS=UA-RPMI,UA_with_LPS=UA_LPS-RPMI_LPS,LPS_within_RPMI_positive_control=RPMI_LPS-RPMI,levels=design)
writeTSV(cbind(sample_id=m$sample_id,as.data.frame(design)),file.path(O,'16样本_供体阻断完整设计矩阵.tsv'));writeTSV(cbind(coefficient=rownames(C),as.data.frame(C)),file.path(O,'4项预冻结contrast矩阵.tsv'))
source(file.path(P,'方法与匹配注释/官方_mmseq.R'))
ms<-readmmseq(mmseq_files=m$file,sample_names=m$sample_id,normalize=TRUE)
E<-ms$log_mu/log(2)
a<-read.delim(file.path(P,'输入与来源QC/Ensembl68_geneID到symbol_完整映射与资格源.tsv'),check.names=FALSE);stopifnot(identical(rownames(E),a$feature_id))
keep <- rowSums(ms$observed==1)>=4 & rowSums(is.finite(E))==ncol(E) & apply(E,1,var)>0
a$tested_main_gene<-keep;writeTSV(a,file.path(O,'所有原始基因_信息资格与保留状态.tsv'))
E<-E[keep,,drop=FALSE];anno<-a[keep,,drop=FALSE];writeTSV(cbind(feature_id=rownames(E),as.data.frame(E)),file.path(O,'全合格gene_官方归一化log2表达.tsv'))
# Same-symbol IDs are pooled on linear expression scale; no P/FC-based representative selection.
groups<-split(which(nzchar(anno$gene_symbol)),anno$gene_symbol[nzchar(anno$gene_symbol)])
S<-do.call(rbind,lapply(groups,function(ix)log2(colSums(2^E[ix,,drop=FALSE]))));colnames(S)<-colnames(E)
writeTSV(cbind(gene_symbol=rownames(S),as.data.frame(S)),file.path(O,'全合格symbol_归一化log2表达.tsv'))
symanno<-data.frame(feature_id=rownames(S),gene_symbol=rownames(S),source_gene_IDs=sapply(groups,function(ix)paste(anno$feature_id[ix],collapse=';')))
calculate_donor <- function(expr,contrast){
 out<-matrix(NA_real_,nrow(expr),4,dimnames=list(rownames(expr),paste0('Donor',1:4,'_contrast')))
 for(d in 1:4){ii<-which(m$donor==paste0('Donor_',d));x<-expr[,ii,drop=FALSE];colnames(x)<-as.character(m$condition[ii]);out[,d]<-switch(contrast,UAxLPS=x[,'UA_LPS']-x[,'UA']-x[,'RPMI_LPS']+x[,'RPMI'],UA_without_LPS=x[,'UA']-x[,'RPMI'],UA_with_LPS=x[,'UA_LPS']-x[,'RPMI_LPS'],LPS_within_RPMI_positive_control=x[,'RPMI_LPS']-x[,'RPMI'])}
 out
}
fit_and_export<-function(expr,annotation,prefix,trend=TRUE){
 stopifnot(identical(colnames(expr),m$sample_id));fit<-eBayes(contrasts.fit(lmFit(expr,design),C),trend=trend,robust=TRUE)
 globalQ<-matrix(p.adjust(as.vector(fit$p.value),method='BH'),nrow=nrow(expr),dimnames=dimnames(fit$p.value))
 all<-list()
 for(k in colnames(C)){
  tt<-topTable(fit,coef=k,number=Inf,sort.by='none',adjust.method='BH',confint=.95);stopifnot(identical(rownames(tt),rownames(expr)))
  dv<-calculate_donor(expr,k);mu<-rowMeans(dv);se<-apply(dv,1,sd)/2;tu<-mu/se;pu<-2*pt(-abs(tu),df=3);pu[is.nan(pu)]<-1
  tab<-cbind(annotation,contrast=k,tt,BH_all4contrast_gene_family=globalQ[,k],unmoderated_4donor_mean=mu,unmoderated_4donor_SE=se,unmoderated_4donor_t=tu,unmoderated_4donor_P=pu,unmoderated_4donor_BH=p.adjust(pu,'BH'),donors_positive=rowSums(dv>0),dv)
  writeTSV(tab,file.path(O,paste0(prefix,'_',k,'_完整结果.tsv')));all[[k]]<-tab
 }
 list(fit=fit,results=all)
}
gene<-fit_and_export(E,anno,'EnsemblGene',TRUE);symbol<-fit_and_export(S,symanno,'SymbolGene',TRUE)
cand<-read.delim(file.path(P,'输入与来源QC/冻结12candidate.tsv'))$gene_symbol;candidate_tables<-list()
for(k in colnames(C)){
 tab<-symbol$results[[k]];out<-tab[match(cand,tab$gene_symbol),,drop=FALSE];out$gene_symbol<-cand;out$feature_id<-cand;out$contrast<-k;out$eligible_symbol_expression<-cand%in%rownames(S);out$BH_fixed12_family<-NA_real_;good<-is.finite(out$P.Value);out$BH_fixed12_family[good]<-p.adjust(out$P.Value[good],'BH',n=12);candidate_tables[[k]]<-out
}
ct<-do.call(rbind,candidate_tables);ct$BH_fixed12x4_family<-NA_real_;good<-is.finite(ct$P.Value);ct$BH_fixed12x4_family[good]<-p.adjust(ct$P.Value[good],'BH',n=48);writeTSV(ct,file.path(O,'冻结12candidate_4contrast_完整结果.tsv'))
pc<-prcomp(t(E),scale.=FALSE,center=TRUE);pv<-pc$sdev^2/sum(pc$sdev^2);writeTSV(cbind(m[,c('sample_id','donor','condition','UA','LPS')],pc$x[,1:4]),file.path(O,'16样本_PCA_成图source.tsv'));writeTSV(data.frame(PC=paste0('PC',seq_along(pv)),variance_fraction=pv),file.path(O,'PCA解释率.tsv'))
qs<-t(apply(E,2,quantile,probs=c(.01,.25,.5,.75,.99)));writeTSV(cbind(sample_id=rownames(qs),as.data.frame(qs)),file.path(O,'log2表达分布_成图source.tsv'))
saveRDS(list(metadata=m,design=design,contrasts=C,genes=E,symbol=S,annotation=anno,symbol_annotation=symanno,gene_fit=gene$fit,symbol_fit=symbol$fit),file.path(O,'供体阻断_完整可复现对象.rds'))
capture.output(sessionInfo(),file=file.path(O,'R_sessionInfo.txt'))
summary<-do.call(rbind,lapply(names(gene$results),function(k){x<-gene$results[[k]];data.frame(contrast=k,n_tested=nrow(x),nominal_P_lt05=sum(x$P.Value<.05),BH_lt05=sum(x$adj.P.Val<.05),min_BH=min(x$adj.P.Val),global4_BH_lt05=sum(x$BH_all4contrast_gene_family<.05),unmoderated_4donor_BH_lt05=sum(x$unmoderated_4donor_BH<.05))}));writeTSV(summary,file.path(O,'全基因contrast_完整族统计摘要.tsv'));print(summary);cat('MODELS_COMPLETE genes',nrow(E),'symbols',nrow(S),'residual_df',unique(gene$fit$df.residual),'\n')
