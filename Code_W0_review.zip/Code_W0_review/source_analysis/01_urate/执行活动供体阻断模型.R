options(stringsAsFactors=FALSE)
P<-'E:/痛风/研究深化_2026-11-02/07_实测药物与功能验证/01_尿酸刺激独立数据'
.libPaths(c('G:/痛风/第二步_靶点预测与疾病交集/runtime/R_geo_libraries',.libPaths()));library(limma);library(statmod)
A<-file.path(P,'完整调控与通路活动');x<-readRDS(file.path(P,'实际模型结果/供体阻断_完整可复现对象.rds'));m<-x$metadata;design<-x$design;C<-x$contrasts
writeTSV<-function(x,p)write.table(x,p,sep='\t',quote=FALSE,row.names=FALSE,na='NA')
donorDiff<-function(expr,k){
 out<-matrix(NA_real_,nrow(expr),4,dimnames=list(rownames(expr),paste0('Donor',1:4,'_contrast')))
 for(d in 1:4){ii<-which(m$donor==paste0('Donor_',d));v<-expr[,ii,drop=FALSE];colnames(v)<-as.character(m$condition[ii]);out[,d]<-switch(k,UAxLPS=v[,'UA_LPS']-v[,'UA']-v[,'RPMI_LPS']+v[,'RPMI'],UA_without_LPS=v[,'UA']-v[,'RPMI'],UA_with_LPS=v[,'UA_LPS']-v[,'RPMI_LPS'],LPS_within_RPMI_positive_control=v[,'RPMI_LPS']-v[,'RPMI'])};out
}
summary<-list()
for(network in c('CollecTRI','PROGENy')){
 d<-read.delim(file.path(A,paste0(network,'_16样本_官方ULM活动.tsv')),check.names=FALSE);mat<-as.matrix(d[,-1]);rownames(mat)<-d$feature_id;stopifnot(identical(colnames(mat),m$sample_id),all(is.finite(mat)))
 fit<-eBayes(contrasts.fit(lmFit(mat,design),C),trend=FALSE,robust=TRUE)
 gq<-matrix(p.adjust(as.vector(fit$p.value),'BH'),nrow(mat),dimnames=dimnames(fit$p.value))
 for(k in colnames(C)){
  tt<-topTable(fit,coef=k,number=Inf,sort.by='none',confint=.95);dv<-donorDiff(mat,k);mu<-rowMeans(dv);se<-apply(dv,1,sd)/2;t<-mu/se;p<-2*pt(-abs(t),df=3);p[is.nan(p)]<-1
  out<-cbind(feature_id=rownames(mat),network=network,contrast=k,tt,BH_all4contrast_family=gq[,k],unmoderated_4donor_mean=mu,unmoderated_4donor_SE=se,unmoderated_4donor_t=t,unmoderated_4donor_P=p,unmoderated_4donor_BH=p.adjust(p,'BH'),donors_positive=rowSums(dv>0),dv)
  writeTSV(out,file.path(A,paste0(network,'_',k,'_供体阻断完整结果.tsv')))
  summary[[paste(network,k)]]<-data.frame(network=network,contrast=k,n_tested=nrow(mat),nominal_P_lt05=sum(out$P.Value<.05),BH_lt05=sum(out$adj.P.Val<.05),min_BH=min(out$adj.P.Val),unmoderated_4donor_BH_lt05=sum(out$unmoderated_4donor_BH<.05))
 }
 saveRDS(list(activity_matrix=mat,model=fit,metadata=m,design=design,contrasts=C),file.path(A,paste0(network,'_供体阻断完整模型.rds')))
}
z<-do.call(rbind,summary);writeTSV(z,file.path(A,'TF与通路_4contrast完整族统计摘要.tsv'));print(z);cat('ACTIVITY_DONOR_MODELS_COMPLETE\n')
