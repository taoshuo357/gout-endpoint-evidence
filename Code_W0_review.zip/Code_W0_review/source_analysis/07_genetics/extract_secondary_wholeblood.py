from pathlib import Path
import json,urllib.request,time,hashlib
from extract_indexed_regions import read_tbi,extract,decode_bgzf,NETWORK_LOG,ROOT
P=ROOT
genes=json.loads((P/'GTEx_v8_12gene_reference.json').read_text())['data']
scope=dict(fixed_before_secondary_wholeblood_results=True,frozen_at_local='2026-10-30',tissues=['BLUEPRINT naive monocyte QTD000021 N191','GTEx whole blood QTD000356 N670'],genes=[g['geneSymbol'] for g in genes],outcome='GCST90428600 European non23andMe gout',instrument_p_threshold=5e-8,instrument_F_min_exclusive=10,primary_instrument='strongest nonpalindromic biallelic cis SNP selected by exposure only; no outcome-driven replacement',family_size=24,correction='Bonferroni 24 for all gene-tissue Wald tests; not-tested NA; no pseudo P reported',coloc='all dense available nominal cis variants; p12 1e-6,1e-5,1e-4; pp4 >=0.8 robust across three priors',ancestry_caution='GTEx donors are multi-ancestry; do not claim strictly ancestry-matched or a monocyte cell-specific effect',no_other_tissue_expansion_this_round=True)
(P/'第二组织分析前_固定分析范围.json').write_text(json.dumps(scope,ensure_ascii=False,indent=2),encoding='utf-8')
Q='https://ftp.ebi.ac.uk/pub/databases/spot/eQTL/sumstats/QTS000015/QTD000356/QTD000356.all.tsv.gz'
for name,url,rng in [('GTEXWholeBlood.tbi',Q+'.tbi',None),('GTEXWholeBlood_header.bgzf',Q,'0-65535')]:
 p=P/name
 if not p.exists():
  h={'User-Agent':'GoutPublicRegionFollowup/1.0'}
  if rng:h['Range']='bytes='+rng
  with urllib.request.urlopen(urllib.request.Request(url,headers=h),timeout=50) as r:
   if rng:assert r.status==206
   b=r.read(5_000_001 if not rng else 65537)
   assert len(b)<=5_000_000 if not rng else len(b)<=65536
   p.write_bytes(b)
   NETWORK_LOG.append(dict(url=url,range=rng,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),content_range=r.headers.get('Content-Range')))
  time.sleep(2)
(P/'GTEXWholeBlood_header.tsv').write_text('\n'.join(decode_bgzf((P/'GTEXWholeBlood_header.bgzf').read_bytes()).splitlines()[:4]),encoding='utf-8')
index=read_tbi(P/'GTEXWholeBlood.tbi');manifest=[]
for g in genes:
 gene=g['geneSymbol'];chrom=g['chromosome'].replace('chr','');start=max(1,g['start']-1000000);end=g['end']+1000000
 r=dict(gene=gene,gene_id=g['gencodeId'].split('.')[0],chromosome=chrom,start_GRCh38=start,end_GRCh38=end)
 try:
  path=P/f'GTEXWholeBlood_{gene}_all_cis.tsv.gz'
  r['eqtl_rows']=extract('GTEXWholeBlood',Q,index,chrom,start,end,path,r['gene_id']);r['eqtl_path']=str(path);r['status']='regional_stats_obtained'
 except Exception as e:r.update(status='incomplete',error=str(e))
 manifest.append(r);print(json.dumps(r,ensure_ascii=False),flush=True)
 (P/'GTExWholeBlood_12靶点_区域资源.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
 (P/'HTTP_Range下载记录.json').write_text(json.dumps(NETWORK_LOG,ensure_ascii=False,indent=2),encoding='utf-8')
