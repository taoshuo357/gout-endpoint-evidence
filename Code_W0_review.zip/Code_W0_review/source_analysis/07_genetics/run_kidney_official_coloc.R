args <- commandArgs(trailingOnly=FALSE)
project <- getwd()
source_root <- file.path(project,'全面验证_2026-11-02','04_遗传补强')
root <- if('--whole-blood' %in% commandArgs(trailingOnly=TRUE)) file.path(source_root,'GTExWholeBlood_analysis') else source_root
# Source contains only function definitions; downloaded from the official coloc repository.
# We execute the official core functions rather than claiming the full coloc package is installed.
source(file.path(source_root,'coloc_official_claudia.R'),local=TRUE)
params <- read.delim(file.path(root,'coloc_model_parameters.tsv'),check.names=FALSE)
ans <- list(); constrained <- list(); maximum_sdY_difference <- 0
for(i in seq_len(nrow(params))) {
 gene <- params$gene[i]
 d <- read.delim(file.path(root,paste0(gene,'_harmonized_full_nominal.tsv')),check.names=FALSE)
 if(nrow(d)<100) next
 q <- read.delim(file.path(root,paste0(gene,'_exposure_full_for_sdY.tsv')),check.names=FALSE)
 sy <- sdY.est(q$eqtl_se^2,q$eqtl_maf,params$N[i])
 maximum_sdY_difference <- max(maximum_sdY_difference,abs(sy-params$sdY[i]))
 stopifnot(abs(sy-params$sdY[i])<1e-10)
 for(sdytype in c('estimated_sdY','sdY_1_sensitivity')) {
  sy1 <- if(sdytype=='estimated_sdY') sy else 1
  bf1 <- approx.bf.estimates(d$eqtl_beta/d$eqtl_se,d$eqtl_se^2,type='quant',sdY=sy1)
  bf2 <- approx.bf.estimates(d$gwas_beta_ALT/d$gwas_se,d$gwas_se^2,type='cc')
  for(prior in c(1e-6,1e-5,1e-4)) {
   # Match coloc.abf's check for oversized region-wide prior mass.
   p1 <- adjust_prior(1e-4,nrow(q),'p1')
   p2 <- adjust_prior(1e-4,params$n_gwas_full[i],'p2')
   p12 <- adjust_prior(prior,nrow(d),'p12')
   pp <- combine.abf(bf1$lABF,bf2$lABF,p1,p2,p12,quiet=TRUE)
   rr <- data.frame(gene=gene,model=sdytype,sdY=sy1,n_common=nrow(d),p1=p1,p2=p2,p12_requested=prior,p12=p12,t(pp),check.names=FALSE)
   ans[[length(ans)+1]] <- rr
   p12c <- min(p12,p1,p2)
   ppc <- combine.abf(bf1$lABF,bf2$lABF,p1,p2,p12c,quiet=TRUE)
   constrained[[length(constrained)+1]] <- data.frame(gene=gene,model=sdytype,sdY=sy1,n_common=nrow(d),p1=p1,p2=p2,p12_requested=prior,p12_after_official_adjust=p12,official_joint_prior_exceeds_marginal=p12>min(p1,p2),p12_constrained=p12c,t(ppc),check.names=FALSE)
  }
 }
 cat(gene,'n=',nrow(d),'\n')
}
if(!('--sensitivity-only' %in% commandArgs(trailingOnly=TRUE))) write.table(do.call(rbind,ans),file.path(root,'official_coloc_posteriors.tsv'),sep='\t',row.names=FALSE,quote=FALSE)
write.table(do.call(rbind,constrained),file.path(root,'official_coloc_posteriors_constrained.tsv'),sep='\t',row.names=FALSE,quote=FALSE)
writeLines(c(capture.output(sessionInfo()),paste('Official functions source: coloc GitHub main downloaded 2026-10-30; exact source SHA256 recorded separately; package DESCRIPTION version inspected.'),paste('Maximum Python versus official R sdY difference',format(maximum_sdY_difference,digits=16))),file.path(root,'R_coloc_session_and_crosscheck.txt'))
writeLines(capture.output(warnings()),file.path(root,'R_coloc_warnings.txt'))
