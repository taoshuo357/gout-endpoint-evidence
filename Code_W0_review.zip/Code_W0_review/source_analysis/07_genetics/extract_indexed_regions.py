from pathlib import Path
import struct,gzip,json,urllib.request,time,csv,io,re,hashlib,shutil
ROOT=Path(__file__).resolve().parent
LOGPATH=ROOT/'HTTP_Range下载记录.json'
NETWORK_LOG=json.loads(LOGPATH.read_text(encoding='utf-8')) if LOGPATH.exists() else []
def read_tbi(path):
 raw=path.read_bytes()
 if raw[:2]==b'\x1f\x8b':raw=gzip.decompress(raw)
 assert raw[:4]==b'TBI\x01'
 nr,fmt,cseq,cbeg,cend,meta,skip,ln=struct.unpack_from('<8i',raw,4);p=36
 names=raw[p:p+ln].rstrip(b'\0').decode().split('\0');p+=ln;data={}
 for name in names:
  nb=struct.unpack_from('<i',raw,p)[0];p+=4;bins={}
  for _ in range(nb):
   b,n=struct.unpack_from('<Ii',raw,p);p+=8
   bins[b]=[struct.unpack_from('<QQ',raw,p+16*i) for i in range(n)];p+=16*n
  ni=struct.unpack_from('<i',raw,p)[0];p+=4;linear=list(struct.unpack_from('<'+'Q'*ni,raw,p));p+=8*ni
  data[name]=(bins,linear)
 return dict(format=fmt,col_seq=cseq,col_beg=cbeg,col_end=cend,meta=meta,skip=skip,names=names,refs=data)
def reg2bins(beg,end):
 end-=1;out=[0]
 for offset,shift in [(1,26),(9,23),(73,20),(585,17),(4681,14)]:out.extend(range(offset+(beg>>shift),offset+(end>>shift)+1))
 return out
def query_chunks(index,chrom,start,end):
 bins,linear=index['refs'][str(chrom)];beg=max(0,start-1)
 mo=linear[min(beg>>14,len(linear)-1)] if linear else 0
 chunks=sorted((max(b,mo),e) for bn in reg2bins(beg,end) for b,e in bins.get(bn,[]) if e>mo)
 merged=[]
 for b,e in chunks:
  if merged and b<=merged[-1][1]:merged[-1][1]=max(e,merged[-1][1])
  else:merged.append([b,e])
 return merged
def decode_bgzf(b):
 pos=0;out=[]
 while pos+18<=len(b):
  if b[pos:pos+2]!=b'\x1f\x8b':break
  xlen=struct.unpack_from('<H',b,pos+10)[0];extra=b[pos+12:pos+12+xlen];j=0;sz=None
  while j+4<=len(extra):
   ln=struct.unpack_from('<H',extra,j+2)[0]
   if extra[j:j+2]==b'BC':sz=struct.unpack_from('<H',extra,j+4)[0]+1
   j+=4+ln
  if sz is None or pos+sz>len(b):break
  out.append(gzip.decompress(b[pos:pos+sz]));pos+=sz
 return b''.join(out).decode('utf-8')
def get_range(url,start,end,label):
 cache=ROOT/'range_cache';cache.mkdir(exist_ok=True)
 p=cache/f'{label}_{start}_{end}.bgzf'
 if p.exists():return p.read_bytes()
 n=end-start+1
 if n>60_000_000:raise ValueError(f'Planned range {n} bytes exceeds 60MB cap')
 if sum(x.stat().st_size for x in cache.glob('*.bgzf'))+n>850_000_000:raise ValueError('Cumulative cached Range downloads would exceed 850MB reserve cap')
 if shutil.disk_usage(ROOT).free<3_000_000_000:raise ValueError('G free space below reserved 3GB')
 req=urllib.request.Request(url,headers={'Range':f'bytes={start}-{end}','User-Agent':'GoutLocalRegionResearch/1.0'})
 with urllib.request.urlopen(req,timeout=60) as r:
  if r.status!=206:raise ValueError(f'Range not honored: {r.status}')
  b=r.read(n+1)
  if len(b)>n:raise ValueError('oversized Range response')
  p.write_bytes(b);NETWORK_LOG.append(dict(url=url,range=f'{start}-{end}',content_range=r.headers.get('Content-Range'),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
 time.sleep(2)
 return b
def extract(prefix,url,index,chrom,start,end,outpath,gene_id=None):
 if outpath.exists():
  with gzip.open(outpath,'rt',encoding='utf-8') as f:return sum(1 for line in f if line.strip())-1
 chunks=query_chunks(index,chrom,start,end)
 # Contiguous compressed range reduces EBI request frequency; source rows are position-filtered after reading.
 if not chunks:return 0
 lo=min(b>>16 for b,e in chunks);hi=max(e>>16 for b,e in chunks)+65535
 text=decode_bgzf(get_range(url,lo,hi,prefix))
 header=(ROOT/(prefix+'_header.tsv')).read_text(encoding='utf-8').splitlines()[0].split('\t')
 seq=header.index('chromosome');pos=header.index('position' if 'position' in header else 'base_pair_location');gi=header.index('gene_id') if gene_id else None
 records=[];seen=set()
 for line in text.splitlines():
  cells=line.split('\t')
  if len(cells)!=len(header):continue
  if cells[seq]!=str(chrom):continue
  try:p=int(cells[pos])
  except:continue
  if not(start<=p<=end):continue
  if gene_id and cells[gi].split('.')[0]!=gene_id:continue
  if line not in seen:records.append(line);seen.add(line)
 with gzip.open(outpath,'wt',encoding='utf-8',newline='') as f:f.write('\t'.join(header)+'\n'+'\n'.join(records)+'\n')
 return len(records)
def main():
 genes=json.loads((ROOT/'GTEx_v8_12gene_reference.json').read_text())['data']
 Q='https://ftp.ebi.ac.uk/pub/databases/spot/eQTL/sumstats/QTS000002/QTD000021/QTD000021.all.tsv.gz'
 W='https://ftp.ebi.ac.uk/pub/databases/gwas/summary_statistics/GCST90428001-GCST90429000/GCST90428600/harmonised/GCST90428600.h.tsv.gz'
 qi=read_tbi(ROOT/'BLUEPRINT.tbi');wi=read_tbi(ROOT/'gout_GCST90428600_harmonised.tbi')
 manifest=[]
 for g in genes:
  gene=g['geneSymbol'];chrom=g['chromosome'].replace('chr','');start=max(1,g['start']-1000000);end=g['end']+1000000
  r=dict(gene=gene,gene_id=g['gencodeId'].split('.')[0],chromosome=chrom,start_GRCh38=start,end_GRCh38=end)
  try:
   qp=ROOT/f'BLUEPRINT_monocyte_{gene}_all_cis.tsv.gz';wp=ROOT/f'gout_GCST90428600_{gene}_region.tsv.gz'
   r['eqtl_rows']=extract('BLUEPRINT',Q,qi,chrom,start,end,qp,r['gene_id']);r['eqtl_path']=str(qp)
   r['gwas_rows']=extract('gout_GCST90428600_harmonised',W,wi,chrom,start,end,wp);r['gwas_path']=str(wp)
   r['status']='regional_stats_obtained'
  except Exception as e:r['status']='incomplete';r['error']=str(e)
  manifest.append(r);print(json.dumps(r,ensure_ascii=False),flush=True)
  (ROOT/'12靶点_公开cis与GWAS区域资源.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
  (ROOT/'HTTP_Range下载记录.json').write_text(json.dumps(NETWORK_LOG,ensure_ascii=False,indent=2),encoding='utf-8')
if __name__=='__main__':main()
