from pathlib import Path
import csv,json,math,hashlib,shutil,sys
P=Path(__file__).resolve().parent
genes=['NLRP3','CASP1','IL1B','XDH','SLC22A12','ABCG2','SLC2A9','TLR4','RELA','NFKB1','TNF','AKT1']
def load(p):
 with p.open(encoding='utf-8') as f:return list(csv.DictReader(f,delimiter='\t'))
def save(name,data):
 fields=list(dict.fromkeys(k for r in data for k in r))
 with (P/name).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,delimiter='\t');w.writeheader();w.writerows(data)
all_audit=[];all_pp=[];all_sens=[];all_wald=[];all_raw=[]
for tissue,folder in [('BLUEPRINT_monocyte',P),('GTEx_whole_blood',P/'GTExWholeBlood_analysis')]:
 audits={a['gene']:a for a in load(folder/'12靶点_区域等位基因与覆盖审计.tsv')}
 pp=load(folder/'official_coloc_posteriors.tsv');sens=load(folder/'official_coloc_posteriors_constrained.tsv')
 leads={r['gene']:r for r in load(folder/'12靶点_暴露独立选择的cis主工具与Wald.tsv')}
 primary={r['gene']:r for r in pp if r['model']=='estimated_sdY' and math.isclose(float(r['p12_requested']),1e-5)}
 for r in pp:
  r.update(tissue=tissue,joint_prior_valid=float(r['p12'])<=min(float(r['p1']),float(r['p2'])));all_raw.append(r)
 for r in sens:r['tissue']=tissue;all_sens.append(r)
 for gene in genes:
  a=audits[gene];r=dict(a);r['tissue']=tissue
  if gene in primary:
   r.update({f'PP_H{i}':primary[gene][f'PP.H{i}.abf'] for i in range(5)})
   ss=[s for s in sens if s['gene']==gene and s['model']=='estimated_sdY'];r['PP4_constrained_prior_min']=min(float(s['PP.H4.abf']) for s in ss);r['PP4_constrained_prior_max']=max(float(s['PP.H4.abf']) for s in ss)
   r['robust_PP4_ge_0_8']=all(float(s['PP.H4.abf'])>=.8 for s in ss)
   all_pp.append(dict(primary[gene]))
  else:r.update(PP_H0='',PP_H1='',PP_H2='',PP_H3='',PP_H4='',robust_PP4_ge_0_8='NA')
  if gene in leads:
   lead=leads[gene];r.update(instrument_variant=lead['variant_id'],instrument_p=lead['eqtl_p'],instrument_F=lead['F_statistic'],instrument_status=lead['status'])
   if lead.get('wald_p',''):
    b=float(lead['wald_log_OR_per_processed_expression_unit']);s=float(lead['wald_SE_delta_second_order']);lead.update(wald_delta2_OR_CI_low=math.exp(b-1.96*s),wald_delta2_OR_CI_high=math.exp(b+1.96*s),wald_delta2_p=math.erfc(abs(b/s)/math.sqrt(2)),wald_delta2_p_Bonferroni24=min(1,math.erfc(abs(b/s)/math.sqrt(2))*24))
    lead['PP_H3']=r['PP_H3'];lead['PP_H4']=r['PP_H4'];lead['causal_claim_supported']=False;all_wald.append(dict(lead,tissue=tissue))
  else:r['instrument_status']='Not tested: no exact-gene cis nominal statistics'
  all_audit.append(r)
save('全部24基因组织_固定家族审计.tsv',all_audit)
save('图源_19区域默认PP0至PP4.tsv',all_pp)
save('图源_19区域先验与sdY敏感性_受限合法先验.tsv',all_sens)
save('审计_官方原始先验网格_含joint合法性标记.tsv',all_raw)
save('图源_3个合格单cis_Wald_24家族校正.tsv',all_wald)
cache_bytes=sum(p.stat().st_size for p in (P/'range_cache').glob('*'))
summary=dict(frozen_targets=genes,frozen_tissues=2,prespecified_gene_tissue_family=24,coloc_testable_gene_tissue_pairs=len(all_pp),common_variant_pairs=sum(int(p['n_common']) for p in all_pp),monocyte_common_variant_pairs=sum(int(p['n_common']) for p in all_pp if p['tissue']=='BLUEPRINT_monocyte'),whole_blood_common_variant_pairs=sum(int(p['n_common']) for p in all_pp if p['tissue']=='GTEx_whole_blood'),strong_primary_cis_Wald_tests=len(all_wald),strong_primary_cis_genes=[r['gene'] for r in all_wald],Wald_Bonferroni_24_significant=[r['gene'] for r in all_wald if float(r['wald_p_Bonferroni_24'])<.05],strong_colocalization_PP4_ge_0_8=[r['gene']+' '+r['tissue'] for r in all_audit if r.get('robust_PP4_ge_0_8') is True],default_PP4_min=min(float(r['PP.H4.abf']) for r in all_pp),default_PP4_max=max(float(r['PP.H4.abf']) for r in all_pp),cached_HTTP_range_bytes=cache_bytes,all_files_total_bytes=sum(p.stat().st_size for p in P.rglob('*') if p.is_file()),G_free_bytes=shutil.disk_usage(P).free,Python=sys.version,R='4.6.1',coloc_source_DESCRIPTION_version='6.0.3',coloc_source_git_commit=json.loads((P/'coloc_main_commit.json').read_text())['sha'],coloc_source_SHA256=hashlib.sha256((P/'coloc_official_claudia.R').read_bytes()).hexdigest(),coloc_execution='Official core functions source, not full installed coloc package',full_package_installed=False,clinical_data_uploaded=False)
(P/'最终实际结果摘要.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
methods='''Exploratory cis-eQTL and gout genetic triangulation. The scope was fixed at the 12 prioritized targets in two expression contexts: naive BLUEPRINT monocytes (eQTL Catalogue QTD000021, 191 donors) and GTEx whole blood (QTD000356, 670 donors). Full nominal cis-association statistics were retrieved from public indexed files and matched to European-ancestry gout GWAS summary statistics excluding 23andMe (GCST90428600; 27,194 cases and 614,881 controls), using exact GRCh38 chromosome, position, REF and ALT. The case and control totals were calculated from Major et al. Supplementary Table 1; per-variant GWAS N was retained. Duplicate rsID aliases with identical statistics were collapsed; conflicting records and incompatible alleles were quarantined. Colocalization retained all available shared variants, including indels, without selection by significance or MAF. Each exposure was a single exact gene-level molecular phenotype. Genotype-call N (AN/2) was retained separately from dataset N, particularly for the multi-ancestry GTEx dataset.

We executed official coloc core functions (GitHub source DESCRIPTION 6.0.3, commit 27776b1bb14e19d1542798ac7477fa378fc2fc0d) in R 4.6.1. Approximate Bayes factors used published beta and SE squared, quantitative-trait sdY estimated by the official sdY.est function with MAF and dataset N, and a case-control effect prior SD of 0.2 on the log-odds scale. Fixed sdY=1 was assessed separately. Requested SNP-level priors were p1=p2=10^-4 and p12=10^-6, 10^-5 or 10^-4. Official automatic prior adjustments used the respective full exposure/outcome datasets for p1/p2 and their intersection for p12. Original outputs were retained. Additional sensitivity results constrained p12 to at most min(p1,p2), explicitly flagging incompatible original upper-grid priors. The default p12=10^-5 was the main result; robust support required PP4>=0.8 across the valid constrained prior grid. The model assumes at most one causal signal per trait per region; no LD-dependent conditional or SuSiE analysis was performed.

For each gene-tissue pair, the strongest non-palindromic biallelic cis SNP was selected using the exposure alone, without replacement based on the outcome. Wald ratios were calculated only when the exposure P<=5x10^-8, F=(beta/SE)^2>10, both aligned associations were available and the ALT-allele frequency difference was <=0.2. Ratios describe gout log-odds per unit of Catalogue-processed expression, not a clinical expression concentration. The first-order SE was SE_outcome/abs(beta_exposure); a second-order delta-method SE was provided as sensitivity. Bonferroni correction used the fixed 24 gene-tissue family; untested pairs remained NA. The single-instrument estimates do not permit MR-Egger, heterogeneity or robust pleiotropy tests. Individual-level sample overlap could not be verified. GTEx whole-blood findings were treated as secondary, multi-ancestry exploratory evidence, without inference to a CD14-specific effect.'''
(P/'可直接入稿_Methods_实际执行版.txt').write_text(methods,encoding='utf-8')
results=f'''Genetic triangulation did not establish expression-mediated causality for the prioritized targets. Exact-gene nominal cis statistics were available for 9/12 monocyte targets and 10/12 whole-blood targets, yielding {summary['monocyte_common_variant_pairs']:,} and {summary['whole_blood_common_variant_pairs']:,} matched variants, respectively. Monocyte cis statistics were unavailable for ABCG2, XDH and SLC22A12; whole-blood statistics were unavailable for XDH and SLC22A12. No monocyte exposure met the prespecified genome-wide instrument threshold. In whole blood, NLRP3, SLC2A9 and TLR4 qualified for single-cis Wald estimation. NLRP3 (OR 1.053, first-order 95% CI 0.942-1.178; P=0.366) and TLR4 (OR 1.042, 0.977-1.113; P=0.213) showed no statistically supported association. SLC2A9 yielded an association (OR 1.561, 1.445-1.687; P=1.95x10^-29; Bonferroni-adjusted P=4.69x10^-28), but regional colocalization strongly favored distinct signals under the single-causal-signal model (PP3=0.999999994; PP4=1.06x10^-9). None of the 19 testable gene-tissue pairs reached PP4>=0.8 with the default prior or robust constrained-prior sensitivity. Thus, the SLC2A9 ratio association did not support a shared expression-mediated mechanism, and the inflammatory target hypotheses remained unconfirmed by these cis-eQTL datasets. Lack of a qualifying instrument or colocalization does not demonstrate absence of biological activity; power, cellular context, multi-ancestry exposure data and multiple causal signals remain limitations.'''
(P/'可直接入稿_Results_实际执行版.txt').write_text(results,encoding='utf-8')
report='''本轮遗传验证已实际完成；没有把基因列表重叠当作MR。

固定范围：12靶点×2组织=24个预选基因组织组合。使用BLUEPRINT纯化单核细胞与GTEx全血的Catalogue统一处理nominal cis结果，均为公开汇总资料；未上传临床数据。
真实结果：单核细胞9个可测/0个合格5e-8工具；全血10个可测/3个合格工具（NLRP3/SLC2A9/TLR4）。SLC2A9单SNP比值虽显著，但PP3近1而PP4约1e-9，不能据此称其表达导致痛风。19个可测组合均没有可靠强共定位。其余5个缺组织覆盖的组合保留NA，未虚构为阴性p值。

图表入口：
1. 全部24基因组织_固定家族审计.tsv：完整预选目标、覆盖、弱工具、缺失、SNP计数、PP及工具状态。
2. 图源_19区域默认PP0至PP4.tsv：默认合法先验下的19行矩阵来源。
3. 图源_19区域先验与sdY敏感性_受限合法先验.tsv：每个可测组合的3个先验×2种sdY结果。
4. 图源_3个合格单cis_Wald_24家族校正.tsv：3点探索性森林图数据；同时提供两种SE和CI；图中必须标注SLC2A9无共享信号支持。
5. 审计_官方原始先验网格_含joint合法性标记.tsv：官方原始结果与联合先验合法性检查，不替换原始结果。

等位基因：曝光始终ALT；结局按REF/ALT精确核准后转换到ALT方向。位置是GRCh38。indel保留于共定位；主工具仅非回文双等位SNP。不按P或MAF筛选共定位集合。
N：BLUEPRINT metadata N191、AN/2=191；GTEx metadata N670、每SNP非缺失基因型AN/2有变动，二者分列；outcome N逐SNP保留，642075是总体。GTEx为多祖源供者，不宣称严格欧洲祖源匹配或CD14细胞特异效应。
尺度：Catalogue CQN/逆正态等处理后的表达单位，非TPM剂量、非临床蛋白浓度。主sdY按官方估计；固定1敏感性另列。
软件：Python用于下载/解BGZF/等位基因整理与单cis比值。R4.6.1实际执行官方coloc core函数，源码6.0.3指定commit，不谎称安装并执行了整个coloc包。R会输出估sdY及自动调prior警告，已保存，非吞掉失败。
边界：单因果模型不需要LD矩阵，但不能替代允许多信号的SuSiE/条件共定位；无多效性稳健性声称；单SNP比值不能判定不存在水平多效性。没有执行伪IVW、伪Egger或pQTL分析。样本重叠无法逐人核实，不说完全无重叠。

资源取得：HTTP Range只取索引所需区域，未整包下载2.99GB单核细胞全nominal或全血大包。没有填FinnGen身份/访问同意表，FinnGen额外队列未作为本轮独立复制，因其可能与Major2024重叠。GTEx API显著eQTL仅作初始可用性审查，不混入统一Catalogue分析选择更显著工具。
主稿、冻结22图、原有397/12目标集合没有改动。可直接入稿Methods与Results及6条DOI核验元数据在同目录。
'''
(P/'本轮实际完成与结论边界.txt').write_text(report,encoding='utf-8')
