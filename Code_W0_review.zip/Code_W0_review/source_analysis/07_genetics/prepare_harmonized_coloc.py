from pathlib import Path
import json,csv,gzip,math,collections,sys,hashlib
SOURCE=Path(__file__).resolve().parent
WHOLEBLOOD='--whole-blood' in sys.argv
P=SOURCE/'GTExWholeBlood_analysis' if WHOLEBLOOD else SOURCE
P.mkdir(exist_ok=True)
EXPECTED_N=670 if WHOLEBLOOD else 191
Q_PREFIX='GTEXWholeBlood' if WHOLEBLOOD else 'BLUEPRINT_monocyte'
TISSUE='GTEx whole blood' if WHOLEBLOOD else 'BLUEPRINT monocytes'
MANIFEST='GTExWholeBlood_12靶点_区域资源.json' if WHOLEBLOOD else '12靶点_公开cis与GWAS区域资源.json'
def rows(p):
 if not p.exists():return []
 with gzip.open(p,'rt',encoding='utf-8') as f:return list(csv.DictReader(f,delimiter='\t'))
def save(name,data):
 fields=list(dict.fromkeys(k for r in data for k in r))
 with (P/name).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,delimiter='\t');w.writeheader();w.writerows(data)
def finite(*x):return all(math.isfinite(v) for v in x)
def unique(data,key,signature):
 d={};dup=0;bad=set()
 for x in data:
  k=key(x)
  if k in d:
   dup+=1
   if signature(x)!=signature(d[k]):bad.add(k)
  else:d[k]=x
 for k in bad:d.pop(k,None)
 return d,dup,bad
def qkey(q):return f"{q['chromosome']}_{q['position']}_{q['ref']}_{q['alt']}"
audit=[];leads=[];full_parameters=[]
for m in json.loads((SOURCE/MANIFEST).read_text(encoding='utf-8')):
 g=m['gene'];qraw=rows(SOURCE/f'{Q_PREFIX}_{g}_all_cis.tsv.gz');wraw=rows(SOURCE/f'gout_GCST90428600_{g}_region.tsv.gz')
 r={k:v for k,v in m.items() if k in ('gene','gene_id','chromosome','start_GRCh38','end_GRCh38')};r.update(eqtl_raw_rows=len(qraw),gwas_raw_rows=len(wraw))
 r['tissue']=TISSUE
 if not qraw:r['status']='No cis statistics for this exact gene in '+TISSUE;audit.append(r);continue
 assert set(q['gene_id'] for q in qraw)=={m['gene_id']}
 assert set(q['molecular_trait_id'] for q in qraw)=={m['gene_id']},'Do not mix molecular traits'
 qd,qddup,qbad=unique(qraw,qkey,lambda q:tuple(q[k] for k in ('beta','se','pvalue','maf','an','ac')))
 wd,wddup,wbad=unique(wraw,lambda w:w['variant_id'],lambda w:tuple(w[k] for k in ('beta','standard_error','p_value','effect_allele','other_allele','n')))
 qs={};qinvalid=0
 for k,q in qd.items():
  try:
   b,s,maf,ac,an,p=map(float,(q['beta'],q['se'],q['maf'],q['ac'],q['an'],q['pvalue']))
   assert finite(b,s,maf,ac,an,p) and s>0 and 0<maf<=.5 and an>0 and 0<=ac<=an and 0<=p<=1
   assert q['variant']=='chr'+k
   assert 0<an/2<=EXPECTED_N
   qs[k]=dict(variant_id=k,chromosome=q['chromosome'],position=int(q['position']),ref=q['ref'],alt=q['alt'],eqtl_beta=b,eqtl_se=s,eqtl_p=p,eqtl_maf=maf,eqtl_eaf=ac/an,eqtl_N=EXPECTED_N,eqtl_genotype_called_N=an/2,eqtl_rsid=q['rsid'])
  except (ValueError,AssertionError):qinvalid+=1
 ns=sorted(set(q['eqtl_N'] for q in qs.values()));called_ns=sorted(set(q['eqtl_genotype_called_N'] for q in qs.values()));assert ns==[float(EXPECTED_N)],f'Unexpected sample size {g} {ns}'
 inv=[1/q['eqtl_se']**2 for q in qs.values()]
 sdY=math.sqrt(sum(a*2*q['eqtl_N']*q['eqtl_maf']*(1-q['eqtl_maf']) for a,q in zip(inv,qs.values()))/sum(a*a for a in inv))
 shared=[];allele_mismatch=[];invalidout=0
 for k,q in qs.items():
  w=wd.get(k)
  if w is None:continue
  try:
   y,sy,py,eaf,n=map(float,(w['beta'],w['standard_error'],w['p_value'],w['effect_allele_frequency'],w['n']))
   assert finite(y,sy,py,eaf,n) and sy>0 and 0<=py<=1 and 0<=eaf<=1 and n>0
  except (ValueError,AssertionError):invalidout+=1;continue
  if (w['effect_allele'],w['other_allele'])==(q['alt'],q['ref']):flip=1
  elif (w['effect_allele'],w['other_allele'])==(q['ref'],q['alt']):flip=-1
  else:allele_mismatch.append(k);continue
  eafalt=eaf if flip==1 else 1-eaf
  shared.append(dict(q,gwas_beta_ALT=y*flip,gwas_se=sy,gwas_p=py,gwas_eaf_ALT=eafalt,gwas_N=n,gwas_rsid=w['rsid'],gwas_effect_flipped=int(flip==-1),eaf_abs_difference=abs(q['eqtl_eaf']-eafalt),is_biallelic_SNP=int(len(q['ref'])==len(q['alt'])==1 and q['ref'] in 'ACGT' and q['alt'] in 'ACGT'),is_palindromic=int(set((q['ref'],q['alt'])) in ({'A','T'},{'G','C'}))))
 shared.sort(key=lambda x:(x['position'],x['ref'],x['alt']))
 save(f'{g}_harmonized_full_nominal.tsv',shared)
 save(f'{g}_exposure_full_for_sdY.tsv',list(qs.values()))
 r.update(eqtl_unique_valid=len(qs),eqtl_duplicate_rows_collapsed=qddup,eqtl_conflicting_variant_ids=len(qbad),eqtl_invalid_rows=qinvalid,gwas_duplicate_rows_collapsed=wddup,gwas_conflicting_variant_ids=len(wbad),common_variants=len(shared),common_SNPs=sum(q['is_biallelic_SNP'] for q in shared),common_indels_or_other=sum(not q['is_biallelic_SNP'] for q in shared),allele_mismatch_count=len(allele_mismatch),invalid_gwas_count=invalidout,eqtl_N_min=min(ns),eqtl_N_max=max(ns),eqtl_genotype_called_N_min=min(called_ns),eqtl_genotype_called_N_max=max(called_ns),estimated_sdY=sdY,eqtl_min_p=min(q['eqtl_p'] for q in qs.values()),common_eqtl_min_p=min((q['eqtl_p'] for q in shared),default=''),gwas_N_min=min((q['gwas_N'] for q in shared),default=''),gwas_N_max=max((q['gwas_N'] for q in shared),default=''),gwas_min_p=min((q['gwas_p'] for q in shared),default=''),eaf_difference_gt_0_2=sum(q['eaf_abs_difference']>.2 for q in shared),status='Ready for official single-causal coloc' if len(shared)>=100 else 'Insufficient common variants')
 candidates=[q for q in qs.values() if len(q['ref'])==len(q['alt'])==1 and q['ref'] in 'ACGT' and q['alt'] in 'ACGT' and set((q['ref'],q['alt'])) not in ({'A','T'},{'G','C'})]
 if candidates:
  # Choose by exposure alone; never replace missing outcome lead with an outcome-selected SNP.
  lead=min(candidates,key=lambda q:(q['eqtl_p'],-abs(q['eqtl_beta']/q['eqtl_se']),q['variant_id']))
  lr=dict(gene=g,tissue=TISSUE,**lead,F_statistic=(lead['eqtl_beta']/lead['eqtl_se'])**2,exposure_selected_without_outcome=True)
  match=next((s for s in shared if s['variant_id']==lead['variant_id']),None)
  if lead['eqtl_p']>5e-8 or lr['F_statistic']<=10:lr['status']='No genome-wide significant strong primary cis instrument'
  elif match is None:lr['status']='Exposure-selected lead absent or invalid in outcome; no proxy substitution'
  elif match['eaf_abs_difference']>.2:lr['status']='Exposure-selected lead frequency discordance > 0.2; Wald withheld'
  else:
   bx,sx,by,sy=lead['eqtl_beta'],lead['eqtl_se'],match['gwas_beta_ALT'],match['gwas_se'];beta=by/bx;se=abs(sy/bx);se2=math.sqrt(sy**2/bx**2+by**2*sx**2/bx**4)
   lr.update(gwas_beta_ALT=by,gwas_se=sy,gwas_p=match['gwas_p'],gwas_N=match['gwas_N'],gwas_eaf_ALT=match['gwas_eaf_ALT'],eaf_abs_difference=match['eaf_abs_difference'],wald_log_OR_per_processed_expression_unit=beta,wald_SE_first_order=se,wald_SE_delta_second_order=se2,wald_OR=math.exp(beta),wald_OR_CI_low=math.exp(beta-1.96*se),wald_OR_CI_high=math.exp(beta+1.96*se),wald_p=math.erfc(abs(beta/se)/math.sqrt(2)),wald_p_Bonferroni_24=min(1,math.erfc(abs(beta/se)/math.sqrt(2))*24),status='Single-cis Wald computed; require colocalization before interpretation')
  leads.append(lr)
 audit.append(r);full_parameters.append(dict(gene=g,sdY=sdY,N=EXPECTED_N,n_common=len(shared),n_qtl_full=len(qs),n_gwas_full=len(wd)))
 print(g,len(qs),len(shared),'sdY',sdY,'minimum eQTL p',r['eqtl_min_p'],flush=True)
save('12靶点_区域等位基因与覆盖审计.tsv',audit);save('12靶点_暴露独立选择的cis主工具与Wald.tsv',leads);save('coloc_model_parameters.tsv',full_parameters)
(P/'harmonization_audit.json').write_text(json.dumps(dict(audit=audit,leads=leads,software=dict(Python=sys.version),case_control_source=dict(source='Major2024 Supplementary Table S1, European total minus 23andMe European',cases=100671-73477,controls=2106212-1491331,N=642075,case_fraction=27194/642075),coloc=dict(primary_sdY=f'estimated from full valid exact-gene nominal eQTL statistics; official sdY.est formula; N={EXPECTED_N}',sensitivity_sdY=1,p1=1e-4,p2=1e-4,p12=[1e-6,1e-5,1e-4],single_causal_per_trait=True,LD_available=False,sample_overlap='not individually verifiable; no zero-overlap claim',no_significance_or_MAF_filter=True),fixed_Wald_family=24),ensure_ascii=False,indent=2),encoding='utf-8')
