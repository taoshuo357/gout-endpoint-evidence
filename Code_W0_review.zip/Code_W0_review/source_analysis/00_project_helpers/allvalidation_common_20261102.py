from pathlib import Path
import sys,json,csv,hashlib,gzip,os
BASE=Path(__file__).resolve().parent
assert BASE.drive.upper()=='G:'
sys.path.insert(0,str(BASE/'runtime/ppi_analysis_libraries'))
sys.path.append(str(BASE/'论文推进_2026-10-30'/'单细胞定位'/'runtime'))
sys.path.append(str(BASE/'rdkit_runtime'))
ROOT=BASE/'全面验证_2026-11-02'
ROOT.mkdir(exist_ok=True)
GENES=['NLRP3','CASP1','IL1B','XDH','SLC22A12','ABCG2','SLC2A9','TLR4','RELA','NFKB1','TNF','AKT1']
DB=['TCMSP','SwissTargetPrediction','PharmMapper','STITCH']
def read(p):
    p=Path(p)
    op=gzip.open if p.suffix=='.gz' else open
    with op(p,'rt',encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t' if '.tsv' in p.name else ','))
def write(p,rows):
    rows=list(rows)
    if not rows:return
    with Path(p).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def bh(p):
    import numpy as np
    x=np.asarray(p);idx=np.argsort(x);a=np.minimum.accumulate((x[idx]*len(x)/np.arange(1,len(x)+1))[::-1])[::-1];out=np.empty_like(a);out[idx]=np.minimum(a,1);return out

