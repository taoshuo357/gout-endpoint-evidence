from pathlib import Path
import sys,json,csv,hashlib
BASE=Path(__file__).resolve().parent
assert BASE.drive.upper()=='G:'
sys.path.insert(0,str(BASE/'runtime/ppi_analysis_libraries'))
sys.path.append(str(BASE/'rdkit_runtime'))
OUT=BASE/'生信扩展_2026-11-02'
DATA=OUT/'结果表';FIG=OUT/'科研图';RAW=OUT/'公开结构原始';QA=OUT/'质量核验'
for p in [OUT,DATA,FIG,RAW,QA]:p.mkdir(exist_ok=True)
GENES=['NLRP3','CASP1','IL1B','XDH','SLC22A12','ABCG2','SLC2A9','TLR4','RELA','NFKB1','TNF','AKT1']
DB=['TCMSP','SwissTargetPrediction','PharmMapper','STITCH']
def read(p):
    with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t' if str(p).endswith('.tsv') else ','))
def write(name,rows):
    rows=list(rows)
    if not rows:return
    with (DATA/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
