from pathlib import Path
import sys,json,hashlib,datetime
O=Path(__file__).resolve().parent
for p in reversed(['G:/痛风/第二步_靶点预测与疾病交集/runtime/ppi_analysis_libraries','G:/痛风/第二步_靶点预测与疾病交集/论文推进_2026-10-30/单细胞定位/runtime']):sys.path.insert(0,p)
import pandas as pd,numpy as np
from scipy.stats import t as student_t
P=O/'Quercetin_IL1B_车辆配对比值_全部重复.tsv';L=O/'Quercetin_S1_全部作者归一重复_long.tsv';Q=O/'Quercetin_S1_均值SEM逐行一致性.tsv'
source_sha={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [P,L,Q]}
protocol={'frozen_before_this_inferential_stage':datetime.datetime.now().astimezone().isoformat(),'not_preregistered':True,'earlier_descriptive_values_inspected':True,'source':'10.1371/journal.pone.0237752 / PMC7446918 / actual S1 Data DOCX','full_family':'all3timings x all5doses20,40,60,80,100uM =15 tests, no effect-direction exclusion','estimand':'within-timing mean log(treated IL1beta / stimulated vehicle IL1beta) across author-labeled independent Exp columns; geometric ratio and t-based marginal95CI','biological_unit_basis':'Figure3 caption explicitly says at least3 independent experiments; S1 has4 co and3 pre/post Exp columns. Global statistics section says3; this inconsistency is reported. Analysis uses all supplied Exp columns, never deletes fourth co column.','pairing_basis_and_assumption':'Within a given timing, same Exp column is treated as the same experimental run for its treated and PAO1+vehicle values, as aligned in source table. No global run IDs or plate map supplied; inference is conditional on that alignment.','comparison':'stimulated PAO1+vehicle, not untreated and not PAO1-alone; both other controls preserved','P_model':'two-sided one-sample t of within-column logratios against0; independent run errors approximately normal on log scale; n=3/4 limits diagnostics','multiplicity':'BH across all15 two-sided P values; 95% CIs are marginal, not simultaneous and not BH-adjusted','replicates':'author-stated cell-culture experiments; not new patient/donor counts','viability':'separate drug-only MTT, methods24h vs Figure2 caption48h discrepancy; never paired with secretion Exp numbers, never used for cytotox correction or joint Pareto ranking','no_Hill_no_monotonic_constraint':True,'source_sha256':source_sha}
(O/'Quercetin_15对比_推断前冻结方案.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
pdta=pd.read_csv(P,sep='\t');ld=pd.read_csv(L,sep='\t')
results=[];rows=[]
for (schedule,dose),z in pdta.groupby(['schedule','dose_uM'],sort=True):
 rr=z.IL1beta_percent_of_withinExp_vehicle.to_numpy(float)/100
 assert len(rr)==(4 if schedule=='IL1beta_cotreatment' else 3) and np.isfinite(rr).all() and (rr>0).all()
 logs=np.log(rr);n=len(logs);mean=float(logs.mean());sd=float(logs.std(ddof=1));se=sd/np.sqrt(n);tv=mean/se;pv=float(2*student_t.sf(abs(tv),n-1));crit=float(student_t.ppf(.975,n-1));lo=mean-crit*se;hi=mean+crit*se
 for exp,ratio,logr in zip(z.Exp_as_labeled,rr,logs):rows.append({'schedule':schedule,'dose_uM':float(dose),'Exp_as_labeled':int(exp),'treated_over_stimulated_vehicle_ratio':float(ratio),'log_ratio':float(logr),'run_identity_scope':'within_this_timing_only'})
 results.append({'schedule':schedule,'dose_uM':float(dose),'n_author_independent_Exp_columns':n,'mean_log_treated_over_vehicle':mean,'SD_log_ratio':sd,'SE_log_ratio':se,'geometric_treated_over_vehicle_ratio':float(np.exp(mean)),'ratio_95CI_low_marginal':float(np.exp(lo)),'ratio_95CI_high_marginal':float(np.exp(hi)),'geometric_inhibition_percent':float(100*(1-np.exp(mean))),'inhibition_95CI_low_marginal':float(100*(1-np.exp(hi))),'inhibition_95CI_high_marginal':float(100*(1-np.exp(lo))),'t_statistic':float(tv),'df':n-1,'P_two_sided_logratio':pv,'analysis_scope':'Conditional source-table aligned independent cell-culture run logratio, not new patient evidence'})
R=pd.DataFrame(results);assert len(R)==15
pv=R.P_two_sided_logratio.to_numpy();order=np.argsort(pv);adj=np.minimum.accumulate((pv[order]*15/np.arange(1,16))[::-1])[::-1].clip(0,1);q=np.empty(15);q[order]=adj
R['BH_q_all15']=q;R['direction']=np.where(R.mean_log_treated_over_vehicle.lt(0),'lower_than_stimulated_vehicle','higher_than_stimulated_vehicle');R['source_PMC']='PMC7446918';R['source_DOI']='10.1371/journal.pone.0237752'
R.to_csv(O/'Quercetin_全部15剂量时序_配对logratio_CI_BH.tsv',sep='\t',index=False);pd.DataFrame(rows).to_csv(O/'Quercetin_推断输入_全部50同列logratio.tsv',sep='\t',index=False)
# Both vehicle and untreated values remain visible; viability is a different protocol and never matched to secretion runs.
control=ld[ld.treatment.str.contains('vehicle|untreated|^PAO1\\s*$',case=False,regex=True)].copy();control.to_csv(O/'Quercetin_全部刺激与未刺激对照_long.tsv',sep='\t',index=False)
V=ld[ld.source_table_index.eq(1)].copy();V['infection_status']='drug_only_MTT_as_described_no_PAO1';V['exposure_time_methods']='24h';V['exposure_time_Figure2_caption']='48h';V['pair_to_secretion_Exp']='NO';V['source_time_conflict']=True
V.to_csv(O/'Quercetin_viability_独立协议_所有重复.tsv',sep='\t',index=False)
VS=[]
for (treatment,dose),z in V.groupby(['treatment','dose_uM'],dropna=False):
 vals=z.author_supplied_normalized_value.to_numpy(float)
 VS.append({'treatment':treatment,'dose_uM':None if pd.isna(dose) else float(dose),'n_author_Exp_columns':len(vals),'mean_author_normalized_viability_percent':float(vals.mean()),'SD_recomputed':float(vals.std(ddof=1)),'SEM_recomputed':float(vals.std(ddof=1)/np.sqrt(len(vals))),'protocol':'drug alone; uninfected as described; methods24h vs caption48h unresolved','not_matched_to_secretion':True})
pd.DataFrame(VS).to_csv(O/'Quercetin_viability_独立协议_剂量汇总.tsv',sep='\t',index=False)
assert all(hashlib.sha256(p.read_bytes()).hexdigest()==source_sha[p.name] for p in [P,L,Q])
summary={'completed':datetime.datetime.now().astimezone().isoformat(),'all15_preserved':True,'BH15_lower_response_q05_count':int((R.BH_q_all15.lt(.05)&R.mean_log_treated_over_vehicle.lt(0)).sum()),'BH15_other_rows_preserved':True,'results':R.to_dict(orient='records'),'no_cross_timing_pairing':True,'no_viability_secretion_pairing':True,'not_cytotox_corrected':True,'no_Hill_fit':True,'no_Pareto_joint_constraint_due_different_protocols':True,'unit':'author-caption independent cell-culture experimental columns, not patient/donor observations','assumption':'Within-timing same Exp labels aligned as same run; source has no plate/run IDs beyond column names. Small-sample t intervals/tests conditional.','source_data_unchanged':True,'source_statistics_errors_not_silently_changed':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(O/'Quercetin_15对比真实结果与统计单位.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
print(R[['schedule','dose_uM','n_author_independent_Exp_columns','geometric_inhibition_percent','inhibition_95CI_low_marginal','inhibition_95CI_high_marginal','P_two_sided_logratio','BH_q_all15']].to_string(index=False),flush=True)
