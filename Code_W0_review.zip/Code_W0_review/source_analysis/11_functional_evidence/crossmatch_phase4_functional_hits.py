from pathlib import Path
import sys,json,time,threading,concurrent.futures,hashlib,datetime
E=Path(__file__).resolve().parent
for p in reversed(['G:/痛风/第二步_靶点预测与疾病交集/runtime/ppi_analysis_libraries','G:/痛风/第二步_靶点预测与疾病交集/论文推进_2026-10-30/单细胞定位/runtime']):sys.path.insert(0,p)
import requests,pandas as pd
O=E/'07_实测药物与功能验证/04_NLRP3功能筛选';R=O/'原始公开快照';P=R/'ActiveCID_properties';P.mkdir(exist_ok=True)
data=pd.read_csv(R/'NCGC_IL1B_743279_concise.csv',usecols=['SID','CID','Activity Outcome'],dtype={'SID':'Int64','CID':'Int64'})
active=sorted(data.loc[data['Activity Outcome'].eq('Active'),'CID'].dropna().astype(int).unique())
rate=threading.Lock();last=[0.0];errors=[];records=[]
def limited_get(url):
 with rate:
  delay=.40-(time.monotonic()-last[0])
  if delay>0:time.sleep(delay)
  last[0]=time.monotonic()
 return requests.get(url,timeout=(15,60))
def batch(item):
 i,cids=item;p=P/f'active_{i:03d}.json'
 if p.exists():return json.loads(p.read_text(encoding='utf-8')).get('PropertyTable',{}).get('Properties',[])
 u='https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/'+','.join(map(str,cids))+'/property/InChIKey,Title/JSON'
 for j in range(3):
  try:
   r=limited_get(u);r.raise_for_status();d=r.json()
   assert 'PropertyTable' in d
   p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
   return d['PropertyTable']['Properties']
  except Exception as ex:
   if j==2:
    errors.append({'batch':i,'requested_CIDs':cids,'url':u,'error':str(ex)})
    return []
   time.sleep(2*(j+1))
batches=[(i,active[start:start+250]) for i,start in enumerate(range(0,len(active),250))]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 for n,rows in enumerate(ex.map(batch,batches),1):
  records+=rows
  if n%5==0:print('ACTIVE_PROPERTIES',n,'/',len(batches),'records',len(records),flush=True)
props=pd.DataFrame(records).drop_duplicates('CID');props.to_csv(O/'所有主筛ActiveCID_官方身份.tsv',sep='\t',index=False)
mol=json.loads((O/'ChEMBL_phase4_smallmolecules_all.json').read_text(encoding='utf-8'))
m=[]
for z in mol:
 st=z.get('molecule_structures') or {}
 m.append({'molecule_chembl_id':z['molecule_chembl_id'],'name':z.get('pref_name'),'max_phase':z.get('max_phase'),'withdrawn_flag':z.get('withdrawn_flag'),'standard_InChIKey':st.get('standard_inchi_key'),'canonical_SMILES':st.get('canonical_smiles'),'parent_chembl_id':(z.get('molecule_hierarchy') or {}).get('parent_chembl_id')})
m=pd.DataFrame(m);m.to_csv(O/'ChEMBL全部phase4小分子_身份与状态.tsv',sep='\t',index=False)
merged=props.merge(m,left_on='InChIKey',right_on='standard_InChIKey',how='inner')
merged['source_AID']=743279;merged['evidence_level']='PubChem primary-screen Active exact-InChIKey match; not validated NLRP3 binding/clinical efficacy'
merged.to_csv(O/'phase4小分子_实测IL1B主筛阳性_精确身份交叉.tsv',sep='\t',index=False)
raw=data.merge(merged[['CID']].drop_duplicates(),on='CID',how='inner')
raw.to_csv(O/'phase4命中_原始SID全部结局.tsv',sep='\t',index=False)
summary={'completed':datetime.datetime.now().astimezone().isoformat(),'all_screen_rows':len(data),'all_active_CIDs':len(active),'active_property_records':len(props),'property_batches':len(batches),'failed_property_batches':len(errors),'phase4_rows':len(m),'phase4_with_InChIKey':int(m.standard_InChIKey.notna().sum()),'exact_matched_active_CIDs':merged.CID.nunique(),'matched_ChEMBL_molecules':merged.molecule_chembl_id.nunique(),'screen_qualified_not_clinical_or_binding':True,'matched_names':sorted(set(merged.name.dropna().astype(str)))}
(O/'扩药主筛精确交叉_实际完成摘要.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(P/'下载错误与缺口.json').write_text(json.dumps(errors,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False),flush=True)
