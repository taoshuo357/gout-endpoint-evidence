from pathlib import Path
import sys,json,hashlib,datetime,collections
P=Path(__file__).resolve().parent; O=P.parent; E=O.parents[1]; G=Path('G:/痛风/第二步_靶点预测与疾病交集')
for x in reversed([G/'runtime/ppi_analysis_libraries',G/'论文推进_2026-10-30/单细胞定位/runtime',G/'rdkit_runtime']):sys.path.insert(0,str(x))
import pandas as pd
from rdkit import Chem,rdBase
from rdkit.Chem.MolStandardize import rdMolStandardize

def dump(name,x): (P/name).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def tab(name,x): x.to_csv(P/name,sep='\t',index=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stereo(m):
 out=[]
 for s in Chem.FindPotentialStereo(m):out.append({'type':str(s.type),'centeredOn':s.centeredOn,'specified':str(s.specified),'descriptor':str(s.descriptor)})
 return out

def normalize(record):
 r=dict(record); smi=r.get('source_SMILES','') or ''; inc=r.get('source_InChI','') or ''; official=r.get('source_full_InChIKey','') or ''
 r.update(normalization_status='UNATTEMPTED',parent_full_InChIKey='',parent_isomeric_SMILES='')
 try:
  m=Chem.MolFromSmiles(smi) if smi else None; parsedkey=Chem.MolToInchiKey(m) if m is not None else ''
  r['SMILES_parsed_full_InChIKey']=parsedkey
  im=Chem.MolFromInchi(inc) if inc else None; ik=Chem.MolToInchiKey(im) if im is not None else ''
  r['InChI_parsed_full_InChIKey']=ik; r['input_method']='SMILES'
  if official and parsedkey!=official and ik==official:m=im;r['input_method']='InChI_fallback'
  elif m is None and im is not None:m=im;r['input_method']='InChI_only'
  if m is None:r['normalization_status']='MISSING_OR_INVALID_STRUCTURE';return r
  rawkey=Chem.MolToInchiKey(m);r['input_full_InChIKey']=rawkey
  r['source_key_agrees_with_parsed_structure']=rawkey==official if official else 'NO_OFFICIAL_SOURCE_KEY'
  r['input_isomeric_SMILES']=Chem.MolToSmiles(m,isomericSmiles=True,canonical=True)
  r['input_formal_charge']=Chem.GetFormalCharge(m)
  frags=Chem.GetMolFrags(m,asMols=True,sanitizeFrags=True)
  fraginfo=[{'isomeric_SMILES':Chem.MolToSmiles(f,isomericSmiles=True,canonical=True),'atoms':f.GetNumAtoms(),'carbon_atoms':sum(a.GetAtomicNum()==6 for a in f.GetAtoms()),'formal_charge':Chem.GetFormalCharge(f),'stereo':stereo(f)} for f in frags]
  r['input_fragments_n']=len(frags);r['input_carbon_fragments_n']=sum(z['carbon_atoms']>0 for z in fraginfo);r['input_fragments_JSON']=json.dumps(fraginfo,ensure_ascii=False)
  inpst=stereo(m);r['input_potential_stereo_JSON']=json.dumps(inpst);r['input_assigned_stereo_n']=sum(z['specified']=='Specified' for z in inpst);r['input_unassigned_stereo_n']=sum(z['specified']!='Specified' for z in inpst)
  parent=rdMolStandardize.FragmentParent(m);parent=rdMolStandardize.Uncharger().uncharge(parent);Chem.SanitizeMol(parent);Chem.GetSymmSSSR(parent)
  r['parent_isomeric_SMILES']=Chem.MolToSmiles(parent,isomericSmiles=True,canonical=True);r['parent_full_InChIKey']=Chem.MolToInchiKey(parent);r['parent_formal_charge']=Chem.GetFormalCharge(parent)
  pst=stereo(parent);r['parent_potential_stereo_JSON']=json.dumps(pst);r['parent_assigned_stereo_n']=sum(z['specified']=='Specified' for z in pst);r['parent_unassigned_stereo_n']=sum(z['specified']!='Specified' for z in pst)
  r['parent_changed_full_key']=rawkey!=r['parent_full_InChIKey'];r['multiple_organic_fragments_sensitivity_flag']=r['input_carbon_fragments_n']>1
  r['removed_fragment_contains_potential_stereo_flag']=len(frags)>1 and sum(len(z['stereo']) for z in fraginfo)>len(pst)
  r['normalization_status']='OK' if not official or rawkey==official else 'SOURCE_KEY_STRUCTURE_MISMATCH_EXCLUDED'
 except Exception as ex:r['normalization_status']='ERROR';r['error']=type(ex).__name__+':'+str(ex)
 return r

props=json.loads((P/'17187ActiveCID_官方结构_完整JSON合并.json').read_text(encoding='utf-8'))['PropertyTable']['Properties']; ident=pd.read_csv(O/'所有主筛ActiveCID_官方身份.tsv',sep='\t',dtype={'CID':str}).fillna('');key=ident.set_index('CID').to_dict('index')
active=[]
for z in props:
 cid=str(z['CID']); k=key[cid];active.append({'source':'PubChem_AID743279_Active','source_id':cid,'CID':cid,'Title':k['Title'],'source_full_InChIKey':k['InChIKey'],'source_SMILES':z.get('SMILES',z.get('IsomericSMILES','')),'source_InChI':z.get('InChI','')})
rawchem=json.loads((O/'ChEMBL_phase4_smallmolecules_all.json').read_text(encoding='utf-8-sig'));chem=[]
for z in rawchem:
 st=z.get('molecule_structures') or {}; hi=z.get('molecule_hierarchy') or {};chem.append({'source':'ChEMBL_phase4_smallmolecule','source_id':z['molecule_chembl_id'],'molecule_chembl_id':z['molecule_chembl_id'],'pref_name':z.get('pref_name'),'max_phase':z.get('max_phase'),'withdrawn_flag':z.get('withdrawn_flag'),'source_full_InChIKey':st.get('standard_inchi_key'),'source_SMILES':st.get('canonical_smiles'),'source_InChI':st.get('standard_inchi'),'ChEMBL_parent_chembl_id':hi.get('parent_chembl_id'),'ChEMBL_active_chembl_id':hi.get('active_chembl_id')})
swiss=pd.read_csv(G/'Swiss分批提交队列.csv',dtype={'预测CID':str}).fillna('');oldedges=pd.read_csv(G/'合并交集_2026-10-29/成分_交集靶点关联.csv',dtype={'pubchem_cid':str}).fillna('');xdh=set(oldedges.loc[oldedges.gene_symbol.eq('XDH'),'pubchem_cid']);assert len(xdh)==52
sw=[]
for z in swiss.to_dict('records'):sw.append({'source':'Swiss_frozen104_SMILES','source_id':str(z['顺序']),'CID':z['预测CID'],'name_from_frozen_queue':z['预测结构'],'source_full_InChIKey':'','source_SMILES':z['SMILES'],'source_InChI':'','old_XDH52_member':z['预测CID'] in xdh,'Swiss_original_row_JSON':json.dumps(z,ensure_ascii=False)})
allsets=[]
for label,rows in [('PubChem17187',active),('ChEMBL3475',chem),('Swiss104',sw)]:
 if (P/(label+'_完整结构与父体审计.tsv')).exists():
  df=pd.read_csv(P/(label+'_完整结构与父体审计.tsv'),sep='\t',dtype={'source_id':str,'CID':str}).fillna('');assert len(df)==len(rows);allsets.append(df);continue
 vals=[]
 for i,r in enumerate(rows):
  vals.append(normalize(r))
  if (i+1)%2000==0:print(label,i+1,flush=True)
 df=pd.DataFrame(vals).fillna('');tab(label+'_完整结构与父体审计.tsv',df);allsets.append(df)
a,c,s=allsets
# Full exact key joins only. All pair rows retained, no connectivity truncation.
al=a[a.normalization_status.eq('OK')].copy();cl=c[c.normalization_status.eq('OK')].copy();sl=s[s.normalization_status.eq('OK')].copy()
l1=ident.merge(c[c.source_full_InChIKey.ne('')],left_on='InChIKey',right_on='source_full_InChIKey',how='inner')
tab('Level1_原始完整key_全部ChEMBL匹配对.tsv',l1)
l2=al.merge(cl,on='parent_full_InChIKey',how='inner',suffixes=('_PubChem','_ChEMBL'))
l2.rename(columns={'CID':'CID_PubChem'},inplace=True)
l2['Level1_original_full_key_exact']=l2.source_full_InChIKey_PubChem.eq(l2.source_full_InChIKey_ChEMBL)
l2['identity_level']='L2_EXACT_FULL_STEREO_PARENT'
tab('Level2_完整立体父体_全部ChEMBL匹配对.tsv',l2)
ls=sl.merge(al,on='parent_full_InChIKey',how='inner',suffixes=('_Swiss','_ActivePubChem'))
ls['Level1_frozen_SMILES_raw_key_exact']=ls.input_full_InChIKey_Swiss.eq(ls.source_full_InChIKey_ActivePubChem)
ls['identity_level']='L2_EXACT_FULL_STEREO_PARENT';tab('Level2_完整立体父体_全部Swiss104匹配对.tsv',ls)
concise=pd.read_csv(O/'原始公开快照/NCGC_IL1B_743279_concise.csv',dtype={'CID':str,'SID':str},low_memory=False).fillna('');agg=concise.groupby('CID').agg(screen_rows=('SID','size'),all_SIDs=('SID',lambda v:';'.join(sorted(set(v)))),all_outcomes=('Activity Outcome',lambda v:';'.join(sorted(set(v)))))
for label,df in [('Level1',l1),('Level2',l2)]:
 col='CID' if label=='Level1' else 'CID_PubChem'; full=df.merge(agg,left_on=col,right_index=True,how='left');tab(label+'_匹配对_原CID全部SID与结局.tsv',full)
 if len(df):
  out=concise[concise.CID.isin(set(df[col]))].copy();out['identity_level']=label;tab(label+'_匹配ActiveCID_全部原始SID结局.tsv',out)
coverage=s[['source_id','CID','name_from_frozen_queue','old_XDH52_member','normalization_status','input_full_InChIKey','parent_full_InChIKey','input_isomeric_SMILES','parent_isomeric_SMILES']].copy()
coverage['matched_Active_CID_count']=coverage.source_id.map(ls.groupby('source_id_Swiss').CID_ActivePubChem.nunique()).fillna(0).astype(int)
coverage['matched_Active_CIDs']=coverage.source_id.map(ls.groupby('source_id_Swiss').CID_ActivePubChem.agg(lambda v:';'.join(sorted(set(v))))).fillna('')
coverage['interpretation']=coverage.matched_Active_CID_count.map(lambda n:'PARENT_MATCH_REQUIRES_FULL_ASSAY_CONFLICT_AUDIT' if n else 'NO_MATCH_IN_ACTIVE_STRUCTURE_SET_NOT_ASSAY_NEGATIVE')
tab('Swiss104_全部覆盖与缺口.tsv',coverage)
status={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'RDKit_version':rdBase.rdkitVersion,'scope':'Identity and coverage only, no drug efficacy or cytotoxicity inference','all_original_rows_retained':True,'source_denominators':{'ActiveCID':len(a),'ChEMBL_phase4_smallmolecules':len(c),'Swiss':len(s),'Swiss_old_XDH52':len(xdh)},'normalization_status':{label:df.normalization_status.value_counts().to_dict() for label,df in zip(['ActiveCID','ChEMBL','Swiss'],allsets)},'Level1':{'pair_rows':len(l1),'ActiveCID':l1.CID.nunique(),'ChEMBL':l1.molecule_chembl_id.nunique()},'Level2':{'pair_rows':len(l2),'ActiveCID':l2.CID_PubChem.nunique(),'ChEMBL':l2.molecule_chembl_id.nunique(),'rawkey_exact_pair_rows':int(l2.Level1_original_full_key_exact.sum()),'additional_parent_pair_rows':int((~l2.Level1_original_full_key_exact).sum()),'additional_ActiveCID_vs_L1':sorted(set(l2.CID_PubChem)-set(l1.CID),key=int)},'Swiss_parent_hits':{'pair_rows':len(ls),'Swiss104':ls.CID_Swiss.nunique(),'oldXDH52':ls.loc[ls.old_XDH52_member.eq(True),'CID_Swiss'].nunique(),'ActiveCID':ls.CID_ActivePubChem.nunique(),'needs_complete_concise_parent_conflict_audit':bool(len(ls))},'multiple_carbon_fragments':{label:int(df.multiple_organic_fragments_sensitivity_flag.eq(True).sum()) for label,df in zip(['ActiveCID','ChEMBL','Swiss'],allsets)},'old_sources_unchanged':{k:sha(Path(z['path']))==z['sha256'] for k,z in json.loads((P/'父体完整立体身份敏感性_匹配前冻结.json').read_text(encoding='utf-8'))['source_files'].items()}}
dump('结构标准化与L1L2交叉_实际状态.json',status)
print(json.dumps(status,ensure_ascii=False,indent=2),flush=True)

