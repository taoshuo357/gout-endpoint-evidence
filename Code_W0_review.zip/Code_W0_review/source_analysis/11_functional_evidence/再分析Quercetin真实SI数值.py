from pathlib import Path
import sys,zipfile,xml.etree.ElementTree as ET,re,json,hashlib,datetime
O=Path(__file__).resolve().parent
for p in reversed(['G:/痛风/第二步_靶点预测与疾病交集/runtime/ppi_analysis_libraries','G:/痛风/第二步_靶点预测与疾病交集/论文推进_2026-10-30/单细胞定位/runtime']):sys.path.insert(0,p)
import pandas as pd,numpy as np
p=O/'原研究SI归档/PMC7446918__pone.0237752.s001.docx';ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
with zipfile.ZipFile(p) as z:r=ET.fromstring(z.read('word/document.xml'))
labels=['bacterial_growth','THP1_viability','IL1beta_cotreatment','IL1beta_pretreatment','IL1beta_posttreatment','p_p38_WB','p_JNK_WB','caspase1_WB','IL1beta_WB','NLRP3_WB']
cellrows=[];long=[];qc=[]
for ti,t in enumerate(r.findall('.//w:tbl',ns)):
 rows=[[' '.join((x.text or '') for x in c.findall('.//w:t',ns)) for c in tr.findall('w:tc',ns)] for tr in t.findall('w:tr',ns)]
 hi=next(i for i,z in enumerate(rows) if any('Exp.' in v for v in z));header=rows[hi];excols=[i for i,v in enumerate(header) if 'Exp.' in v];last=''
 for ri,row in enumerate(rows):
  for ci,value in enumerate(row):cellrows.append({'table_index':ti,'endpoint':labels[ti],'row_index':ri,'column_index':ci,'value_as_supplied':value})
  if ri<=hi:continue
  if row and row[0].strip():last=row[0].strip()
  if len(row)!=len(header):continue
  try:vals=np.array([float(row[i]) for i in excols]);reportedmean=float(row[-2]);reportedsem=float(row[-1])
  except (ValueError,IndexError):continue
  title=last;dose=None
  dosefield=' '.join(row[:min(excols)])
  md=re.search(r'(\d+(?:\.\d+)?)\s*[µμ]M',dosefield)
  if md:dose=float(md.group(1))
  calcmean=float(vals.mean());calcsem=float(vals.std(ddof=1)/np.sqrt(len(vals)))
  flag=abs(calcmean-reportedmean)>.002 or abs(calcsem-reportedsem)>.002
  qc.append({'table_index':ti,'endpoint':labels[ti],'source_row':ri,'treatment':title,'dose_uM':dose,'n_labeled_Exp_columns':len(vals),'source_mean':reportedmean,'recomputed_mean':calcmean,'source_SEM':reportedsem,'recomputed_SEM':calcsem,'mean_difference':calcmean-reportedmean,'SEM_difference':calcsem-reportedsem,'outside_rounding_tolerance002':flag})
  for j,value in enumerate(vals):long.append({'source_DOI':'10.1371/journal.pone.0237752','source_file':p.name,'source_table_index':ti,'endpoint':labels[ti],'source_row':ri,'treatment':title,'dose_uM':dose,'Exp_as_labeled':j+1,'author_supplied_normalized_value':float(value),'normalization':'Author normalized replicate values, not absolute raw ELISA/OD readings','source_mean':reportedmean,'source_SEM':reportedsem})
C=pd.DataFrame(cellrows);L=pd.DataFrame(long);Q=pd.DataFrame(qc)
C.to_csv(O/'Quercetin_S1_逐表原始单元格.tsv',sep='\t',index=False)
L.to_csv(O/'Quercetin_S1_全部作者归一重复_long.tsv',sep='\t',index=False)
Q.to_csv(O/'Quercetin_S1_均值SEM逐行一致性.tsv',sep='\t',index=False)
paired=[];summary=[]
for ti in [2,3,4]:
 z=L[L.source_table_index.eq(ti)]
 v=z[z.treatment.str.contains('vehicle',case=False)].set_index('Exp_as_labeled').author_supplied_normalized_value
 assert len(v) in [3,4]
 for dose,zz in z[z.dose_uM.notna()].groupby('dose_uM'):
  vv=zz.set_index('Exp_as_labeled').author_supplied_normalized_value
  assert set(v.index)==set(vv.index)
  ratio=100*vv.sort_index()/v.sort_index()
  for ex,val in ratio.items():paired.append({'schedule':labels[ti],'dose_uM':dose,'Exp_as_labeled':int(ex),'IL1beta_percent_of_withinExp_vehicle':float(val),'reduction_percent_of_withinExp_vehicle':float(100-val)})
  summary.append({'schedule':labels[ti],'dose_uM':dose,'n_author_labeled_experiments':len(ratio),'mean_author_percent_stimulated_control':float(vv.mean()),'mean_vehicle_percent_stimulated_control':float(v.mean()),'mean_withinExp_vehicle_response_percent':float(ratio.mean()),'SD_withinExp_vehicle_response_percent':float(ratio.std(ddof=1)),'mean_withinExp_vehicle_reduction_percent':float(100-ratio.mean()),'new_P_value_computed':False})
P=pd.DataFrame(paired);S=pd.DataFrame(summary);P.to_csv(O/'Quercetin_IL1B_车辆配对比值_全部重复.tsv',sep='\t',index=False);S.to_csv(O/'Quercetin_功能剂量与车辆对照_描述性再分析.tsv',sep='\t',index=False)
V=Q[Q.table_index.isin([0,1])].copy();V.to_csv(O/'Quercetin_活力与菌增殖_作者归一数值.tsv',sep='\t',index=False)
assert len(S)==15 and len(P)==50 and len(L)==sum(Q.n_labeled_Exp_columns)
# Actual source arithmetic discrepancies are preserved, not forced to pass.
source_dose_QC=Q[Q.table_index.isin([0,1,2,3,4])]
mean_flag_count=int(source_dose_QC.mean_difference.abs().gt(.002).sum())
sem_flag_count=int(source_dose_QC.SEM_difference.abs().gt(.002).sum())
report={'status':'COMPLETED_NORMALIZED_REPLICATE_REANALYSIS','completed':datetime.datetime.now().astimezone().isoformat(),'source_DOI':'10.1371/journal.pone.0237752','source_PMID':'32817646','source_PMID_to_confirm_from_XML':True,'source_PM C':'PMC7446918','source_SI_SHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'all_source_tables':10,'author_normalized_replicates_saved':len(L),'recomputed_source_rows':len(Q),'source_arithmetic_flags':Q[Q.outside_rounding_tolerance002].to_dict(orient='records'),'dose_tables_mean_flags':mean_flag_count,'dose_tables_SEM_flags':sem_flag_count,'source_arithmetic_all_PASS':False,'IL1beta_schedule_dose_rows':len(S),'vehicle_matched_labeled_Exp_ratios':len(P),'IL1beta_results':S.to_dict(orient='records'),'viability_dose_values':V[V.table_index.eq(1)&V.dose_uM.notna()].to_dict(orient='records'),'no_new_P_values_or_patient_claim':True,'boundary':'Author-supplied normalized repeated experimental values; not absolute raw fluorescence/ELISA, not new patient observations. Within-column vehicle ratios descriptive. Viability from separate experiment displayed alongside, never used to divide secretion data. WB arithmetic inconsistencies retained and not silently repaired.'}
# Official PMID is taken from downloaded article, not guessed.
full=ET.parse(O/'原研究全文/PMC7446918.xml').getroot();report['source_PMID']=next(x.text for x in full.findall('.//article-id') if x.get('pub-id-type')=='pmid');report.pop('source_PMID_to_confirm_from_XML');report['source_PMC']=report.pop('source_PM C')
def clean(x):
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
 if isinstance(x,list):return [clean(v) for v in x]
 if isinstance(x,float) and not np.isfinite(x):return None
 return x
report=clean(report)
(O/'Quercetin_真实SI再分析摘要.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
print('Summary',json.dumps({k:report[k] for k in ['source_PMID','all_source_tables','author_normalized_replicates_saved','recomputed_source_rows','dose_tables_mean_flags','dose_tables_SEM_flags','vehicle_matched_labeled_Exp_ratios']},ensure_ascii=False),flush=True)
print(S.to_string(index=False),flush=True)
print('Arithmetic flags',Q[Q.outside_rounding_tolerance002][['endpoint','treatment','source_mean','recomputed_mean','source_SEM','recomputed_SEM']].to_string(index=False),flush=True)
