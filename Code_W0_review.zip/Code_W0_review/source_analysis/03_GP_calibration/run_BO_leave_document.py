"""Document-held-out sensitivity: all eligible >=20-compound documents, no UQ or BO rerun."""
from pathlib import Path
import sys,json,hashlib,datetime,csv,traceback
E=Path(__file__).resolve().parent
for p in reversed(['G:/痛风/第二步_靶点预测与疾病交集/runtime/ppi_analysis_libraries','G:/痛风/第二步_靶点预测与疾病交集/论文推进_2026-10-30/单细胞定位/runtime','G:/痛风/第二步_靶点预测与疾病交集/rdkit_runtime']):sys.path.insert(0,p)
import numpy as np,pandas as pd,sklearn
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Kernel
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score
from rdkit import Chem,rdBase
from rdkit.Chem import rdFingerprintGenerator
O=E/'06_干实验文献与贝叶斯优化/BO实测标签基准/留文献外预测';O.mkdir(exist_ok=True)
A=O.parent/'全部1064记录_纳入排除与结构审计.tsv'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def key(s):return hashlib.sha256(s.encode()).hexdigest()[:16]
d=pd.read_csv(A,sep='\t',low_memory=False)
q=d[d.primary_metadata_eligible.eq(True)].copy()
assert len(q)==605 and q.normalized_SMILES.notna().all() and np.isfinite(q.pIC50_computed).all()
# Eligibility is based on frozen source membership and sample size only, not observed prediction performance.
counts=q.groupby('document_chembl_id').normalized_SMILES.nunique()
docs=sorted(counts[counts.ge(20)].index.tolist())
contract={'created_before_fitting':datetime.datetime.now().astimezone().isoformat(),'task':'leave-document-out prediction sensitivity, retaining original scaffold benchmark','source_SHA256':sha(A),'source_script_SHA256':sha(__file__),'primary_records':len(q),'all_documents_included_if_unique_compounds_at_least':20,'documents':[{ 'document':doc,'unique_compounds':int(counts.loc[doc])} for doc in docs],'number_of_folds':len(docs),'not_restricted_to_expected8_if_rule_yields9':True,'test_endpoint':'Median pIC50 using held-out document records only','training_endpoint':'Exclude held-out document and all held-out normalized structures from every other document, then aggregate remaining records by normalized structure','model':'fixed sklearn Tanimoto GP, Morgan radius2 1024bit includeChirality, alpha=.25^2 normalized outcome units, normalize_y=True, optimizer=None','baseline':'arithmetic mean of reaggregated training compound endpoints; no fitted test parameters','UQ':'not performed; original calibration partition not reused','report':'All folds GP and mean-baseline RMSE/MAE/R2; all test compound predictions; maximum train Tanimoto and nearest training compound; no fold or endpoint selection','scientific_scope':'Historical reported IC50 exact-label subset; no new drug activity, no source-unit relabeling, no prospective efficacy claim'}
contractfile=O/'拟合前冻结_留文献外预测.json'
if contractfile.exists():
 old=json.loads(contractfile.read_text(encoding='utf-8'));assert old['source_SHA256']==contract['source_SHA256'] and old['documents']==contract['documents']
else:dump(contractfile,contract)
assert len(docs)==9
class Tanimoto(Kernel):
 def __init__(self):pass
 def __call__(self,X,Y=None,eval_gradient=False):
  if Y is None:Y=X
  dots=X@Y.T;den=X.sum(1)[:,None]+Y.sum(1)[None,:]-dots
  K=np.divide(dots,den,out=np.zeros_like(dots),where=den>0)
  return (K,np.empty((*K.shape,0))) if eval_gradient else K
 def diag(self,X):return np.ones(len(X))
 def is_stationary(self):return False
allsmiles=sorted(q.normalized_SMILES.unique())
gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=1024,includeChirality=True)
fp={}
for smi in allsmiles:
 m=Chem.MolFromSmiles(smi);assert m is not None
 arr=np.array(gen.GetFingerprint(m)).astype(float);assert arr.shape==(1024,) and arr.sum()>0
 fp[smi]=arr

def aggregate(z):
 out=z.groupby('normalized_SMILES',sort=True).agg(pIC50=('pIC50_computed','median'),pIC50_min=('pIC50_computed','min'),pIC50_max=('pIC50_computed','max'),n_records=('pIC50_computed','size'),n_assays=('assay_chembl_id','nunique'),assay_ids=('assay_chembl_id',lambda a:';'.join(sorted(set(a)))),document_ids=('document_chembl_id',lambda a:';'.join(sorted(set(a)))),molecule_chembl_ids=('molecule_chembl_id',lambda a:';'.join(sorted(set(a.dropna().astype(str)))))).reset_index()
 out['compound_key']=out.normalized_SMILES.map(key);return out

def metrics(y,p):
 return {'RMSE':float(np.sqrt(mean_squared_error(y,p))),'MAE':float(mean_absolute_error(y,p)),'R2':float(r2_score(y,p)) if np.std(y)>0 else None}
rows=[];predictions=[];foldsource=[]
for doc in docs:
 held=q[q.document_chembl_id.eq(doc)].copy();heldstruct=set(held.normalized_SMILES)
 remaining=q[~q.document_chembl_id.eq(doc)].copy()
 shared=int(remaining.normalized_SMILES.isin(heldstruct).sum())
 traw=remaining[~remaining.normalized_SMILES.isin(heldstruct)].copy()
 te=aggregate(held);tr=aggregate(traw)
 assert len(te)>=20 and len(tr)>=20 and not (set(te.normalized_SMILES)&set(tr.normalized_SMILES))
 assert not traw.document_chembl_id.eq(doc).any() and set(te.document_ids)=={doc}
 Xtr=np.stack([fp[s] for s in tr.normalized_SMILES]);Xte=np.stack([fp[s] for s in te.normalized_SMILES])
 ytr=tr.pIC50.to_numpy(float);yte=te.pIC50.to_numpy(float)
 gp=GaussianProcessRegressor(kernel=Tanimoto(),alpha=.25**2,optimizer=None,normalize_y=True)
 gp.fit(Xtr,ytr);mu=gp.predict(Xte);base=np.full(len(te),ytr.mean())
 sim=Tanimoto()(Xte,Xtr);nearest=np.argmax(sim,axis=1);mx=sim[np.arange(len(te)),nearest]
 out=te.copy();out.insert(0,'heldout_document',doc)
 out=out.rename(columns={'pIC50':'observed_document_only_pIC50'})
 out['predicted_GP_pIC50']=mu;out['predicted_trainingmean_pIC50']=base
 out['GP_residual']=yte-mu;out['baseline_residual']=yte-base
 out['maximum_Tanimoto_to_training']=mx
 out['nearest_training_compound_key']=tr.compound_key.to_numpy()[nearest]
 out['nearest_training_normalized_SMILES']=tr.normalized_SMILES.to_numpy()[nearest]
 out['nearest_training_document_ids']=tr.document_ids.to_numpy()[nearest]
 predictions.append(out)
 mg=metrics(yte,mu);mb=metrics(yte,base)
 row={'heldout_document':doc,'heldout_records':len(held),'test_compounds':len(te),'training_records_after_exclusion':len(traw),'training_compounds':len(tr),'other_document_rows_removed_for_heldout_structure':shared,'test_pIC50_mean':float(yte.mean()),'test_pIC50_sd':float(yte.std()),'train_pIC50_mean':float(ytr.mean()),**{'GP_'+k:v for k,v in mg.items()},**{'trainingmean_'+k:v for k,v in mb.items()},'RMSE_reduction_vs_trainingmean':mb['RMSE']-mg['RMSE'],'median_max_train_Tanimoto':float(np.median(mx)),'minimum_max_train_Tanimoto':float(mx.min()),'maximum_max_train_Tanimoto':float(mx.max()),'test_compounds_maxTanimoto_eq1':int(np.isclose(mx,1,atol=1e-12).sum()),'status':'COMPLETED'}
 rows.append(row)
 tr.to_csv(O/f'{doc}_训练端点_排除留出结构后.tsv',sep='\t',index=False)
 out.to_csv(O/f'{doc}_全部预测与最近训练结构.tsv',sep='\t',index=False)
 foldsource.append({'heldout_document':doc,'no_normalized_structure_overlap':True,'train_endpoint_rebuilt_after_exclusion':True,'test_labels_from_heldout_document_only':True,'source_activity_ids_test':sorted(map(int,held.activity_id)),'source_activity_ids_train':sorted(map(int,traw.activity_id))})
 print('Completed',doc,'n=',len(te),'GP_RMSE=',mg['RMSE'],'baseline=',mb['RMSE'],'maxTanimoto=',float(mx.max()),flush=True)
res=pd.DataFrame(rows);allpred=pd.concat(predictions,ignore_index=True)
res.to_csv(O/'全部9折_预测指标与来源规模.tsv',sep='\t',index=False)
allpred.to_csv(O/'全部9折_每分子预测与最大Tanimoto.tsv',sep='\t',index=False)
pooledgp=metrics(allpred.observed_document_only_pIC50,allpred.predicted_GP_pIC50)
pooledbase=metrics(allpred.observed_document_only_pIC50,allpred.predicted_trainingmean_pIC50)
summary={'status':'COMPLETED_ALL9_DOCUMENTS','completed':datetime.datetime.now().astimezone().isoformat(),'planned_by_size_only_documents':len(docs),'completed_documents':len(res),'heldout_compound_document_rows':len(allpred),'unique_heldout_normalized_structures':allpred.normalized_SMILES.nunique(),'GP_lower_RMSE_than_trainingmean_folds':int((res.GP_RMSE<res.trainingmean_RMSE).sum()),'macro_mean_fold_RMSE_GP':float(res.GP_RMSE.mean()),'macro_mean_fold_RMSE_trainingmean':float(res.trainingmean_RMSE.mean()),'macro_mean_fold_MAE_GP':float(res.GP_MAE.mean()),'macro_mean_fold_MAE_trainingmean':float(res.trainingmean_MAE.mean()),'pooled_descriptive_GP':pooledgp,'pooled_descriptive_trainingmean':pooledbase,'fold_results':res.to_dict(orient='records'),'all_folds_preserved':True,'no_test_structure_in_any_training_fold':True,'source_input_SHA256_unchanged':sha(A)==contract['source_SHA256'],'calibration_reused':False,'UQ_performed':False,'BO_rerun_in_this_module':False,'scope':'Leave-document-out historical-label sensitivity; all9docs including poor folds, no p-values or biological-repeat interpretation; not replacement of original scaffold result. Shared patent families/assay protocols and near structures can still cross document IDs.','software':{'sklearn':sklearn.__version__,'numpy':np.__version__,'pandas':pd.__version__,'RDKit':rdBase.rdkitVersion},'script_SHA256':sha(__file__)}
assert summary['source_input_SHA256_unchanged'] and len(res)==9 and len(allpred)==sum(counts.loc[docs])
dump(O/'实际完成_留文献外预测.json',summary);dump(O/'逐折来源与泄漏断言.json',foldsource)
report='''留文献外预测敏感性：实际完成
完成时间：{time}
9个满足≥20独立规范化化合物的文献全部纳入，未按结果挑折；原骨架holdout结果未替换。
每折test端点仅取留出文献内部pIC50中位数；训练先排除该文献与任何同结构分子，再重聚合剩余记录。没有复用全库中位数、calibration区间或test标签。
全部{n}个化合物–文献测试行保存了实测端点、GP预测、训练均值基线、残差及与训练库最大Tanimoto/最近邻来源。
GP的RMSE低于训练均值基线的折数：{wins}/9；逐折结果和不利折均完整保留。宏平均RMSE GP={gp:.4f}，训练均值={base:.4f}。折间不合并成生物学重复，没有按结果改模型超参数。
该敏感性检验文献外迁移；不同专利ID仍可能属于同系列，近似化学结构也可跨来源，因此不是严格时间外或全新化学空间验证。实测数据库/专利的内部单位风险按独立审阅记录保留，未更改任何标签。
没有在这里做UQ校准、BO选择或新药效发现。
'''.format(time=summary['completed'],n=len(allpred),wins=summary['GP_lower_RMSE_than_trainingmean_folds'],gp=summary['macro_mean_fold_RMSE_GP'],base=summary['macro_mean_fold_RMSE_trainingmean'])
(O/'方法与真实结果_交付说明.txt').write_text(report,encoding='utf-8')
dump(O/'文件SHA256.json',[{'file':p.name,'sha256':sha(p)} for p in sorted(O.iterdir()) if p.is_file() and p.name!='文件SHA256.json'])
print(json.dumps({k:v for k,v in summary.items() if k!='fold_results'},ensure_ascii=False,indent=2),flush=True)
