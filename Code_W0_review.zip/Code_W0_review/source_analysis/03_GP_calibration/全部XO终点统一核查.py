from pathlib import Path
import sys,re,json,hashlib,datetime,subprocess
E=Path(__file__).resolve().parents[2]; O=Path(__file__).resolve().parent
sys.path[:0]=['G:/痛风/第二步_靶点预测与疾病交集/runtime/ppi_analysis_libraries','G:/痛风/第二步_靶点预测与疾病交集/论文推进_2026-10-30/单细胞定位/runtime']
import pandas as pd
A=E/'06_干实验文献与贝叶斯优化/BO实测标签基准'
a=pd.read_csv(A/'全部1064记录_纳入排除与结构审计.tsv',sep='\t',low_memory=False).fillna('')
# Frozen textual screen: direct mention is an audit flag, not automatic correction of source data.
rules={'DPPH':r'\bDPPH\b|diphenyl.?2.?picrylhydrazyl','ABTS':r'\bABTS\b','FRAP':r'\bFRAP\b|ferric reducing antioxidant','tyrosinase':r'\btyrosinase\b','PTP1B':r'\bPTP.?1B\b','acetylcholinesterase':r'\bacetylcholinesterase\b'}
xo=r'\bxanthine\b|\bXOD\b|\bXO\b|uric acid|urate formation'
def classify(t):
 t=str(t);hits=[k for k,p in rules.items() if re.search(p,t,re.I)]
 has=bool(re.search(xo,t,re.I))
 return '|'.join(hits),has,('explicit_nonXO_endpoint_description' if hits and not has else 'mixed_XO_and_other_endpoint_needs_original_table' if hits else 'XO_text_present_not_primary_source_verified' if has else 'endpoint_not_clear_in_description')
c=a.assay_description.map(classify)
a['explicit_other_endpoint_terms']=[x[0] for x in c];a['XO_text_present']=[x[1] for x in c];a['endpoint_text_audit_class']=[x[2] for x in c]
a['text_rule_version']='2026-11-03_uniform_regex_v1; semantics only; no source overwrite'
a.to_csv(O/'全部1064_统一终点语义审查_原记录保留.tsv',sep='\t',index=False)
assay=a.groupby(['assay_chembl_id','assay_description','explicit_other_endpoint_terms','XO_text_present','endpoint_text_audit_class'],dropna=False).agg(n_records=('activity_id','size'),n_compounds=('canonical_smiles','nunique'),n_oldprimary=('primary_metadata_eligible',lambda x:sum(str(v).lower()=='true' for v in x)),documents=('document_chembl_id',lambda x:'|'.join(sorted(set(x))))).reset_index()
assay.to_csv(O/'全部assay_统一终点语义审查.tsv',sep='\t',index=False)
a[a.explicit_other_endpoint_terms.ne('')].to_csv(O/'明确其他终点_全部原始记录.tsv',sep='\t',index=False)
b=pd.read_csv(A/'原方XDH_精确匹配_全部原始记录含排除.tsv',sep='\t',low_memory=False).fillna('')
print('BRIDGE_COLS',list(b.columns),flush=True)
sel=['activity_id','explicit_other_endpoint_terms','XO_text_present','endpoint_text_audit_class']
b=b.merge(a[sel],on='activity_id',how='left')
b.to_csv(O/'原方三已匹配结构_全部记录_终点审查.tsv',sep='\t',index=False)
print(assay[assay.explicit_other_endpoint_terms.ne('')][['assay_chembl_id','n_records','n_compounds','n_oldprimary','endpoint_text_audit_class']].to_string(index=False),flush=True)
print(b[['original_formula_pubchem_cid','assay_chembl_id','document_chembl_id','standard_value','standard_units','assay_description','endpoint_text_audit_class']].to_string(index=False),flush=True)
(O/'终点审查_规则与实际摘要.json').write_text(json.dumps({'date':datetime.datetime.now().astimezone().isoformat(),'all_records':len(a),'assays':len(assay),'raw_SHA':hashlib.sha256((A/'全部1064记录_纳入排除与结构审计.tsv').read_bytes()).hexdigest(),'regex_rules':rules,'XO_regex':xo,'flagged_records':int(a.explicit_other_endpoint_terms.ne('').sum()),'flagged_assays':assay[assay.explicit_other_endpoint_terms.ne('')].to_dict(orient='records'),'historical547_not_modified':True,'warning':'Description screen cannot resolve ambiguous copied descriptions or verify species; original tables required. No label was corrected here.'},ensure_ascii=False,indent=2),encoding='utf-8')
D=O/'XO原来源核查';D.mkdir(exist_ok=True)
docs=sorted(set(b.document_chembl_id)|{'CHEMBL1158850'})
lines=["$ErrorActionPreference='Continue'","$taskD=Join-Path $PSScriptRoot 'XO原来源核查'"]
for d in docs:
 lines.append("try { Invoke-WebRequest -Uri 'https://www.ebi.ac.uk/chembl/api/data/document/"+d+".json' -UseBasicParsing -TimeoutSec 20 -OutFile (Join-Path $taskD '"+d+".json'); Write-Output 'OK "+d+"' } catch { Write-Output ('FAIL "+d+" '+$_.Exception.Message) }; Start-Sleep -Milliseconds 400")
p=O/'获取全部桥接XO来源.ps1';p.write_text('\n'.join(lines),encoding='utf-8-sig')
subprocess.run(['powershell','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(p)],check=True)

