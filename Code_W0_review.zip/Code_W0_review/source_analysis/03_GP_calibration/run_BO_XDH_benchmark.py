"""Measured-label XDH benchmark: grouped holdout prediction, uncertainty, budget-matched BO replay."""
from pathlib import Path
import os,sys,json,hashlib,datetime,warnings
E=Path(__file__).resolve().parent
for p in reversed(['G:/痛风/第二步_靶点预测与疾病交集/runtime/ppi_analysis_libraries','G:/痛风/第二步_靶点预测与疾病交集/论文推进_2026-10-30/单细胞定位/runtime','G:/痛风/第二步_靶点预测与疾病交集/rdkit_runtime']):sys.path.insert(0,p)
import numpy as np,pandas as pd,scipy,sklearn
from scipy.linalg import cho_factor,cho_solve,solve_triangular
from scipy.special import log_ndtr
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Kernel
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score
from rdkit import Chem,DataStructs,rdBase
from rdkit.Chem import rdFingerprintGenerator
from rdkit.Chem.Scaffolds import MurckoScaffold
from rdkit.Chem.MolStandardize import rdMolStandardize
F=E/'06_干实验文献与贝叶斯优化';O=F/'BO实测标签基准';O.mkdir(exist_ok=True)
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
stamp=datetime.datetime.now().astimezone().isoformat()
protocol={'frozen_before_model_comparison':stamp,'not_preregistered':True,'scope':'XDH human-target-assigned IC50 historical measured-label benchmark, separate from formula efficacy','input_SHA256':hashlib.sha256((F/'XDH_IC50_全部原始记录与assay元数据.tsv').read_bytes()).hexdigest(),'primary_records':'IC50 = positive nM; standard_flag1; empty validity flags; potential_duplicate0; assay organism Homo sapiens and target confidence9; no variant; exclude description contradicting human provenance; all exclusions retained','curation':'RDKit fragment parent + uncharger + canonical isomeric SMILES; molecule endpoint median pIC50=9-log10(nM), preserve all assay/doc IDs and ranges','human_assay_metadata_not_independently_reverified':'ChEMBL metadata and descriptions, not new wet assay verification','features':'Morgan radius2 1024bits includeChirality, Tanimoto kernel','holdout':'Murcko scaffold GroupShuffleSplit seed42 20%scaffolds test; remaining25%scaffolds calibration seed43; no same scaffold across three partitions','model':'fixed Tanimoto GP normalize_y; alpha=.25^2 in standardized outcome units; no hyperparameter search or heldout model selection','uncertainty':'latent GP std plus fixed observation noise; raw90 interval; separately calibrated 90 group-max standardized residual quantile; empirical heldout molecule and all-within-scaffold coverage, not unconditional safety guarantee','BO_pool':'training partition only; test/calibration labels never used by acquisition','BO':'20 seeds0..19, common10initialrandommolecules, budget40totalorallpoolifsmaller; random, greedymean, LogEI; alltrajectories retained; noiseless historical median oracle and fixed regularization model; not prospective new experiments','BO_endpoints':'all steps best pIC50 and recall of pool top5% threshold; full curves; no metric or seed selection','biochemical_hit':'median pIC50>=6 (IC50<=1uM) descriptive benchmark cutoff, not clinical efficacy','publication_boundary':'exploratory single-target feasibility, not a new method claim or independent proof of anti-gout clinical efficacy'}
pp=O/'建模与比较规则_模型结果前冻结.json'
if not pp.exists():dump(pp,protocol)
else:
 old=json.loads(pp.read_text(encoding='utf-8'));assert old['input_SHA256']==protocol['input_SHA256']
d=pd.read_csv(F/'XDH_IC50_全部原始记录与assay元数据.tsv',sep='\t',low_memory=False)
rules={
 'not_exact_IC50_nM':~(d.standard_type.eq('IC50')&d.standard_relation.eq('=')&d.standard_units.eq('nM')),
 'invalid_numeric':~(pd.to_numeric(d.standard_value,errors='coerce')>0),
 'not_standard_flag1':~d.standard_flag.eq(1),
 'validity_flag':d.data_validity_comment.notna(),
 'potential_duplicate':pd.to_numeric(d.potential_duplicate,errors='coerce').fillna(0).ne(0),
 'assay_organism_not_human':~d.metadata_assay_organism.eq('Homo sapiens'),
 'confidence_not9':~pd.to_numeric(d.metadata_confidence_score,errors='coerce').eq(9),
 'variant_or_mutation':d.assay_variant_accession.notna()|d.assay_variant_mutation.notna(),
 'description_nonhuman_source':d.assay_description.fillna('').str.contains(r'\bbovine\b|\brat\b|\bmurine\b|\bporcine\b|\bmouse\b|\bmilk\b|\bbuffalo\b',case=False,regex=True)
}
for k,v in rules.items():d[k]=v
d['exclusion_reasons']=[';'.join(k for k in rules if bool(d.loc[i,k])) for i in d.index]
d['primary_metadata_eligible']=d.exclusion_reasons.eq('')
norms=[];scafs=[];rdBase.DisableLog('rdApp.warning')
for i,row in d.iterrows():
 if not row.primary_metadata_eligible:norms.append(None);scafs.append(None);continue
 try:
  m=Chem.MolFromSmiles(str(row.canonical_smiles));assert m is not None
  m=rdMolStandardize.FragmentParent(m);m=rdMolStandardize.Uncharger().uncharge(m);Chem.SanitizeMol(m);Chem.GetSymmSSSR(m)
  smi=Chem.MolToSmiles(m,isomericSmiles=True,canonical=True)
  scaffold=MurckoScaffold.MurckoScaffoldSmiles(mol=m,includeChirality=False) or '<ACYCLIC>'
  norms.append(smi);scafs.append(scaffold)
 except Exception:
  norms.append(None);scafs.append(None);d.loc[i,'exclusion_reasons']='structure_parse_failure';d.loc[i,'primary_metadata_eligible']=False
d['normalized_SMILES']=norms;d['Murcko_scaffold']=scafs
d['pIC50_computed']=9-np.log10(pd.to_numeric(d.standard_value,errors='coerce').clip(lower=1e-300))
d.to_csv(O/'全部1064记录_纳入排除与结构审计.tsv',sep='\t',index=False)
q=d[d.primary_metadata_eligible].copy()
rows=[]
for smi,z in q.groupby('normalized_SMILES',sort=True):
 rows.append({'compound_key':hashlib.sha256(smi.encode()).hexdigest()[:16],'normalized_SMILES':smi,'Murcko_scaffold':z.Murcko_scaffold.iloc[0],'molecule_chembl_ids':';'.join(sorted(set(z.molecule_chembl_id.dropna().astype(str)))),'names':';'.join(sorted(set(z.molecule_pref_name.dropna().astype(str)))),'pIC50_median':float(z.pIC50_computed.median()),'pIC50_min':float(z.pIC50_computed.min()),'pIC50_max':float(z.pIC50_computed.max()),'pIC50_range':float(z.pIC50_computed.max()-z.pIC50_computed.min()),'n_records':len(z),'n_assays':z.assay_chembl_id.nunique(),'n_documents':z.document_chembl_id.nunique(),'assay_ids':';'.join(sorted(set(z.assay_chembl_id))),'document_ids':';'.join(sorted(set(z.document_chembl_id))),'activity_ids':';'.join(map(str,sorted(set(z.activity_id))))})
c=pd.DataFrame(rows).sort_values('compound_key').reset_index(drop=True)
assert len(c)>=60 and c.Murcko_scaffold.nunique()>=15,'Insufficient chemical/scaffold data; do not force benchmark'
traincal,test=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=42).split(c,groups=c.Murcko_scaffold))
tr_local,cal_local=next(GroupShuffleSplit(n_splits=1,test_size=.25,random_state=43).split(c.iloc[traincal],groups=c.iloc[traincal].Murcko_scaffold))
train=traincal[tr_local];cal=traincal[cal_local]
assert not(set(c.loc[train,'Murcko_scaffold'])&set(c.loc[test,'Murcko_scaffold']))
assert not(set(c.loc[train,'Murcko_scaffold'])&set(c.loc[cal,'Murcko_scaffold']))
assert not(set(c.loc[cal,'Murcko_scaffold'])&set(c.loc[test,'Murcko_scaffold']))
c['partition']='';c.loc[train,'partition']='train_BO_pool';c.loc[cal,'partition']='calibration';c.loc[test,'partition']='test'
c['median_IC50_nM']=10.**(9-c.pIC50_median);c['biochemical_hit_pIC50_ge6']=c.pIC50_median.ge(6)
c.to_csv(O/'规范化化合物_完整端点与骨架划分.tsv',sep='\t',index=False)
c[c.biochemical_hit_pIC50_ge6].sort_values('pIC50_median',ascending=False).to_csv(O/'已知实测活性阳性_不称新发现.tsv',sep='\t',index=False)
gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=1024,includeChirality=True)
X=np.vstack([np.array(gen.GetFingerprint(Chem.MolFromSmiles(s))) for s in c.normalized_SMILES]).astype(float)
y=c.pIC50_median.to_numpy()
class Tanimoto(Kernel):
 def __init__(self):pass
 def __call__(self,X,Y=None,eval_gradient=False):
  if Y is None:Y=X
  dots=X@Y.T;den=X.sum(1)[:,None]+Y.sum(1)[None,:]-dots
  K=np.divide(dots,den,out=np.zeros_like(dots),where=den>0)
  return (K,np.empty((*K.shape,0))) if eval_gradient else K
 def diag(self,X):return np.ones(len(X))
 def is_stationary(self):return False
K=Tanimoto()(X)
eval_model=GaussianProcessRegressor(kernel=Tanimoto(),alpha=.25**2,optimizer=None,normalize_y=True)
eval_model.fit(X[train],y[train])
mu_cal,s_cal=eval_model.predict(X[cal],return_std=True)
mu_test,s_test=eval_model.predict(X[test],return_std=True)
noise=.25*np.std(y[train])
sd_cal=np.sqrt(s_cal*s_cal+noise*noise);sd_test=np.sqrt(s_test*s_test+noise*noise)
rs=np.abs(y[cal]-mu_cal)/np.maximum(sd_cal,1e-12)
gmax=pd.DataFrame({'group':c.loc[cal,'Murcko_scaffold'].to_numpy(),'score':rs}).groupby('group').score.max().to_numpy()
rank=int(np.ceil((len(gmax)+1)*.9))
qcal=float(np.sort(gmax)[min(rank,len(gmax))-1])
if rank>len(gmax):qcal=float(np.inf)
assert np.isfinite(qcal),'Too few calibration scaffold groups for finite90 interval'
pred=c.loc[np.r_[cal,test],['compound_key','names','partition','Murcko_scaffold','pIC50_median']].copy()
pred['predicted_pIC50']=np.r_[mu_cal,mu_test];pred['observation_std']=np.r_[sd_cal,sd_test]
pred['raw90_low']=pred.predicted_pIC50-1.6448536269514722*pred.observation_std
pred['raw90_high']=pred.predicted_pIC50+1.6448536269514722*pred.observation_std
pred['calibrated90_low']=pred.predicted_pIC50-qcal*pred.observation_std
pred['calibrated90_high']=pred.predicted_pIC50+qcal*pred.observation_std
pred.to_csv(O/'不确定性_独立骨架calibration与test逐值.tsv',sep='\t',index=False)
def coverage(df,low,high):
 ok=df.pIC50_median.between(df[low],df[high])
 return {'molecule_empirical_coverage':float(ok.mean()),'all_members_scaffold_empirical_coverage':float(pd.DataFrame({'g':df.Murcko_scaffold,'ok':ok}).groupby('g').ok.all().mean()),'mean_interval_width':float((df[high]-df[low]).mean())}
t=pred[pred.partition.eq('test')]
metrics={'n_records_all':len(d),'n_primary_records':len(q),'n_compounds':len(c),'n_scaffolds':c.Murcko_scaffold.nunique(),'partition_compounds':c.partition.value_counts().astype(int).to_dict(),'partition_scaffolds':c.groupby('partition').Murcko_scaffold.nunique().astype(int).to_dict(),'test_RMSE_GP':float(np.sqrt(mean_squared_error(y[test],mu_test))),'test_MAE_GP':float(mean_absolute_error(y[test],mu_test)),'test_R2_GP':float(r2_score(y[test],mu_test)),'test_RMSE_trainingmean_baseline':float(np.sqrt(mean_squared_error(y[test],np.repeat(y[train].mean(),len(test))))),'calibration_scaffold_groups':len(gmax),'calibration_multiplier90':qcal,'raw90':coverage(t,'raw90_low','raw90_high'),'calibrated90':coverage(t,'calibrated90_low','calibrated90_high'),'known_measured_biochemical_hits_pIC50ge6':int(c.biochemical_hit_pIC50_ge6.sum()),'new_unmeasured_activity_discovered':False}
dump(O/'预测与不确定性_实测指标.json',metrics)
print('Curated/prediction:',json.dumps(metrics,ensure_ascii=False),flush=True)
pool=np.asarray(sorted(train));pooly=y[pool];poolK=K[np.ix_(pool,pool)]
topth=float(np.quantile(pooly,.95));top=pooly>=topth;budget=min(40,len(pool));initial=10
def posterior(obs):
 yy=pooly[obs];ym=yy.mean();ys=yy.std() or 1.
 A=poolK[np.ix_(obs,obs)]+(.25**2)*np.eye(len(obs))
 cf=cho_factor(A,lower=True,check_finite=False)
 a=cho_solve(cf,(yy-ym)/ys,check_finite=False)
 k=poolK[np.ix_(obs,np.arange(len(pool)))]
 mu=(k.T@a)*ys+ym
 sol=solve_triangular(cf[0],k,lower=True,check_finite=False)
 var=np.maximum(1-np.sum(sol*sol,axis=0),1e-14)*ys*ys
 return mu,np.sqrt(var)
def logEI(mu,sd,best):
 z=(mu-best)/np.maximum(sd,1e-15);lp=-.5*z*z-.5*np.log(2*np.pi)
 out=np.empty(len(z));a=z>=0
 out[a]=np.log(sd[a])+np.logaddexp(lp[a],np.log(np.maximum(z[a],1e-300))+log_ndtr(z[a]))
 b=(z<0)&(z>=-10);zz=z[b];term=1+zz*np.exp(log_ndtr(zz)-lp[b])
 assert np.all(term>0)
 out[b]=np.log(sd[b])+lp[b]+np.log(term)
 tail=z<-10;u=-z[tail];inv2=(1/u)**2;poly=np.ones(len(u));term=np.ones(len(u))
 for k in range(1,20):
  term*=-(2*k+1)*inv2;poly+=term
 assert np.all(poly>0)
 out[tail]=np.log(sd[tail])+lp[tail]-2*np.log(u)+np.log(poly)
 return out
# Mathematical/numeric acquisition checks and actual official sklearn equivalence.
checks={'LogEI_finite_grid':bool(np.isfinite(logEI(np.array([-10.,-5.,0.,5.]),np.ones(4),0)).all()),'LogEI_monotone_mean':bool(np.all(np.diff(logEI(np.linspace(-10,10,201),np.ones(201),0))>0)),'sklearn_equivalence':[]}
from scipy.integrate import quad
tailchecks=[]
for zz in [-1.,-5.,-10.,-20.,-50.,-100.,-1e4]:
 u=-zz
 integ=quad(lambda v:v*np.exp(-v-v*v/(2*u*u)),0,np.inf,epsabs=1e-13,epsrel=1e-13)[0]
 ref=-.5*zz*zz-.5*np.log(2*np.pi)-2*np.log(u)+np.log(integ)
 got=float(logEI(np.array([zz]),np.array([1.]),0)[0]);err=abs(got-ref)
 assert err<1e-8, (zz,got,ref,err)
 tailchecks.append({'z':zz,'logEI':got,'scaled_integral_reference':float(ref),'absolute_log_error':float(err)})
checks['negative_tail_scaled_integral_QA']=tailchecks
checks['low_sigma_finite']=bool(np.isfinite(logEI(np.array([-1.,0.,1.]),np.full(3,1e-12),0)).all())
checks['logEI_tail_method']='z<-10:20-term Mills asymptotic series; other negative z:log_ndtr relation; positive z:logaddexp'
curves=[]
for seed in range(20):
 start=np.random.default_rng(seed).choice(len(pool),initial,replace=False).tolist()
 for method in ['random','greedy_mean','LogEI']:
  obs=start.copy();rng=np.random.default_rng(seed+10000)
  for n in range(initial,budget+1):
   observed=pooly[obs]
   curves.append({'seed':seed,'method':method,'evaluated_total':n,'best_measured_pIC50':float(observed.max()),'best_measured_IC50_nM':float(10**(9-observed.max())),'top5pct_recall':float(top[obs].sum()/top.sum()),'biochemical_hits_found':int((observed>=6).sum()),'last_compound_key':str(c.loc[pool[obs[-1]],'compound_key']),'last_observed_pIC50':float(observed[-1]),'initial_shared':n==initial})
   if n==budget:break
   avail=np.setdiff1d(np.arange(len(pool)),obs)
   if method=='random':nxt=int(rng.choice(avail))
   else:
    mu,sd=posterior(obs)
    if seed==0 and method=='LogEI' and n in [initial,20,30]:
     ck=GaussianProcessRegressor(kernel=Tanimoto(),alpha=.25**2,optimizer=None,normalize_y=True).fit(X[pool[obs]],pooly[obs])
     cm,cs=ck.predict(X[pool],return_std=True)
     er1=float(np.max(np.abs(cm-mu)));er2=float(np.max(np.abs(cs-sd)));assert er1<1e-8 and er2<1e-8
     checks['sklearn_equivalence'].append({'round':n,'max_mean_error':er1,'max_std_error':er2})
    score=mu if method=='greedy_mean' else logEI(mu,sd,float(observed.max()))
    nxt=int(avail[np.argmax(score[avail])])
   assert nxt not in obs;obs.append(nxt)
 print('BO seed',seed,'completed',flush=True)
cur=pd.DataFrame(curves);cur.to_csv(O/'BO_20种子三策略_全部逐轮轨迹.tsv',sep='\t',index=False)
end=cur[cur.evaluated_total.eq(budget)]
summ=end.groupby('method').agg(seeds=('seed','size'),best_pIC50_mean=('best_measured_pIC50','mean'),best_pIC50_sd=('best_measured_pIC50','std'),top5pct_recall_mean=('top5pct_recall','mean'),top5pct_recall_sd=('top5pct_recall','std'),biochemical_hits_mean=('biochemical_hits_found','mean')).reset_index()
summ.to_csv(O/'BO_等预算终点_完整策略汇总.tsv',sep='\t',index=False)
paired=end.pivot(index='seed',columns='method',values='top5pct_recall')
delta=(paired.LogEI-paired.random).to_numpy()
boot=np.random.default_rng(20261103).choice(delta,(10000,len(delta)),replace=True).mean(1)
result={'status':'COMPLETED_HISTORICAL_LABEL_PREDICTION_UQ_AND_BO_REPLAY','completed':datetime.datetime.now().astimezone().isoformat(),'software':{'sklearn':sklearn.__version__,'numpy':np.__version__,'scipy':scipy.__version__,'RDKit':rdBase.rdkitVersion},'metrics':metrics,'BO_pool_compounds':len(pool),'BO_pool_top5pct_n':int(top.sum()),'BO_pool_top5pct_pIC50_threshold':topth,'budget_including10initial':budget,'seeds':20,'strategy_summary':summ.to_dict(orient='records'),'paired_LogEI_minus_random_top5pct_recall_mean':float(delta.mean()),'paired_seed_bootstrap95_CI':[float(np.quantile(boot,.025)),float(np.quantile(boot,.975))],'CI_unit':'algorithm initialisation on this one fixed chemical library; not biological replications/new assays','scientific_claim':'retrospective candidate selection and empirical uncertainty benchmark, not new prospective anti-gout efficacy','calibration_labels_used_for_acquisition':False,'heldout_test_labels_used_for_acquisition':False}
dump(O/'BO_实际完成摘要.json',result);dump(O/'数学与实现核验.json',checks)
readme='''本模块使用公开实测历史标签，完成预测—不确定性校准—贝叶斯优化离线回放。\n没有把数据库阳性写成新药发现，也没有把IC50或对接分数写成临床抗痛风疗效。\n原始1064条IC50完整保存；严格来源、精确单位、重复/变体/validity排除逐条列出；盐/结构归一后按化合物取pIC50中位数并保留跨assay范围。\n骨架分组训练/校准/测试不重叠，报告训练均值baseline与固定GP；UQ展示原始及独立校准区间的真实测试覆盖和宽度。\nBO仅在训练分区的历史实测化合物库做隐藏标签oracle回放，共20相同初始预算种子，比随机与纯均值贪心；不使用test/calibration标签优化。\n20次seed只衡量这一个固定化合物库上的算法初始化变异，不是20个独立药效实验。\nGP预测通过官方sklearn；BO采用相同Tanimoto GP的预计算矩阵实现，选定步骤与官方sklearn均值/标准差逐值核验。\n没有安装或宣称运行BoTorch；LogEI使用Gaussian单点解析式稳定枚举，后续大批量/多保真可换BoTorch并重新基准。\nChEMBL human target/assay标签不是逐文实验原始溯源的替代，assay/文献异质性及重复测量需要进一步独立研究验证。此为可执行先导，不是方法已优于所有方法的结论。\n来源：https://www.ebi.ac.uk/chembl/api/data/target/CHEMBL1929.json ; https://scikit-learn.org/stable/modules/gaussian_process.html ; https://arxiv.org/abs/2310.20708\n'''
(O/'实际计算_方法与结果边界.txt').write_text(readme,encoding='utf-8')
print(json.dumps(result,ensure_ascii=False),flush=True)

