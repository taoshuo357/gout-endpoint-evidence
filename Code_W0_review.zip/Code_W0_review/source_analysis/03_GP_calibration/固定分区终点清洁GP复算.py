"""Post-hoc endpoint semantic correction; frozen inherited partitions and model, no BO replay."""
from pathlib import Path
import sys,json,hashlib,datetime,html
P=Path(__file__).resolve().parent;E=P.parents[1];G=Path('G:/痛风/第二步_靶点预测与疾病交集');B=E/'06_干实验文献与贝叶斯优化/BO实测标签基准';F=P.parent/'03_候选功能证据';C=B/'原方候选优先序'
for p in reversed([G/'runtime/ppi_analysis_libraries',G/'论文推进_2026-10-30/单细胞定位/runtime',G/'rdkit_runtime']):sys.path.insert(0,str(p))
import numpy as np,pandas as pd,scipy,sklearn
from scipy.stats import norm,spearmanr
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Kernel
from sklearn.metrics import mean_squared_error,mean_absolute_error,r2_score
from rdkit import Chem,rdBase
from rdkit.Chem import rdFingerprintGenerator

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def tab(n,x):x.to_csv(P/n,sep='\t',index=False)
def read(p):return pd.read_csv(p,sep='\t',low_memory=False).fillna('')
paths={'uniform_endpoint_audit':F/'全部1064_统一终点语义审查_原记录保留.tsv','uniform_audit_summary':F/'终点审查_规则与实际摘要.json','old1064':B/'全部1064记录_纳入排除与结构审计.tsv','old547_and_partitions':B/'规范化化合物_完整端点与骨架划分.tsv','old_holdout_predictions':B/'不确定性_独立骨架calibration与test逐值.tsv','old_metrics':B/'预测与不确定性_实测指标.json','old_GP_source':E/'run_BO_XDH_benchmark.py','old_candidate52':C/'全部52_XDH候选_部署均值标准差与来源.tsv','old_candidate_mean49':C/'未精确匹配49_纯预测均值队列.tsv','old_candidate_std49':C/'未精确匹配49_模型标准差探索队列.tsv','old_candidate_source':C/'生成全部52候选优先序.py'}
contract={'frozen_before_this_sensitivity_fit':datetime.datetime.now().astimezone().isoformat(),'posthoc_semantic_correction_not_preregistered':True,'reason':'Uniform explicit non-XO assay description identifies DPPH radical scavenging assay CHEMBL5736870, not XO inhibition. This is endpoint semantic curation, not removal for model residual or predictive performance.','change':'Remove only the16 old-primary records in CHEMBL5736870 flagged explicit_nonXO_endpoint_description; all1064 source rows and other eligibility fields remain immutable. No imputed XO replacement values.','aggregation':'Same normalized isomeric SMILES and compound key; pIC50=9-log10(nM); median across retained primary records; min/max/counts/assay/document/activity IDs recomputed.','partition':'Inherit every old547 compound-key train_BO_pool/calibration/test assignment exactly; removed compounds naturally disappear, never reshuffle or replace.','model':'Morgan radius2 1024bits includeChirality=True; Tanimoto kernel; GaussianProcessRegressor alpha=.25**2 in standardized output units, normalize_y=True, optimizer=None; identical old and clean.','uncertainty':'Same latent GP SD plus .25*population_SD(training_y) observation noise; raw90 z1.6448536269514722; same group-max calibration residual quantile ceil((g+1)*.9), recalculated on inherited clean calibration only.','paired_test':'Old and clean models compared on intersection of oldtest and cleantest. Primary common truth is endpoint-clean median labels, with old-label truth comparison also fully retained. No post-clean result used for tuning.','candidate_fixed_partition':'All frozen49 previously unmatched structures predicted by old and clean training-partition GP, include latent/observation SD, inherited calibration intervals and nearest-training provenance. Candidate intervals have no demonstrated OOD guarantee.','deployment_secondary':'Separate all547-old vs allclean deployment fits reproduce old52 predictions then recompute all52 and frozen49 queues. Uncalibrated latentSD only, no transferred calibration intervals. Not test validation.','no_BO_replay':True,'no_new_labels_or_assays':True,'limits':['Source descriptions, target/assay species metadata and review-based copied records are not independently original-table verified.','Removing explicit DPPH does not verify all remaining605-16 rows as true human XO assays.','Single fixed chemical/scaffold split, heterogeneous assays/documents and literature transport limitations remain.','Prediction or UQ does not establish gout efficacy, new measured inhibitor potency, or safety.'],'software':{'sklearn':sklearn.__version__,'RDKit':rdBase.rdkitVersion,'numpy':np.__version__,'scipy':scipy.__version__},'source_inputs':{k:{'path':str(p),'SHA256':sha(p)} for k,p in paths.items()},'script_SHA256':sha(Path(__file__)),'official_method_reference':'https://scikit-learn.org/stable/modules/generated/sklearn.gaussian_process.GaussianProcessRegressor.html'}
cp=P/'终点敏感性_复算前冻结合同.json'
if cp.exists():assert json.loads(cp.read_text(encoding='utf-8'))['source_inputs']==contract['source_inputs']
else:dump(cp.name,contract)
d=read(paths['uniform_endpoint_audit']);oldc=read(paths['old547_and_partitions']).sort_values('compound_key').reset_index(drop=True);oldpred=read(paths['old_holdout_predictions']);oldmetrics=json.loads(paths['old_metrics'].read_text(encoding='utf-8'))
assert len(d)==1064 and len(oldc)==547
primary=d.primary_metadata_eligible.astype(str).str.lower().eq('true');remove=primary&d.endpoint_text_audit_class.eq('explicit_nonXO_endpoint_description');assert int(primary.sum())==605 and int(remove.sum())==16 and set(d.loc[remove,'assay_chembl_id'])=={'CHEMBL5736870'}
assert d.loc[remove,'explicit_other_endpoint_terms'].eq('DPPH').all() and d.loc[remove,'XO_text_present'].astype(str).str.lower().eq('false').all()
d['endpoint_sensitivity_old_primary']=primary;d['endpoint_sensitivity_removed_explicit_DPPH']=remove;d['endpoint_clean_primary']=primary&~remove;d['endpoint_sensitivity_reason']=np.where(remove,'Explicit DPPH radical-scavenging endpoint in assay description; no XO endpoint evidence in description','Unchanged old eligibility')
tab('全部1064_仅增敏感性纳入标记_原字段保留.tsv',d);tab('移除16条DPPH_全部原记录.tsv',d.loc[remove])
q=d[d.endpoint_clean_primary].copy();q['pIC50_sensitivity_recomputed']=9-np.log10(pd.to_numeric(q.standard_value));assert np.max(np.abs(q.pIC50_sensitivity_recomputed-pd.to_numeric(q.pIC50_computed)))<1e-12

def aggregate(z):
 rows=[]
 for smi,v in z.groupby('normalized_SMILES',sort=True):
  yy=pd.to_numeric(v.pIC50_computed)
  rows.append({'compound_key':hashlib.sha256(smi.encode()).hexdigest()[:16],'normalized_SMILES':smi,'Murcko_scaffold':v.Murcko_scaffold.iloc[0],'molecule_chembl_ids':';'.join(sorted(set(v.molecule_chembl_id.astype(str)))),'names':';'.join(sorted(set(v.molecule_pref_name.astype(str))-{''})),'pIC50_median':float(yy.median()),'pIC50_min':float(yy.min()),'pIC50_max':float(yy.max()),'pIC50_range':float(yy.max()-yy.min()),'n_records':len(v),'n_assays':v.assay_chembl_id.nunique(),'n_documents':v.document_chembl_id.nunique(),'assay_ids':';'.join(sorted(set(v.assay_chembl_id))),'document_ids':';'.join(sorted(set(v.document_chembl_id))),'activity_ids':';'.join(map(str,sorted(set(v.activity_id))))})
 return pd.DataFrame(rows).sort_values('compound_key').reset_index(drop=True)
re_old=aggregate(d[primary]);assert list(re_old.compound_key)==list(oldc.compound_key) and np.max(np.abs(re_old.pIC50_median-oldc.pIC50_median))<1e-12
clean=aggregate(q);clean=clean.merge(oldc[['compound_key','partition']],on='compound_key',validate='one_to_one');assert clean.partition.ne('').all() and set(clean.compound_key).issubset(set(oldc.compound_key))
clean['median_IC50_nM']=10.**(9-clean.pIC50_median);clean['biochemical_hit_pIC50_ge6']=clean.pIC50_median.ge(6)
tab('endpoint_clean_全部化合物_继承旧骨架分区.tsv',clean)
changes=oldc.merge(clean,on='compound_key',how='outer',suffixes=('_old','_clean'),indicator=True);changes['record_count_delta']=pd.to_numeric(changes.n_records_clean,errors='coerce').fillna(0)-pd.to_numeric(changes.n_records_old,errors='coerce');changes['pIC50_median_delta']=pd.to_numeric(changes.pIC50_median_clean,errors='coerce')-pd.to_numeric(changes.pIC50_median_old,errors='coerce');changes['removed_compound']=changes['_merge'].eq('left_only');changes['partition_preserved']=changes.partition_old.eq(changes.partition_clean)|changes.removed_compound
assert changes.partition_preserved.all();tab('全部547化合物_原清洁端点与分区变动.tsv',changes);tab('所有受影响化合物_完整变动.tsv',changes[changes.record_count_delta.ne(0)])
for pair in [('train_BO_pool','calibration'),('train_BO_pool','test'),('calibration','test')]:assert not set(clean.loc[clean.partition.eq(pair[0]),'Murcko_scaffold'])&set(clean.loc[clean.partition.eq(pair[1]),'Murcko_scaffold'])
class Tanimoto(Kernel):
 def __init__(self):pass
 def __call__(self,X,Y=None,eval_gradient=False):
  if Y is None:Y=X
  dots=X@Y.T;den=X.sum(1)[:,None]+Y.sum(1)[None,:]-dots;K=np.divide(dots,den,out=np.zeros_like(dots),where=den>0)
  return (K,np.empty((*K.shape,0))) if eval_gradient else K
 def diag(self,X):return np.ones(len(X))
 def is_stationary(self):return False

gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=1024,includeChirality=True)
def fp(s):
 m=Chem.MolFromSmiles(s);assert m is not None
 return np.array(gen.GetFingerprint(m)).astype(float)
fpmap={r.compound_key:fp(r.normalized_SMILES) for r in oldc.itertuples()}

def fit_holdout(c,label):
 tr=c[c.partition.eq('train_BO_pool')];ev=c[c.partition.isin(['calibration','test'])].copy();X=np.stack([fpmap[k] for k in tr.compound_key]);y=tr.pIC50_median.to_numpy(float)
 model=GaussianProcessRegressor(kernel=Tanimoto(),alpha=.25**2,optimizer=None,normalize_y=True).fit(X,y)
 mu,ss=model.predict(np.stack([fpmap[k] for k in ev.compound_key]),return_std=True);noise=.25*np.std(y)
 ev['predicted_pIC50']=mu;ev['latent_std']=ss;ev['observation_std']=np.sqrt(ss**2+noise**2);ev['abs_standardized_residual']=np.abs(ev.pIC50_median-mu)/np.maximum(ev.observation_std,1e-12)
 ca=ev[ev.partition.eq('calibration')];groups=ca.groupby('Murcko_scaffold').abs_standardized_residual.max().sort_values();rank=int(np.ceil((len(groups)+1)*.9));assert rank<=len(groups);qm=float(groups.iloc[rank-1])
 ev['raw90_low']=mu-1.6448536269514722*ev.observation_std;ev['raw90_high']=mu+1.6448536269514722*ev.observation_std;ev['calibrated90_low']=mu-qm*ev.observation_std;ev['calibrated90_high']=mu+qm*ev.observation_std;ev['model']=label
 tab(label+'_calibration_test_全部逐值.tsv',ev);tab(label+'_校准骨架最大标准残差.tsv',groups.rename('group_max_standardized_residual').reset_index())
 return model,ev,{'training_n':len(tr),'calibration_n':len(ca),'test_n':int(ev.partition.eq('test').sum()),'training_population_SD':float(np.std(y)),'fixed_observation_noise_SD':float(noise),'calibration_scaffold_n':len(groups),'calibration_90_rank':rank,'calibration_multiplier90':qm,'train_mean':float(y.mean())}
oldmodel,op,om=fit_holdout(oldc,'old547_fixedsplit');newmodel,npred,nm=fit_holdout(clean,'endpointclean_fixedsplit')
check=op.merge(oldpred,on='compound_key',suffixes=('_replay','_archive'),validate='one_to_one');qa={col:float(np.max(np.abs(pd.to_numeric(check[col+'_replay'])-pd.to_numeric(check[col+'_archive'])))) for col in ['pIC50_median','predicted_pIC50','observation_std','raw90_low','raw90_high','calibrated90_low','calibrated90_high']};assert max(qa.values())<1e-8;assert abs(om['calibration_multiplier90']-oldmetrics['calibration_multiplier90'])<1e-8
dump('旧模型逐值重放_存档一致性.json',qa)

def metrics(ev,truth_col,train_mean):
 yy=ev[truth_col].to_numpy(float);mu=ev.predicted_pIC50.to_numpy(float)
 out={'n':len(ev),'scaffolds':ev.Murcko_scaffold.nunique(),'RMSE':float(np.sqrt(mean_squared_error(yy,mu))),'MAE':float(mean_absolute_error(yy,mu)),'R2':float(r2_score(yy,mu)),'trainingmean_RMSE':float(np.sqrt(mean_squared_error(yy,np.repeat(train_mean,len(yy)))))}
 for t in ['raw90','calibrated90']:
  inside=yy>=ev[t+'_low'].to_numpy(float);inside&=yy<=ev[t+'_high'].to_numpy(float)
  out[t+'_molecule_coverage']=float(inside.mean());out[t+'_whole_scaffold_coverage']=float(pd.DataFrame({'g':ev.Murcko_scaffold,'ok':inside}).groupby('g').ok.all().mean());out[t+'_mean_width']=float((ev[t+'_high']-ev[t+'_low']).mean())
 return out
oldtest=op[op.partition.eq('test')].copy();newtest=npred[npred.partition.eq('test')].copy();common=oldtest.merge(newtest,on='compound_key',suffixes=('_old','_clean'),validate='one_to_one');assert len(common)==len(newtest)
common['old_error_vs_clean_truth']=common.predicted_pIC50_old-common.pIC50_median_clean;common['clean_error_vs_clean_truth']=common.predicted_pIC50_clean-common.pIC50_median_clean;common['squared_error_change_clean_minus_old']=common.clean_error_vs_clean_truth**2-common.old_error_vs_clean_truth**2;common['absolute_error_change_clean_minus_old']=np.abs(common.clean_error_vs_clean_truth)-np.abs(common.old_error_vs_clean_truth);tab('共同旧test_两模型同真值_配对逐化合物.tsv',common)
metricsrows=[]
for label,ev,meta in [('old_full_test_original_truth',oldtest,om),('clean_retained_test_clean_truth',newtest,nm)]:metricsrows.append({'comparison':label,'model':'old' if label.startswith('old') else 'clean','truth':'old' if label.startswith('old') else 'clean',**metrics(ev,'pIC50_median',meta['train_mean'])})
for truth in ['clean','old']:
 for model,meta in [('old',om),('clean',nm)]:
  cols=['compound_key','Murcko_scaffold','predicted_pIC50','observation_std','raw90_low','raw90_high','calibrated90_low','calibrated90_high'];ev=pd.DataFrame({k:common[k+'_'+model] if k!='compound_key' else common[k] for k in cols});ev['common_truth']=common['pIC50_median_'+truth]
  metricsrows.append({'comparison':'COMMON_OLD_TEST_SAME_'+truth.upper()+'_TRUTH','model':model,'truth':truth,**metrics(ev,'common_truth',meta['train_mean'])})
mt=pd.DataFrame(metricsrows);tab('old_vs_endpointclean_完整误差覆盖汇总.tsv',mt)
reliability=[]
for label,ev in [('old_own_fulltest',oldtest),('clean_own_retainedtest',newtest)]:
 for nominal in [.5,.8,.9,.95]:
  z=float(norm.ppf((1+nominal)/2));inside=np.abs(ev.pIC50_median-ev.predicted_pIC50)<=z*ev.observation_std
  reliability.append({'model_evaluation':label,'nominal_Gaussian_observation_coverage':nominal,'z':z,'test_molecule_empirical_coverage':float(inside.mean()),'test_whole_scaffold_empirical_coverage':float(pd.DataFrame({'g':ev.Murcko_scaffold,'inside':inside}).groupby('g').inside.all().mean()),'mean_width':float((2*z*ev.observation_std).mean()),'test_n':len(ev)})
tab('UQ_全部固定覆盖水平_描述性.tsv',pd.DataFrame(reliability))
# Frozen49 are preserved even when semantic corrections could alter known3 membership.
u=read(paths['old_candidate52']);u['original_pubchem_cid']=u.original_pubchem_cid.astype(str);u['frozen_old49']=~u.known_exact_match.astype(str).str.lower().eq('true');assert len(u)==52 and u.frozen_old49.sum()==49
Xu=np.stack([fp(x) for x in u.normalized_SMILES]);fixed=[]
for label,model,c,meta in [('old_fixedsplit',oldmodel,oldc,om),('clean_fixedsplit',newmodel,clean,nm)]:
 mu,sd=model.predict(Xu,return_std=True);tr=c[c.partition.eq('train_BO_pool')].reset_index(drop=True);XX=np.stack([fpmap[k] for k in tr.compound_key]);sim=Tanimoto()(Xu,XX);near=sim.argmax(1)
 for i,r in u.iterrows():
  obs=float(np.sqrt(sd[i]**2+meta['fixed_observation_noise_SD']**2));rr={'model':label,'original_pubchem_cid':r.original_pubchem_cid,'original_compound_names':r.original_compound_names,'frozen_old49':r.frozen_old49,'normalized_SMILES':r.normalized_SMILES,'prediction_mean_pIC50':float(mu[i]),'latent_std_pIC50':float(sd[i]),'observation_std_pIC50':obs,'calibrated90_low':float(mu[i]-meta['calibration_multiplier90']*obs),'calibrated90_high':float(mu[i]+meta['calibration_multiplier90']*obs),'nearest_training_Tanimoto':float(sim[i,near[i]]),'nearest_training_compound_key':tr.iloc[near[i]].compound_key,'nearest_training_assay_ids':tr.iloc[near[i]].assay_ids,'nearest_training_document_ids':tr.iloc[near[i]].document_ids,'exact_member_of_this_training_partition':r.normalized_SMILES in set(tr.normalized_SMILES),'scope':'Fixed inherited-training GP prediction; unmeasured candidates not a validation test; calibrated intervals do not guarantee OOD coverage.'};fixed.append(rr)
fixed=pd.DataFrame(fixed);tab('固定旧训练分区_全部52及冻结49预测.tsv',fixed);tab('固定旧训练分区_冻结49预测.tsv',fixed[fixed.frozen_old49])
fpa=fixed[fixed.frozen_old49].pivot(index='original_pubchem_cid',columns='model',values='prediction_mean_pIC50').reset_index();fpa['clean_minus_old_prediction']=fpa.clean_fixedsplit-fpa.old_fixedsplit;tab('固定分区49_均值配对差.tsv',fpa)
# Deployment sensitivity: refit all retained endpoints only after heldout analysis; never reuse test calibrator.
dep=[];depqa={}
for label,c in [('old_all547',oldc),('clean_all_retained',clean)]:
 XX=np.stack([fpmap[k] for k in c.compound_key]);model=GaussianProcessRegressor(kernel=Tanimoto(),alpha=.25**2,optimizer=None,normalize_y=True).fit(XX,c.pIC50_median.to_numpy(float));mu,sd=model.predict(Xu,return_std=True);sim=Tanimoto()(Xu,XX);near=sim.argmax(1)
 if label=='old_all547':
  depqa={'mean_max_abs_difference_vs_archive':float(np.max(np.abs(mu-pd.to_numeric(u.prediction_mean_pIC50)))),'latentSD_max_abs_difference_vs_archive':float(np.max(np.abs(sd-pd.to_numeric(u.prediction_latent_std_pIC50))))};assert max(depqa.values())<1e-8
 for i,r in u.iterrows():dep.append({'model':label,'original_pubchem_cid':r.original_pubchem_cid,'original_compound_names':r.original_compound_names,'frozen_old49':r.frozen_old49,'normalized_SMILES':r.normalized_SMILES,'known_exact_member_of_this_all_data_library':r.normalized_SMILES in set(c.normalized_SMILES),'prediction_mean_pIC50':float(mu[i]),'latent_std_pIC50':float(sd[i]),'nearest_training_Tanimoto':float(sim[i,near[i]]),'nearest_training_compound_key':c.iloc[near[i]].compound_key,'nearest_training_molecule_chembl_ids':c.iloc[near[i]].molecule_chembl_ids,'nearest_training_assay_ids':c.iloc[near[i]].assay_ids,'nearest_training_document_ids':c.iloc[near[i]].document_ids,'deployment_scope':'All-data fit after heldout evaluation; uncalibrated latentSD only; not heldout validation or measured efficacy.'})
dep=pd.DataFrame(dep);tab('部署拟合_全部52_原清洁模型预测.tsv',dep);dep49=dep[dep.frozen_old49].copy();queues=[]
for label,z in dep49.groupby('model'):
 for rule,col in [('predicted_mean','prediction_mean_pIC50'),('latent_uncertainty','latent_std_pIC50')]:
  z=z.copy();z['numericCID']=pd.to_numeric(z.original_pubchem_cid);z=z.sort_values([col,'numericCID'],ascending=[False,True],kind='mergesort');z['queue_rank']=np.arange(1,len(z)+1);z['queue_rule']=rule;queues.append(z.drop(columns='numericCID'))
queues=pd.concat(queues,ignore_index=True);tab('部署冻结49_全部两模型两队列.tsv',queues)
queuepair=queues.pivot(index=['original_pubchem_cid','queue_rule'],columns='model',values='queue_rank').reset_index();queuepair['clean_minus_old_rank']=queuepair.clean_all_retained-queuepair.old_all547;tab('部署冻结49_全部排名变动.tsv',queuepair)
summary={'status':'COMPLETE_POSTHOC_ENDPOINT_SEMANTIC_SENSITIVITY_NO_RESHUFFLE_NO_TUNING','completed':datetime.datetime.now().astimezone().isoformat(),'records_all':1064,'old_primary_records':605,'removed_explicit_DPPH_primary_records':16,'retained_primary_records':len(q),'old_compounds':len(oldc),'retained_compounds':len(clean),'removed_compounds':int(changes.removed_compound.sum()),'retained_compounds_with_changed_median':int((changes.pIC50_median_delta.abs()>1e-12).sum()),'old_partition_n':oldc.partition.value_counts().astype(int).to_dict(),'clean_partition_n':clean.partition.value_counts().astype(int).to_dict(),'old_partition_scaffold_n':oldc.groupby('partition').Murcko_scaffold.nunique().astype(int).to_dict(),'clean_partition_scaffold_n':clean.groupby('partition').Murcko_scaffold.nunique().astype(int).to_dict(),'removed_compounds_by_old_partition':changes.loc[changes.removed_compound,'partition_old'].value_counts().astype(int).to_dict(),'old_test_n':len(oldtest),'common_oldtest_n':len(common),'removed_oldtest_n':len(oldtest)-len(common),'common_test_labels_changed':int((np.abs(common.pIC50_median_old-common.pIC50_median_clean)>1e-12).sum()),'old_model_archive_replay_max_abs_error':qa,'old_deployment_archive_replay':depqa,'old_calibration':om,'clean_calibration':nm,'metrics_all':metricsrows,'primary_paired_common_clean_truth_delta_clean_minus_old':{k:float(mt.loc[(mt.comparison=='COMMON_OLD_TEST_SAME_CLEAN_TRUTH')&mt.model.eq('clean'),k].iloc[0]-mt.loc[(mt.comparison=='COMMON_OLD_TEST_SAME_CLEAN_TRUTH')&mt.model.eq('old'),k].iloc[0]) for k in ['RMSE','MAE','R2','raw90_molecule_coverage','calibrated90_molecule_coverage','calibrated90_mean_width']},'frozen_candidate49_n':49,'candidate_fixed_partition_prediction_pairs':int(len(fixed[fixed.frozen_old49])/2),'candidate_fixed_partition_mean_max_absolute_change':float(fpa.clean_minus_old_prediction.abs().max()),'candidate_deployment_two_full_queues_retained':True,'deployment49_mean_queue_spearman':float(spearmanr(queuepair.loc[queuepair.queue_rule.eq('predicted_mean'),'old_all547'],queuepair.loc[queuepair.queue_rule.eq('predicted_mean'),'clean_all_retained']).statistic),'original_inputs_unchanged':{k:sha(v)==contract['source_inputs'][k]['SHA256'] for k,v in paths.items()},'limitations':contract['limits'],'no_BO20seed_replay':True,'no_new_experiment_or_oracle':True}
assert all(summary['original_inputs_unchanged'].values());dump('终点清洁敏感性_实际完整状态.json',summary)
print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
primaryrows=mt[mt.comparison.eq('COMMON_OLD_TEST_SAME_CLEAN_TRUTH')]
lines=['终点语义勘误敏感性已真实完成；这是事后发现显式非XO终点后的更正，不是预注册。','仅从旧605条primary移除DPPH assay CHEMBL5736870的16条；其余条件、数值及旧分区不改。','化合物547→'+str(len(clean))+'；primary605→'+str(len(q))+'。旧分区 '+str(summary['old_partition_n'])+'；清洁继承分区 '+str(summary['clean_partition_n'])+'。','删除化合物所在旧分区：'+str(summary['removed_compounds_by_old_partition'])+'；保留但中位数改变='+str(summary['retained_compounds_with_changed_median'])+'。','共同旧test n='+str(len(common))+'，被移除旧test='+str(summary['removed_oldtest_n'])+'，共同test标签改变='+str(summary['common_test_labels_changed'])+'。两模型都在同一清洁真值下比较：']
for r in primaryrows.itertuples():lines.append(f'{r.model}: RMSE={r.RMSE:.9f}, MAE={r.MAE:.9f}, R2={r.R2:.9f}; raw90 coverage={r.raw90_molecule_coverage:.6f}, calibrated90 coverage={r.calibrated90_molecule_coverage:.6f}, whole-scaffold={r.calibrated90_whole_scaffold_coverage:.6f}, width={r.calibrated90_mean_width:.6f}.')
lines+=['旧GP与存档逐值重放最大误差='+str(max(qa.values()))+'；旧全547部署模型与存档也重放通过。','冻结49全部给固定旧训练分区预测与原清洁配对差；另列all-data部署敏感性，52全部结构和49两条完整队列均保留，无选择性裁剪。部署只输出未校准latentSD，未移用旧校准器。','不重做20seed BO，不把清洁性能结果当作新预注册验证，不据此扩称真实humanXO或痛风疗效。源物种、复制描述、review原文未核和跨assay异质性边界保留。','主要文件：old_vs_endpointclean_完整误差覆盖汇总.tsv；共同旧test_两模型同真值_配对逐化合物.tsv；所有受影响化合物_完整变动.tsv；终点清洁敏感性_实际完整状态.json。']
text='\n'.join(lines)+'\n';(P/'给主代理的最终交付.txt').write_text(text,encoding='utf-8')
report='<!doctype html><html lang="zh"><meta charset="utf-8"><title>终点一致性敏感性</title><style>body{max-width:1120px;margin:40px auto;font:16px/1.65 system-ui;color:#24364a}pre{white-space:pre-wrap;background:#eef4f8;padding:20px}table{border-collapse:collapse;font-size:13px}th,td{padding:7px;border:1px solid #c8d2dd}</style><h1>终点一致性敏感性：保留旧骨架分区与GP参数</h1><pre>'+html.escape(text)+'</pre><h2>完整比较</h2>'+mt.to_html(index=False,escape=True)+'<h2>全部受影响化合物</h2>'+changes.loc[changes.record_count_delta.ne(0),['compound_key','names_old','partition_old','n_records_old','n_records_clean','pIC50_median_old','pIC50_median_clean','pIC50_median_delta','removed_compound']].to_html(index=False,escape=True)+'<h2>方法限制</h2><ul>'+''.join('<li>'+html.escape(x)+'</li>' for x in contract['limits'])+'</ul><p>方法：<a href="https://scikit-learn.org/stable/modules/generated/sklearn.gaussian_process.GaussianProcessRegressor.html">scikit-learn GaussianProcessRegressor</a>。原始数据和分区均只读，全部输入SHA已复核。</p></html>'
(P/'终点一致性敏感性_正式报告.html').write_text(report,encoding='utf-8');tab('全部交付与输入源SHA256.tsv',pd.DataFrame([{'role':'output','file':str(p),'bytes':p.stat().st_size,'SHA256':sha(p)} for p in sorted(P.iterdir()) if p.is_file() and p.name!='全部交付与输入源SHA256.tsv']+[{'role':'readonly_input','file':str(v),'bytes':v.stat().st_size,'SHA256':sha(v)} for v in paths.values()]))
print(text,flush=True)

