"""Deployment-only fixed GP priorities for all52 original XDH-associated structures. No validation claims."""
from pathlib import Path
import sys,json,hashlib,datetime
O=Path(__file__).resolve().parent;B=O.parent;E=O.parents[2]
for p in reversed(['G:/痛风/第二步_靶点预测与疾病交集/runtime/ppi_analysis_libraries','G:/痛风/第二步_靶点预测与疾病交集/论文推进_2026-10-30/单细胞定位/runtime','G:/痛风/第二步_靶点预测与疾病交集/rdkit_runtime']):sys.path.insert(0,p)
import numpy as np,pandas as pd,sklearn
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Kernel
from rdkit import Chem,rdBase
from rdkit.Chem import rdFingerprintGenerator,Descriptors,Crippen,rdMolDescriptors

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
files={'original52_bridge':B/'原方XDH_实测活性桥接.tsv','measured547':B/'规范化化合物_完整端点与骨架划分.tsv','leave_document_result':B/'留文献外预测/实际完成_留文献外预测.json','previous_test_result':B/'预测与不确定性_实测指标.json'}
before={k:sha(p) for k,p in files.items()}
c=pd.read_csv(files['measured547'],sep='\t',dtype={'compound_key':str}).sort_values('compound_key').reset_index(drop=True)
u=pd.read_csv(files['original52_bridge'],sep='\t',dtype={'original_pubchem_cid':str}).fillna('')
ldo=json.loads(files['leave_document_result'].read_text(encoding='utf-8'))
assert len(c)==547 and len(u)==52 and u.original_pubchem_cid.nunique()==52 and u.normalization_status.eq('NORMALIZED').all()
assert int(u.exact_match_to_measured547.eq(True).sum())==3
contract={'frozen_before_deployment_predictions':datetime.datetime.now().astimezone().isoformat(),'purpose':'deployment candidate prioritization after independent test evaluation; not another validation','training':'all547 historical compound endpoints; original test/calibration results remain unchanged','features':'Morgan radius2 1024bits includeChirality; exact normalized structures preserved','model':'fixed Tanimoto GP alpha=.25^2 standardized outcome units, normalize_y=True, optimizer=None','outputs':'all52 mean pIC50 + latent posterior standard deviation + exact-match flag + nearest-training structural similarity and source + MW/LogP/TPSA context','priority_queues':'all49 not-exactly-matched structures retained in mean-descending and latent-std-descending queues; numericCID ascending for ties; no hard property/score filtering','known3':'training members, not validation or new candidates','uncertainty':'uncalibrated model latent std; no old calibrator, probability, confidence interval or P value','domain_boundary':'nine-document-out transfer weak; not prospective efficacy or global absence of prior measurement','no_docking_or_new_labels':True,'source_files':{k:{'path':str(p),'sha256':before[k]} for k,p in files.items()},'source_script_SHA256':sha(__file__)}
dump(O/'部署拟合前_全部52优先序规则.json',contract)
class Tanimoto(Kernel):
 def __init__(self):pass
 def __call__(self,X,Y=None,eval_gradient=False):
  if Y is None:Y=X
  dots=X@Y.T;den=X.sum(1)[:,None]+Y.sum(1)[None,:]-dots
  K=np.divide(dots,den,out=np.zeros_like(dots),where=den>0)
  return (K,np.empty((*K.shape,0))) if eval_gradient else K
 def diag(self,X):return np.ones(len(X))
 def is_stationary(self):return False

gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=1024,includeChirality=True)
def fingerprint(s):
 m=Chem.MolFromSmiles(s);assert m is not None
 a=np.array(gen.GetFingerprint(m)).astype(float);assert a.shape==(1024,) and a.sum()>0
 return a,m
training=[fingerprint(s)[0] for s in c.normalized_SMILES]
target=[fingerprint(s) for s in u.normalized_SMILES]
X=np.stack(training);Xu=np.stack([a for a,m in target]);y=c.pIC50_median.to_numpy(float)
model=GaussianProcessRegressor(kernel=Tanimoto(),alpha=.25**2,optimizer=None,normalize_y=True)
model.fit(X,y);mu,std=model.predict(Xu,return_std=True)
K=Tanimoto()(Xu,X);idx=np.argmax(K,axis=1);mx=K[np.arange(len(u)),idx]
assert np.isfinite(mu).all() and np.isfinite(std).all() and (std>=0).all()
source_exact=set(c.normalized_SMILES)
assert np.array_equal(u.exact_match_to_measured547.to_numpy(bool),u.normalized_SMILES.isin(source_exact).to_numpy())
out=u.copy().rename(columns={'exact_match_to_measured547':'known_exact_match'})
out['prediction_mean_pIC50']=mu;out['prediction_latent_std_pIC50']=std
out['nearest_training_Tanimoto']=mx
for dest,src in [('nearest_training_compound_key','compound_key'),('nearest_training_molecule_chembl_ids','molecule_chembl_ids'),('nearest_training_names','names'),('nearest_training_normalized_SMILES','normalized_SMILES'),('nearest_training_assay_ids','assay_ids'),('nearest_training_document_ids','document_ids'),('nearest_training_activity_ids','activity_ids'),('nearest_training_observed_median_pIC50','pIC50_median'),('nearest_training_backtransformed_median_pIC50_nM','median_IC50_nM')]:
 out[dest]=c[src].to_numpy()[idx]
out['identical_fingerprint_different_normalized_structure']=np.isclose(mx,1,atol=1e-12)&~out.known_exact_match.astype(bool)
out['RDKit_MW']=[Descriptors.MolWt(m) for a,m in target]
out['RDKit_cLogP']=[Crippen.MolLogP(m) for a,m in target]
out['RDKit_TPSA_A2']=[rdMolDescriptors.CalcTPSA(m) for a,m in target]
out['priority_scope']='Pending validation; not exact-matched to selected547 library does not mean never measured.'
out['uncertainty_scope']='Uncalibrated latent GP posterior SD; excludes measurement noise and cross-assay transport error.'
out['deployment_training_context']='All547 endpoints fitted after locked test evaluation; known3 are training members.'
out['CID_numeric_tiebreak']=pd.to_numeric(out.original_pubchem_cid,errors='raise').astype('int64')
unknown=out[~out.known_exact_match.astype(bool)].copy();assert len(unknown)==49
qm=unknown.sort_values(['prediction_mean_pIC50','CID_numeric_tiebreak'],ascending=[False,True],kind='mergesort').copy()
qs=unknown.sort_values(['prediction_latent_std_pIC50','CID_numeric_tiebreak'],ascending=[False,True],kind='mergesort').copy()
qm.insert(0,'queue_rank',range(1,50));qm.insert(1,'queue_rule','Pure predicted-mean descending; numericCID ascending ties; all49 retained')
qs.insert(0,'queue_rank',range(1,50));qs.insert(1,'queue_rule','Pure latent-standard-deviation descending; numericCID ascending ties; all49 retained')
mr=dict(zip(qm.original_pubchem_cid,qm.queue_rank));sr=dict(zip(qs.original_pubchem_cid,qs.queue_rank))
out['mean_queue_rank_among49_unmatched']=out.original_pubchem_cid.map(mr).astype('Int64')
out['exploration_queue_rank_among49_unmatched']=out.original_pubchem_cid.map(sr).astype('Int64')
known=out[out.known_exact_match.astype(bool)].copy()
for tab,name in [(out,'全部52_XDH候选_部署均值标准差与来源.tsv'),(qm,'未精确匹配49_纯预测均值队列.tsv'),(qs,'未精确匹配49_模型标准差探索队列.tsv'),(known,'已知精确匹配3_训练内标记_不作验证.tsv')]:
 tab.drop(columns='CID_numeric_tiebreak').to_csv(O/name,sep='\t',index=False)
# Smaller reader table preserves every candidate and both queue positions.
compactcols=['original_pubchem_cid','original_compound_names','original_source_herbs','qualified_sources','qualified_Swiss_missing_url_flags','known_exact_match','prediction_mean_pIC50','prediction_latent_std_pIC50','nearest_training_Tanimoto','nearest_training_molecule_chembl_ids','nearest_training_assay_ids','nearest_training_document_ids','mean_queue_rank_among49_unmatched','exploration_queue_rank_among49_unmatched','RDKit_MW','RDKit_cLogP','RDKit_TPSA_A2']
out[compactcols].to_csv(O/'全部52_作者阅读简表.tsv',sep='\t',index=False)
assert set(qm.original_pubchem_cid)==set(qs.original_pubchem_cid)==set(unknown.original_pubchem_cid)
assert out.original_pubchem_cid.nunique()==52 and all(sha(p)==before[k] for k,p in files.items())
topcols=['original_pubchem_cid','original_compound_names','prediction_mean_pIC50','prediction_latent_std_pIC50','nearest_training_Tanimoto','nearest_training_molecule_chembl_ids','nearest_training_document_ids']
summary={'status':'COMPLETED_DEPLOYMENT_PRIORITIES_NOT_VALIDATION','completed':datetime.datetime.now().astimezone().isoformat(),'training_compounds':547,'all_original_candidates_predicted':52,'known_exact_training_members':3,'unmatched_candidates_in_each_complete_queue':49,'structure_gaps':0,'new_measured_labels':0,'old_calibrator_used':False,'calibrated_probabilities_or_intervals':False,'P_values':False,'docking_done':False,'source_files_unchanged':True,'model_outcome_train_mean':float(y.mean()),'model_outcome_train_sd':float(y.std()),'top5_mean_queue':qm[topcols].head(5).to_dict(orient='records'),'top5_std_exploration_queue':qs[topcols].head(5).to_dict(orient='records'),'minimum_max_training_Tanimoto_unknown':float(unknown.nearest_training_Tanimoto.min()),'maximum_max_training_Tanimoto_unknown':float(unknown.nearest_training_Tanimoto.max()),'unknown_identical_fingerprint_to_training_count':int(unknown.identical_fingerprint_different_normalized_structure.sum()),'nine_document_transfer_context':{k:ldo[k] for k in ['completed_documents','GP_lower_RMSE_than_trainingmean_folds','macro_mean_fold_RMSE_GP','macro_mean_fold_RMSE_trainingmean','pooled_descriptive_GP']},'software':{'sklearn':sklearn.__version__,'numpy':np.__version__,'pandas':pd.__version__,'RDKit':rdBase.rdkitVersion},'interpretation':'Transparent follow-up candidate priorities under one historical pooled model. Not calibrated activity probabilities, proof of new anti-gout efficacy, or evidence structures have never been measured elsewhere. Unknown49 have no exact label in selected547, so the historical oracle cannot currently adjudicate their true activities.','script_SHA256':sha(__file__)}
dump(O/'实际完成_全部52部署候选优先序.json',summary)
report=['原方52个XDH候选：部署模型优先序（待验证）','完成时间：'+summary['completed'],'','这次已对全部52个原CID实际输出预测。模型在全部547个历史端点上作部署后拟合，使用与基准相同Morgan/Tanimoto GP、alpha0.25²和normalize_y；旧独立测试、校准及9折留文献结果没有重算或改写。','3个已有精确实测匹配属于本次训练成员，单独标明，不作为验证或新发现。其余49个在选定547库中无精确匹配；这不代表它们在其他来源从未被测过。','全部52主表含预测pIC50均值、潜变量后验标准差、最近训练结构Tanimoto/化合物/assay/document/已测端点，以及原CID和旧来源/qualified标记。MW、cLogP、TPSA仅供背景判断，未据此筛除任何候选。','两个完整队列各49个：一份按预测均值从高到低，一份按latent标准差从高到低；并列按数字CID升序。低分候选也完整保留，不进行选择性裁剪。高标准差可以表示模型不熟悉的结构，不能解释成更可能有效。','注意：这里的标准差未校准，不含实测噪声或跨assay迁移误差。旧calibrator没有迁移到全数据重新拟合模型；未输出命中概率、置信区间或统计P。','9文献外迁移仅4/9折优于均值基线，宏平均RMSE1.363 vs1.420、合并R²−0.192；因此下面数值只用于安排下一步测量/检索，不能定性为阳性药效。','49个没有当前历史库的精确实测端点，不能把本模型预测当成oracle返回值。下一步若比较两队列，应在预先固定的同一测定/计算oracle、同预算和不重叠规则下取得真实新端点；对接分数若另作oracle，也不能冒充实测IC50。','','预测均值队列前5（全部49见TSV）：']
for a in summary['top5_mean_queue']:report.append(f"CID{a['original_pubchem_cid']} {a['original_compound_names']}: mean={a['prediction_mean_pIC50']:.4f}, latentSD={a['prediction_latent_std_pIC50']:.4f}, nearestTanimoto={a['nearest_training_Tanimoto']:.3f} ({a['nearest_training_molecule_chembl_ids']}).")
report+=['','模型标准差探索队列前5（全部49见TSV）：']
for a in summary['top5_std_exploration_queue']:report.append(f"CID{a['original_pubchem_cid']} {a['original_compound_names']}: mean={a['prediction_mean_pIC50']:.4f}, latentSD={a['prediction_latent_std_pIC50']:.4f}, nearestTanimoto={a['nearest_training_Tanimoto']:.3f} ({a['nearest_training_molecule_chembl_ids']}).")
report+=['','English manuscript-ready wording','After completing the scaffold and document-held-out evaluations, we refitted the same fixed GP to all 547 historical endpoints for deployment. All 52 original XDH-associated structures received a predicted pIC50 mean, uncalibrated latent posterior standard deviation and nearest-training structural similarity with assay provenance. Three exact training-library matches were flagged and excluded from follow-up prioritization, leaving 49 structures in each of two complete queues ordered by predicted mean or latent uncertainty. No property or activity cutoff was applied. Given limited document-held-out transfer, these outputs define transparent pending-validation priorities rather than calibrated activity probabilities, new measured inhibitors or evidence of clinical efficacy.']
(O/'作者说明_具体候选与使用边界.txt').write_text('\n'.join(report),encoding='utf-8')
dump(O/'输出SHA256.json',[{'file':p.name,'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(O.iterdir()) if p.is_file() and p.name!='输出SHA256.json'])
print(json.dumps({k:v for k,v in summary.items() if k not in ['software','nine_document_transfer_context']},ensure_ascii=False,indent=2),flush=True)
