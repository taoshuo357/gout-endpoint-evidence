from pathlib import Path
import sys,json,hashlib,datetime,time
E=Path(__file__).resolve().parent
for p in reversed(['G:/痛风/第二步_靶点预测与疾病交集/runtime/ppi_analysis_libraries','G:/痛风/第二步_靶点预测与疾病交集/论文推进_2026-10-30/单细胞定位/runtime','G:/痛风/第二步_靶点预测与疾病交集/rdkit_runtime']):sys.path.insert(0,p)
import requests,pandas as pd,numpy as np
F=E/'06_干实验文献与贝叶斯优化';R=F/'ChEMBL原始快照';R.mkdir(exist_ok=True)
s=requests.Session();base='https://www.ebi.ac.uk/chembl/api/data/'
log=[]
def fetch(url,p):
 if p.exists():return json.loads(p.read_text(encoding='utf-8'))
 for attempt in range(3):
  try:
   r=s.get(url,timeout=(15,60));r.raise_for_status();data=r.json();p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');log.append({'url':url,'path':str(p),'SHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'downloaded':datetime.datetime.now().astimezone().isoformat()});return data
  except Exception:
   if attempt==2:raise
 return None
acts=[]
offset=0
while True:
 u=base+f'activity.json?target_chembl_id=CHEMBL1929&standard_type=IC50&limit=1000&offset={offset}'
 d=fetch(u,R/f'activities_offset{offset}.json');acts+=d['activities']
 print('activity records',len(acts),flush=True)
 if not d['page_meta']['next']:break
 offset+=d['page_meta']['limit']
assayids=sorted(set(x['assay_chembl_id'] for x in acts));ad={}
for start in range(0,len(assayids),30):
 ids=','.join(assayids[start:start+30]);d=fetch(base+'assay.json?assay_chembl_id__in='+ids+'&limit=1000',R/f'assays_batch{start}.json')
 for x in d['assays']:ad[x['assay_chembl_id']]=x
 print('assays metadata',len(ad),'/',len(assayids),flush=True)
df=pd.DataFrame(acts)
for col in ['assay_organism','assay_tax_id','confidence_score','relationship_type','assay_test_type','assay_category','assay_cell_type','assay_tissue']:
 df['metadata_'+col]=df.assay_chembl_id.map({k:v.get(col) for k,v in ad.items()})
df.to_csv(F/'XDH_IC50_全部原始记录与assay元数据.tsv',sep='\t',index=False)
pd.DataFrame(ad.values()).to_csv(F/'XDH_assay_全部元数据.tsv',sep='\t',index=False)
(F/'ChEMBL下载来源与哈希.json').write_text(json.dumps(log,ensure_ascii=False,indent=2),encoding='utf-8')
summary={'activity_records':len(df),'assays':len(ad),'assay_organisms':df.metadata_assay_organism.value_counts(dropna=False).astype(int).to_dict(),'confidence':{str(k):int(v) for k,v in df.metadata_confidence_score.value_counts(dropna=False).items()},'standard_relations':df.standard_relation.value_counts(dropna=False).astype(int).to_dict(),'data_validity':df.data_validity_comment.value_counts(dropna=False).astype(int).to_dict(),'bioactivity_model_or_optimization_run':False}
(F/'BO_原始数据分布_建模前.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False),flush=True)
