.libPaths(c('G:/痛风/第二步_靶点预测与疾病交集/runtime/R_geo_libraries',.libPaths()))
library(limma)
E <- getwd(); P <- file.path(E,'07_实测药物与功能验证','02_药物扰动公共数据','GSE160430_实际分析')
x <- read.delim(gzfile(file.path(P,'全唯一符号_RMAlog2中位数表达.tsv.gz')),check.names=FALSE)
rownames(x)<-x$gene_symbol;x$gene_symbol<-NULL;y<-as.matrix(x)
m<-read.delim(file.path(P,'样本清单_全10培养.tsv'),check.names=FALSE)
stopifnot(identical(colnames(y),m$sample_id),all(is.finite(y)),!anyDuplicated(rownames(y)))
run_model <- function(y,m,label,drugs) {
 m$passage<-factor(m$passage);m$treatment<-factor(m$treatment,levels=c('DMSO',drugs))
 design<-model.matrix(~passage+treatment,m);stopifnot(qr(design)$rank==ncol(design))
 fit<-eBayes(lmFit(y,design),trend=TRUE,robust=TRUE)
 tabs<-list()
 for (drug in drugs) {
  k<-match(paste0('treatment',drug),colnames(design));stopifnot(!is.na(k))
  tt<-topTable(fit,coef=k,number=Inf,sort.by='none',adjust.method='BH',confint=TRUE)
  tt$gene_symbol<-rownames(tt);tt$contrast<-paste0(drug,'_minus_DMSO');tt$model<-label
  tt$moderated_SE<-fit$stdev.unscaled[,k]*sqrt(fit$s2.post);tt$moderated_df<-fit$df.total
  tt$P_for_BH<-ifelse(is.finite(tt$P.Value),tt$P.Value,1)
  tt$q_BH_all_genes<-p.adjust(tt$P_for_BH,'BH',n=nrow(y));tt$gene_family_n<-nrow(y)
  tt$test_status<-ifelse(is.finite(tt$P.Value),'estimable','nonestimable_P1_for_correction_only')
  stopifnot(max(abs((tt$CI.R-tt$CI.L)/2-qt(.975,tt$moderated_df)*tt$moderated_SE))<1e-8)
  tabs[[drug]]<-tt
 }
 all<-do.call(rbind,tabs);all$q_BH_all_genes_all_drugs<-p.adjust(all$P_for_BH,'BH',n=nrow(all))
 write.table(all,file.path(P,paste0(label,'_所有基因所有比较_limma.tsv')),sep='\t',quote=FALSE,row.names=FALSE)
 write.table(data.frame(sample_id=m$sample_id,design,check.names=FALSE),file.path(P,paste0(label,'_实际设计矩阵.tsv')),sep='\t',quote=FALSE,row.names=FALSE)
 candidates<-read.delim(file.path(P,'冻结12候选.tsv'))$gene_symbol
 cc<-do.call(rbind,lapply(drugs,function(d){a<-all[all$contrast==paste0(d,'_minus_DMSO'),];z<-a[match(candidates,a$gene_symbol),];z$gene_symbol<-candidates;z$contrast<-paste0(d,'_minus_DMSO');z$model<-label;z$assay_status<-ifelse(is.na(z$logFC),'not uniquely mapped/not in assay','tested');z}))
 write.table(cc,file.path(P,paste0(label,'_冻结12完整结果.tsv')),sep='\t',quote=FALSE,row.names=FALSE,na='NA')
 stats<-do.call(rbind,lapply(drugs,function(d){z<-tabs[[d]];data.frame(model=label,contrast=paste0(d,'_minus_DMSO'),n_genes=nrow(z),residual_df=unique(fit$df.residual),BH05=sum(z$q_BH_all_genes<.05),BH05_absFC1=sum(z$q_BH_all_genes<.05&abs(z$logFC)>1),global_BH05=sum(all$q_BH_all_genes_all_drugs[all$contrast==paste0(d,'_minus_DMSO')]<.05))}))
 write.table(stats,file.path(P,paste0(label,'_模型计数汇总.tsv')),sep='\t',quote=FALSE,row.names=FALSE)
 print(stats)
 # Save all genes and the fitted covariance information for independent downstream checking.
 saveRDS(list(fit=fit,design=design,metadata=m,all_gene_results=all),file.path(P,paste0(label,'_完整模型.rds')))
 invisible(stats)
}
a<-run_model(y,m,'主分析_全10_传代阻断',c('Myricetin','Punicalagin','Quercetin'))
ix<-m$passage%in%c(7,8)&m$treatment%in%c('DMSO','Quercetin');stopifnot(sum(ix)==4)
b<-run_model(y[,ix],m[ix,],'敏感性_完全匹配p7p8',c('Quercetin'))
writeLines(c(capture.output(sessionInfo()),paste('limma',packageVersion('limma')),paste('statmod',packageVersion('statmod')),'RMA log2 scale as deposited; no new log/quantile normalization. No culture excluded.','Main model uses all10 cultures, design full rank6 and residual df4. Sensitivity uses4 cultures, design rank3 and residual df1.','Biological replication is passage/culture-level in one cell line; no donor/patient inference.','Two-sided empirical Bayes moderated t, trend and robust. Full mapped gene family BH within every drug and across3 drugs.'),file.path(P,'R实际软件与模型记录.txt'))
