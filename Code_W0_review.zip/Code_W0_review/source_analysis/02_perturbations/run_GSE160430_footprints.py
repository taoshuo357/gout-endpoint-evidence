from pathlib import Path
import sys,json,hashlib,datetime,importlib.metadata
E=Path('E:/痛风/研究深化_2026-11-02');G=Path('G:/痛风/第二步_靶点预测与疾病交集');O=E/'07_实测药物与功能验证/02_药物扰动公共数据';P=O/'GSE160430_实际分析'
for p in reversed([E/'runtime/decoupler_libraries',G/'runtime/ppi_analysis_libraries',G/'论文推进_2026-10-30/单细胞定位/runtime']):sys.path.insert(0,str(p))
import numpy as np,pandas as pd,decoupler as dc
from decoupler.mt._ulm import _func_ulm
from decoupler.pp.data import extract
from decoupler.pp.net import prune,adjmat
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bh(x):
 x=np.asarray(x,float);ii=np.argsort(x);q=np.minimum.accumulate((x[ii]*len(x)/np.arange(1,len(x)+1))[::-1])[::-1];z=np.empty_like(q);z[ii]=np.minimum(1,q);return z
path=E/'02_decoupler官方方法/PROGENy_次级通路足迹/PROGENy_官方默认完整网络.tsv';tf=E/'02_decoupler官方方法/冻结CollecTRI_monoTF网络.tsv'
files=sorted(P.glob('*_所有基因所有比较_limma.tsv'));assert len(files)==2
contract={'timestampUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before_new_footprint_outcomes':True,'original_gene_contract':sha(P/'计算前冻结合同.json'),'pathway_prior':str(path),'pathway_sha':sha(path),'TF_prior':str(tf),'TF_sha':sha(tf),'input':'all19233gene moderatedt separately eachdrugcontrast; noDEGselection','method':'official decoupler2.3.1 mt.ulm tmin5; private rawP numerical output checkedagainstpublic','geneFootprintP':'conditional overgenes, NOT culture/patientlevelP; pathway14 and fullTFfamilyBH','additional_all10_sample_scores':'centerandSDscaleeachgeneacrossall10samples, allnonconstantgenes; samefrozen14/fullTFnetworkULM; thenblockedlimmamodelacrosscultures, samplemodelP separate fromgenefootprintP','exploratory_status':'samepre-requestedpriors; geneeffects alreadyseen, nofootprintoutcomesyet; noindependentpreregistration','inputs':[{'file':str(p),'sha':sha(p)} for p in files]}
cp=P/'足迹计算前冻结合同.json';assert not cp.exists();cp.write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
data=[]
for f in files:
 a=pd.read_csv(f,sep='\t')
 for c,z in a.groupby('contrast',sort=False):
  assert z.gene_symbol.is_unique and np.isfinite(z.t).all()
  data.append(pd.Series(z.t.to_numpy(),index=z.gene_symbol,name=z.model.iloc[0]+'|'+c))
d=pd.DataFrame(data);assert d.shape==(4,19233) and np.isfinite(d.to_numpy()).all()
d.to_csv(P/'全部基因全部药物_有符号moderatedt输入.tsv.gz',sep='\t',index_label='contrast_id',compression='gzip')
x=pd.read_csv(P/'全唯一符号_RMAlog2中位数表达.tsv.gz',sep='\t',index_col=0);sd=x.std(axis=1,ddof=1);z=x.loc[sd.gt(0)].sub(x.mean(axis=1),axis=0).div(sd[sd.gt(0)],axis=0).T
assert np.isfinite(z.to_numpy()).all();records=[];covers=[];tests=[]
for name,f in [('PROGENy14',path),('CollecTRI_monoTF',tf)]:
 net=pd.read_csv(f,sep='\t');assert not net.duplicated(['source','target']).any()
 for kind,inp in [('contrast_moderatedt',d),('sample_gene_standardized',z)]:
  es,oq=dc.mt.ulm(data=inp,net=net,tmin=5,verbose=False)
  mat,obs,genes=extract(inp,raw=False,empty=True,shuffle=True,verbose=False);trim=prune(features=genes,net=net,tmin=5);names,target,adj=adjmat(features=genes,net=trim)
  vals,pv=_func_ulm(mat,adj);q=np.vstack([bh(v) for v in pv]);err=float(np.max(np.abs(es.loc[obs,names].to_numpy()-vals)));assert err<1e-9
  assert np.array_equal(oq.loc[obs,names].to_numpy().astype(np.float32),q.astype(np.float32))
  tests.append({'resource':name,'input':kind,'maxerror_public_private':err,'n_features':len(genes),'n_scores':len(names),'BH_matches_official_float32':True})
  counts=trim.groupby('source').target.nunique()
  for source in names:covers.append({'resource':name,'input':kind,'source':source,'measured_targets':int(counts[source]),'prior_targets':int(net.loc[net.source.eq(source),'target'].nunique()),'all_background_genes':len(genes)})
  for i,o in enumerate(obs):
   for j,s in enumerate(names):records.append({'resource':name,'input_kind':kind,'input_id':o,'source':s,'ULM_score':float(vals[i,j]),'rawP_gene_footprint_not_cultureP':float(pv[i,j]),'BH_source_family_gene_footprint_not_cultureP':float(q[i,j]),'family_n':len(names),'measured_targets':int(counts[s])})
  if kind=='sample_gene_standardized':es.loc[z.index].T.to_csv(P/(name+'_全10培养基因标准化ULM分数.tsv'),sep='\t',index_label='feature')
r=pd.DataFrame(records);r.to_csv(P/'全部通路与TF_官方ULM完整结果.tsv.gz',sep='\t',index=False,compression='gzip');pd.DataFrame(covers).to_csv(P/'全部通路与TF_目标覆盖.tsv',sep='\t',index=False)
(P/'官方ULM数值QA.json').write_text(json.dumps(tests,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'decoupler':importlib.metadata.version('decoupler'),'shape':r.shape,'methods':tests},ensure_ascii=False))
