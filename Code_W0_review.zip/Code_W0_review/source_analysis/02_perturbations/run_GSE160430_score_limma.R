.libPaths(c('G:/痛风/第二步_靶点预测与疾病交集/runtime/R_geo_libraries',.libPaths()))
library(limma)
P<-file.path(getwd(),'07_实测药物与功能验证','02_药物扰动公共数据','GSE160430_实际分析')
m0<-read.delim(file.path(P,'样本清单_全10培养.tsv'),check.names=FALSE)
results<-list();summary<-list()
for(resource in c('PROGENy14','CollecTRI_monoTF')){
 x<-read.delim(file.path(P,paste0(resource,'_全10培养基因标准化ULM分数.tsv')),check.names=FALSE);rownames(x)<-x$feature;x$feature<-NULL;y0<-as.matrix(x);stopifnot(identical(colnames(y0),m0$sample_id))
 for (model in c('主分析_全10_传代阻断','敏感性_完全匹配p7p8')){
  ix<-if(model=='主分析_全10_传代阻断') rep(TRUE,10) else m0$passage%in%c(7,8)&m0$treatment%in%c('DMSO','Quercetin')
  y<-y0[,ix];m<-m0[ix,];drugs<-if(sum(ix)==10)c('Myricetin','Punicalagin','Quercetin') else 'Quercetin'
  m$passage<-factor(m$passage);m$treatment<-factor(m$treatment,levels=c('DMSO',drugs));design<-model.matrix(~passage+treatment,m)
  f<-eBayes(lmFit(y,design),trend=TRUE,robust=TRUE);tables<-list()
  for (d in drugs){
   k<-match(paste0('treatment',d),colnames(design));tt<-topTable(f,coef=k,number=Inf,sort.by='none',confint=TRUE);tt$source<-rownames(tt);tt$score_difference<-tt$logFC;tt$logFC<-NULL;tt$resource<-resource;tt$model<-model;tt$contrast<-paste0(d,'_minus_DMSO');tt$q_BH_all_sources_this_drug<-p.adjust(ifelse(is.finite(tt$P.Value),tt$P.Value,1),'BH');tt$source_family_n<-nrow(tt);tt$P_unit<-'culture-level blocked score model, not ULM gene-regression P';tables[[d]]<-tt
  }
  a<-do.call(rbind,tables);a$q_BH_all_sources_all3drugs_ifmain<-p.adjust(ifelse(is.finite(a$P.Value),a$P.Value,1),'BH');results[[paste(resource,model)]]<-a
  summary[[paste(resource,model)]]<-data.frame(resource=resource,model=model,n_sources=nrow(y),n_cultures=ncol(y),residual_df=unique(f$df.residual),Quercetin_BH05=sum(a$q_BH_all_sources_this_drug[a$contrast=='Quercetin_minus_DMSO']<.05))
 }
}
write.table(do.call(rbind,results),file.path(P,'全部通路与TF_培养级阻断分数模型.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
write.table(do.call(rbind,summary),file.path(P,'全部通路与TF_培养级模型汇总.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
print(do.call(rbind,summary))
writeLines(c(capture.output(sessionInfo()),'Input is official ULM score per culture after gene-wise centering/SD scaling across all10 cultures, including nonnetwork genes as background.','All14PROGENy and714TF kept. Same full10 scaling used for fourculture sensitivity. P and BH here test cultures via passage-blocked limma, distinct from ULM conditional gene-footprint P.','These scores are transformed transcriptomic footprints, not directly measured protein activity; all exploratory, no patient inference.'),file.path(P,'培养级足迹模型说明.txt'))
