from pathlib import Path
import sys,json,hashlib,itertools,datetime
E=Path('E:/痛风/研究深化_2026-11-02');B=E/'07_实测药物与功能验证';P=B/'06_跨研究整合';U=B/'01_尿酸刺激独立数据/实际模型结果';D=B/'02_药物扰动公共数据/GSE160430_实际分析';G=Path('G:/痛风/第二步_靶点预测与疾病交集');sys.path.insert(0,str(G/'runtime/ppi_analysis_libraries'))
import pandas as pd,numpy as np
contract=json.loads((P/'计算前规则与源SHA256.json').read_text(encoding='utf-8'));sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert all(sha(x['path'])==x['sha256'] for x in contract['inputs'])
cons=contract['UA_order'];drugs=contract['drug_order'];drug=pd.read_csv(D/'主分析_全10_传代阻断_所有基因所有比较_limma.tsv',sep='\t');assert len(drug)==19233*3 and drug.model.nunique()==1
ua={c:pd.read_csv(U/('SymbolGene_'+c+'_完整结果.tsv'),sep='\t') for c in cons}
for c,v in ua.items():assert v.gene_symbol.is_unique and v.contrast.eq(c).all()
for s,v in drug.groupby('contrast'):assert v.gene_symbol.is_unique
records=[];long=[]
for c in cons:
 u=ua[c].set_index('gene_symbol')
 for dr in drugs:
  d=drug[drug.contrast.eq(dr+'_minus_DMSO')].set_index('gene_symbol');q=u[['logFC']].rename(columns={'logFC':'UA_logFC'}).join(d[['logFC']].rename(columns={'logFC':'Drug_logFC'}),how='inner');q=q[np.isfinite(q.UA_logFC)&np.isfinite(q.Drug_logFC)].sort_index();a=q.UA_logFC.to_numpy();b=q.Drug_logFC.to_numpy();n=len(q);assert n>10000
  r1=pd.Series(a).rank(method='average').to_numpy();r2=pd.Series(b).rank(method='average').to_numpy();rho=float(np.corrcoef(r1,r2)[0,1]);cos=float(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)));prod=a*b;ns=int((prod>0).sum());no=int((prod<0).sum());nz=int((prod==0).sum());assert ns+no+nz==n
  records.append({'UA_contrast':c,'drug':dr,'Drug_contrast':dr+'_minus_DMSO','shared_exact_symbol_n':n,'spearman_logFC_descriptive_noP':rho,'cosine_logFC_descriptive':cos,'same_strict_sign_n':ns,'opposite_strict_sign_n':no,'zero_in_either_n':nz,'same_strict_sign_fraction_allshared':ns/n,'opposite_strict_sign_fraction_allshared':no/n,'zero_in_either_fraction_allshared':nz/n,'UA_all_eligible_symbol_n':len(u),'drug_all_eligible_symbol_n':len(d),'interpretation':'different study/cell/model/contrast estimands; not treatment reversal test'})
  q=q.reset_index();q.insert(0,'drug',dr);q.insert(0,'UA_contrast',c);long.append(q)
s=pd.DataFrame(records);assert len(s)==12;s.to_csv(P/'全部12对_完整共同签名_描述性对照.tsv',sep='\t',index=False);full=pd.concat(long,ignore_index=True);full.to_csv(P/'全部12对_全部共同可测基因logFC.tsv.gz',sep='\t',index=False,compression='gzip')
# Fixed candidate families retain source-specific original models and adjustments.
cand=pd.read_csv(G/'关键靶点与通路筛选_2026-10-29/优先12靶点_合格成分关联.csv').gene_symbol.drop_duplicates().tolist();assert len(cand)==12
u12=pd.read_csv(U/'冻结12candidate_4contrast_完整结果.tsv',sep='\t');assert len(u12)==48
Ecols=['feature_id','logFC','P.Value','adj.P.Val','BH_all4contrast_gene_family'];ens={c:pd.read_csv(U/('EnsemblGene_'+c+'_完整结果.tsv'),sep='\t',usecols=Ecols).set_index('feature_id') for c in cons}
def bh(x):
 x=np.asarray(x,float);i=np.argsort(x);v=np.minimum.accumulate((x[i]*len(x)/np.arange(1,len(x)+1))[::-1])[::-1];r=np.empty_like(v);r[i]=np.minimum(v,1);return r
D12=[]
for dr in drugs:
 v=drug[drug.contrast.eq(dr+'_minus_DMSO')].set_index('gene_symbol').reindex(cand).copy();v['gene_symbol']=cand;v['drug']=dr;v['q_fixed12_secondary']=bh(v['P.Value'].fillna(1));D12.append(v)
d12=pd.concat(D12,ignore_index=True);d12['q_fixed12x3_secondary']=bh(d12['P.Value'].fillna(1));d12.to_csv(P/'药物固定12_完整三药_校正族分列.tsv',sep='\t',index=False)
rc=[]
for c in cons:
 for dr in drugs:
  for g in cand:
   ur=u12[u12.contrast.eq(c)&u12.gene_symbol.eq(g)];dd=d12[d12.drug.eq(dr)&d12.gene_symbol.eq(g)];assert len(ur)==len(dd)==1;ur=ur.iloc[0];dd=dd.iloc[0]
   rr={'gene_symbol':g,'UA_contrast':c,'drug':dr,'Drug_contrast':dr+'_minus_DMSO','UA_symbol_source_geneIDs':ur.source_gene_IDs,'UA_symbol_logFC':ur.logFC,'UA_symbol_CI_L':ur['CI.L'],'UA_symbol_CI_R':ur['CI.R'],'UA_symbol_rawP':ur['P.Value'],'UA_q_all_eligible_symbols':ur['adj.P.Val'],'UA_q_all_symbols_x4contrasts':ur.BH_all4contrast_gene_family,'UA_q_frozen12':ur.BH_fixed12_family,'UA_q_frozen12x4':ur.BH_fixed12x4_family,'UA_original_unmoderated_4donor_P':ur.unmoderated_4donor_P,'UA_original_unmoderated_fullfamily_BH':ur.unmoderated_4donor_BH,'Drug_logFC':dd.logFC,'Drug_CI_L':dd['CI.L'],'Drug_CI_R':dd['CI.R'],'Drug_rawP':dd['P.Value'],'Drug_q_all19233genes':dd.q_BH_all_genes,'Drug_q_all19233genes_x3drugs':dd.q_BH_all_genes_all_drugs,'Drug_q_frozen12_secondary':dd.q_fixed12_secondary,'Drug_q_frozen12x3_secondary':dd.q_fixed12x3_secondary,'UA_symbol_test_status':'tested' if np.isfinite(ur.logFC) else 'not_tested','Drug_test_status':'tested' if np.isfinite(dd.logFC) else 'not_tested','UA_unit':'4 healthy primary-monocyte donors; paired factorial within study','Drug_unit':'THP1 culture/passages; not human donors; dose/stimulus GSM mapping unresolved','crossstudy_unit':'no matched donors/cultures, no co-normalization, descriptive only'}
   ids=str(ur.source_gene_IDs).split(';') if pd.notna(ur.source_gene_IDs) else []
   if len(ids)==1 and ids[0] in ens[c].index:
    er=ens[c].loc[ids[0]];rr.update({'UA_primary_Ensembl_status':'single_sourceID_original_primary_family','UA_primary_Ensembl_ID':ids[0],'UA_primary_Ensembl_logFC':er.logFC,'UA_primary_Ensembl_rawP':er['P.Value'],'UA_primary_Ensembl_q_all_eligible_Ensembl':er['adj.P.Val'],'UA_primary_Ensembl_q_allEnsembl_x4contrasts':er.BH_all4contrast_gene_family})
   else:rr['UA_primary_Ensembl_status']='not_one_sourceID; no primaryP assigned to pooledsymbol'
   p=rr['UA_symbol_logFC']*rr['Drug_logFC'];rr['RNA_effect_sign_relation']='same_sign' if p>0 else 'opposite_sign' if p<0 else 'zero_or_missing';rc.append(rr)
r=pd.DataFrame(rc);assert len(r)==144 and not r.duplicated(['gene_symbol','UA_contrast','drug']).any();r.to_csv(P/'固定12_全部4x3效应与原校正族_144行.tsv',sep='\t',index=False);core=['IL1B','NLRP3','CASP1','TLR4'];z=r[r.gene_symbol.isin(core)].copy();z['core_order']=z.gene_symbol.map(dict(zip(core,range(4))));z=z.sort_values(['UA_contrast','drug','core_order']);assert len(z)==48;z.to_csv(P/'固定4_全部4x3效应与原校正族_48行.tsv',sep='\t',index=False)
# No new functional analysis: point to existing measured endpoint evidence and its distinct estimand.
F=B/'03_候选功能证据';layers=[
{'evidence':'GSE107821','compound':'none; UA stimulus','endpoint':'monocyte bulk mRNA/factorial UA-by-LPS interaction','unit':'4 healthy identified donors','source':str(U/'冻结12candidate_4contrast_完整结果.tsv'),'scope':'independent healthy ex vivo inflammatory context; not goutcasecontrol, drug response, or secretion'},
{'evidence':'GSE160430','compound':'Quercetin;Myricetin;Punicalagin','endpoint':'PMA-differentiated THP1 mRNA drug-minus-DMSO','unit':'culture/passages within one cellline','source':str(D/'主分析_全10_传代阻断_所有基因所有比较_limma.tsv'),'scope':'realcelllinedrugperturbation; cannot establish gout efficacy or matureIL1beta secretion; myricetin/punicalagin secretion notassessed in thisbounded integration'},
{'evidence':'PMID32817626;doi10.1371/journal.pone.0237752','compound':'Quercetin','endpoint':'secretedIL1beta, PAO1infection, full15dose/timingcomparisons','unit':'previously reanalyzed source experiment columns; not samecultures asarray','source':str(F/'Quercetin_全部15剂量时序_配对logratio_CI_BH.tsv'),'scope':'functional secretedprotein evidence in separate stimulus/time/dose setting; cannot infer matchedRNAprotein mechanism'},
{'evidence':'PMID19388706;doi10.1021/np8007123','compound':'Quercetin','endpoint':'purifiedbovineXO inhibition/kineticKi','unit':'purifiedenzymeassay','source':str(F/'Quercetin_XO_Table1_原研究动力学汇总.tsv'),'scope':'enzymeactivity distinct fromXDHmRNA; not directNLRP3binding orclinicalgout efficacy'}]
for l in layers:l['sha256']=sha(l['source'])
pd.DataFrame(layers).to_csv(P/'转录_分泌_酶活_证据层级与可支持范围.tsv',sep='\t',index=False)
assert all(sha(x['path'])==x['sha256'] for x in contract['inputs'])
summary={'status':'COMPLETED_ALL12_PRESPECIFIED_PAIRS','n_pairs':len(s),'shared_symbols_eachpair':s.shared_exact_symbol_n.tolist(),'fixed12_rows':len(r),'fixed4_rows':len(z),'noDEG_or_resultselection':True,'crossstudy_P_computed':False,'source_hashes_unchanged':True,'source_q_families_not_relabelled':True,'primaryUAcontrast':'UAxLPS','new_downloads':0,'no_treatment_reversal_claim':True}
(P/'实际完成与QA.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8');print(s[['UA_contrast','drug','shared_exact_symbol_n','spearman_logFC_descriptive_noP','cosine_logFC_descriptive','same_strict_sign_fraction_allshared','opposite_strict_sign_fraction_allshared']].to_string(index=False));print('COMPLETE',summary)

