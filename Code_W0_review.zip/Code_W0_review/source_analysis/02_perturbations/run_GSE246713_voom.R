.libPaths(c('G:/痛风/第二步_靶点预测与疾病交集/runtime/R_geo_libraries',.libPaths()))
library(edgeR);library(limma)
P<-file.path(getwd(),'07_实测药物与功能验证','02_药物扰动公共数据','GSE246713_实际分析')
x<-read.delim(gzfile(file.path(P,'全部原始计数_22培养.tsv.gz')),check.names=FALSE);rownames(x)<-x$ID;x$ID<-NULL;y<-as.matrix(x)
m<-read.delim(file.path(P,'全部22培养_计数列与GSM明确映射.tsv'),check.names=FALSE);stopifnot(identical(colnames(y),m$count_column),all(is.finite(y)),all(y>=0),ncol(y)==22)
groups<-c('D303N_Untreated','D303N_Dox','D303N_Dox_MCC950','WT_Untreated','WT_Dox','WT_Dox_MCC950');m$group<-factor(m$group,levels=groups);design<-model.matrix(~0+group,m);colnames(design)<-groups;rownames(design)<-m$count_column;stopifnot(qr(design)$rank==6)
d<-DGEList(y,group=m$group);keep<-filterByExpr(d,design=design);filter<-data.frame(gene_id=rownames(y),pass_fullgroup_filter=keep);write.table(filter,file.path(P,'全部基因_过滤纳入审计.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
d<-calcNormFactors(d[keep,,keep.lib.sizes=FALSE],method='TMM');write.table(data.frame(count_column=colnames(d),d$samples,check.names=FALSE),file.path(P,'全部样本_TMM与文库量.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
v<-voom(d,design=design,plot=FALSE);fit<-lmFit(v,design)
C<-makeContrasts(MCC950_D303N=D303N_Dox_MCC950-D303N_Dox,MCC950_WT=WT_Dox_MCC950-WT_Dox,DrugByGenotype=(D303N_Dox_MCC950-D303N_Dox)-(WT_Dox_MCC950-WT_Dox),DoxInduction_D303N=D303N_Dox-D303N_Untreated,DoxInduction_WT=WT_Dox-WT_Untreated,levels=design)
f<-eBayes(contrasts.fit(fit,C),robust=TRUE,trend=FALSE)
if(file.exists(file.path(P,'GENCODE_M25官方基因注释.tsv'))){ann<-read.delim(file.path(P,'GENCODE_M25官方基因注释.tsv'),check.names=FALSE)}else{ann<-data.frame(gene_id=character(),gene_id_noversion=character(),gene_symbol=character(),gene_type=character())};stopifnot(!anyDuplicated(ann$gene_id),!anyDuplicated(ann$gene_id_noversion))
res<-list();summ<-list()
for(k in seq_len(ncol(C))){
 tt<-topTable(f,coef=k,number=Inf,sort.by='none',adjust.method='BH',confint=TRUE);tt$gene_id<-rownames(tt);tt$gene_id_noversion<-sub('\\..*$','',tt$gene_id);mi<-match(tt$gene_id,ann$gene_id);ni<-match(tt$gene_id_noversion,ann$gene_id_noversion);tt$annotation_status<-ifelse(!is.na(mi),'exact_version',ifelse(!is.na(ni),'version_stripped_only','not_in_M25'));ai<-ifelse(is.na(mi),ni,mi);tt$mouse_gene_symbol<-ann$gene_symbol[ai];tt$gene_type<-ann$gene_type[ai];tt$contrast<-colnames(C)[k];tt$moderated_SE<-f$stdev.unscaled[,k]*sqrt(f$s2.post);tt$moderated_df<-f$df.total;tt$q_BH_all_filtered_genes<-p.adjust(ifelse(is.finite(tt$P.Value),tt$P.Value,1),'BH',n=nrow(d));tt$gene_family_n<-nrow(d);tt$input_status<-'as-deposited DRAGEN count-like, fractional; source labels raw but exact normalization provenance unresolved';res[[k]]<-tt
 summ[[k]]<-data.frame(contrast=colnames(C)[k],n_genes=nrow(d),BH05=sum(tt$q_BH_all_filtered_genes<.05),BH05_abslogFC1=sum(tt$q_BH_all_filtered_genes<.05&abs(tt$logFC)>1),residual_df=unique(f$df.residual))
}
a<-do.call(rbind,res);a$q_BH_all_genes_all5contrasts<-p.adjust(ifelse(is.finite(a$P.Value),a$P.Value,1),'BH',n=nrow(a));write.table(a,file.path(P,'全部过滤基因_完整5比较_voomlimma.tsv'),sep='\t',quote=FALSE,row.names=FALSE,na='NA');write.table(do.call(rbind,summ),file.path(P,'模型计数概况.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
write.table(data.frame(count_column=rownames(design),design,check.names=FALSE),file.path(P,'实际全6组设计矩阵.tsv'),sep='\t',quote=FALSE,row.names=FALSE);write.table(data.frame(group=rownames(C),C,check.names=FALSE),file.path(P,'全部5比较系数.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
saveRDS(list(voom=v,fit=f,metadata=m,design=design,contrasts=C,filter=keep),file.path(P,'完整voom模型.rds'))
writeLines(c(capture.output(sessionInfo()),paste('input_gene_rows',nrow(y)),'Fractional values retained without rounding; raw-counts filename and DRAGEN EM documentation support estimated-count-like treatment, but source normalization not independently verified.','Exploratory sensitivity/context analysis, not confirmed raw integer recount. No pairing inferred from replicate suffixes.','Mouse immortalized host with inducible human NLRP3 transgene, not human primary macrophages or gout patient data.','All6groups retained, 5contrasts fullgene BH and globalBH reported; source noninteger definition gap remains.'),file.path(P,'实际方法与输入定义限制.txt'))
print(do.call(rbind,summ))

