from pathlib import Path
import sys,json,hashlib,re,datetime
E=Path('E:/痛风/研究深化_2026-11-02');G=Path('G:/痛风/第二步_靶点预测与疾病交集');O=E/'07_实测药物与功能验证/02_药物扰动公共数据';P=O/'GSE246713_实际分析'
for p in reversed([E/'runtime/decoupler_libraries',G/'runtime/ppi_analysis_libraries',G/'论文推进_2026-10-30/单细胞定位/runtime']):sys.path.insert(0,str(p))
import pandas as pd,numpy as np,decoupler as dc
from decoupler.mt._ulm import _func_ulm
from decoupler.pp.data import extract
from decoupler.pp.net import prune,adjmat
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bh(x):
 x=np.asarray(x,float);i=np.argsort(x);q=np.minimum.accumulate((x[i]*len(x)/np.arange(1,len(x)+1))[::-1])[::-1];r=np.empty_like(q);r[i]=np.minimum(q,1);return r
hcop=O/'来源/human_mouse_hcop_fifteen_column.txt.gz';h=pd.read_csv(hcop,sep='\t',keep_default_na=False);assert len(h)==68080
h['support_n']=h.support.map(lambda x:len(set(t.strip() for t in re.split(r'[,|;]',x) if t.strip())));h['valid_3sources']=h.support_n.ge(3)&h.human_symbol.ne('-')&h.mouse_symbol.ne('-')&h.human_ensembl_gene.str.match(r'^ENSG[0-9]+$')&h.mouse_ensembl_gene.str.match(r'^ENSMUSG[0-9]+$')
v=h[h.valid_3sources].copy();pairs=v[['human_symbol','human_ensembl_gene','mouse_symbol','mouse_ensembl_gene']].drop_duplicates();hm=pairs.groupby('human_ensembl_gene').mouse_ensembl_gene.nunique();mh=pairs.groupby('mouse_ensembl_gene').human_ensembl_gene.nunique();hs=pairs.groupby('human_symbol').mouse_ensembl_gene.nunique();ms=pairs.groupby('mouse_ensembl_gene').human_symbol.nunique();pairs['reciprocal_unique']=pairs.human_ensembl_gene.map(hm).eq(1)&pairs.mouse_ensembl_gene.map(mh).eq(1)&pairs.human_symbol.map(hs).eq(1)&pairs.mouse_ensembl_gene.map(ms).eq(1);accepted=pairs[pairs.reciprocal_unique].drop_duplicates(['human_symbol','mouse_ensembl_gene']);assert accepted.human_symbol.is_unique and accepted.mouse_ensembl_gene.is_unique
h.to_csv(P/'HCOP_所有支持证据与纳入资格.tsv.gz',sep='\t',index=False,compression='gzip');pairs.to_csv(P/'HCOP_全部合格支持对_唯一性审计.tsv',sep='\t',index=False);accepted.to_csv(P/'HCOP_实际双向唯一映射.tsv',sep='\t',index=False)
mp=accepted.set_index('human_symbol');human2mouse=mp.mouse_ensembl_gene;human2msym=mp.mouse_symbol
priorpaths={'PROGENy14':E/'02_decoupler官方方法/PROGENy_次级通路足迹/PROGENy_官方默认完整网络.tsv','CollecTRI_monoTF':E/'02_decoupler官方方法/冻结CollecTRI_monoTF网络.tsv'}
contract={'before_mouse_footprint_outcomes':True,'timestampUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_gene_model_contract_sha':sha(P/'计算前冻结合同.json'),'HCOP_URL':'https://storage.googleapis.com/public-download-files/hcop/human_mouse_hcop_fifteen_column.txt.gz','HCOP_sha256':sha(hcop),'orthology_rule':'>=3 supporting source databases; reciprocal uniquehumanEnsembl/mouseEnsembl andhumanSymbol/mouseEnsembl amongsupporteligiblepairs; no uppercase mapping; allinputgenesselectedbeforepathoutcomes','mapping_count':len(accepted),'pathway14':'sourcepathwaylabels unchanged; human targetgene symbols translatedtoformalHCOPmouseEnsemblIDs','TF_both_ends':'sourceTF and targetgene mustboth have formalacceptedHCOPrelation; humanTFlabelretained andmouseTFsymbolsrecorded','input':'all14423testedgenemoderatedt; no DEG filter; backgroundall14423mouseIDs evenunmappedtonetwork','culture_scores':'pergenezscoreeachfull22cultures, separatelyvoomprimary andnoTMMlogCPMsensitivity; same6group5contrasts','unit':'conditionalgeneregressionP separatelyfromculturelevelscoremodelP; nothumanpatientgout','Nlrp3':'engineeredKO/humantransgenehost andmm10reference; retain inallfamily, flag noendogenousmechanisticclaim','prior_sha':{n:sha(f) for n,f in priorpaths.items()},'exploratory':'after primarygenemodeloutcomes, no pathresultsseen; no modelsubstitution'}
cp=P/'HCOP通路计算前冻结合同.json';assert not cp.exists();cp.write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
contrast_rows=[]
for fn,model in [('main_voom_TMM_完整5比较_MGI注释.tsv','main_voom_TMM'),('sensitivity_logCPM_noTMM_完整5比较_MGI注释.tsv','sensitivity_logCPM_noTMM')]:
 a=pd.read_csv(P/fn,sep='\t')
 for c,z in a.groupby('contrast',sort=False):
  genes=z.gene_id.str.split('.').str[0];assert genes.is_unique;contrast_rows.append(pd.Series(z.t.to_numpy(),index=genes,name=model+'|'+c))
d=pd.DataFrame(contrast_rows);assert d.shape==(10,14423) and np.isfinite(d.to_numpy()).all()
allrows=[];cov=[];qa=[];netrows=[]
for resource,f in priorpaths.items():
 original=pd.read_csv(f,sep='\t');net=original.copy();net['human_target']=net.target;net['target']=net.target.map(human2mouse)
 if resource=='CollecTRI_monoTF':net['source_mouse_id']=net.source.map(human2mouse);net=net[net.source_mouse_id.notna()]
 net=net[net.target.notna()].copy();assert not net.duplicated(['source','target']).any();net.to_csv(P/(resource+'_HCOP正式鼠网络.tsv'),sep='\t',index=False)
 for input_kind,model,inp in [('contrast_moderatedt','both_models',d)]+[('sample_standardized',model,pd.read_csv(P/fn,sep='\t',index_col=0)) for model,fn in [('main_voom_TMM','主模型_voom全部过滤基因表达.tsv.gz'),('sensitivity_logCPM_noTMM','敏感性_无TMM全部过滤基因表达.tsv.gz')]]:
  if input_kind=='sample_standardized':
   inp.index=inp.index.str.split('.').str[0];assert inp.index.is_unique
   sd=inp.std(axis=1,ddof=1);inp=inp.loc[sd.gt(0)].sub(inp.mean(axis=1),axis=0).div(sd[sd.gt(0)],axis=0).T
  es,oq=dc.mt.ulm(data=inp,net=net[['source','target','weight']],tmin=5,verbose=False)
  mat,obs,genes=extract(inp,raw=False,empty=True,shuffle=True,verbose=False);tr=prune(features=genes,net=net[['source','target','weight']],tmin=5);names,target,adj=adjmat(features=genes,net=tr);val,pv=_func_ulm(mat,adj);err=float(np.max(abs(es.loc[obs,names].to_numpy()-val)));assert err<1e-9
  qq=np.vstack([bh(a) for a in pv]);assert np.array_equal(oq.loc[obs,names].to_numpy().astype(np.float32),qq.astype(np.float32));qa.append({'resource':resource,'kind':input_kind,'model':model,'background':len(genes),'eligible_sources':len(names),'max_public_private_error':err,'BH_numerical_match':True})
  ct=tr.groupby('source').target.nunique()
  for s in original.source.unique():cov.append({'resource':resource,'input_kind':input_kind,'model':model,'source_human_label':s,'source_mouse_symbol':human2msym.get(s,'') if resource.startswith('Collec') else 'pathway_label_not_gene','original_human_targets':int(original[original.source.eq(s)].target.nunique()),'HCOP_mapped_measured_targets':int(ct.get(s,0)),'tmin5_eligible':s in names,'all_background_genes':len(genes)})
  for i,o in enumerate(obs):
   for j,s in enumerate(names):allrows.append({'resource':resource,'input_kind':input_kind,'model':model,'input_id':o,'source_human_label':s,'source_mouse_symbol':human2msym.get(s,'') if resource.startswith('Collec') else 'pathway_label_not_gene','ULM_score':float(val[i,j]),'rawP_gene_footprint_not_cultureP':float(pv[i,j]),'BH_full_eligible_source_family_not_cultureP':float(qq[i,j]),'family_n':len(names),'measured_targets':int(ct[s])})
  if input_kind=='sample_standardized':es.loc[inp.index].T.to_csv(P/(resource+'_'+model+'_全22培养ULM分数.tsv'),sep='\t',index_label='feature')
 print('DONE',resource,flush=True)
r=pd.DataFrame(allrows);r.to_csv(P/'全部通路与TF_HCOP官方ULM完整结果.tsv.gz',sep='\t',index=False,compression='gzip');pd.DataFrame(cov).to_csv(P/'全部通路与TF_HCOP覆盖与缺失资格.tsv',sep='\t',index=False);(P/'HCOP官方ULM_实际数值QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'HCOP_accepted':len(accepted),'QA':qa},ensure_ascii=False),flush=True)
