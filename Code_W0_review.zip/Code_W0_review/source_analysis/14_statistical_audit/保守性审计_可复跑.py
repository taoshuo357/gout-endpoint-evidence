"""Read-only re-audit of frozen G-drive statistics. All new output is on E.
This computes diagnostics/sensitivity summaries, not new biological validation.
"""
from pathlib import Path
import os,sys,json,csv,gzip,hashlib,collections,html
from fractions import Fraction
ROOT=Path(__file__).resolve().parent.parent
assert ROOT.drive.upper()=='E:'
OUT=Path(__file__).resolve().parent
OLD=Path('G:/痛风/第二步_靶点预测与疾病交集')
sys.path.insert(0,str(OLD/'runtime/ppi_analysis_libraries'))
import numpy as np,pandas as pd
from scipy.stats import false_discovery_control

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def dump(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def save(df,name):df.to_csv(OUT/name,sep='\t',index=False,encoding='utf-8-sig',float_format='%.17g')
def bh(p):
 p=np.asarray(p,float);assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all()
 order=np.argsort(p,kind='stable');q=np.minimum.accumulate((p[order]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1]
 result=np.empty_like(q);result[order]=np.minimum(q,1)
 assert np.allclose(result,false_discovery_control(p,method='bh'),rtol=1e-12,atol=1e-14)
 return result
sources={
 'TF':OLD/'全面验证_2026-11-02/05_调控与通讯/TF_全部细胞类型阶段检验.tsv',
 'LR':OLD/'全面验证_2026-11-02/05_调控与通讯/LR_全部合格文库级阶段检验.tsv',
 'LRall':OLD/'全面验证_2026-11-02/05_调控与通讯/LR_所有配体受体细胞类型组合_6文库.tsv.gz',
 'KO':OLD/'虚拟敲除_2026-11-02/06_统计结果/Heat_五候选_主45项匹配比较.tsv',
 'PBMC':OLD/'GEO表达核验_2026-10-29/独立队列_GSE211783/表达结果/配对身份未确证_保守全基因汇总.csv',
 'Bulk':OLD/'GEO表达核验_2026-10-29/两队列_GEO表达核验汇总.json',
 'methods_TF_LR':OLD/'allvalidation_regulation_20261102.py',
 'methods_KO':OLD/'virtualko_statistics_20261102.py',
 'methods_pseudobulk':OLD/'analyze_geo_pseudobulk.R',
 'methods_Bulk':OLD/'analyze_geo_expression.R',
 'pairing_metadata':OLD/'GEO表达核验_2026-10-29/独立队列_GSE211783/独立队列元数据审计.txt'}
assert all(p.is_file() for p in sources.values())
before={k:sha(p) for k,p in sources.items()}
rows=[];diagnostics={}
for method in ['TF','LR']:
 d=pd.read_csv(sources[method],sep='\t')
 names=['cell_type','TF'] if method=='TF' else ['sender','receiver','ligand','receptor','pair_id']
 complete=d[names].copy()
 native='BH_all_TF_celltype' if method=='TF' else 'BH_all_eligible_LR_typepairs'
 for label,col in [('编号推定配对_'+str(i),'pairing_'+str(i)+'_P') for i in range(1,7)]+[('最坏六配对包络','worst_pairing_P')]:
  p=d[col].to_numpy(float);q=bh(p)
  rows.append({'分析':method,'映射或规则':label,'固定检验族数':len(p),'未校正P小于05':int((p<.05).sum()),'完整族BH小于05':int((q<.05).sum()),'最小P':float(p.min()),'最小BHq':float(q.min()),'推断标签':'配对身份未核实的映射敏感性；不可择优映射' if label!='最坏六配对包络' else '强保守包络；不是唯一常规主分析'})
  complete[col]=p;complete[col+'_BH全族']=q
  if col=='worst_pairing_P':assert np.allclose(q,d[native],rtol=1e-12,atol=1e-13)
 save(complete,method+'_全部逐项P与各映射完整族BH.tsv')
 diagnostics[method]={'tests':len(d),'best_pairing_nominal_P_lt05':int(d.best_pairing_P.lt(.05).sum()),'worst_pairing_nominal_P_lt05':int(d.worst_pairing_P.lt(.05).sum()),'all_six_maps_individually_BH_count': [r['完整族BH小于05'] for r in rows if r['分析']==method and r['映射或规则']!='最坏六配对包络'],'best_pairing_is_not_valid_selected_inference':True}
summary=pd.DataFrame(rows);save(summary,'TF_LR_六映射与最坏包络_完整族检验对照.tsv')
# Source score>0 means every ligand/receptor subunit passed >=10% detection in that sample/type.
# It does NOT mean RNA absent when score=0, and is not a significance test.
patterns={
 '急性三库过阈_缓解至少一库未过阈':lambda a,b:a==3 and b<3,
 '缓解三库过阈_急性至少一库未过阈':lambda a,b:b==3 and a<3,
 '急性三库过阈_缓解三库均未过阈':lambda a,b:a==3 and b==0,
 '缓解三库过阈_急性三库均未过阈':lambda a,b:b==3 and a==0}
handles={};writers={};counts=collections.Counter();totals=collections.Counter()
with gzip.open(sources['LRall'],'rt',encoding='utf-8-sig',newline='') as f:
 reader=csv.DictReader(f,delimiter='\t')
 fields=list(reader.fieldnames)+['acute_threshold_pass_libraries','remission_threshold_pass_libraries','审计定义_非显著性']
 try:
  for name in patterns:
   h=(OUT/('LR候选_'+name+'.tsv')).open('w',encoding='utf-8-sig',newline='');handles[name]=h
   w=csv.DictWriter(h,fieldnames=fields,delimiter='\t');w.writeheader();writers[name]=w
  for row in reader:
   a=sum(float(row[s])>0 for s in ['A1','A2','A3']);b=sum(float(row[s])>0 for s in ['B1','B2','B3'])
   totals['全部组合']+=1;totals['至少一库过阈']+=int(a+b>0);totals['全部六库过阈']+=int(a+b==6)
   assert int(row['library_detections'])==a+b
   for name,predicate in patterns.items():
    if predicate(a,b):
     counts[name]+=1
     writers[name].writerow({**row,'acute_threshold_pass_libraries':a,'remission_threshold_pass_libraries':b,'审计定义_非显著性':'score>0表示配体与受体全部亚基≥10%检出；未过阈不代表RNA绝对不存在。仅阈值分布候选，无新P/q，无真实通讯/药效结论。'})
 finally:
  for h in handles.values():h.close()
assert totals['全部组合']==292288 and totals['全部六库过阈']==5556
assert [counts[k] for k in patterns]==[600,691,17,9]
save(pd.DataFrame([{'阈值分布模式':k,'LR乘发送接收细胞类型组合数':v,'统计解释':('原all6主检验纳入；不是差异通讯阳性' if k=='全部六库过阈' else '资格分布总览；不是差异通讯阳性' if k in totals else '原all6主检验未纳入；阶段阈值候选，不是差异通讯阳性')} for k,v in {**totals,**counts}.items()]),'LR_全六库规则与阶段阈值模式计数.tsv')
# Frozen KO comparisons: repeat mathematical interpretation, do not change original family.
k=pd.read_csv(sources['KO'],sep='\t');assert len(k)==45 and k.controls.eq(99).all()
assert np.allclose(bh(k.adjusted_P_for_fixed_family_BH),k.BH45_adjusted_conditional,rtol=1e-12,atol=1e-13)
save(k.loc[k.adjusted_upper_conditional_P.lt(.05)].sort_values('adjusted_upper_conditional_P'), 'KO_全部四项未校正提示信号_保留原BH45.tsv')
ko={'hypotheses':45,'controls_each':99,'minimum_attainable_conditional_P':.01,'nominal_P_lt05':int(k.adjusted_upper_conditional_P.lt(.05).sum()),'target_above_control_median':int(k.adjusted_excess_over_control_median.gt(0).sum()),'BH45_lt05':int(k.BH45_adjusted_conditional.lt(.05).sum()),'minimum_actual_BH45':float(k.BH45_adjusted_conditional.min()),'fraction_positive_is_not_a_significance_test':True,'finite_rank_resolution_is_not_a_formal_power_calculation':True}
calc=[]
for n in range(1,46):
 q=Fraction(45,100*n)
 calc.append({'极端P等于001的项目数':n,'其他项目P设为1':45-n,'该组BHq_精确分数':str(q),'该组BHq':float(q),'q小于005':q<Fraction(1,20),'q小于等于005':q<=Fraction(1,20),'标签':'阈值算例，非生物学功效估计，非真实新增结果'})
save(pd.DataFrame(calc),'KO_99背景与45族_分辨率阈值算例.tsv')
pb=pd.read_csv(sources['PBMC'])
pbmc={'tested':len(pb),'numbering_assumed_pairing_FDR_lt05':int(pb.numbering_assumed_q.lt(.05).sum()),'worst_pairing_FDR_lt05':int(pb.worst_pairing_q_all_genes.lt(.05).sum()),'worst_pairing_FDR_lt05_before_FC_cutoff':int(pb.worst_pairing_q_all_genes.lt(.05).sum()),'interpretation':'编号推定配对也是0全基因FDR；不能说全基因阴性仅由worst-P或FC2造成。'}
judgments=[
 ['保留必要控制','患者/文库层级、全族BH、原始输入与混杂记录','不得以细胞数/元细胞数/技术种子增加患者n；不能事后选择显著映射或缩小原族。'],
 ['强保守敏感性','六配对maxP包络','可报告编号推定映射、全六映射与最大P/效应范围；未知配对必须标注，不把包络作为唯一主结论。'],
 ['问题不匹配','全部六库LR>=10%资格','会排除阶段获得/丢失候选。新探索应遵循官方逐样本过滤/联合候选策略，区分检测改变与强度变化；输出不自动成为患者差异P。'],
 ['方法待对照','自定义ULM/共表达评分','应与官方decoupler/LIANA实现并列核对；工具细胞级置换P不等于患者级阶段差异。'],
 ['检验分辨率不足','KO99个匹配对照与45项家族','Pmin=.01；孤立信号不利于通过BH。不得用重复抽相同基因伪造更多背景；下一方案需预先设计并校准。'],
 ['estimand改变','KO匹配出度+L1相对份额+共同readout','有意去掉总体扰动/hub优势，检验额外通路分配；不能以0/45否定基因参与痛风或标准经典KO响应。'],
 ['未校准的模型排序','近邻匹配KO条件rankP','匹配基因不是随机样本；条件交换性和真实扰动下零分布尚未校准。BH不应声称已校准生物学FDR，宜作为自定义敏感性。'],
 ['约定而非生物边界','DEG绝对log2FC>=1','应并列连续效应/FDR/通路，不把低于2倍说成无作用；本次PBMC编号配对q仍全0，门槛不是唯一原因。'],
 ['不可计算消除的设计限制','Bulk精确扫描场次与AG完全混杂','ComBat或共线协变量不能识别被完全混杂的疾病效应；已做日期/同日敏感性仍非独立验证。'],
 ['模型表征限制','KO受限1500基因、CP低范数指标、heat对称近似','经典与heat、自定义specificity要分开；数值实现一致不等于生物预测准确。宜用真实扰动与参考目标校准。']]
save(pd.DataFrame(judgments,columns=['判断类别','环节','合规改进与边界']),'必要控制_额外保守_不适配_审计判断.tsv')
assert all(sha(p)==before[key] for key,p in sources.items())
record={'status':'AUDIT_COMPLETE_WITH_DESIGN_LIMITATIONS','date':'2026-11-02','new_biological_tests':0,'old_results_modified':False,'source_SHA256_unchanged':True,'TF_LR':diagnostics,'LR_threshold_counts':dict(totals),'LR_stage_threshold_candidates':dict(counts),'KO':ko,'PBMC':pbmc,'source_files':[{'key':key,'path':str(p),'sha256':before[key]} for key,p in sources.items()],'audit_code':str(Path(__file__)),'audit_code_sha256':sha(__file__),'statistical_recalculation':'numpy BH independently checked against SciPy false_discovery_control and native old worst-pairing q; complete families unchanged','interpretation':'存在额外强保守及问题不匹配；移除这些规则不会保证显著；本审计没有新造阳性。'}
dump(OUT/'审计实际数字与来源.json',record)
text='统计保守性与问题适配审计（2026-11-02）\n\n结论：存在额外强保守及问题不匹配，尤其LR全六库资格和KO有限背景/自定义份额检验；未发现本轮BH数值实现问题。不能把0显著解释为靶点没有作用，也不能声称放松后必然阳性。\n\n一、TF/LR逐映射\n'+summary.to_string(index=False)+'\n\n最佳映射P不能事后择优用于推断。TF最优未校正P<.05=550、最坏21；LR最优849、最坏20。重新对每个映射完整族BH后，TF和LR的六种映射均0显著。\n\n二、LR资格与gain/loss候选\n'+json.dumps({**totals,**counts},ensure_ascii=False,indent=2)+'\nscore=0仅表示至少一亚基未满足>=10%检出阈值，不表示RNA绝对不存在。17/9为严格三库对三库阈值模式；600/691包含这两组。它们是原规则未纳入的候选组合，不是差异通讯显著性或真实信号传递。\n\n三、KO分辨率和estimand\n'+json.dumps(ko,ensure_ascii=False,indent=2)+'\n99背景使最小rankP=.01。若只有一个P=.01其余1，BHq=.45；若k个P=.01其余1，q=.45/k，k=9刚好.05，严格小于.05需要k>=10。仅阈值算例，不是正式功效估计。\n近邻匹配和出度控制去掉整体/hub优势，L1把绝对扰动转成份额。共用背景在同模型/同路径是同一常数，单独相减不改变组内排序，不能说共享扣除直接把阳性减没；聚合/归一化/readout共同改变估计目标。99近邻的交换性未通过真实扰动零分布验证，条件rankP/BH宜作模型排序敏感性，而非已校准生物学FDR。\n\n四、PBMC与Bulk\n'+json.dumps(pbmc,ensure_ascii=False,indent=2)+'\nBulk已有50候选差异，不是全阴性；但精确扫描场次与AG完全混杂，原日期调整与同日子集不能完全识别疾病效应。不能仅用ComBat抹去不可识别性。\n\n五、设计判断\n'+'\n\n'.join(' / '.join(row) for row in judgments)+'\n\n六、可执行下一步\n1. 旧结果保留；E盘另列标准实现对照与敏感性，不重命名为预注册主分析。\n2. 官方LIANA/decoupler逐样本执行，比较表达资格、复合物处理、排序与现有自定义方法；对阈值gain/loss候选作描述，不用细胞置换P替代患者阶段P。\n3. 经典scTenifoldKnk、heat近似、自定义specificity分别报告。用真实Perturb-seq或明确参考扰动校准能力，而不是只凭数值实现一致升级机制证据。\n4. 若新增hdWGCNA，以模块留一稳定性和真正独立队列模块保留为目标，元细胞不增加患者n。\n5. 每种资源须匹配问题：健康人槲皮素、已用药急性/缓解PBMC、正常组织弱eQTL分别能回答的内容不同，不一律要求重复同一个方药机制。\n\n全部输入SHA256复核不变；本审计不改旧主结果、不新增生物学检验、不启动Swiss查询。\n'
(OUT/'保守性审计_结论与改进.txt').write_text(text,encoding='utf-8')
links=[p for p in OUT.iterdir() if p.suffix in ['.tsv','.json','.py','.txt']]
body='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>统计保守性与问题适配审计</title><style>body{max-width:1250px;margin:35px auto;padding:20px;font:16px/1.7 Arial,"Microsoft YaHei",sans-serif;color:#243b4b}table{border-collapse:collapse;font-size:13px;width:100%}th,td{border-bottom:1px solid #ccd8df;padding:10px;text-align:left;vertical-align:top}pre{white-space:pre-wrap;background:#f1f5f7;padding:20px}a{color:#276b90}</style><h1>统计保守性与问题适配审计</h1><p>旧数据只读，全部新增产物在E盘。本报告区分必要控制、额外强保守与分析问题不匹配。</p><h2>完整族逐映射结果</h2>'+summary.to_html(index=False,border=0,float_format=lambda x:f'{x:.6g}')+'<h2>判断与修订</h2>'+pd.DataFrame(judgments,columns=['类别','环节','解释与修订']).to_html(index=False,border=0)+'<h2>完整解释</h2><pre>'+html.escape(text)+'</pre><h2>复跑代码与完整表</h2><ul>'+''.join('<li><a href="'+html.escape(p.name,quote=True)+'">'+html.escape(p.name)+'</a></li>' for p in links)+'</ul></html>'
(OUT/'统计保守性_完整审计报告.html').write_text(body,encoding='utf-8')
print(json.dumps({'status':record['status'],'summary_rows':len(summary),'LR_candidates':dict(counts),'KO_nominal':ko['nominal_P_lt05'],'report':str(OUT/'统计保守性_完整审计报告.html'),'old_SHA_unchanged':True},ensure_ascii=False),flush=True)

