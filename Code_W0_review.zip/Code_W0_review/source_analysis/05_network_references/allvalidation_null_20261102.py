from allvalidation_common_20261102 import *
import numpy as np
import networkx as nx
from collections import defaultdict,Counter
OUT=ROOT/'03_匹配背景与置换';OUT.mkdir(exist_ok=True)
N=9999;SEED=20261102
nodes=read(BASE/'下一步_PPI与富集_2026-10-29'/'PPI_397主分析_节点指标.csv')
edges=read(BASE/'下一步_PPI与富集_2026-10-29'/'PPI_功能关联700_主边表.csv')
ann={r['gene_symbol']:r for r in read(BASE/'合并交集_2026-10-29'/'痛风交集_候选基因.csv')}
names=sorted(r['gene_symbol'] for r in nodes);pos={g:i for i,g in enumerate(names)}
assert len(names)==393 and len(edges)==3295 and all(g in pos for g in GENES)
G=nx.Graph();G.add_nodes_from(names);G.add_edges_from((r['gene_A'],r['gene_B']) for r in edges)
A=nx.to_numpy_array(G,nodelist=names,dtype=np.int16)
H=np.zeros((393,393))
for g,ds in nx.all_pairs_shortest_path_length(G):
    i=pos[g]
    for t,d in ds.items():
        if d:H[i,pos[t]]=1/d
ix=np.array([pos[g] for g in GENES]);up=np.triu_indices(12,1)
def metrics(i):return float(A[np.ix_(i,i)].sum()/2),float(H[np.ix_(i,i)][up].mean())
obs=metrics(ix)
degree=np.array([G.degree(g) for g in names]);breadth=np.array([int(ann[g]['compound_count']) for g in names]);sources=np.array([int(ann[g]['compound_database_count']) for g in names])
# Repeated ties stay in the same numerical-quantile bin.
dbin=np.digitize(degree,np.unique(np.quantile(degree,[.25,.5,.75])),right=True)
bbin=np.digitize(breadth,np.unique(np.quantile(breadth,[.25,.5,.75])),right=True)
strata={'Uniform':[(0,) for g in names],'Degree matched':[(int(d),) for d in dbin],'Degree breadth source matched':[(int(d),int(b),int(s>=2)) for d,b,s in zip(dbin,bbin,sources)]}
contract={'seed':SEED,'gene_null_draws_per_family':N,'fixed_genes':GENES,'background_nodes':393,'fixed_graph':'STRING functional700 393/3295; original mapped isolates retained','metrics':['Induced edge count','Harmonic pair efficiency (unreachable=0)'],'strata':'Numerical degree quartiles; compound breadth quartiles; source breadth 1 versus >=2. Ties stay together. Samples without replacement within each observed stratum. Singleton strata may force retention and are reported.','compound_null':'Degree-preserving Curveball trades on the 104x12 qualified binary matrix, burn5000, 100 trades between1000 samples. Same row and column degrees exactly.','multiplicity':'All six gene-network + three compound-network tests are one BH9 family. All upper-tail tests declared before null generation.','limits':'Candidates were selected partly using biology and networks; matching does not undo all post-selection bias and is not independent biological validation.'}
dump(OUT/'计算前合同.json',contract)
results=[];draws=[];stratarows=[]
for label,keys in strata.items():
    rng=np.random.default_rng(SEED)
    pools=defaultdict(list)
    for i,k in enumerate(keys):pools[k].append(i)
    counts=Counter(keys[i] for i in ix)
    for k,n in counts.items():stratarows.append({'family':label,'stratum':str(k),'selected_count':n,'pool_size':len(pools[k]),'forced_whole_pool':int(n==len(pools[k])),'pool_genes':';'.join(names[i] for i in pools[k])})
    null=np.empty((N,2))
    for j in range(N):
        sample=np.concatenate([rng.choice(pools[k],size=n,replace=False) for k,n in counts.items()])
        null[j]=metrics(sample)
        draws.append({'family':label,'draw':j+1,'induced_edges':null[j,0],'harmonic_efficiency':null[j,1]})
    for m,metric in enumerate(['Induced edges','Harmonic pair efficiency']):
        p=(1+np.count_nonzero(null[:,m]>=obs[m]-1e-12))/(N+1)
        results.append({'family':label,'metric':metric,'observed':obs[m],'null_median':float(np.median(null[:,m])),'null_q025':float(np.quantile(null[:,m],.025)),'null_q975':float(np.quantile(null[:,m],.975)),'upper_tail_p':p,'draws':N})
    print(label,obs,np.median(null,0),flush=True)
write(OUT/'基因网络_全部29997随机结果.tsv',draws);write(OUT/'匹配分层与强制保留核对.tsv',stratarows)
q=read(BASE/'生信扩展_2026-11-02'/'结果表'/'Network_104乘12_全部候选关联.tsv')
Q=np.array([int(r['recorded_edge']) for r in q],dtype=np.int16).reshape(104,12)
rowdeg=Q.sum(1);coldeg=Q.sum(0);up104=np.triu_indices(104,1)
def cm(M):
    union=rowdeg[:,None]+rowdeg[None,:]-M@M.T
    gain=union-np.maximum(rowdeg[:,None],rowdeg[None,:])
    u=union[up104];g=gain[up104]
    return np.array([u.max(),np.count_nonzero(u>=8),g.max()],float)
cobs=cm(Q);sets=[set(np.flatnonzero(r)) for r in Q];rng=np.random.default_rng(SEED)
def trades(n):
    for _ in range(n):
        a,b=rng.choice(104,2,replace=False);common=sets[a]&sets[b];x=sets[a]-common;y=sets[b]-common
        if not x or not y:continue
        pool=list(x|y);rng.shuffle(pool);sets[a]=common|set(pool[:len(x)]);sets[b]=common|set(pool[len(x):])
trades(5000);cnull=[];digest=Counter()
for j in range(1000):
    trades(100)
    M=np.zeros_like(Q)
    for i,ss in enumerate(sets):M[i,list(ss)]=1
    assert np.array_equal(M.sum(0),coldeg) and np.array_equal(M.sum(1),rowdeg)
    digest[hashlib.sha256(M.tobytes()).hexdigest()]+=1
    vals=cm(M);cnull.append(vals)
    draws_row={'draw':j+1,'maximum_union':vals[0],'pairs_union_ge8':vals[1],'maximum_gain':vals[2]}
    if j==0:crows=[]
    crows.append(draws_row)
cnull=np.array(cnull)
for k,metric in enumerate(['Maximum pair candidate union','Pairs covering >=8 candidates','Maximum gain over better single']):
    results.append({'family':'Bipartite exact-degree Curveball','metric':metric,'observed':cobs[k],'null_median':float(np.median(cnull[:,k])),'null_q025':float(np.quantile(cnull[:,k],.025)),'null_q975':float(np.quantile(cnull[:,k],.975)),'upper_tail_p':(1+np.count_nonzero(cnull[:,k]>=cobs[k]))/1001,'draws':1000})
for r,qval in zip(results,bh([r['upper_tail_p'] for r in results])):r['BH9']=float(qval)
write(OUT/'全部九项统计与BH.tsv',results);write(OUT/'成分网络_全部1000随机结果.tsv',crows)
dump(OUT/'置换混合核查.json',{'distinct_degree_preserving_matrices':len(digest),'sampled_matrices':1000,'all_row_column_degrees_exact':True,'mixing_boundary':'Distinct configurations and100 thinning trades are diagnostics, not proof of independence or uniform convergence.'})
dump(OUT/'实际结果摘要.json',{'status':'COMPUTED','results':results,'matched_strata':stratarows,'unique_curveball_matrices':len(digest),'source_hashes':{str(p.relative_to(BASE)):sha(p) for p in [BASE/'下一步_PPI与富集_2026-10-29'/'PPI_功能关联700_主边表.csv',BASE/'合并交集_2026-10-29'/'痛风交集_候选基因.csv']}})
print(json.dumps(results,ensure_ascii=False,indent=2),flush=True)

