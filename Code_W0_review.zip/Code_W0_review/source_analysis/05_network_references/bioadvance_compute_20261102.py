from bioadvance_common_20261102 import *
import numpy as np
import scipy
from scipy.spatial.distance import squareform,pdist
from scipy.cluster.hierarchy import linkage,leaves_list,fcluster
from scipy.stats import rankdata
from rdkit import Chem,DataStructs,rdBase
from rdkit.Chem import Descriptors,Crippen,Lipinski,rdMolDescriptors,rdFingerprintGenerator,QED
from rdkit.Chem.Scaffolds import MurckoScaffold
from collections import Counter,defaultdict
import itertools,math

queue=read(BASE/'Swiss分批提交队列.csv')
assert len(queue)==104 and len({r['预测CID'] for r in queue})==104
full=read(BASE/'合并交集_2026-10-29'/'成分靶点_去重关联.csv')
gout=read(BASE/'合并交集_2026-10-29'/'成分_交集靶点关联.csv')
qual=read(BASE/'关键靶点与通路筛选_2026-10-29'/'优先12靶点_合格成分关联.csv')
coverage={r['pubchem_cid']:r for r in read(BASE/'合并交集_2026-10-29'/'成分_覆盖与交集计数.csv')}
assert len(full)==9421 and len(gout)==4759 and len(qual)==213
assert len({r['gene_symbol'] for r in full})==980 and len({r['gene_symbol'] for r in gout})==397
cidpos={r['预测CID']:i for i,r in enumerate(queue)}
fpgen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048,includeChirality=True)
mols=[];fps=[];desc=[]
for i,q in enumerate(queue):
    mol=Chem.MolFromSmiles(q['SMILES']);assert mol is not None,(i,q['预测CID'])
    mols.append(mol);fps.append(fpgen.GetFingerprint(mol))
    d={'compound_id':f'C{i+1:03d}','cid':q['预测CID'],'name':q['预测结构'],'source_herbs':coverage[q['预测CID']]['source_herbs'],
       'input_smiles':q['SMILES'],'canonical_isomeric_smiles':Chem.MolToSmiles(mol,isomericSmiles=True),
       'MW':Descriptors.MolWt(mol),'cLogP':Crippen.MolLogP(mol),'TPSA':rdMolDescriptors.CalcTPSA(mol),
       'HBD':Lipinski.NumHDonors(mol),'HBA':Lipinski.NumHAcceptors(mol),'RotB':Lipinski.NumRotatableBonds(mol),
       'Fsp3':rdMolDescriptors.CalcFractionCSP3(mol),'Rings':rdMolDescriptors.CalcNumRings(mol),
       'AromaticRings':rdMolDescriptors.CalcNumAromaticRings(mol),'QED':QED.qed(mol),
       'formal_charge':Chem.GetFormalCharge(mol),'fragment_count':len(Chem.GetMolFrags(mol)),
       'Murcko_scaffold':MurckoScaffold.MurckoScaffoldSmiles(mol=mol,includeChirality=True)}
    d['Ro5_violations']=int(d['MW']>500)+int(d['cLogP']>5)+int(d['HBD']>5)+int(d['HBA']>10)
    d['Veber_violations']=int(d['TPSA']>140)+int(d['RotB']>10)
    desc.append(d)
S=np.array([DataStructs.BulkTanimotoSimilarity(fp,fps) for fp in fps]);assert np.allclose(S,S.T) and np.allclose(np.diag(S),1)
Z=linkage(squareform(np.clip(1-S,0,1),checks=False),method='average',optimal_ordering=True)
order=leaves_list(Z);clusters=fcluster(Z,t=.6,criterion='distance')
features=['MW','cLogP','TPSA','HBD','HBA','RotB','Fsp3','Rings','AromaticRings']
X=np.array([[d[k] for k in features] for d in desc]);mean=X.mean(0);sd=X.std(0,ddof=1);Xs=(X-mean)/sd
U,s,Vt=np.linalg.svd(Xs,full_matrices=False);coords=U[:,:2]*s[:2]
# Stabilize PCA signs by largest absolute loading, preserving score/loading equality.
for k in range(2):
    sign=1 if Vt[k,np.argmax(abs(Vt[k]))]>=0 else -1;coords[:,k]*=sign;Vt[k]*=sign
for i,d in enumerate(desc):d.update({'PC1':coords[i,0],'PC2':coords[i,1],'chemical_cluster':int(clusters[i]),'chemical_order':int(np.flatnonzero(order==i)[0])})
write('Chem_104结构全描述符与PCA.tsv',desc)
write('Chem_PCA载荷与标准化.tsv',[{'descriptor':f,'mean':mean[j],'sd':sd[j],'PC1_loading':Vt[0,j],'PC2_loading':Vt[1,j]} for j,f in enumerate(features)])
write('Chem_全部结构相似度.tsv',[{'compound_a':desc[i]['compound_id'],'compound_b':desc[j]['compound_id'],'Tanimoto':S[i,j]} for i in range(104) for j in range(i,104)])
write('Chem_层次聚类连接矩阵.tsv',[{'merge':i,'left':int(r[0]),'right':int(r[1]),'distance':r[2],'size':int(r[3])} for i,r in enumerate(Z)])
np.savez_compressed(DATA/'analysis_arrays.npz',similarity=S,chemical_order=order,linkage=Z)

sets=defaultdict(set)
for r in full:sets[r['pubchem_cid']].add(r['gene_symbol'])
mantel=[];pairrows=[]
for scenario,remove in [('All sources',None)]+[(f'Without {db}',db) for db in DB]:
    temp=defaultdict(set)
    for r in full:
        if any(int(r[db]) for db in DB if db!=remove):temp[r['pubchem_cid']].add(r['gene_symbol'])
    ix=[i for i,q in enumerate(queue) if temp[q['预测CID']]]
    n=len(ix);T=np.zeros((n,n))
    for a,i in enumerate(ix):
        for b,j in enumerate(ix):
            A=temp[queue[i]['预测CID']];B=temp[queue[j]['预测CID']];T[a,b]=len(A&B)/len(A|B)
    up=np.triu_indices(n,1);sx=S[np.ix_(ix,ix)][up];ty=T[up]
    rx=rankdata(sx);ry=rankdata(ty);rx-=rx.mean();ry-=ry.mean();den=np.linalg.norm(rx)*np.linalg.norm(ry)
    rho=float(rx@ry/den);rankmat=np.zeros((n,n));rankmat[up]=ry;rankmat[(up[1],up[0])]=ry
    rng=np.random.default_rng(20261102);extreme=0
    for k in range(9999):
        perm=rng.permutation(n);r=float(rx@rankmat[np.ix_(perm,perm)][up]/den)
        extreme+=abs(r)>=abs(rho)-1e-12
    p=(extreme+1)/10000
    mantel.append({'scenario':scenario,'compounds_with_records':n,'compound_pairs':len(sx),'Mantel_Spearman_r':rho,'permutations':9999,'two_sided_permutation_p':p})
    if remove is None:
        for a,i in enumerate(ix):
            for b,j in enumerate(ix):
                if b>a:pairrows.append({'compound_a':desc[i]['compound_id'],'compound_b':desc[j]['compound_id'],'Tanimoto':S[i,j],'target_Jaccard':T[a,b],'a_target_count':len(temp[queue[i]['预测CID']]),'b_target_count':len(temp[queue[j]['预测CID']])})
    print(scenario,n,rho,p,flush=True)
pv=np.array([r['two_sided_permutation_p'] for r in mantel]);idx=np.argsort(pv);adj=np.minimum.accumulate((pv[idx]*5/np.arange(1,6))[::-1])[::-1];qv=np.empty(5);qv[idx]=np.minimum(adj,1)
for r,q in zip(mantel,qv):r['BH_5_scenarios']=q
write('Chem_结构靶点谱Mantel_全部来源情景.tsv',mantel);write('Chem_全部可测化合物对_结构与靶点相似.tsv',pairrows)

# Database presence is provenance, not calibrated independent confidence.
upsets=[]
for scope,edges in [('All compound-target edges',full),('Gout-overlap edges',gout)]:
    # Frozen per-database fields can count multiple evidence rows: binarize presence.
    c=Counter(tuple(int(int(r[db])>0) for db in DB) for r in edges)
    for mask,n in sorted(c.items(),key=lambda z:(-z[1],z[0])):
        upsets.append({'scope':scope,**dict(zip(DB,mask)),'edge_count':n,'databases':';'.join(db for db,b in zip(DB,mask) if b)})
write('Network_完整数据库组合计数.tsv',upsets)
deletion=[]
for name,removed in [('All sources',None)]+[(f'Without {db}',db) for db in DB]:
    keep=[r for r in full if any(int(r[db]) for db in DB if db!=removed)]
    gs={r['gene_symbol'] for r in keep};goutgenes={r['gene_symbol'] for r in gout}
    deletion.append({'scenario':name,'edges':len(keep),'genes':len(gs),'gout_genes':len(gs&goutgenes),'compounds_with_records':len({r['pubchem_cid'] for r in keep})})
write('Network_逐库剔除完整计数.tsv',deletion)
qmatrix=np.zeros((104,12),int);source_count=np.zeros_like(qmatrix)
qualified_sets=defaultdict(set)
for r in qual:
    i=cidpos[r['pubchem_cid']];j=GENES.index(r['gene_symbol'])
    assert qmatrix[i,j]==0
    qmatrix[i,j]=1;source_count[i,j]=int(r['source_count']);qualified_sets[r['pubchem_cid']].add(r['gene_symbol'])
write('Network_104乘12_全部候选关联.tsv',[{'compound_id':d['compound_id'],'cid':d['cid'],'name':d['name'],'source_herbs':d['source_herbs'],'gene':g,'recorded_qualified_sources':int(source_count[i,j]),'recorded_edge':int(qmatrix[i,j])} for i,d in enumerate(desc) for j,g in enumerate(GENES)])
pairs=[]
for i,j in itertools.combinations(range(104),2):
    A=qualified_sets[desc[i]['cid']];B=qualified_sets[desc[j]['cid']];union=A|B
    pairs.append({'compound_a':desc[i]['compound_id'],'compound_b':desc[j]['compound_id'],'cid_a':desc[i]['cid'],'cid_b':desc[j]['cid'],'name_a':desc[i]['name'],'name_b':desc[j]['name'],'a_candidate_count':len(A),'b_candidate_count':len(B),'union_candidate_count':len(union),'gain_over_best_single':len(union)-max(len(A),len(B)),'shared_candidate_count':len(A&B),'Tanimoto':S[i,j],'union_genes':';'.join(g for g in GENES if g in union)})
assert len(pairs)==5356
pairs.sort(key=lambda r:(-r['union_candidate_count'],-r['gain_over_best_single'],r['Tanimoto'],r['cid_a'],r['cid_b']))
write('Network_全部5356成分对_覆盖互补.tsv',pairs)
solo=[]
for i,d in enumerate(desc):
    genes=qualified_sets[d['cid']]
    solo.append({'compound_id':d['compound_id'],'cid':d['cid'],'name':d['name'],'candidate_count':len(genes),'genes':';'.join(g for g in GENES if g in genes),'source_herbs':d['source_herbs'],'chemical_order':d['chemical_order']})
write('Network_全部104成分_候选覆盖.tsv',solo)
summary={'structures':104,'parsed':len(mols),'rdkit':rdBase.rdkitVersion,'numpy':np.__version__,'scipy':scipy.__version__,
 'PCA_explained_variance_ratio':(s*s/(s*s).sum()).tolist(),'nonempty_exact_Murcko_scaffolds':len({d['Murcko_scaffold'] for d in desc if d['Murcko_scaffold']}),
 'acyclic_structures':sum(not d['Murcko_scaffold'] for d in desc),'chemical_clusters_at_distance_0_6':len(set(clusters)),
 'Ro5_violations_0':sum(d['Ro5_violations']==0 for d in desc),'Ro5_violations_le1':sum(d['Ro5_violations']<=1 for d in desc),'Veber_both_within':sum(d['Veber_violations']==0 for d in desc),
 'qualified_priority_edges':int(qmatrix.sum()),'compounds_with_qualified_candidate_edges':int(np.count_nonzero(qmatrix.sum(1))),
 'all_pair_count':len(pairs),'maximum_single_candidate_coverage':max(r['candidate_count'] for r in solo),'maximum_pair_candidate_coverage':max(r['union_candidate_count'] for r in pairs),
 'maximum_pair_gain':max(r['gain_over_best_single'] for r in pairs),'Mantel_scenarios':mantel,'source_deletions':deletion,
 'limits':'Computed descriptors and structure similarity are exploratory, not measured PK/toxicity. Database-count corroboration is not independent confidence. Coverage complementarity is not drug synergy. Compound-label permutations respect pair dependence but do not control herb/target-breadth confounding.'}
dump(OUT/'化学与网络结果摘要.json',summary)
print(json.dumps(summary,ensure_ascii=False,indent=2))
