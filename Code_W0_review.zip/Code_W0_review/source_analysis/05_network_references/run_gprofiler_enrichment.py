"""Auditable gProfiler requests and local full-family ORA; use project launcher.

The PowerShell HTTPS bridge uses native Windows certificate validation. Never
disables TLS validation and never contacts Swiss or STRING.
"""
from __future__ import annotations
import argparse
import csv
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from functools import lru_cache
from pathlib import Path
import shutil
import subprocess
import time

BASE = Path(__file__).resolve().parent
OUT = BASE / '下一步_PPI与富集_2026-10-29/富集分析'
API = 'https://biit.cs.ut.ee/gprofiler/api'
SOURCES = ['GO:BP', 'GO:MF', 'GO:CC', 'KEGG']
VERSION = 'e114_eg62_p19_9dc92ac8'
REQUEST_LOG = []
LAST_REQUEST = 0.0

def require(condition, message):
    if not condition:
        raise ValueError(message)

def local(path):
    value = (BASE / path).resolve()
    require(BASE.drive.upper() == 'G:' and value.drive.upper() == 'G:' and value.is_relative_to(BASE),
            'All project files must remain on G: '+str(path))
    return value

def relative(path):
    return local(path).relative_to(BASE).as_posix()

def json_text(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def dump(path, value):
    path = local(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def load(path):
    return json.loads(local(path).read_text(encoding='utf-8-sig'))

def fingerprint(path):
    data = local(path).read_bytes()
    return {'path': relative(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def post(name, endpoint, payload):
    global LAST_REQUEST
    request = {'url': API+'/'+endpoint+'/', 'payload': payload}
    request_hash = hashlib.sha256(json_text(request).encode('utf-8')).hexdigest()
    folder = local(OUT/'HTTP原始记录')
    folder.mkdir(parents=True, exist_ok=True)
    prefix = folder/(name+'_'+request_hash[:16])
    request_path = prefix.with_suffix('.request.json')
    response_path = prefix.with_suffix('.response.json')
    access_path = prefix.with_suffix('.access.json')
    if access_path.exists():
        access = load(access_path)
        require(access.get('status') == 200 and response_path.exists(),
                'Previous API attempt did not succeed; inspect before explicitly retrying: '+relative(access_path))
        require(hashlib.sha256(response_path.read_bytes()).hexdigest() == access['sha256'], 'Cached response hash mismatch')
        require(load(request_path) == request, 'Cached request does not match')
        REQUEST_LOG.append({'name': name, 'cached': True, 'request': fingerprint(request_path),
                            'response': fingerprint(response_path), 'access': fingerprint(access_path)})
        print(json.dumps({'request':name,'cached':True,'bytes':access['bytes']}), flush=True)
        return load(response_path)
    dump(request_path, request)
    delay = 1.1 - (time.monotonic()-LAST_REQUEST)
    if delay > 0:
        time.sleep(delay)
    powershell = shutil.which('pwsh') or shutil.which('powershell')
    require(powershell, 'A native PowerShell HTTPS client is required')
    command = [powershell, '-NoLogo', '-NoProfile', '-NonInteractive', '-File',
               str(local(BASE/'invoke_gprofiler_https.ps1')), '-RequestPath', str(request_path),
               '-ResponsePath', str(response_path), '-AccessPath', str(access_path)]
    result = subprocess.run(command, cwd=BASE, text=True, encoding='utf-8', capture_output=True)
    LAST_REQUEST = time.monotonic()
    require(result.returncode == 0 and access_path.exists(),
            'gProfiler request failed; no automatic duplicate POST. '+result.stdout.strip()+' '+result.stderr.strip())
    access = load(access_path)
    require(access['status'] == 200 and access.get('certificate_validation_disabled') is False,
            'gProfiler response/TLS validation failed')
    require(hashlib.sha256(response_path.read_bytes()).hexdigest() == access['sha256'], 'Response hash mismatch')
    REQUEST_LOG.append({'name': name, 'cached': False, 'request': fingerprint(request_path),
                        'response': fingerprint(response_path), 'access': fingerprint(access_path)})
    print(json.dumps({'request':name,'cached':False,'bytes':access['bytes']}), flush=True)
    return load(response_path)

def profile_payload(query, background, no_evidences=False):
    return {'organism': 'hsapiens', 'query': query, 'sources': SOURCES,
            'background': background, 'domain_scope': 'custom', 'ordered': False,
            'combined': False, 'all_results': True, 'user_threshold': 1.0,
            'significance_threshold_method': 'fdr', 'measure_underrepresentation': False,
            'no_iea': False, 'no_evidences': no_evidences, 'output': 'json'}

def probe():
    background = ['TP53', 'EGFR', 'AKT1', 'IL6', 'TNF']
    conversion = post('probe_convert', 'convert/convert',
                      {'organism':'hsapiens','target':'ENSG','query':background,'output':'json'})
    family = post('probe_background', 'gost/profile', profile_payload(background, background, True))
    actual = post('probe_query', 'gost/profile', profile_payload(['TP53', 'EGFR'], background, False))
    report = {'performed_at_utc': datetime.now(timezone.utc).isoformat(),
              'probe_genes': background, 'conversion_keys': list(conversion),
              'conversion_first_rows': conversion.get('result', [])[:6],
              'family_result_count': len(family.get('result', [])),
              'actual_result_count': len(actual.get('result', [])),
              'family_first_rows': family.get('result', [])[:2],
              'actual_first_rows': actual.get('result', [])[:2],
              'family_metadata': family.get('meta'), 'actual_metadata': actual.get('meta'),
              'requests': REQUEST_LOG, 'study_gene_queries_submitted': False}
    dump(OUT/'小型接口探针核验.json', report)
    print(json.dumps({key: report[key] for key in ['family_result_count','actual_result_count','conversion_first_rows']}, ensure_ascii=False))

def read_csv(path, delimiter=','):
    with local(path).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream, delimiter=delimiter))

def write_csv(path, rows, fields=None):
    require(rows or fields, 'An empty CSV needs explicit headers')
    path = local(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields or list(rows[0]), lineterminator='\r\n')
        writer.writeheader()
        writer.writerows(rows)

def write_genes(path, genes):
    path = local(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text('\n'.join(sorted(genes))+'\n', encoding='utf-8')

def prepare_inputs():
    merged = BASE/'合并交集_2026-10-29'
    files = [merged/'痛风交集_候选基因.txt', merged/'成分靶点_去重基因.txt',
             merged/'敏感性_各场景交集基因.csv', merged/'成分靶点_纳入证据长表.csv',
             BASE/'UniProt_2026-10-20/human_reviewed.tsv',
             BASE/'UniProt_2026-10-20/human_reviewed.tsv.access.json',
             OUT/'服务元数据/gprofiler_data_versions_native.response',
             OUT/'服务元数据/gprofiler_data_versions_native.access.json']
    source_files = [fingerprint(path) for path in files]
    primary_list = [gene.strip() for gene in files[0].read_text(encoding='utf-8-sig').splitlines() if gene.strip()]
    background_list = [gene.strip() for gene in files[1].read_text(encoding='utf-8-sig').splitlines() if gene.strip()]
    require(len(primary_list) == len(set(primary_list)) == 397 and
            len(background_list) == len(set(background_list)) == 980, 'Primary 397/980 input count mismatch')
    primary, background = set(primary_list), set(background_list)
    strict = {row['gene_symbol'] for row in read_csv(files[2]) if row['scenario_id'] == 'human_source_strict'}
    strict_background = {row['gene_symbol'] for row in read_csv(files[3])
                         if row['tcmsp_species_unverified'] != '1' and row['pm_representative_mapping'] != '1'}
    require(len(strict) == 366 and len(strict_background) == 896, 'Strict 366/896 input count mismatch')
    require(primary <= background and strict <= strict_background, 'Query is not a subset of its candidate background')
    reference = read_csv(files[4], '\t')
    require(len(reference) == 20431 and all(row['Organism (ID)'] == '9606' and row['Reviewed'] == 'reviewed'
                                          for row in reference), 'Unexpected human reviewed reference')
    human, all_split, ambiguous_reference = set(), set(), []
    singleton_rows = 0
    for row in reference:
        genes = [gene.strip() for gene in row['Gene Names (primary)'].split(';') if gene.strip()]
        all_split.update(genes)
        if len(genes) == 1:
            singleton_rows += 1
            human.add(genes[0])
        else:
            ambiguous_reference.append({'accession':row['Entry'],'primary_field':row['Gene Names (primary)'],
                                        'status':'排除背景：非唯一primary，不机械展开'})
    require(singleton_rows == 20215 and len(human) == 20122, 'Conventional 20122 unique-single-primary background mismatch')
    versions = load(files[6])
    require(versions['gprofiler_version'] == VERSION and all(source in versions['sources'] for source in SOURCES),
            'gProfiler metadata version/source mismatch')
    backgrounds = {'component_primary':background, 'component_strict':strict_background, 'human_reviewed_single_primary':human}
    queries = {'primary':primary, 'human_source_strict':strict}
    for name, genes in backgrounds.items():
        write_genes(OUT/'背景与映射'/f'{name}.input_symbols.txt', genes)
    for name, genes in queries.items():
        write_genes(OUT/'背景与映射'/f'{name}.query_input_symbols.txt', genes)
    write_csv(OUT/'背景与映射/全人类参考_非唯一primary隔离.csv', ambiguous_reference,
              ['accession','primary_field','status'])
    report = {'query_sizes_requested':{name:len(genes) for name,genes in queries.items()},
              'background_sizes_requested':{name:len(genes) for name,genes in backgrounds.items()},
              'human_reference_accession_rows':len(reference),'human_single_primary_accession_rows':singleton_rows,
              'human_unique_single_primary_genes':len(human),'human_split_primary_genes_inventory_only':len(all_split),
              'human_nonunique_or_missing_primary_rows_excluded':len(ambiguous_reference),
              'primary_outside_conventional_background':sorted(primary-human),
              'strict_outside_conventional_background':sorted(strict-human),
              'source_files':source_files, 'gprofiler_data_versions':versions,
              'strict_background_rule':'成分纳入证据长表同时排除tcmsp_species_unverified=1及pm_representative_mapping=1后按gene_symbol去重',
              'conventional_background_rule':'存档human9606 reviewed条目仅保留primary为唯一非空gene的条目，再按gene去重；不是全部人类基因组',
              'family_definition':'每source在对应有效背景内K>=1的全部term；不按研究query的k或p值预筛选，零命中term补k=0,p=1',
              'main_multiple_testing_rule':'逐analysis、逐source在完整背景term家族上BH；另给同analysis四source合并BH作补充',
              'annotation_electronic_evidence_included':True,'ordered_query':False}
    dump(OUT/'富集_输入与背景核验.json', report)
    return queries, backgrounds, report

def unique_ensembl_mapping(symbols):
    symbols = sorted(symbols)
    response = post('study_identifier_conversion', 'convert/convert',
                    {'organism':'hsapiens','target':'ENSG','query':symbols,'output':'json'})
    groups = defaultdict(list)
    for row in response['result']:
        require(row['incoming'] in symbols, 'Conversion returned an unknown incoming symbol')
        groups[row['incoming']].append(row)
    candidates = {}
    names = {}
    for symbol in symbols:
        records = groups[symbol]
        converted = {row['converted'] for row in records if str(row.get('converted','')).startswith('ENSG')}
        if len(converted) == 1:
            candidates[symbol] = next(iter(converted))
        names[symbol] = sorted({row.get('name','') for row in records if row.get('name')})
    incoming_by_ensg = defaultdict(list)
    for symbol, ensg in candidates.items():
        incoming_by_ensg[ensg].append(symbol)
    collisions = {ensg:symbols for ensg,symbols in incoming_by_ensg.items() if len(symbols) > 1}
    mapping = {symbol:ensg for symbol,ensg in candidates.items() if ensg not in collisions}
    audit = []
    for symbol in symbols:
        converted = sorted({row['converted'] for row in groups[symbol] if str(row.get('converted','')).startswith('ENSG')})
        status = ('纳入：官方唯一ENSG映射' if symbol in mapping else
                  '隔离：多个输入符号共用ENSG' if symbol in candidates else
                  '隔离：官方ENSG一对多' if len(converted)>1 else '未覆盖：官方无ENSG映射')
        audit.append({'input_gene_symbol':symbol,'ensembl_gene_id':mapping.get(symbol,''),
                      'official_converted_ids':';'.join(converted),'official_returned_names':';'.join(names[symbol]),
                      'official_name_exactly_matches_input':str(names[symbol] == [symbol]).lower(),
                      'mapping_status':status,'official_response_rows_json':json_text(groups[symbol])})
    write_csv(OUT/'背景与映射/官方gConvert_符号到ENSG_逐基因审计.csv', audit)
    report = {'input_unique_symbols':len(symbols),'accepted_one_to_one_symbols':len(mapping),
              'status_counts':dict(Counter(row['mapping_status'] for row in audit)),
              'cross_symbol_ensembl_collisions':collisions,
              'accepted_changed_official_names':[row for row in audit if row['input_gene_symbol'] in mapping
                                                 and row['official_name_exactly_matches_input']=='false'],
              'policy':'一对多或多个不同输入符号共用ENSG均隔离，不把一个源gene膨胀成多个抽样单元；唯一官方别名转换保留原符号及返回名称'}
    dump(OUT/'背景与映射/官方gConvert_映射汇总.json', report)
    return mapping, report

def validate_profile(response, expected_query, expected_background):
    require(response['meta']['version'] == VERSION, 'Annotation release changed during analysis')
    metadata = response['meta']['query_metadata']
    require(metadata['domain_scope']=='custom' and metadata['ordered'] is False and metadata['all_results'] is True,
            'gProfiler did not preserve the requested domain/query method')
    genes = response['meta']['genes_metadata']
    require(not genes.get('failed') and not genes.get('ambiguous') and not genes.get('duplicates'),
            'Pre-converted ENSG identifiers were not uniquely recognized')
    query_metadata = genes['query']['query_1']
    require(set(query_metadata['ensgs']) == set(expected_query) and len(query_metadata['ensgs']) == len(expected_query),
            'API query metadata is not the exact submitted unique ENSG set')
    require(set(expected_query) <= set(expected_background), 'Effective ENSG query is outside background')
    rows = response.get('result', [])
    require(len({(row['source'],row['native']) for row in rows})==len(rows), 'Duplicate API source/term')
    return rows

def background_family(name, symbols, mapping):
    mapped_symbols = sorted(set(symbols)&set(mapping))
    ensgs = sorted(mapping[symbol] for symbol in mapped_symbols)
    require(len(ensgs)==len(set(ensgs))>0, 'Background mapping is empty or duplicated')
    response = post('background_family_'+name, 'gost/profile', profile_payload(ensgs, ensgs, True))
    rows = validate_profile(response, ensgs, ensgs)
    families = {source:{} for source in SOURCES}
    for row in rows:
        require(row['source'] in SOURCES, 'Unexpected enrichment source')
        N,n,K,k = (int(row[key]) for key in ['effective_domain_size','query_size','term_size','intersection_size'])
        require(N==n==len(ensgs) and 1<=K==k<=N, 'Background-query source-specific effective domain does not match its submitted set')
        families[row['source']][row['native']] = row
    require(all(families[source] for source in SOURCES), 'A requested source has no background family')
    info = {'background_id':name,'requested_symbols':len(symbols),'unique_mapped_symbols':len(mapped_symbols),
            'effective_unique_ensembl_genes':len(ensgs),'unmapped_or_quarantined_symbols':sorted(set(symbols)-set(mapping)),
            'term_family_sizes':{source:len(families[source]) for source in SOURCES},
            'N_effective_by_source':{source:sorted({row['effective_domain_size'] for row in families[source].values()}) for source in SOURCES},
            'meta_result_metadata_is_organism_wide_not_custom_N':response['meta']['result_metadata'],
            'background_response_file':REQUEST_LOG[-1]['response']['path']}
    dump(OUT/'背景与映射'/f'{name}.family_summary.json', info)
    write_genes(OUT/'背景与映射'/f'{name}.mapped_symbols.txt', mapped_symbols)
    write_genes(OUT/'背景与映射'/f'{name}.mapped_ensembl.txt', ensgs)
    return families, ensgs, info

def bh_adjust(pvalues):
    require(all(math.isfinite(value) and 0<=value<=1 for value in pvalues), 'Invalid p-value for BH')
    m = len(pvalues)
    adjusted = [1.0]*m
    running = 1.0
    for rank,index in reversed(list(enumerate(sorted(range(m),key=lambda i:pvalues[i]),1))):
        running = min(running,pvalues[index]*m/rank,1.0)
        adjusted[index] = running
    return adjusted

@lru_cache(maxsize=300000)
def log_choose(total, chosen):
    require(0<=chosen<=total,'Invalid combinatorial arguments')
    chosen = min(chosen,total-chosen)
    return math.lgamma(total+1)-math.lgamma(chosen+1)-math.lgamma(total-chosen+1)

@lru_cache(maxsize=300000)
def hypergeom_tail(k,N,K,n):
    """One-sided P[X>=k] using log PMF plus upper-tail recurrence.

    Summing positive log-space tail terms avoids subtracting nearly equal CDFs.
    The log tail remains available when exponentiation underflows to zero.
    """
    require(0<=n<=N and 0<=K<=N and 0<=k<=min(n,K),'Invalid hypergeometric counts')
    lower,upper = max(0,n-(N-K)),min(n,K)
    if k<=lower:
        return 1.0,0.0
    log_pmf = log_choose(K,k)+log_choose(N-K,n-k)-log_choose(N,n)
    log_total = log_pmf
    for x in range(k,upper):
        log_pmf += math.log(K-x)+math.log(n-x)-math.log(x+1)-math.log(N-K-n+x+1)
        larger,smaller = max(log_total,log_pmf),min(log_total,log_pmf)
        log_total = larger+math.log1p(math.exp(smaller-larger))
    log_total = min(0.0,log_total)
    return min(1.0,math.exp(log_total)),log_total

def verify_numerics():
    cases = [(5,K,2,k) for K in range(1,6) for k in range(0,min(K,2)+1)]
    cases += [(50,10,7,3),(100,40,20,15),(50,48,30,28),(20,1,19,1),(100,3,4,3)]
    errors = []
    for N,K,n,k in cases:
        exact = sum(math.comb(K,x)*math.comb(N-K,n-x)
                    for x in range(max(k,0,n-(N-K)),min(n,K)+1))/math.comb(N,n)
        observed,log_p = hypergeom_tail(k,N,K,n)
        require(abs(observed-exact)<2e-12,'Hypergeometric tail failed exact-integer numerical cross-check')
        errors.append(abs(observed-exact))
    expected = [0.02,0.04,0.04,0.008]
    require(all(abs(a-b)<1e-14 for a,b in zip(bh_adjust([0.01,0.04,0.03,0.002]),expected)),
            'BH adjustment failed its independently specified rank example')
    report = {'algorithm':'Python stdlib math.lgamma/log1p upper-tail recurrence in log space',
              'exact_integer_combinatorial_crosscheck_cases':len(cases),'max_absolute_error':max(errors),
              'BH_independent_rank_example_passed':True}
    dump(OUT/'超几何与BH数值核验.json',report)
    return report

def analyze(analysis_id, query_name, background_id, query_symbols, background_symbols, mapping, family_data):
    families, background_ensgs, family_info = family_data
    allowed_query_symbols = sorted(set(query_symbols)&set(background_symbols)&set(mapping))
    query_ensgs = sorted(mapping[symbol] for symbol in allowed_query_symbols)
    reverse = {mapping[symbol]:symbol for symbol in allowed_query_symbols}
    require(len(reverse)==len(query_ensgs)>0,'Effective query mapping is empty or duplicated')
    response = post('study_query_'+analysis_id, 'gost/profile', profile_payload(query_ensgs, background_ensgs, False))
    actual_rows = validate_profile(response, query_ensgs, background_ensgs)
    actual_path = REQUEST_LOG[-1]['response']['path']
    api_ensgs = response['meta']['genes_metadata']['query']['query_1']['ensgs']
    actual_by_source = {source:{} for source in SOURCES}
    for row in actual_rows:
        require(row['source'] in SOURCES and row['native'] in families[row['source']],
                'Study-query term is absent from the complete background term family')
        actual_by_source[row['source']][row['native']] = row
    all_rows, summaries = [], []
    for source in SOURCES:
        observed = actual_by_source[source]
        require(observed, 'Source has no study-query overlap; its query size needs a separate coverage audit')
        Ns = {int(row['effective_domain_size']) for row in observed.values()}
        ns = {int(row['query_size']) for row in observed.values()}
        family_Ns = {int(row['effective_domain_size']) for row in families[source].values()}
        require(len(Ns)==len(ns)==1 and Ns==family_Ns, 'Source-specific API effective N/n is inconsistent')
        N,n = next(iter(Ns)),next(iter(ns))
        require(N==len(background_ensgs) and n==len(query_ensgs),
                'API source-specific effective N/n differs from the audited exact ENSG sets; stop rather than substitute gene totals')
        source_rows = []
        for term_id,family_term in sorted(families[source].items()):
            actual = observed.get(term_id)
            K = int(family_term['term_size'])
            k = int(actual['intersection_size']) if actual else 0
            require(0<=k<=min(K,n) and K<=N, 'Invalid hypergeometric contingency counts')
            if actual:
                require(int(actual['term_size'])==K, 'Study/background term_size changed')
                intersections = actual.get('intersections')
                require(isinstance(intersections,list) and len(intersections)==len(api_ensgs),
                        'Term intersections are not aligned with query metadata')
                hit_ensgs = [gene for gene,evidence in zip(api_ensgs,intersections) if evidence]
                require(len(hit_ensgs)==k and all(gene in reverse for gene in hit_ensgs), 'Hit-gene count/mapping mismatch')
                evidence = {reverse[gene]:codes for gene,codes in zip(api_ensgs,intersections) if codes}
            else:
                hit_ensgs,evidence = [],{}
            raw_p,log_p = hypergeom_tail(k,N,K,n)
            require(math.isfinite(raw_p) and 0<=raw_p<=1,'Hypergeometric calculation failed')
            source_rows.append({'analysis_id':analysis_id,'query_id':query_name,'background_id':background_id,
                'source':source,'term_id':term_id,'term_name':family_term['name'],
                'N_background_effective':N,'n_query_effective':n,'K_background_term':K,'k_query_overlap':k,
                'query_symbols_requested':len(query_symbols),'background_symbols_requested':len(background_symbols),
                'p_raw':raw_p,'ln_p_raw':log_p,'p_underflow':str(raw_p==0 and math.isfinite(log_p)).lower(),
                'q_bh_source':None,'q_bh_all_four_sources':None,
                'q_service_fdr':float(actual['p_value']) if actual else '',
                'q_bh_overlap_only_service_check':'','service_q_check_abs_difference':'',
                'gene_ratio':k/n,'background_ratio':K/N,'fold_enrichment':(k/n)/(K/N),
                'overlap_gene_symbols':';'.join(sorted(reverse[gene] for gene in hit_ensgs)),
                'overlap_ensembl_ids':';'.join(sorted(hit_ensgs)),'overlap_evidence_json':json_text(evidence),
                'zero_query_overlap_completed':str(actual is None).lower(),
                'family_terms_tested':len(families[source]),'domain_scope':'custom',
                'gprofiler_version':VERSION,'family_response_path':family_info['background_response_file'],
                'study_response_path':actual_path})
        source_q = bh_adjust([row['p_raw'] for row in source_rows])
        for row,q in zip(source_rows,source_q):
            row['q_bh_source'] = q
        overlap_only = [row for row in source_rows if not row['zero_query_overlap_completed']=='true']
        overlap_q = bh_adjust([row['p_raw'] for row in overlap_only])
        for row,q in zip(overlap_only,overlap_q):
            row['q_bh_overlap_only_service_check'] = q
            row['service_q_check_abs_difference'] = abs(q-row['q_service_fdr'])
        delta = max(row['service_q_check_abs_difference'] for row in overlap_only)
        summaries.append({'analysis_id':analysis_id,'source':source,'query_symbols_requested':len(query_symbols),
            'background_symbols_requested':len(background_symbols),'background_N_effective':N,'query_n_effective':n,
            'terms_in_complete_family':len(source_rows),'terms_with_query_overlap':len(overlap_only),
            'zero_overlap_terms_completed':len(source_rows)-len(overlap_only),
            'terms_q_bh_source_lt_0_05':sum(row['q_bh_source']<0.05 for row in source_rows),
            'max_abs_service_fdr_vs_local_overlap_only_bh':delta,
            'all_effective_N_n_K_k_and_hit_genes_validated':True})
        all_rows.extend(source_rows)
    q_joint = bh_adjust([row['p_raw'] for row in all_rows])
    for row,q in zip(all_rows,q_joint):
        row['q_bh_all_four_sources'] = q
    all_rows.sort(key=lambda row:(SOURCES.index(row['source']),row['q_bh_source'],row['p_raw'],row['term_id']))
    output_file = OUT/'完整检验家族'/f'{analysis_id}.all_terms.csv'
    write_csv(output_file,all_rows)
    coverage = {'analysis_id':analysis_id,'query_id':query_name,'background_id':background_id,
                'query_symbols_requested':len(query_symbols),'query_symbols_after_mapping_and_background':len(allowed_query_symbols),
                'background_symbols_requested':len(background_symbols),'background_unique_mapped_ensgs':len(background_ensgs),
                'query_symbols_unmapped_or_quarantined':sorted(set(query_symbols)-set(mapping)),
                'query_symbols_outside_this_background':sorted(set(query_symbols)-set(background_symbols)),
                'effective_query_symbols':allowed_query_symbols,'effective_query_ensembl_ids':query_ensgs,
                'source_summaries':summaries,'full_family_csv':fingerprint(output_file)}
    dump(OUT/'背景与映射'/f'{analysis_id}.coverage.json',coverage)
    print(json.dumps({'analysis_completed':analysis_id,'full_terms':len(all_rows),
                      'effective_query':len(query_ensgs),'effective_background':len(background_ensgs)}),flush=True)
    return [row for row in all_rows if row['q_bh_source']<0.05], summaries, coverage

def run_analysis():
    require((OUT/'小型接口探针核验.json').exists(), 'Run the small capability probe first')
    numerical_check = verify_numerics()
    queries,backgrounds,input_report = prepare_inputs()
    mapping,mapping_report = unique_ensembl_mapping(set().union(*backgrounds.values(),*queries.values()))
    families = {}
    significant, summaries, coverages = [],[],[]
    scenarios = [('primary_component_bg','primary','component_primary'),
                 ('strict_component_bg','human_source_strict','component_strict'),
                 ('primary_human_reviewed_bg','primary','human_reviewed_single_primary'),
                 ('strict_human_reviewed_bg','human_source_strict','human_reviewed_single_primary')]
    for analysis_id,query_id,background_id in scenarios:
        if background_id not in families:
            families[background_id] = background_family(background_id,backgrounds[background_id],mapping)
        hits,source_summaries,coverage = analyze(analysis_id,query_id,background_id,queries[query_id],
                                              backgrounds[background_id],mapping,families[background_id])
        significant.extend(hits)
        summaries.extend(source_summaries)
        coverages.append(coverage)
    require(significant,'No significant terms; preserve a header-only significant table instead of assuming success')
    write_csv(OUT/'富集_各场景_sourceBH小于0.05.csv',significant)
    write_csv(OUT/'富集_场景与source汇总.csv',summaries)
    for record in input_report['source_files']:
        require(fingerprint(BASE/record['path'])==record,'An input source changed during enrichment')
    output_files = [fingerprint(OUT/'富集_各场景_sourceBH小于0.05.csv'),fingerprint(OUT/'富集_场景与source汇总.csv')]
    output_files.extend(coverage['full_family_csv'] for coverage in coverages)
    report = {'analysis_date':'2026-10-29','gprofiler_version':VERSION,
        'gprofiler_data_versions':input_report['gprofiler_data_versions'],
        'source_files':input_report['source_files'],'source_file_hashes_unchanged_after_analysis':True,
        'script_sources':[fingerprint(BASE/'run_gprofiler_enrichment.py'),fingerprint(BASE/'invoke_gprofiler_https.ps1')],
        'python_statistics':numerical_check,
        'family_definition':input_report['family_definition'],
        'BH_primary_rule':input_report['main_multiple_testing_rule'],
        'GO_electronic_annotations_included':True,'GO_term_size_filter':None,'KEGG_term_size_filter':None,
        'mapping_report':mapping_report,'coverage':coverages,'source_summary_rows':summaries,
        'http_requests':REQUEST_LOG,'output_files':output_files,
        'no_swiss_or_string_requests':True,'no_prediction_submission':True,
        'scope':'四场景ORA使用输入预定义背景；20122仅为reviewed唯一primary可归属gene组，非完整人类基因组。'
                'gConvert一对多及不同输入共享ENSG隔离后，实际背景N和query n逐source由API结果验证，未强套输入总数。'
                '完整family来自同背景整集query，K>=1的所有term均检验，实际query未返回项补k=0,p=1后逐source BH。'
                '服务FDR字段仅作不同检验家族口径核对；不是原始p。原p在本地重算并保留命中基因及原始响应。'
                '本次为候选集过度代表性分析，不能证明作用方向、直接结合或机制因果。'}
    dump(OUT/'富集分析_正式核验.json',report)
    print(json.dumps({'completed':True,'scenarios':len(scenarios),'summary_rows':len(summaries),
                      'source_BH_significant_rows':len(significant),
                      'report':relative(OUT/'富集分析_正式核验.json')},ensure_ascii=False),flush=True)

def main():
    local(BASE)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['probe','prepare','run'])
    arguments = parser.parse_args()
    if arguments.mode == 'probe':
        probe()
    elif arguments.mode == 'prepare':
        _,_,report = prepare_inputs()
        print(json.dumps({key:report[key] for key in ['query_sizes_requested','background_sizes_requested',
              'human_unique_single_primary_genes','human_split_primary_genes_inventory_only']},ensure_ascii=False))
    else:
        run_analysis()

if __name__ == '__main__':
    main()
