"""Version-pinned STRING retrieval and deterministic PPI summaries, with G-only writes."""
from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime, timezone
from decimal import Decimal
import csv, hashlib, io, json, math, re, ssl, sys, time
import urllib.request, urllib.parse, urllib.error

BASE=Path(__file__).resolve().parent; assert BASE.drive.upper()=='G:'
sys.path.insert(0,str(BASE/'runtime/ppi_analysis_libraries'))
OUT=BASE/'下一步_PPI与富集_2026-10-29'; OUT.mkdir(exist_ok=True)
API=OUT/'STRING原始响应';API.mkdir(exist_ok=True)
MERGE=BASE/'合并交集_2026-10-29'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def dump(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def read(p,sep=','):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter=sep))
def write(name,records,fields=None):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(records[0]));w.writeheader();w.writerows(records)
def parts(s):return [a.strip() for a in s.split(';') if a.strip()]
def fileinfo(p):return {'path':p.relative_to(BASE).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size}

def request(name,url,params=None):
    target=API/name; meta=API/(name+'.access.json')
    if target.exists() and meta.exists():
        m=load(meta)
        assert m['url']==url and m['parameters']==params and m['status']==200 and m['sha256']==sha(target)
        return target.read_bytes()
    for attempt in range(1,4):
        time.sleep(1.05)
        raw=None if params is None else urllib.parse.urlencode(params).encode('utf-8')
        req=urllib.request.Request(url,data=raw,headers={'User-Agent':'Gout-network-pharmacology-local-research/1.0',
            'Content-Type':'application/x-www-form-urlencoded'} if raw else {'User-Agent':'Gout-network-pharmacology-local-research/1.0'})
        detail={'url':url,'parameters':params,'method':'GET' if params is None else 'POST',
                'attempt':attempt,'retrieved_at_utc':datetime.now(timezone.utc).isoformat()}
        try:
            with urllib.request.urlopen(req,timeout=90,context=ssl.create_default_context()) as response:
                data=response.read();detail.update(status=response.status,headers=dict(response.headers),bytes=len(data),
                    sha256=hashlib.sha256(data).hexdigest(),resolved_url=response.url)
            target.write_bytes(data);dump(meta,detail)
            assert detail['status']==200
            return data
        except Exception as error:
            detail['error']=repr(error);dump(API/(name+f'.attempt_{attempt}.error.json'),detail)
            if attempt==3:raise
            time.sleep(attempt*2)

def inputs():
    prior=load(MERGE/'合并与交集核验.json')
    for item in prior['files']:
        p=BASE/item['path'];assert sha(p)==item['sha256']
    primary=sorted((MERGE/'痛风交集_候选基因.txt').read_text(encoding='utf-8').split())
    alltargets=sorted((MERGE/'成分靶点_去重基因.txt').read_text(encoding='utf-8').split())
    scenes=read(MERGE/'敏感性_各场景交集基因.csv')
    strict=sorted(r['gene_symbol'] for r in scenes if r['scenario_id']=='human_source_strict')
    evidence=read(MERGE/'成分靶点_纳入证据长表.csv')
    strictbg=sorted({r['gene_symbol'] for r in evidence if r['tcmsp_species_unverified']=='0' and r['pm_representative_mapping']=='0'})
    ref=read(BASE/'UniProt_2026-10-20/human_reviewed.tsv','\t')
    single=sorted({r['Gene Names (primary)'].strip() for r in ref if len(parts(r['Gene Names (primary)']))==1})
    allgenes=sorted({g for r in ref for g in parts(r['Gene Names (primary)'])})
    assert [len(primary),len(alltargets),len(strict),len(strictbg),len(single),len(allgenes)]==[397,980,366,896,20122,20315]
    assert set(strict)<=set(primary)<=set(alltargets)<=set(single)
    assert set(strict)<=set(strictbg)<=set(alltargets)
    inp=OUT/'输入';inp.mkdir(exist_ok=True)
    for name,genes in [('主分析397',primary),('主背景980',alltargets),('敏感性366',strict),('敏感背景896',strictbg),
                       ('人类reviewed单primary背景20122',single),('全部primary基因盘点20315',allgenes)]:
        (inp/(name+'.txt')).write_text('\n'.join(genes)+'\n',encoding='utf-8')
    gene_info={r['gene_symbol']:r for r in read(MERGE/'成分靶点_去重基因.csv')}
    accessions=sorted({a for g in primary for a in parts(gene_info[g]['uniprot_accessions'])})
    mapping_inputs=primary+accessions
    assert len(set(mapping_inputs))==len(mapping_inputs)
    config={'analysis_date':'2026-10-29','foreground_primary':397,'background_primary':980,'foreground_sensitivity':366,
        'background_sensitivity':896,'human_single_primary_background':20122,'human_all_primary_inventory':20315,
        'species':9606,'network_type':'functional','retrieved_min_required_score':400,'primary_score_threshold':0.7,
        'lower_threshold_sensitivity':0.4,'physical_comparison_threshold':0.7,'add_nodes':0,
        'centrality_graph':'undirected unweighted induced graph; scores retained as evidence, not distances',
        'betweenness':'normalized unweighted; exact shortest paths; mapping-isolated nodes retained',
        'closeness':'Wasserman-Faust disconnected-component correction (networkx default)',
        'community_method':'greedy modularity (weighted combined score), descriptive only',
        'candidate_display':'top 20 by primary degree; tie by betweenness, then gene; not validated core targets',
        'plot_backend':'python (saved preference read only)','ora_design':'foreground as subset of eligible candidate background; human single-primary reference only as comparison',
        'ora_test':'one-sided hypergeometric; BH separately within GO:BP,GO:MF,GO:CC,KEGG complete term families per scenario',
        'fdr_cutoff':0.05,'no_new_prediction_submissions':True,'all_outputs_on_G':True,
        'limits':['STRING functional associations do not demonstrate direct binding','Physical associations can reflect common complexes',
            'GeneCards-dependent intersection; PPI/text-mining/database circularity retained as a limitation',
            'No GSEA is run because no experimental ranked genome-wide list was provided'],
        'source_files':[fileinfo(MERGE/name) for name in ['合并与交集核验.json','成分靶点_去重基因.csv','痛风交集_候选基因.txt',
              '敏感性_各场景交集基因.csv','成分靶点_纳入证据长表.csv']]+[fileinfo(BASE/'UniProt_2026-10-20/human_reviewed.tsv')]}
    plan=OUT/'分析参数与口径.json'
    if plan.exists():assert load(plan)==config
    else:dump(plan,config)
    return primary,strict,ref,gene_info,mapping_inputs

def fetch():
    primary,strict,ref,gene_info,mapping_inputs=inputs()
    version=json.loads(request('version.json','https://string-db.org/api/json/version'))
    assert len(version)==1
    stable=version[0].get('stable_address',version[0].get('string_stable_address','')).rstrip('/')
    assert re.fullmatch(r'https://version-[0-9-]+\.string-db\.org',stable),stable
    dump(OUT/'STRING版本.json',version[0])
    request('官方API说明.html','https://string-db.org/help/api/')
    params={'identifiers':'\r'.join(mapping_inputs),'species':9606,'echo_query':1,
            'caller_identity':'gout_network_pharmacology_local_research'}
    mapping=json.loads(request('gene_accession_mapping.json',stable+'/api/json/get_string_ids',params))
    refs={r['Entry']:r for r in ref}
    names=defaultdict(set)
    for r in ref:
        for name in parts(r['Gene Names (primary)'])+r['Gene Names (synonym)'].replace(';',' ').split():
            names[name].update(parts(r['Gene Names (primary)']))
    indexed=defaultdict(list)
    for r in mapping:
        ix=int(r['queryIndex']);assert 0<=ix<len(mapping_inputs)
        assert r['queryItem']==mapping_inputs[ix] and int(r['ncbiTaxonId'])==9606
        assert r['stringId'].startswith('9606.')
        indexed[r['queryItem']].append(r)
    audit=[]
    for gene in primary:
        acc=parts(gene_info[gene]['uniprot_accessions'])
        assert all(a in refs and parts(refs[a]['Gene Names (primary)'])==[gene] for a in acc)
        genehits=indexed[gene]; acchits=[hit for a in acc for hit in indexed[a]]
        ids={r['stringId'] for r in genehits+acchits}
        labels={r['preferredName'] for r in genehits+acchits}
        labelok=all(label==gene or names[label]=={gene} for label in labels)
        if len(ids)==1 and labelok:
            sid=next(iter(ids));status='纳入：gene及accession一致' if genehits and acchits else '纳入：仅gene或accession映射且名称核对一致'
        elif not ids:sid='';status='隔离：STRING未返回映射'
        elif len(ids)>1:sid='';status='隔离：gene/accession或候选STRING实体冲突'
        else:sid='';status='隔离：preferredName与官方primary/唯一synonym不一致'
        audit.append({'gene_symbol':gene,'expected_uniprot_accessions':';'.join(acc),'string_id':sid,'mapping_status':status,
            'string_preferred_names':';'.join(sorted(labels)),'all_candidate_string_ids':';'.join(sorted(ids)),
            'gene_query_hits':len(genehits),'accession_query_hits':len(acchits),
            'in_sensitivity_366':int(gene in strict)})
    colliding={k for k,n in Counter(r['string_id'] for r in audit if r['string_id']).items() if n>1}
    for r in audit:
        if r['string_id'] in colliding:r.update(string_id='',mapping_status='隔离：不同输入基因映射至同一STRING实体')
    write('STRING_397基因映射审计.csv',audit)
    accepted=[r for r in audit if r['string_id']]
    write('STRING_未纳入映射.csv',[r for r in audit if not r['string_id']],list(audit[0]))
    ids=sorted(r['string_id'] for r in accepted);assert len(ids)==len(set(ids))
    assert len(ids)>300
    for kind,score,name in [('functional',400,'functional_400.tsv'),('physical',700,'physical_700.tsv')]:
        params={'identifiers':'\r'.join(ids),'species':9606,'required_score':score,'add_nodes':0,
                'network_type':kind,'caller_identity':'gout_network_pharmacology_local_research'}
        request(name,stable+'/api/tsv/network',params)
    print(json.dumps({'version':version[0],'input_genes':len(primary),'mapped_genes':len(accepted),
         'unmapped_or_conflicting':len(audit)-len(accepted),'combined_mapping_inputs':len(mapping_inputs)},ensure_ascii=False))

def analyze():
    import networkx as nx
    primary,strict,ref,gene_info,mapping_inputs=inputs()
    audit=read(OUT/'STRING_397基因映射审计.csv')
    bysid={r['string_id']:r['gene_symbol'] for r in audit if r['string_id']};assert len(bysid)>300
    mapped=set(bysid.values()); sens=mapped&set(strict)
    def edges(name,threshold):
        raw=read(API/name,'\t');seen={}; cleaned=[]
        for r in raw:
            a,b=r['stringId_A'],r['stringId_B'];assert a in bysid and b in bysid and a!=b
            assert r['ncbiTaxonId']=='9606' and Decimal(r['score'])>=Decimal(str(threshold))
            key=tuple(sorted((a,b)))
            if key in seen:
                # Opposite orientations must carry identical undirected scores.
                assert all(r[k]==seen[key][k] for k in ('score','nscore','fscore','pscore','ascore','escore','dscore','tscore'))
                continue
            seen[key]=r
            z={'gene_A':bysid[key[0]],'gene_B':bysid[key[1]],'stringId_A':key[0],'stringId_B':key[1],
                'score':float(r['score']),'nscore':float(r['nscore']),'fscore':float(r['fscore']),
                'pscore':float(r['pscore']),'ascore':float(r['ascore']),'escore':float(r['escore']),
                'dscore':float(r['dscore']),'tscore':float(r['tscore'])}
            cleaned.append(z)
        return sorted(cleaned,key=lambda r:(r['gene_A'],r['gene_B']))
    medium=edges('functional_400.tsv',0.4)
    high=[r for r in medium if r['score']>=0.7]
    physical=edges('physical_700.tsv',0.7)
    supported=[r for r in high if r['escore']>=0.7 or r['dscore']>=0.7]
    definitions=[('primary_functional_700',mapped,high),('sensitivity366_functional_700',sens,
        [r for r in high if r['gene_A'] in sens and r['gene_B'] in sens]),
        ('primary_functional_400',mapped,medium),('primary_physical_700',mapped,physical),
        ('functional700_exp_or_database700',mapped,supported)]
    summaries=[];metrics=[]; graphs={}
    for code,nodes,ee in definitions:
        g=nx.Graph();g.add_nodes_from(sorted(nodes))
        for r in ee:g.add_edge(r['gene_A'],r['gene_B'],weight=r['score'])
        assert g.number_of_edges()==len(ee) and set(g.nodes())==nodes
        graphs[code]=g
        comp=sorted(nx.connected_components(g),key=lambda c:(-len(c),min(c)))
        between=nx.betweenness_centrality(g,normalized=True,weight=None)
        close=nx.closeness_centrality(g,wf_improved=True)
        core=nx.core_number(g);cluster=nx.clustering(g)
        communities=nx.community.greedy_modularity_communities(g,weight='weight') if g.number_of_edges() else [frozenset([v]) for v in sorted(nodes)]
        community={v:i+1 for i,c in enumerate(communities) for v in c}
        ordered=sorted(nodes,key=lambda v:(-g.degree(v),-between[v],v))
        for rank,v in enumerate(ordered,1):
            metrics.append({'network':code,'gene_symbol':v,'degree':g.degree(v),'degree_rank':rank,
                'degree_centrality':g.degree(v)/(len(nodes)-1),'betweenness_centrality':between[v],
                'closeness_centrality_wf':close[v],'clustering_coefficient':cluster[v],'k_core':core[v],
                'weighted_strength':g.degree(v,weight='weight'),'community_id':community[v],
                'in_sensitivity_366':int(v in strict)})
        summaries.append({'network':code,'mapped_nodes':len(nodes),'edges':g.number_of_edges(),
            'isolated_nodes':len(list(nx.isolates(g))),'connected_components':len(comp),'largest_component_nodes':len(comp[0]),
            'density':nx.density(g),'mean_degree':2*g.number_of_edges()/len(nodes),
            'average_clustering':nx.average_clustering(g),'weighted_modularity':nx.community.modularity(g,communities,weight='weight') if ee else None,
            'description':'undirected induced associations; isolated mapped nodes retained; unweighted shortest-path metrics'})
    write('PPI_网络统计.csv',summaries);write('PPI_全部网络节点指标.csv',metrics)
    write('PPI_397主分析_节点指标.csv',[r for r in metrics if r['network']=='primary_functional_700'])
    write('PPI_366敏感性_节点指标.csv',[r for r in metrics if r['network']=='sensitivity366_functional_700'])
    edgefields=['gene_A','gene_B','stringId_A','stringId_B','score','nscore','fscore','pscore','ascore','escore','dscore','tscore']
    for name,data in [('PPI_功能关联400_边表.csv',medium),('PPI_功能关联700_主边表.csv',high),
                      ('PPI_物理关联700_边表.csv',physical),('PPI_实验或数据库通道700_边表.csv',supported)]:write(name,data,edgefields)
    mainmetrics=[r for r in metrics if r['network']=='primary_functional_700']
    sm={r['gene_symbol']:r for r in metrics if r['network']=='sensitivity366_functional_700'}
    comparison=[]
    for r in mainmetrics:
        s=sm.get(r['gene_symbol'])
        comparison.append({'gene_symbol':r['gene_symbol'],'primary_degree':r['degree'],'primary_rank':r['degree_rank'],
            'primary_betweenness':r['betweenness_centrality'],'present_in_strict_input':int(r['gene_symbol'] in strict),
            'strict_degree':s['degree'] if s else None,'strict_rank':s['degree_rank'] if s else None,
            'strict_betweenness':s['betweenness_centrality'] if s else None})
    write('PPI_拓扑排名敏感性.csv',comparison)
    write('PPI_主网络前20拓扑候选.csv',mainmetrics[:20])
    outputs=[fileinfo(p) for p in OUT.iterdir() if p.is_file() and p.suffix=='.csv']
    data={'species':9606,'string_version':load(OUT/'STRING版本.json'),'input_genes':397,'strict_input_genes':366,
        'mapped_genes':len(mapped),'strict_mapped_genes':len(sens),'mapping_quarantined':397-len(mapped),
        'network_summaries':summaries,'top20_degree_candidates':[r['gene_symbol'] for r in mainmetrics[:20]],
        'primary_top20_retained_in_strict':len(set(r['gene_symbol'] for r in mainmetrics[:20])&set(sm)),
        'top20_overlap_primary_strict':len(set(r['gene_symbol'] for r in mainmetrics[:20])&set(sorted(sm,key=lambda v:(sm[v]['degree_rank'],v))[:20])),
        'centrality_metrics_are_not_causal_target_validation':True,'unmapped_are_not_isolates':True,
        'input_files':load(OUT/'分析参数与口径.json')['source_files'],
        'http_responses':[fileinfo(p) for p in API.iterdir() if p.is_file()],
        'software':{'python':sys.version,'networkx':nx.__version__},'files':outputs,'script':fileinfo(Path(__file__))}
    for item in data['input_files']:assert sha(BASE/item['path'])==item['sha256']
    dump(OUT/'PPI分析核验.json',data)
    print(json.dumps({k:data[k] for k in ['string_version','input_genes','mapped_genes','strict_mapped_genes','mapping_quarantined','network_summaries','top20_degree_candidates']},ensure_ascii=False))

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'prepare'
    if mode=='prepare':
        p,s,r,g,m=inputs();print(json.dumps({'primary':len(p),'strict':len(s),'mapping_query_inputs':len(m)},ensure_ascii=False))
    elif mode=='fetch':fetch()
    elif mode=='analyze':analyze()
    else:raise SystemExit('prepare/fetch/analyze')
