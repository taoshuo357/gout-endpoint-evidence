"""Append-only four-chain Curveball sensitivity analysis after autocorrelation audit."""
from pathlib import Path
import os,sys,time,json,csv,hashlib,math,concurrent.futures
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
BASE=Path(__file__).resolve().parent;ROOT=BASE/'全面验证_2026-11-02';OUT=ROOT/'03_匹配背景与置换'
sys.path.insert(0,str(BASE/'runtime/ppi_analysis_libraries'))
import numpy as np,pandas as pd
from scipy.stats import rankdata,norm,false_discovery_control
SEEDS=[2026110201,2026110202,2026110203,2026110204]
BURN=10000;THIN=1000;BENCH=100000
ORIGINAL=['计算前合同.json','基因网络_全部29997随机结果.tsv','成分网络_全部1000随机结果.tsv','匹配分层与强制保留核对.tsv','全部九项统计与BH.tsv','实际结果摘要.json','置换混合核查.json']
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def dump(name,data): (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2,default=lambda x:int(x) if isinstance(x,np.integer) else float(x) if isinstance(x,np.floating) else str(x)),encoding='utf-8')
def write(name,rows):
 rows=list(rows)
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
def load_matrix():
 q=pd.read_csv(BASE/'生信扩展_2026-11-02/结果表/Network_104乘12_全部候选关联.tsv',sep='\t')
 compounds=q.compound_id.drop_duplicates().tolist();genes=q.gene.drop_duplicates().tolist()
 Q=q.pivot(index='compound_id',columns='gene',values='recorded_edge').reindex(index=compounds,columns=genes).to_numpy(np.int16)
 assert Q.shape==(104,12) and np.array_equal(Q,q.recorded_edge.to_numpy(np.int16).reshape(104,12))
 return Q
def trade(sets,rng,n):
 changed=0
 for _ in range(n):
  a,b=rng.choice(104,2,replace=False);common=sets[a]&sets[b];x=sets[a]-common;y=sets[b]-common
  if not x or not y:continue
  pool=list(x|y);rng.shuffle(pool);sets[a]=common|set(pool[:len(x)]);sets[b]=common|set(pool[len(x):]);changed+=1
 return changed
def metrics(M,rowdeg):
 overlap=M@M.T;u=rowdeg[:,None]+rowdeg[None,:]-overlap
 v=u[np.triu_indices(104,1)];g=(u-np.maximum(rowdeg[:,None],rowdeg[None,:]))[np.triu_indices(104,1)]
 return np.array([v.max(),np.count_nonzero(v>=8),g.max()],float)
def worker(job):
 chain,seed,n,Q=job;start=time.perf_counter()
 rd=Q.sum(1);cd=Q.sum(0);sets=[set(np.flatnonzero(r)) for r in Q];rng=np.random.default_rng(seed)
 nchange=trade(sets,rng,BURN);draws=np.empty((n,3));hashes=[]
 for i in range(n):
  nchange+=trade(sets,rng,THIN);m=np.zeros_like(Q)
  for r,s in enumerate(sets):m[r,list(s)]=1
  assert np.array_equal(m.sum(1),rd) and np.array_equal(m.sum(0),cd)
  hashes.append(hashlib.sha256(m.tobytes()).hexdigest());draws[i]=metrics(m,rd)
 print('CHAIN_FINISHED',chain,'seed',seed,'saved_draws',n,'seconds',round(time.perf_counter()-start,2),flush=True)
 return {'chain':chain,'seed':seed,'draws':draws,'hashes':hashes,'attempted_trades':BURN+n*THIN,'nontrivial_trades':nchange,'all_row_column_degrees_exact':True,'seconds':time.perf_counter()-start}
def autocorr_ess(y):
 y=np.asarray(y,float);n=len(y);z=y-y.mean()
 if np.all(z==0):return {'lag1':None,'ESS':None,'tau':None,'reason':'Constant diagnostic statistic; mixing not inferable from it.'}
 nfft=1<<(2*n-1).bit_length();f=np.fft.rfft(z,n=nfft);acov=np.fft.irfft(f*np.conjugate(f),n=nfft)[:n]/n;rho=acov/acov[0]
 pairs=[];previous=np.inf
 for k in range(0,n-1,2):
  pair=float(rho[k]+rho[k+1])
  if pair<=0:break
  pair=min(previous,pair);pairs.append(pair);previous=pair
 tau=max(1.,-1+2*sum(pairs));ess=min(float(n),n/tau)
 return {'lag1':float(rho[1]),'ESS':float(ess),'tau':float(tau),'positive_monotone_pairs':len(pairs),'method':'FFT biased ACF; Geyer initial-positive, monotonized paired autocorrelations; ESS capped at saved chain length.'}
def split_rhat(chains):
 a=np.asarray(chains,float);m,n=a.shape;half=n//2
 split=np.concatenate([a[:,:half],a[:,n-half:]],axis=0)
 W=float(np.var(split,axis=1,ddof=1).mean());B=float(half*np.var(split.mean(axis=1),ddof=1))
 if W==0:return None if B==0 else float('inf')
 return float(np.sqrt(((half-1)/half*W+B/half)/W))
def normalized_split_rhat(a):
 z=norm.ppf((rankdata(np.asarray(a).ravel(),method='average')-.375)/(np.size(a)+.25)).reshape(np.shape(a))
 folded=np.abs(a-np.median(a));zf=norm.ppf((rankdata(folded.ravel(),method='average')-.375)/(np.size(a)+.25)).reshape(np.shape(a))
 r=split_rhat(z);rf=split_rhat(zf)
 return {'rank_normalized_split_Rhat':r,'rank_folded_split_Rhat':rf,'rank_or_folded_max_Rhat':max(v for v in [r,rf] if v is not None) if any(v is not None for v in [r,rf]) else None}
def main():
 if (OUT/'Curveball_4链_全部九项统计与BH.tsv').exists():raise FileExistsError('Append-only final files already exist; do not overwrite.')
 before={n:sha(OUT/n) for n in ORIGINAL}
 trigger=json.loads((ROOT/'独立复核_03与05.json').read_text(encoding='utf-8'))
 olddiag=trigger['checks']['03_BH9_independently_recomputed']['details']['mixing_diagnostics_not_proof_of_uniform_convergence']
 contract={'reason':'Triggered by independent mixing audit (lag1=.537 for pairs_union_ge8), not by changing observed statistics or redefining hypotheses.','retain_all_original_files':True,'seeds':SEEDS,'chains':4,'burn_attempted_trades':BURN,'thin_attempted_trades':THIN,'default_draws_per_chain':2500,'fallback_draws_per_chain':1000,'fallback_rule':'Only if trade-only benchmark predicts more than480sec wall under four workers with2x safety allowance. No metric or significance computed before sample size fixed.','original_gene_P_values':'Retain exactly six gene-network P values from existing9999-draw analyses.','updated_family':'Same6 gene-network + same3 compound metrics, BH9; no favorable metric removed.','null':'Uniform-stationary-target Curveball trade proposal over fixed binary104x12 row/column degrees. Correct margins and favorable diagnostics do not prove uniform convergence.','limits':['Dependent-chain approximate Monte Carlo tail P, not10000 formally independent permutations.','Same observed qualified associations; no synergy, causal activity or independent biological validation.'],'original_mixing_diagnostics':olddiag}
 dump('Curveball_4链_追加合同_性能决策前.json',contract)
 Q=load_matrix();sets=[set(np.flatnonzero(r)) for r in Q];rng=np.random.default_rng(920261102)
 t=time.perf_counter();changes=trade(sets,rng,BENCH);elapsed=time.perf_counter()-t
 estimated=elapsed/BENCH*(BURN+2500*THIN)*2
 n=2500 if estimated<=480 else 1000
 dump('Curveball_4链_性能基准.json',{'benchmark_attempts':BENCH,'seconds':elapsed,'nontrivial_trades':changes,'no_metrics_or_P_values_computed':True,'predicted_4worker_wall_seconds_with2x_safety_for2500_each':estimated,'fixed_draws_per_chain':n,'selection_determined_only_by_runtime':True})
 contract['fixed_draws_per_chain']=n;contract['fixed_total_draws']=4*n;contract['benchmark_elapsed_seconds']=elapsed
 dump('Curveball_4链_追加合同_冻结执行版.json',contract)
 print('FIXED_DESIGN','draws_per_chain',n,'total',4*n,'benchmark_seconds',round(elapsed,3),'estimated_wall',round(estimated,2),flush=True)
 start=time.perf_counter()
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:chains=list(pool.map(worker,[(i+1,seed,n,Q) for i,seed in enumerate(SEEDS)]))
 pooled=np.concatenate([r['draws'] for r in chains],axis=0);observed=metrics(Q,Q.sum(1));total=4*n
 raw=[]
 for c in chains:
  for i,vals in enumerate(c['draws']):raw.append({'chain':c['chain'],'draw':i+1,'maximum_union':vals[0],'pairs_union_ge8':vals[1],'maximum_gain':vals[2],'seed':c['seed']})
 write('Curveball_4链_全部随机结果.tsv',raw)
 original=pd.read_csv(OUT/'全部九项统计与BH.tsv',sep='\t')
 metric_names=['Maximum pair candidate union','Pairs covering >=8 candidates','Maximum gain over better single']
 fields=['maximum_union','pairs_union_ge8','maximum_gain'];diags=[];diag_summary=[];newP=[]
 for k,metric in enumerate(metric_names):
  xx=np.vstack([c['draws'][:,k] for c in chains]);stat_rhat=split_rhat(xx);rr=normalized_split_rhat(xx);parts=[];eventparts=[]
  for ci,c in enumerate(chains):
   d=autocorr_ess(xx[ci]);event=autocorr_ess((xx[ci]>=observed[k]).astype(float));parts.append(d);eventparts.append(event)
   diags.append({'metric':metric,'statistic_key':fields[k],'chain':ci+1,'seed':c['seed'],'draws':n,'mean':float(xx[ci].mean()),'null_q025':float(np.quantile(xx[ci],.025)),'null_q975':float(np.quantile(xx[ci],.975)),'lag1':d['lag1'],'ESS':d['ESS'],'tail_indicator_ESS':event['ESS'],'exceedances':int(sum(xx[ci]>=observed[k])),'split_Rhat':stat_rhat,**rr})
  ess=sum(d['ESS'] for d in parts if d['ESS'] is not None);tailess=sum(d['ESS'] for d in eventparts if d['ESS'] is not None)
  count=int(np.count_nonzero(pooled[:,k]>=observed[k]));p=(1+count)/(total+1);newP.append(p)
  mcse=float(np.sqrt((count/total)*(1-count/total)/tailess)) if tailess>0 else None
  diag_summary.append({'metric':metric,'statistic_key':fields[k],'observed':float(observed[k]),'draws':total,'exceedances':count,'upper_tail_P_plus1':p,'pooled_mean':float(pooled[:,k].mean()),'null_median':float(np.median(pooled[:,k])),'null_q025':float(np.quantile(pooled[:,k],.025)),'null_q975':float(np.quantile(pooled[:,k],.975)),'lag1_per_chain':[d['lag1'] for d in parts],'ESS_sum_independent_chains':ess,'tail_indicator_ESS_sum':tailess,'tail_MCSE_approximate':mcse,'split_Rhat':stat_rhat,**rr})
 write('Curveball_4链_混合诊断.tsv',diags)
 updated=original.to_dict('records')
 for row in updated:
  if row['family']=='Bipartite exact-degree Curveball':
   k=metric_names.index(row['metric']);row.update({'observed':float(observed[k]),'null_median':float(np.median(pooled[:,k])),'null_q025':float(np.quantile(pooled[:,k],.025)),'null_q975':float(np.quantile(pooled[:,k],.975)),'upper_tail_p':newP[k],'draws':total})
 pvals=np.array([r['upper_tail_p'] for r in updated]);qvals=false_discovery_control(pvals,method='bh')
 # Independent direct BH formula, as a second implementation.
 order=np.argsort(pvals);q2=np.empty(9);q2[order]=np.minimum.accumulate((pvals[order]*9/np.arange(1,10))[::-1])[::-1].clip(0,1)
 assert np.allclose(qvals,q2,rtol=1e-14,atol=1e-15)
 for row,qv in zip(updated,qvals):row['BH9']=float(qv)
 write('Curveball_4链_全部九项统计与BH.tsv',updated)
 compare=[]
 for i,row in enumerate(updated):
  compare.append({'family':row['family'],'metric':row['metric'],'observed':row['observed'],'original_draws':int(original.iloc[i].draws),'updated_draws':row['draws'],'original_P':float(original.iloc[i].upper_tail_p),'updated_P':row['upper_tail_p'],'original_BH9':float(original.iloc[i].BH9),'updated_BH9':row['BH9'],'same_9_hypotheses':True})
 write('Curveball_4链_新旧对照.tsv',compare)
 after={name:sha(OUT/name) for name in ORIGINAL}
 assert before==after and len(raw)==total and all(c['all_row_column_degrees_exact'] for c in chains)
 summary={'status':'COMPUTED_APPEND_ONLY','trigger':'Original1000-sample chain lag1≈0.537 for pairs_union_ge8','draws_per_chain_fixed_before_metrics':n,'chains':4,'total_saved_draws':total,'seeds':SEEDS,'burn_attempted_trades':BURN,'thin_attempted_trades':THIN,'wall_seconds':time.perf_counter()-start,'all_original_SHA256_unchanged':True,'original_files_SHA256':before,'all10000_or4000_saved_margins_exact':True,'zero_degree_compounds_retained':int(sum(Q.sum(1)==0)),'distinct_sampled_matrices_all_chains':len(set(h for c in chains for h in c['hashes'])),'per_chain':[{'chain':c['chain'],'seed':c['seed'],'saved_draws':n,'unique_matrices':len(set(c['hashes'])),'attempted_trades':c['attempted_trades'],'nontrivial_trades':c['nontrivial_trades'],'seconds':c['seconds']} for c in chains],'diagnostics':diag_summary,'updated_nine_tests':updated,'new_vs_original':compare,'BH_checked_scipy_and_direct_formula':True,'interpretation':'Four independently seeded chains with stronger thinning improve diagnostic credibility. ESS and split Rhat describe these three monitored metrics only; they cannot prove uniform stationary sampling. Report approximate dependent-chain Monte Carlo tails, not guaranteed independent randomizations. Network union coverage does not demonstrate drug synergy.'}
 dump('Curveball_4链_汇总.json',summary)
 manifest=[]
 for p in sorted(OUT.glob('Curveball_4链_*')):
  if p.is_file() and p.name!='Curveball_4链_SHA256.json':manifest.append({'filename':p.name,'bytes':p.stat().st_size,'sha256':sha(p)})
 dump('Curveball_4链_SHA256.json',manifest)
 print(json.dumps({'status':summary['status'],'draws_per_chain':n,'total':total,'wall_seconds':summary['wall_seconds'],'diagnostics':diag_summary,'updated_nine_tests':updated,'original_files_unchanged':before==after},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
