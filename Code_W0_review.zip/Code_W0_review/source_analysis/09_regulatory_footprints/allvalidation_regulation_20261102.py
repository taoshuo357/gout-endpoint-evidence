"""CollecTRI signed ULM activity and LIANA-consensus coexpression potentials.
No cell-level phase tests; all six admissible patient pairings retained."""
from allvalidation_common_20261102 import *
import numpy as np,pandas as pd,itertools,gc
from scipy import sparse
from scipy.stats import t as tdist
P=ROOT/'05_调控与通讯';P.mkdir(exist_ok=True)
SC=BASE/'论文推进_2026-10-30/单细胞定位';RES=SC/'结果表'
samples=['A1','A2','A3','B1','B2','B3']
man=pd.read_csv(RES/'细胞类型pseudobulk输入清单.csv')
types=man[(man.eligible_all6_ge30_cells)&(~man.cell_type.isin(['Platelet mixed','Unresolved']))].cell_type.tolist()
assert len(types)==8
dump(P/'计算前合同.json',{'data':'GSE211783 frozen QC and conservative annotations','libraries':6,'patients':3,'celltypes_primary':types,'replicate_unit':'library with all six unknown crosswalk pairings; never individual cells','TF_resource':'OmniPath CollecTRI downloaded 2026-11-02; ambiguous signs and multi-TF complexes excluded','TF_method':'Custom vectorized signed ULM t statistic, intercept, gene-centered TMM log2CPM across six libraries within each type; >=5 measurable targets; all measured genes with nonregulon weight0','TF_testing':'worst two-sided paired t P across all6 pairings, BH all eligible TF x type tests','LR_resource':'All LIANA consensus 4620 rows before dedup/mapping','LR_score':'sqrt(min subunit mean CP10k ligand * min subunit mean CP10k receptor); both minimum subunit detection fractions>=0.10; autocrine included','LR_testing':'All LR x sender x receiver expressed >=10% in every library are tested with worst-P across six pairings, BH across complete eligible family; no cell-label permutation or CellChat p claim','limits':['TF scores are regulon associations, not measured biochemical activation.','LR coexpression is signalling potential, not observed cell contact, protein secretion or causal communication.','Unknown A-B crosswalk; 3 patients only.','No formula treatment in these data; mixed platelet class excluded from phase testing.','GSE217561 reuses three current libraries and cannot be considered independent validation.']})
def phase_stats(x):
    # x=tests x six libraries
    ds=[x[:,:3]-x[:,3+np.array(p)] for p in itertools.permutations(range(3))]
    means=np.mean(ds,axis=2)
    ps=[]
    for d in ds:
        m=d.mean(1);sd=d.std(1,ddof=1);se=sd/np.sqrt(3)
        tt=np.divide(np.abs(m),se,out=np.full_like(m,np.inf),where=se>1e-15)
        pp=2*tdist.sf(tt,2);pp[(se<=1e-15)&(np.abs(m)<=1e-15)]=1
        ps.append(pp)
    pp=np.array(ps)
    return means.mean(0),pp.max(0),pp.min(0),pp

# TF regulons. Keep mono-symbol entries, including monomer-labelled complexes;
# never split a multi-TF complex into fictitious independent TFs.
raw=pd.read_csv(P/'collectri.tsv',sep='\t')
single=raw.source_genesymbol.str.fullmatch(r'[A-Za-z0-9-]+')&raw.target_genesymbol.str.fullmatch(r'[A-Za-z0-9-]+')
signed=raw.is_stimulation.astype(bool)^raw.is_inhibition.astype(bool)
reg=raw[single&signed&raw.is_directed.astype(bool)].copy()
reg['weight']=np.where(reg.is_stimulation,1.,-1.)
reg=reg[['source_genesymbol','target_genesymbol','weight']].drop_duplicates()
conflict=reg.groupby(['source_genesymbol','target_genesymbol']).weight.nunique()
bad=set(conflict[conflict>1].index)
reg=reg[[((a,b) not in bad) for a,b in zip(reg.source_genesymbol,reg.target_genesymbol)]]
reg.to_csv(P/'CollecTRI_实际单TF有向有符号网络.tsv',sep='\t',index=False)
reggroups={tf:g for tf,g in reg.groupby('source_genesymbol')}
cover=[];act=[];testrows=[];allps=[]
for typ in types:
    stem=man.set_index('cell_type').loc[typ,'file_stem']
    d=pd.read_csv(RES/'细胞类型pseudobulk'/(stem+'_TMM_logCPM.csv'))
    # Duplicated symbols: deterministic median on already transformed pseudobulk.
    d=d[d.gene_symbol.notna()&d.gene_symbol.ne('')]
    expr=d.groupby('gene_symbol')[samples].median()
    y=expr.to_numpy(float);y=y-y.mean(axis=1,keepdims=True)
    n=len(y);sy=y.sum(0);syy=(y*y).sum(0)
    local=[];names=[];ns=[]
    index={g:i for i,g in enumerate(expr.index)}
    for tf,g in reggroups.items():
        keep=g[g.target_genesymbol.isin(index)]
        nt=len(keep)
        cover.append({'cell_type':typ,'TF':tf,'resource_target_count':len(g),'measured_target_count':nt,'eligible_ge5':nt>=5,'measured_genes':n})
        if nt<5:continue
        w=np.zeros(n);w[[index[t] for t in keep.target_genesymbol]]=keep.weight
        sw=w.sum();sxx=w@w-sw*sw/n
        if sxx<=0:continue
        sxy=w@y-sw*sy/n
        beta=sxy/sxx
        sse=np.maximum(syy-sy*sy/n-sxy*sxy/sxx,1e-20)
        stat=beta/np.sqrt(sse/(n-2)/sxx)
        local.append(stat);names.append(tf);ns.append(nt)
    a=np.array(local);delta,pmax,pmin,pp=phase_stats(a)
    for i,tf in enumerate(names):
        for j,s in enumerate(samples):act.append({'cell_type':typ,'TF':tf,'sample_id':s,'phase':'Acute' if s[0]=='A' else 'Remission','ULM_t_activity':a[i,j],'measured_regulon_targets':ns[i]})
        row={'cell_type':typ,'TF':tf,'measured_regulon_targets':ns[i],'acute_minus_remission_activity':delta[i],'worst_pairing_P':pmax[i],'best_pairing_P':pmin[i]}
        for k in range(6):row['pairing_'+str(k+1)+'_P']=pp[k,i]
        testrows.append(row);allps.append(pmax[i])
    print('TF_done',typ,len(names),flush=True)
q=bh(allps)
for r,v in zip(testrows,q):r['BH_all_TF_celltype']=float(v)
write(P/'TF_全调控子覆盖.tsv',cover);write(P/'TF_全部逐文库活性.tsv',act);write(P/'TF_全部细胞类型阶段检验.tsv',testrows)
dump(P/'TF_资源清洗审计.json',{'raw_edges':len(raw),'source_names':raw.source_genesymbol.nunique(),'multi_symbol_or_invalid_rows_removed':int((~single).sum()),'sign_ambiguous_rows_removed':int((~signed).sum()),'conflicting_unique_pairs_removed':len(bad),'retained_edges':len(reg),'retained_TFs':reg.source_genesymbol.nunique(),'tested_TF_celltype_pairs':len(testrows),'worst_pairing_BH_significant':int((q<.05).sum())})

# All public LR pairs and complete complex membership.
lr=pd.read_csv(P/'liana_resource.csv')
lr=lr[lr.resource.eq('consensus')][['source_genesymbol','target_genesymbol']].drop_duplicates().rename(columns={'source_genesymbol':'ligand','target_genesymbol':'receptor'})
lr['pair_id']=lr.ligand+' -> '+lr.receptor
lr.to_csv(P/'LR_完整consensus输入.tsv',sep='\t',index=False)
needed=sorted(set('_'.join(lr.ligand.tolist()+lr.receptor.tolist()).split('_')))
feat=pd.read_csv(BASE/'GEO表达核验_2026-10-29/独立队列_GSE211783/预处理/人类基因特征.csv')
obs=pd.read_csv(RES/'全部QC细胞_最终保守注释.csv.gz')
old=pd.read_csv(SC/'预处理/全部QC细胞_元数据.csv.gz')
assert np.array_equal(obs.cell_id,old.cell_id)
present=[g for g in needed if g in set(feat.source_symbol)]
ixmap={g:i for i,g in enumerate(present)}
rr=[];cc=[]
for i,g in enumerate(feat.source_symbol):
    if g in ixmap:rr.append(i);cc.append(ixmap[g])
mapper=sparse.csr_matrix((np.ones(len(rr),np.int32),(rr,cc)),shape=(len(feat),len(present)))
means=np.zeros((6,len(types),len(present)));fracs=np.zeros_like(means);counts=np.zeros((6,len(types)),int)
exprrows=[];qc=[]
for si,s in enumerate(samples):
    sub=obs[obs.sample_id.eq(s)]
    mat=sparse.load_npz(SC/'预处理'/(s+'_QC_counts.npz'))
    assert mat.shape==(len(sub),len(feat))
    totals=np.asarray(mat.sum(1)).ravel()
    assert np.array_equal(totals,sub.UMI.to_numpy())
    x=(mat@mapper).tocsr();del mat;gc.collect()
    for ti,typ in enumerate(types):
        ix=np.flatnonzero(sub.cell_type.eq(typ).to_numpy());counts[si,ti]=len(ix)
        a=x[ix];f=np.asarray((a>0).mean(0)).ravel()
        norm=sparse.diags(10000/totals[ix])@a
        m=np.asarray(norm.mean(0)).ravel();means[si,ti]=m;fracs[si,ti]=f
        qc.append({'sample_id':s,'cell_type':typ,'n_cells':len(ix),'all6_ge30':True})
        for j,g in enumerate(present):exprrows.append({'sample_id':s,'cell_type':typ,'gene':g,'mean_CP10k':m[j],'fraction_detected':f[j],'n_cells':len(ix)})
    del x;gc.collect();print('LR_aggregate',s,flush=True)
pd.DataFrame(exprrows).to_csv(P/'LR_全部亚基逐文库细胞类型表达.tsv.gz',sep='\t',index=False,compression='gzip')
write(P/'LR_文库细胞数核对.tsv',qc)
pairs=lr.to_dict('records');valid=[];mapping=[]
for i,r in enumerate(pairs):
    lig=r['ligand'].split('_');rec=r['receptor'].split('_')
    missing=[g for g in lig+rec if g not in ixmap]
    mapping.append({**r,'all_subunits_mapped':not bool(missing),'missing_subunits':';'.join(missing)})
    if not missing:valid.append(i)
write(P/'LR_全部复合物映射审计.tsv',mapping)
mapped=[pairs[i] for i in valid];n=len(mapped)
lm=np.zeros((6,len(types),n));rm=lm.copy();lf=lm.copy();rf=lm.copy()
for k,r in enumerate(mapped):
    li=[ixmap[g] for g in r['ligand'].split('_')];ri=[ixmap[g] for g in r['receptor'].split('_')]
    lm[:,:,k]=means[:,:,li].min(2);rm[:,:,k]=means[:,:,ri].min(2)
    lf[:,:,k]=fracs[:,:,li].min(2);rf[:,:,k]=fracs[:,:,ri].min(2)
# Array dimensions send x receiver x LR x sample.
scores=np.zeros((len(types),len(types),n,6));passes=np.zeros_like(scores,dtype=bool)
for a in range(len(types)):
 for b in range(len(types)):
    v=np.sqrt(lm[:,a]*rm[:,b]);ok=(lf[:,a]>=.1)&(rf[:,b]>=.1)
    scores[a,b]=(v*ok).T;passes[a,b]=ok.T
np.savez_compressed(P/'LR_完整评分数组.npz',scores=scores,passes=passes,means=means,fracs=fracs,types=np.array(types),samples=np.array(samples),pairs=np.array([r['pair_id'] for r in mapped]),genes=np.array(present))
# All 6 library scores for every mapped LR x 64 directed type pair, gzip table.
allrows=[];tested=[];ids=[]
for a,source in enumerate(types):
 for b,target in enumerate(types):
    mat=scores[a,b];log=np.log1p(mat)
    eligible=passes[a,b].all(1)
    inds=np.flatnonzero(eligible)
    delta,pmax,pmin,pp=phase_stats(log[inds])
    for i,r in enumerate(mapped):
        row={'sender':source,'receiver':target,**r,'eligible_all6_detection_ge10pct':bool(eligible[i]),'library_detections':int(passes[a,b,i].sum())}
        for j,s in enumerate(samples):row[s]=mat[i,j]
        row['Acute_mean']=float(mat[i,:3].mean());row['Remission_mean']=float(mat[i,3:].mean())
        allrows.append(row)
    for k,i in enumerate(inds):
        r={'sender':source,'receiver':target,**mapped[i],'Acute_mean':float(mat[i,:3].mean()),'Remission_mean':float(mat[i,3:].mean()),'acute_minus_remission_log1p_score':delta[k],'worst_pairing_P':pmax[k],'best_pairing_P':pmin[k]}
        for j in range(6):r['pairing_'+str(j+1)+'_P']=pp[j,k]
        tested.append(r)
pd.DataFrame(allrows).to_csv(P/'LR_所有配体受体细胞类型组合_6文库.tsv.gz',sep='\t',index=False,compression='gzip')
if tested:
    q=bh([r['worst_pairing_P'] for r in tested])
    for r,v in zip(tested,q):r['BH_all_eligible_LR_typepairs']=float(v)
    write(P/'LR_全部合格文库级阶段检验.tsv',tested)
network=[]
for a,source in enumerate(types):
 for b,target in enumerate(types):
  for phase,sl in [('Acute',slice(0,3)),('Remission',slice(3,6))]:
   vals=scores[a,b,:,sl]
   network.append({'sender':source,'receiver':target,'phase':phase,'mean_total_score':float(vals.sum(0).mean()),'mean_detected_pairs':float((vals>0).sum(0).mean()),'libraries':3})
write(P/'LR_通讯潜力网络汇总.tsv',network)
summary={'cells':len(obs),'eligible_celltypes':types,'TF_tests':len(testrows),'TF_BH_significant':sum(r['BH_all_TF_celltype']<.05 for r in testrows),'LR_resource_unique_pairs':len(lr),'LR_allsubunit_mapped_pairs':len(mapped),'LR_mapped_genes':len(present),'LR_total_directed_typepair_hypotheses':len(allrows),'LR_all6_eligible_tests':len(tested),'LR_BH_significant':int((q<.05).sum()) if tested else 0,'raw_counts_totals_verified_all6':True,'resources_sha256':{k:sha(P/k) for k in ['collectri.tsv','liana_resource.csv']},'patient_pairing_verified':False}
dump(P/'实际结果摘要.json',summary);print(json.dumps(summary,ensure_ascii=False),flush=True)


