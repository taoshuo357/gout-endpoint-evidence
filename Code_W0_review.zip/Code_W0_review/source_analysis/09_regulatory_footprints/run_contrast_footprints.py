"""Official decoupler ULM contrast footprints; outcomes frozen before new analysis."""
from pathlib import Path
import sys,os,json,hashlib,platform,shutil,importlib.metadata,itertools,gc
E=Path(__file__).resolve().parents[1];assert E.drive.upper()=='E:'
G=Path('G:/痛风/第二步_靶点预测与疾病交集');O=E/'02_decoupler官方方法'
for p in reversed([E/'runtime/decoupler_libraries',G/'runtime/ppi_analysis_libraries',G/'论文推进_2026-10-30/单细胞定位/runtime']):sys.path.insert(0,str(p))
import numpy as np,pandas as pd
from scipy.stats import t as tdist,spearmanr

def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bh(p):
 p=np.asarray(p,float);assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all()
 idx=np.argsort(p,kind='mergesort');r=p[idx]*len(p)/np.arange(1,len(p)+1);r=np.minimum.accumulate(r[::-1])[::-1];out=np.empty_like(r);out[idx]=np.minimum(r,1);return out
SC=G/'论文推进_2026-10-30/单细胞定位/结果表';D=SC/'细胞类型pseudobulk'
manifest=pd.read_csv(SC/'细胞类型pseudobulk输入清单.csv')
manifest=manifest[manifest.eligible_all6_ge30_cells&~manifest.cell_type.isin(['Platelet mixed','Unresolved'])].copy();assert len(manifest)==8
PERMS=[''.join(map(str,p)) for p in itertools.permutations([1,2,3])]
netpath=G/'全面验证_2026-11-02/05_调控与通讯/CollecTRI_实际单TF有向有符号网络.tsv'
paths=[D/(r.file_stem+'_six_pairings_gene_tests.csv.gz') for r in manifest.itertuples()]
whole=G/'GEO表达核验_2026-10-29/独立队列_GSE211783/表达结果/六种可能配对_全基因QL结果.csv'
feature=G/'GEO表达核验_2026-10-29/独立队列_GSE211783/预处理/人类基因特征.csv'
contract={'date':'2026-11-02','status_at_write':'Before any real contrast ULM outcome','method':'decoupler2.3.1 public mt.ulm with tmin5; official private numerical function only extracts raw P and verifies public results','data':'GSE211783 same3patients/sixlibraries; old raw pseudobulk/edgeRQL outcomes reused, not new independent validation','primary_exploratory_context':'CD14 monocytes already selected in old analysis; post-original-result exploratory extension, not external preregistration','secondary_contexts':manifest.cell_type.tolist()+['Whole PBMC'],'all_pairing_maps':PERMS,'pairing_identity':'unverified; every mapping retained; no favorable mapping selection','gene_input':'all originally count-filtered finite genes, no P/FDR/absFC threshold','signed_statistic':'sign(logFC)*sqrt(F); explicitly signedQLsqrtF, not logFC/Wald or exact common-df t statistic','mapping':'existingcelltype gene_symbol; wholePBMC original feature gene_id/source_symbol; nonempty unambiguous ID mapping; duplicate symbols median signedQLsqrtF within every map, no outcome-based representative selection','network':'unchanged old monoTF/single-symbol/signed CollecTRI to keep comparison scope fixed; not a new full-resource download','n_samples':'3 patients,6 libraries; ULM regressions use genes as observations, so their conditional P/padj are not patient-level phase tests','background':'all input genes retained as features including nonnetwork genes with0weights; official empty/allzero columns removed','multiplicity':['official rowwiseTF BH','permap allTF across8types BH (wholePBMC separate)','permap CD14 TF family (official rowwise)','acrossall6maps and8types sensitivity','max P over6maps perTF/type thenBH reported as sensitivity only'],'old_vs_new':'old per-library gene-centered score phase delta and new contrast-footprint scores have different estimands; rank association descriptive only','calibration':'one synthetic independent OLS-vs-public/privateULM comparison before real ULM outcomes; no wet-lab or causal validation','source_inputs':[{'path':str(p),'sha256':sha(p)} for p in paths+[whole,feature,netpath]],'plotting':'no plots; root Python later'}
contract_path=O/'计算前冻结合同.json'
if contract_path.exists():
 old=json.loads(contract_path.read_text(encoding='utf-8-sig'));assert old==contract,'Do not change contract after outcome'
else:dump(contract_path,contract)
import decoupler as dc
from decoupler.mt._ulm import _func_ulm
from decoupler.pp.data import extract
from decoupler.pp.net import prune,adjmat
assert importlib.metadata.version('decoupler')=='2.3.1'
net=pd.read_csv(netpath,sep='\t').rename(columns={'source_genesymbol':'source','target_genesymbol':'target'})
assert not net.duplicated(['source','target']).any() and set(net.weight.unique())=={-1.,1.}
net.to_csv(O/'冻结CollecTRI_monoTF网络.tsv',sep='\t',index=False)

def score(data,network,tmin):
 public,officialq=dc.mt.ulm(data=data,net=network,tmin=tmin,verbose=False)
 mat,obs,genes=extract(data,raw=False,empty=True,shuffle=True,verbose=False)
 trimmed=prune(features=genes,net=network,tmin=tmin,verbose=False)
 names,returned,adj=adjmat(features=genes,net=trimmed,verbose=False)
 private,praw=_func_ulm(mat,adj,verbose=False)
 es=pd.DataFrame(private,index=obs,columns=names);pv=pd.DataFrame(praw,index=obs,columns=names)
 err=float(np.max(np.abs(public.loc[obs,names].to_numpy()-private)))
 qre=np.vstack([bh(row) for row in praw]);qerr=float(np.max(np.abs(officialq.loc[obs,names].to_numpy()-qre)))
 assert err<1e-10 and np.array_equal(officialq.loc[obs,names].to_numpy().astype(np.float32),qre.astype(np.float32)),(err,qerr)
 return es,pv,officialq,len(genes),trimmed,{'public_private_score_max_error':err,'public_BH_independent_BH_max_error':qerr,'public_BH_float32_equals_independent_BH_rounded_float32':True}

# Independent OLS toy: scores and analytical P use explicit least squares residuals.
rng=np.random.default_rng(20261102);toygenes=[f'G{i:02d}' for i in range(30)]
toy=pd.DataFrame(rng.normal(size=(3,30)),index=['Toy1','Toy2','Toy3'],columns=toygenes)
toynet=pd.DataFrame([{'source':tf,'target':toygenes[j],'weight':(-1 if j%3==0 else 1)} for tf,start in [('TF1',0),('TF2',10),('TF3',20)] for j in range(start,start+7)])
a,p,q,n,tr,chk=score(toy,toynet,5);re=[]
for row in toy.index:
 for tf in a.columns:
  xx=toynet[toynet.source.eq(tf)].set_index('target').weight.reindex(toy.columns,fill_value=0).to_numpy(float)
  yy=toy.loc[row].to_numpy(float);X=np.column_stack([np.ones(len(xx)),xx]);coef=np.linalg.lstsq(X,yy,rcond=None)[0];resid=yy-X@coef
  var=float(resid@resid/(len(xx)-2));se=np.sqrt(var*np.linalg.inv(X.T@X)[1,1]);tval=coef[1]/se;pv=2*tdist.sf(abs(tval),len(xx)-2)
  re.append({'contrast':row,'TF':tf,'official_score':float(a.loc[row,tf]),'independent_OLS_t':float(tval),'absolute_score_error':float(abs(a.loc[row,tf]-tval)),'official_rawP':float(p.loc[row,tf]),'independent_OLS_P':float(pv),'absolute_P_error':float(abs(p.loc[row,tf]-pv))})
qa=pd.DataFrame(re);assert qa.absolute_score_error.max()<1e-10 and qa.absolute_P_error.max()<1e-10
qa.to_csv(O/'Toy_官方ULM与独立OLS逐值核验.tsv',sep='\t',index=False)
dump(O/'Toy_实现核验.json',{'status':'PASS','cases':len(qa),'max_score_error':float(qa.absolute_score_error.max()),'max_P_error':float(qa.absolute_P_error.max()),**chk})

feat=pd.read_csv(feature);assert feat.gene_id.is_unique
mapdict=feat.set_index('gene_id').source_symbol
input_dir=O/'输入对照矩阵';input_dir.mkdir(exist_ok=True)
outputs=[];cover=[];sourceaudit=[]
contexts=[(r.cell_type,D/(r.file_stem+'_six_pairings_gene_tests.csv.gz')) for r in manifest.itertuples()]+[('Whole PBMC',whole)]
for typ,path in contexts:
 dd=pd.read_csv(path,dtype={'pairing_id':str})
 if 'gene_symbol' not in dd:dd['gene_symbol']=dd.gene_id.map(mapdict)
 assert set(dd.pairing_id.unique())==set(PERMS) and not dd.duplicated(['gene_id','pairing_id']).any()
 assert np.isfinite(dd[['logFC','F']].to_numpy()).all()
 negative=dd.F.lt(0)
 assert ((dd.loc[negative,'F']>=-1e-6)&dd.loc[negative,'PValue'].eq(1)).all(),'Substantive negative QL F must not be silently clipped'
 dd['F_for_signedQLsqrtF']=dd.F.clip(lower=0)
 dd['signedQLsqrtF']=np.sign(dd.logFC)*np.sqrt(dd.F_for_signedQLsqrtF)
 if negative.any():dd.loc[negative,['gene_id','gene_symbol','pairing_id','logFC','F','PValue','F_for_signedQLsqrtF','signedQLsqrtF']].to_csv(O/(typ.replace(' ','_').replace('/','_')+'_原QL数值负F归零明细.tsv'),sep='\t',index=False)
 dd['valid_symbol']=dd.gene_symbol.notna()&dd.gene_symbol.astype(str).str.strip().ne('')
 sourceaudit.append({'cell_type':typ,'raw_rows':len(dd),'tiny_negativeF_P1_clipped_to_zero_rows':int(negative.sum()),'unique_gene_ids':dd.gene_id.nunique(),'unmapped_rows':int((~dd.valid_symbol).sum()),'duplicate_symbol_gene_ids':int(dd[dd.valid_symbol].groupby('gene_symbol').gene_id.nunique().gt(1).sum())})
 good=dd[dd.valid_symbol].copy()
 inp=good.groupby(['pairing_id','gene_symbol'],sort=True).signedQLsqrtF.median().unstack('gene_symbol').reindex(PERMS)
 assert inp.notna().all().all()
 slug=typ.replace(' ','_').replace('/','_')
 inp.to_csv(input_dir/(slug+'_全部基因signedQLsqrtF.tsv.gz'),sep='\t',compression='gzip')
 good[['pairing_id','gene_id','gene_symbol','signedQLsqrtF']].to_csv(input_dir/(slug+'_特征到符号审计.tsv.gz'),sep='\t',index=False,compression='gzip')
 a,p,q,n,tr,chk=score(inp,net,5)
 tt=tr.groupby('source').target.nunique()
 for perm in PERMS:
  for tf in a.columns:
   outputs.append({'cell_type':typ,'pairing_id':perm,'TF':tf,'score_ULM_signedQLsqrtF':float(a.loc[perm,tf]),'official_ULM_rawP_gene_footprint':float(p.loc[perm,tf]),'official_BH_within_context_TFs':float(q.loc[perm,tf]),'background_genes':n,'regulon_targets_measured':int(tt.loc[tf]),'statistical_unit':'genes_in_conditional_footprint_model_NOT_independent_patients'})
 cover.append({'cell_type':typ,'input_symbols':len(inp.columns),'official_background_after_zero_column_removal':n,'TFs_ge5targets':len(a.columns),'network_edges_measured':len(tr),**chk})
 print('DONE',typ,'genes',n,'TFs',len(a.columns),'row_q05',[int(q.loc[x].lt(.05).sum()) for x in PERMS],flush=True)
 del dd,good,inp,a,p,q,tr;gc.collect()
res=pd.DataFrame(outputs)
res['BH_all8types_TFs_same_mapping']=np.nan
for perm in PERMS:
 ix=res.pairing_id.eq(perm)&res.cell_type.ne('Whole PBMC');res.loc[ix,'BH_all8types_TFs_same_mapping']=bh(res.loc[ix,'official_ULM_rawP_gene_footprint'].to_numpy())
res['BH_all8types_and_all6maps_sensitivity']=np.nan
ix=res.cell_type.ne('Whole PBMC');res.loc[ix,'BH_all8types_and_all6maps_sensitivity']=bh(res.loc[ix,'official_ULM_rawP_gene_footprint'].to_numpy())
res.to_csv(O/'全部9背景_六映射_官方ULM完整结果.tsv.gz',sep='\t',index=False,compression='gzip')
res[res.cell_type.eq('CD14 monocytes')].to_csv(O/'CD14_全部TF_六映射完整结果.tsv',sep='\t',index=False)
pd.DataFrame(cover).to_csv(O/'全部背景_覆盖与数值核验.tsv',sep='\t',index=False);pd.DataFrame(sourceaudit).to_csv(O/'基因符号与重复处理审计.tsv',sep='\t',index=False)
summary=[]
for (typ,tf),d in res.groupby(['cell_type','TF'],sort=True):
 assert len(d)==6
 v=d.score_ULM_signedQLsqrtF.to_numpy();signsame=bool((v>0).all() or (v<0).all())
 summary.append({'cell_type':typ,'TF':tf,'score_median':float(np.median(v)),'score_min':float(v.min()),'score_max':float(v.max()),'same_direction_all6':signsame,'direction':'Acute-associated positive footprint' if (v>0).all() else 'Remission-associated negative footprint' if (v<0).all() else 'mapping_sensitive','within_context_q05_maps':int(d.official_BH_within_context_TFs.lt(.05).sum()),'within_context_q_min':float(d.official_BH_within_context_TFs.min()),'within_context_q_max':float(d.official_BH_within_context_TFs.max()),'full8type_q05_maps':int(d.BH_all8types_TFs_same_mapping.lt(.05).sum()),'full8type_q_min':float(d.BH_all8types_TFs_same_mapping.min()) if typ!='Whole PBMC' else None,'full8type_q_max':float(d.BH_all8types_TFs_same_mapping.max()) if typ!='Whole PBMC' else None,'worst_mapping_rawP_sensitivity':float(d.official_ULM_rawP_gene_footprint.max()),'numbering_assumed_score':float(d.set_index('pairing_id').loc['123','score_ULM_signedQLsqrtF'])})
sumdf=pd.DataFrame(summary)
for contextname,ix in [('all8',sumdf.cell_type.ne('Whole PBMC')),('wholePBMC',sumdf.cell_type.eq('Whole PBMC'))]:sumdf.loc[ix,'BH_of_worstmapP_sensitivity']=bh(sumdf.loc[ix,'worst_mapping_rawP_sensitivity'].to_numpy())
sumdf.to_csv(O/'全部TF_跨映射方向与效应稳定性.tsv',sep='\t',index=False)
sumdf[sumdf.cell_type.eq('CD14 monocytes')].sort_values('score_median',key=abs,ascending=False).to_csv(O/'CD14_全部TF_跨映射稳定性.tsv',sep='\t',index=False)
# Both estimands use the same TF source resource but are not accuracy/validation comparisons.
oldpath=G/'全面验证_2026-11-02/05_调控与通讯/TF_全部细胞类型阶段检验.tsv'
old=pd.read_csv(oldpath,sep='\t');merge=sumdf.merge(old[['cell_type','TF','acute_minus_remission_activity','BH_all_TF_celltype']],on=['cell_type','TF'],how='left',validate='one_to_one')
merge.to_csv(O/'旧逐库分数差与新contrast足迹_描述性并列.tsv',sep='\t',index=False)
rows=[]
for typ,d in merge[merge.cell_type.ne('Whole PBMC')].groupby('cell_type'):
 finite=d.score_median.notna()&d.acute_minus_remission_activity.notna();rho=spearmanr(d.loc[finite,'score_median'],d.loc[finite,'acute_minus_remission_activity']).statistic
 rows.append({'cell_type':typ,'shared_TFs':int(finite.sum()),'Spearman_new_score_vs_old_delta':float(rho),'not_independent_validation':True,'different_estimands':True})
pd.DataFrame(rows).to_csv(O/'旧新TF方案_排序关联.tsv',sep='\t',index=False)
per=[]
for (typ,perm),d in res.groupby(['cell_type','pairing_id']):per.append({'cell_type':typ,'pairing_id':perm,'TFs':len(d),'nominal_footprint_P05':int(d.official_ULM_rawP_gene_footprint.lt(.05).sum()),'within_context_BH05':int(d.official_BH_within_context_TFs.lt(.05).sum()),'full8type_BH05':int(d.BH_all8types_TFs_same_mapping.lt(.05).sum()) if typ!='Whole PBMC' else None})
pd.DataFrame(per).to_csv(O/'全部背景与六映射_计数概况.tsv',sep='\t',index=False)
cd=sumdf[sumdf.cell_type.eq('CD14 monocytes')];main=sumdf[sumdf.cell_type.ne('Whole PBMC')]
result={'status':'COMPUTED_OFFICIAL_METHOD_WITH_LIMITATIONS','decoupler_version':importlib.metadata.version('decoupler'),'celltypes':8,'whole_PBMC_context':1,'pairing_maps':PERMS,'contrast_rows':len(res),'TF_celltype_pairs':len(main),'CD14_TFs':len(cd),'CD14_same_direction_all6':int(cd.same_direction_all6.sum()),'CD14_within_context_BH05_in_all6':int(cd.within_context_q05_maps.eq(6).sum()),'CD14_full8type_BH05_in_all6':int(cd.full8type_q05_maps.eq(6).sum()),'all8type_fullfamily_BH05_in_all6':int(main.full8type_q05_maps.eq(6).sum()),'all8type_BH_of_worstmapP05':int(main.BH_of_worstmapP_sensitivity.lt(.05).sum()),'old_new_rank_comparisons':rows,'input_contract_SHA256':sha(contract_path),'independent_biological_validation':False,'patient_n':3,'condition_Acute_minus_Remission':True,'gene_footprint_q_is_not_patient_q':True,'new_input_statistic':'signedQLsqrtF','all_gene_rows_retained_no_DEG_threshold':True,'official_return_rawP_definition':'2*StudentT.sf(abs(ULM score), number_input_genes-2); row BH across TFs in public API','official_source_SHA256':{p.name:sha(p) for p in [E/'runtime/decoupler_libraries/decoupler/mt/_ulm.py',E/'runtime/decoupler_libraries/decoupler/mt/_run.py',E/'runtime/decoupler_libraries/decoupler/pp/data.py',E/'runtime/decoupler_libraries/decoupler/pp/net.py']},'software_versions':{x:importlib.metadata.version(x) for x in ['decoupler','numpy','scipy','pandas','anndata','numba']}}
dump(O/'实际完成摘要.json',result)
shutil.copy2(__file__,O/'analysis_executed_snapshot.py')
print(json.dumps(result,ensure_ascii=False),flush=True)



