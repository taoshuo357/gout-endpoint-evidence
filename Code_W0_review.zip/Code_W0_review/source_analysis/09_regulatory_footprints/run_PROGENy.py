from pathlib import Path
import sys,json,hashlib,datetime,gc
E=Path(__file__).resolve().parents[1];G=Path('G:/痛风/第二步_靶点预测与疾病交集');O=E/'02_decoupler官方方法';P=O/'PROGENy_次级通路足迹'
for p in reversed([E/'runtime/decoupler_libraries',G/'runtime/ppi_analysis_libraries',G/'论文推进_2026-10-30/单细胞定位/runtime']):sys.path.insert(0,str(p))
import numpy as np,pandas as pd,decoupler as dc
from decoupler.mt._ulm import _func_ulm
from decoupler.pp.data import extract
from decoupler.pp.net import prune,adjmat

def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bh(p):
 p=np.asarray(p,float);idx=np.argsort(p,kind='mergesort');v=p[idx]*len(p)/np.arange(1,len(p)+1);v=np.minimum.accumulate(v[::-1])[::-1];out=np.empty_like(v);out[idx]=np.minimum(v,1);return out
meta=json.loads((P/'资源获取与许可来源.json').read_text(encoding='utf-8'));assert meta['status']=='RESOURCE_READY' and meta['n_pathways']==14
netfile=P/'PROGENy_官方默认完整网络.tsv';net=pd.read_csv(netfile,sep='\t');paths=sorted((O/'输入对照矩阵').glob('*_全部基因signedQLsqrtF.tsv.gz'));assert len(paths)==9
contract={'date':'2026-11-03','status_before_PROGENy_outcomes':'No pathway ULM scores computed','prior_contract_sha':sha(P/'计算前合同.json'),'resource_sha':sha(netfile),'resource_source':'official decoupler dc.op.progeny human topinf/thr_padj.05/academic','all14_pathways':meta['pathways'],'input_matrices':[{'file':str(p),'sha256':sha(p)} for p in paths],'no_new_gene_or_pathway_selection':True,'same_6mapping_and_p_value_interpretation_as_TF':True}
dump(P/'执行输入冻结.json',contract)
records=[];coverage=[]
for path in paths:
 typ=path.name.replace('_全部基因signedQLsqrtF.tsv.gz','').replace('_',' ')
 data=pd.read_csv(path,sep='\t',index_col=0);data.index=data.index.astype(str);assert len(data)==6 and set(data.index)=={'123','132','213','231','312','321'}
 score,oq=dc.mt.ulm(data=data,net=net,tmin=5,verbose=False)
 mat,obs,genes=extract(data,raw=False,empty=True,shuffle=True,verbose=False);trim=prune(features=genes,net=net,tmin=5);names,target,adj=adjmat(features=genes,net=trim)
 vals,pv=_func_ulm(mat,adj);q=np.vstack([bh(a) for a in pv])
 assert len(names)==14 and np.max(np.abs(score.loc[obs,names].to_numpy()-vals))<1e-10
 assert np.array_equal(oq.loc[obs,names].to_numpy().astype(np.float32),q.astype(np.float32))
 count=trim.groupby('source').target.nunique()
 for i,mapping in enumerate(obs):
  for j,pw in enumerate(names):records.append({'cell_type':typ,'pairing_id':mapping,'pathway':pw,'score_ULM_signedQLsqrtF':float(vals[i,j]),'official_rawP_gene_footprint':float(pv[i,j]),'official_BH_within14paths':float(oq.loc[mapping,pw]),'independent_double_BH_within14paths':float(q[i,j]),'background_genes':len(genes),'measured_pathway_targets':int(count.loc[pw]),'not_patient_level_P':True})
 for pw in names:coverage.append({'cell_type':typ,'pathway':pw,'measured_targets':int(count.loc[pw]),'resource_targets':int(net[net.source.eq(pw)].target.nunique()),'background_genes':len(genes)})
 print('PROGENy_DONE',typ,[int(oq.loc[m].lt(.05).sum()) for m in data.index],flush=True);gc.collect()
r=pd.DataFrame(records);assert len(r)==9*6*14
r['BH_all8types14paths_same_mapping']=np.nan
for m in sorted(r.pairing_id.unique()):
 ix=r.pairing_id.eq(m)&r.cell_type.ne('Whole PBMC');assert ix.sum()==8*14;r.loc[ix,'BH_all8types14paths_same_mapping']=bh(r.loc[ix,'official_rawP_gene_footprint'].to_numpy())
r.to_csv(P/'全部9背景_六映射_14通路官方ULM完整结果.tsv',sep='\t',index=False)
pd.DataFrame(coverage).to_csv(P/'全部通路目标覆盖.tsv',sep='\t',index=False)
rows=[]
for (typ,pw),d in r.groupby(['cell_type','pathway']):
 v=d.score_ULM_signedQLsqrtF.to_numpy()
 rows.append({'cell_type':typ,'pathway':pw,'score_median':float(np.median(v)),'score_min':float(v.min()),'score_max':float(v.max()),'same_direction_all6':bool((v>0).all() or (v<0).all()),'within14path_q05_maps':int(d.official_BH_within14paths.lt(.05).sum()),'within14path_q_min':float(d.official_BH_within14paths.min()),'within14path_q_max':float(d.official_BH_within14paths.max()),'full8type14path_q05_maps':int(d.BH_all8types14paths_same_mapping.lt(.05).sum()),'full8type14path_q_min':float(d.BH_all8types14paths_same_mapping.min()) if typ!='Whole PBMC' else None,'full8type14path_q_max':float(d.BH_all8types14paths_same_mapping.max()) if typ!='Whole PBMC' else None,'worstmap_rawP':float(d.official_rawP_gene_footprint.max()),'measured_targets':int(d.measured_pathway_targets.iloc[0])})
s=pd.DataFrame(rows)
for ix in [s.cell_type.ne('Whole PBMC'),s.cell_type.eq('Whole PBMC')]:s.loc[ix,'BH_of_worstmapP_sensitivity']=bh(s.loc[ix,'worstmap_rawP'].to_numpy())
s.to_csv(P/'全部通路_跨映射方向与效应稳定性.tsv',sep='\t',index=False)
s[s.cell_type.eq('CD14 monocytes')].to_csv(P/'CD14_14通路_跨映射稳定性.tsv',sep='\t',index=False)
per=r.groupby(['cell_type','pairing_id']).agg(pathways=('pathway','size'),within14paths_BH05=('official_BH_within14paths',lambda x:int(x.lt(.05).sum())),full8typepaths_BH05=('BH_all8types14paths_same_mapping',lambda x:int(x.lt(.05).sum()))).reset_index();per.to_csv(P/'全部背景与映射_计数概况.tsv',sep='\t',index=False)
cd=s[s.cell_type.eq('CD14 monocytes')];main=s[s.cell_type.ne('Whole PBMC')]
resources=json.loads((P/'官方资源_HTTP响应_1.bin').read_bytes());license=resources.get('PROGENy',{})
dump(P/'PROGENy_官方资源许可元数据.json',license)
result={'status':'COMPUTED_OFFICIAL_DEFAULT_PROGENy','completed_at_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'allpathways':meta['pathways'],'pathway_count':14,'network_edges':len(net),'observations':len(r),'CD14_same_direction_all6':int(cd.same_direction_all6.sum()),'CD14_full8type14path_BH05_in_all6':int(cd.full8type14path_q05_maps.eq(6).sum()),'CD14_full8type14path_names_BH05_in_all6':cd.loc[cd.full8type14path_q05_maps.eq(6),'pathway'].tolist(),'all8type_fullfamily_BH05_in_all6':int(main.full8type14path_q05_maps.eq(6).sum()),'all8type_BH_of_worstmapP05':int(main.BH_of_worstmapP_sensitivity.lt(.05).sum()),'input_contract_sha256':sha(P/'执行输入冻结.json'),'patient_n':3,'independent_validation':False,'ULM_gene_footprint_P_not_patient_P':True,'resource_license_metadata':license}
dump(P/'实际完成摘要.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
