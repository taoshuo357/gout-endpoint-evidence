"""Outcome-blind memory amendment: preserve472 forced genes; select1028 ranked."""
from pathlib import Path
import sys,os,json,hashlib,shutil,time
BASE=Path(__file__).resolve().parent
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
sys.path.insert(0,str(BASE/'runtime/ppi_analysis_libraries'))
import numpy as np,pandas as pd
from scipy import sparse
P=BASE/'虚拟敲除_2026-11-02/01_输入与资格'
OLD=P/'网络2000_固定输入';NEW=P/'网络1500_低内存固定输入';NEW.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
# Freeze old2000 inputs before reading them; no model output is inspected here.
before=[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(OLD.rglob('*')) if p.is_file()]
dump(NEW/'原2000输入_SHA256_修订前.json',before)
oldg=pd.read_csv(OLD/'网络2000_固定基因顺序.tsv',sep='\t')
forced=oldg[oldg.proposed_reason.ne('equal_library_dispersion_rank')].copy()
assert len(forced)==472 and int(forced.primary5_requested.sum())==5
ranked=oldg[oldg.proposed_reason.eq('equal_library_dispersion_rank')].sort_values(['suggested_common_pool_rank','gene_symbol'],kind='stable').head(1028)
pool=pd.concat([forced,ranked]).sort_values('gene_index_0based',kind='stable').copy()
assert len(pool)==1500 and pool.gene_symbol.is_unique
oldrows=pool.network_gene_index_0based.to_numpy()
pool=pool.rename(columns={'network_gene_index_0based':'network2000_gene_index_0based'})
pool.insert(0,'network_gene_index_0based',np.arange(1500))
pool.to_csv(NEW/'网络1500_固定基因顺序.tsv',sep='\t',index=False)
contract={'amendment_reason':'Before any real KO/model outcome: first fit failed in R locale/RhpcBLASctl path handling; available RAM fell from initial3.2GB to1.4-1.7GB. Retain default10 PCR networks while reducing feature count only.','prior_pool_preserved':str(OLD),'no_KO_results_used':True,'fixed_network_gene_count':1500,'same_eligibility_and_ranking':'Same >=5% all6 library expression, structural exclusions and equal-library normalized-dispersion ranking already frozen. No new phenotype, clinical or predicted-effect selection.','forced_rule':'All472 prior primary5+full-nine-KEGG common members retained exactly; add highest1028 originally ranked non-forced genes.','unchanged_model_settings_expected':{'network_cells':500,'PCR_networks':10,'random_seeds':3},'normalization':'Raw counts genes x cells plus identical full33538-feature UMI denominator. CPM must divide by full33538-feature UMI, not selected1500-gene sum.','biological_patients':3,'source_libraries':6,'A_B_donor_crosswalk_verified':False}
dump(NEW/'网络1500_计算前资源修订合同.json',contract)
rows=[]
for s in ['A1','A2','A3','B1','B2','B3']:
 t=time.time()
 old=sparse.load_npz(OLD/(s+'_CD14_2000genes_raw_counts.npz')).tocsr()
 x=old[oldrows].tocsc();x.sort_indices()
 meta=pd.read_csv(P/(s+'_CD14_细胞顺序.tsv.gz'),sep='\t')
 full=np.load(OLD/(s+'_CD14_full_depth_UMI.npy'))
 assert old.shape[1]==x.shape[1]==len(meta)==len(full)
 assert np.array_equal(full,meta.UMI.to_numpy())
 assert (np.asarray(x.sum(axis=0)).ravel()<=full).all()
 dest=NEW/(s+'_CD14_1500genes_raw_counts.npz')
 sparse.save_npz(dest,x,compressed=True)
 # Low gzip compression is an I/O choice only, not a change to any count.
 pd.DataFrame(x.toarray(),index=pool.gene_symbol,columns=meta.cell_id).to_csv(NEW/(s+'_CD14_1500genes_raw_counts.tsv.gz'),sep='\t',index_label='gene_symbol',compression={'method':'gzip','compresslevel':1})
 shutil.copy2(OLD/(s+'_CD14_full_depth_UMI.npy'),NEW/(s+'_CD14_full_depth_UMI.npy'))
 pd.DataFrame({'matrix_column_index_0based':np.arange(len(meta)),'cell_id':meta.cell_id,'sample_id':s,'full33538_feature_UMI':full,'selected1500_UMI':np.asarray(x.sum(axis=0)).ravel()}).to_csv(NEW/(s+'_CD14_full_depth_UMI.tsv.gz'),sep='\t',index=False,compression={'method':'gzip','compresslevel':1})
 # Independent reread of the stored sparse values and full-depth array.
 back=sparse.load_npz(dest).tocsr()
 assert (back-old[oldrows]).nnz==0
 assert np.array_equal(np.load(NEW/(s+'_CD14_full_depth_UMI.npy')),full)
 rows.append({'sample_id':s,'genes':1500,'cells':len(meta),'counts_path':str(dest),'counts_sha256':sha(dest),'full_depth_path':str(NEW/(s+'_CD14_full_depth_UMI.npy')),'full_depth_sha256':sha(NEW/(s+'_CD14_full_depth_UMI.npy')),'full_depth_equals2000_input_and_frozen_original':True,'raw_count_subset_equals2000_input_exactly':True,'selected1500_UMI_sum':int(x.sum()),'full33538_UMI_sum':int(full.sum())})
 print('1500_READY',s,len(meta),'seconds',round(time.time()-t,2),flush=True)
pd.DataFrame(rows).to_csv(NEW/'网络1500_六库输入清单.tsv',sep='\t',index=False)
unchanged=all(sha(r['path'])==r['sha256'] for r in before);assert unchanged
summary={'all_checks_passed':True,'network_gene_count':1500,'all472_forced_unchanged':set(forced.gene_symbol)==set(pool.loc[pool.proposed_reason.ne('equal_library_dispersion_rank'),'gene_symbol']),'other_ranked_genes':1028,'all5_primary_retained':bool(pool.primary5_requested.sum()==5),'CD14_cells_total':int(sum(r['cells'] for r in rows)),'old2000_inputs_all_SHA_unchanged':unchanged,'no_KO_outcome_inspected':True,'libraries':rows,'data_bytes':sum(p.stat().st_size for p in NEW.rglob('*') if p.is_file())}
assert summary['data_bytes']<=30_000_000
dump(NEW/'网络1500_实际准备汇总.json',summary)
shutil.copy2(Path(__file__),NEW/Path(__file__).name)
print(json.dumps(summary,ensure_ascii=False),flush=True)

