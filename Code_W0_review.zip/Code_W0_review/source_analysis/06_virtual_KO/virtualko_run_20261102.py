from pathlib import Path
import os,sys,json,time,subprocess,hashlib
B=Path(__file__).resolve().parent;O=B/'虚拟敲除_2026-11-02';sys.path.insert(0,str(B/'runtime/ppi_analysis_libraries'))
import psutil
mode=sys.argv[1] if len(sys.argv)>1 else 'fit'
seeds=[2026110201,2026110202,2026110203]
samples=['A1','A2','A3','B1','B2','B3']
logdir=O/'运行日志';logdir.mkdir(exist_ok=True)
env={**os.environ,'R_USER':str(B/'_运行临时/R_user'),'R_LIBS_USER':str(B/'runtime/R_geo_libraries'),'R_ENVIRON':'','R_ENVIRON_USER':'','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','MKL_NUM_THREADS':'2','LANG':'en_US.UTF-8','LC_ALL':'en_US.UTF-8'}
jobs=[(s,seed) for seed in seeds for s in samples]
pending=[]
for s,seed in jobs:
 d=O/'04_模型'/f'{s}_{seed}'
 if not (d/(mode+'_complete.csv')).exists():pending.append((s,seed))
running=[];completed=[];failures=[]
maxworkers=2
while pending or running:
 while pending and len(running)<maxworkers:
  # CP stages are additionally serialized inside R; two light PCR/MA jobs may overlap.
  free=psutil.virtual_memory().available
  if running and free<1.8*1024**3:break
  s,seed=pending.pop(0);d=O/'04_模型'/f'{s}_{seed}';d.mkdir(exist_ok=True,parents=True)
  f=(logdir/f'{mode}_{s}_{seed}.log').open('w',encoding='utf-8')
  snap=d/(mode+'_engine_immutable_snapshot.R')
  snap.write_bytes((B/'virtualko_engine_20261102.R').read_bytes())
  p=subprocess.Popen(['G:/R_Installer/R-4.6.1/bin/Rscript.exe','--vanilla',str(snap),mode,s,str(seed)],cwd=B,env=env,stdout=f,stderr=subprocess.STDOUT)
  running.append({'s':s,'seed':seed,'p':p,'file':f,'start':time.time(),'peak_RSS':0})
  print('START',mode,s,seed,'available_GiB',round(free/1024**3,2),flush=True)
 for r in running[:]:
  p=r['p'];d=O/'04_模型'/f"{r['s']}_{r['seed']}"
  try:
   pidpath=d/(mode+'_R_pid.txt')
   if pidpath.exists():r['peak_RSS']=max(r['peak_RSS'],psutil.Process(int(pidpath.read_text().strip())).memory_info().rss)
  except (psutil.Error,ValueError,OSError):pass
  rc=p.poll()
  if rc is not None:
   r['file'].close()
   row={'sample':r['s'],'seed':r['seed'],'returncode':rc,'seconds':time.time()-r['start'],'real_R_PID_peak_RSS_observed':r['peak_RSS'],'complete_file':(d/(mode+'_complete.csv')).exists()}
   (d/(mode+'_runner.json')).write_text(json.dumps(row,indent=2),encoding='utf-8')
   if rc or not row['complete_file']:
    failures.append(row);pending=[];print('FAILED',mode,json.dumps(row),flush=True)
   else:completed.append(row);print('DONE',mode,r['s'],r['seed'],'count',len(completed),'wall',round(row['seconds'],1),flush=True)
   running.remove(r)
 state={'mode':mode,'running':[{'sample':r['s'],'seed':r['seed'],'elapsed_seconds':time.time()-r['start'],'peak_RSS':r['peak_RSS']} for r in running],'finished_this_run':completed,'failures':failures,'pending':len(pending),'available_memory_bytes':psutil.virtual_memory().available}
 (O/(mode+'_运行状态.json')).write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
 if pending or running:time.sleep(1)
if failures:raise RuntimeError(failures)
print('ALL_COMPLETE',mode,flush=True)


