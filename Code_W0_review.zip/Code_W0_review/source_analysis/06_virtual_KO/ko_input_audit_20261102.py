from pathlib import Path
import sys,json,hashlib,csv,gzip,shutil
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'runtime/ppi_analysis_libraries'))
import numpy as np,pandas as pd
from scipy import sparse
P=BASE/'虚拟敲除_2026-11-02/01_输入与资格';Q=P/'网络2000_固定输入'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
pool=pd.read_csv(Q/'网络2000_固定基因顺序.tsv',sep='\t')
fullgenes=pd.read_csv(P/'CD14_基因顺序.tsv',sep='\t')
oldstats=pd.read_csv(BASE/'论文推进_2026-10-30/单细胞定位/结果表/细胞类型_逐文库marker与12靶点表达.csv')
tests=[];idx=pool.gene_index_0based.to_numpy()
for s in ['A1','A2','A3','B1','B2','B3']:
 x=sparse.load_npz(Q/(s+'_CD14_2000genes_raw_counts.npz')).tocsr()
 full=sparse.load_npz(P/(s+'_CD14_raw_genes_by_cells.npz')).tocsc()
 meta=pd.read_csv(P/(s+'_CD14_细胞顺序.tsv.gz'),sep='\t')
 depth=np.load(Q/(s+'_CD14_full_depth_UMI.npy'))
 assert x.shape==(2000,len(meta))
 assert np.issubdtype(x.dtype,np.integer) and (x.data>=0).all()
 assert (x-full[idx]).nnz==0
 assert np.array_equal(depth,np.asarray(full.sum(axis=0)).ravel())
 assert np.array_equal(depth,meta.UMI.to_numpy())
 with gzip.open(Q/(s+'_CD14_2000genes_raw_counts.tsv.gz'),'rt',encoding='utf-8',newline='') as f:
  reader=csv.reader(f,delimiter='\t');header=next(reader)
  assert header[0]=='gene_symbol' and header[1:]==meta.cell_id.tolist()
  k=0
  for k,row in enumerate(reader,start=1):
   assert row[0]==pool.gene_symbol.iloc[k-1]
   vv=np.array(row[1:],dtype=np.int32)
   assert np.array_equal(vv,x[k-1].toarray().ravel())
  assert k==2000
 diffs=[]
 for g in ['NLRP3','CASP1','IL1B','RELA','NFKB1']:
  i=int(pool.index[pool.gene_symbol.eq(g)][0])
  now=float(x[i].getnnz()/x.shape[1])
  prior=oldstats[oldstats.sample_id.eq(s)&oldstats.cell_type.eq('CD14 monocytes')&oldstats.gene_symbol.eq(g)]
  assert len(prior)==1
  diff=abs(now-float(prior.fraction_detected.iloc[0]));assert diff<1e-12
  diffs.append(diff)
 tests.append({'sample_id':s,'shape':list(x.shape),'NPZ_equals_full_count_subset':True,'TSV_every_value_equals_NPZ':True,'TSV_gene_and_cell_order_passed':True,'full33538_depth_equals_original_UMI':True,'primary5_detection_vs_frozen_table_max_abs_diff':max(diffs)})
 print('STORAGE_VERIFIED',s,flush=True)
before=json.loads((P/'原始输入_SHA256_执行前.json').read_text(encoding='utf-8'))
assert all(sha(r['path'])==r['sha256'] for r in before)
assert set(pool.proposed_reason)=={'requested_primary5','all_nine_KEGG_measured_member','equal_library_dispersion_rank'}
assert int(pool.primary5_requested.sum())==5
assert int((pool.proposed_reason!='equal_library_dispersion_rank').sum())==472
assert int(pool.proposed_reason.eq('equal_library_dispersion_rank').sum())==1528
checks={'all_checks_passed':True,'per_library':tests,'all_original_sources_SHA256_unchanged':True,'selected2000_pool_unique':pool.gene_symbol.is_unique,'primary5_count':5,'forced_primary5_and_allnineKEGG_count':472,'variability_filled_count':1528,'no_knockout_result_generated':True,'biological_patient_count':3,'libraries_are_not_six_independent_patients':True}
dump(P/'输入准备_独立存储与旧表达表核对.json',checks)
(P/'01输入_可复跑说明.txt').write_text("""已完成正式虚拟KO前的原始计数准备与资格审核；本子模块不计算敲除结果。
原33538 features按symbol在细胞层求和为33514唯一symbol，24个重复symbol涉及48行feature、零空名，原全部UMI保留。CD14六库细胞为1389/2679/701/1714/1473/608，共8564。
7317 symbols在六库各>=5%细胞检出，剔线粒体、明确核糖体/血红蛋白/免疫球蛋白结构类后7150。排除正则刻意保留RPS6KA/RPS6KB激酶与IGHMBP2等非结构基因，完整旗标与代码可查。
root依据16GB RAM与约3.2GB可用内存，在看KO结果前把网络特征数由最初3000讨论值固定为2000。包括所有合格primary5及完整冻结九KEGG实测成员的并集472，剩余1528按等文库normalized-log-dispersion排序；完整公式、分箱和所有gene统计保留。最终固定输入合同在“网络2000_固定输入”，旧建议文件仅为准备过程快照。
每库完整原CD14 sparse NPZ为genes×cells；最终2000同样给NPZ及gzip TSV（含symbol行名、cell_id列名）。每个矩阵的细胞顺序与full33538_feature_UMI单独给出；如做CPM，应为1e6*raw/full33538_feature_UMI，禁止用只选2000基因之和作分母。
每库NPZ与完整计数子集逐值相等；gzip TSV所有值、行/列顺序与NPZ独立重读核对；五个primary检出率与已封存表达表一致；所有原始source SHA未改变。
初次可选MatrixMarket gzip导出发生停滞，诊断时0字节、停止后观察到12.2MB，未作为输入；已隔离在失败记录。不依赖它重现，NPZ/TSV都是完整核对后的实际输入。
root实际入口为项目根ko_prepare_CD14_inputs_20261102.py、ko_finalize_input_pool_20261102.py和ko_input_audit_20261102.py，用运行项目脚本.ps1。输出目录中的同名副本供源码审阅，不要在副本目录直接当项目根执行。
仅3患者、6文库，A-B患者crosswalk未核准；网络重抽样不增加患者数。GSE217561已有3个处理文库复用，不在这里制造独立验证。此准备不增加临床病例、不更改既有注释、不处理C盘。
""",encoding='utf-8')
shutil.copy2(Path(__file__),P/Path(__file__).name)
manifest=[{'path':str(p.relative_to(P)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(P.rglob('*')) if p.is_file() and p.name!='输入准备_全部输出SHA256.json']
dump(P/'输入准备_全部输出SHA256.json',manifest)
print(json.dumps({'all_checks_passed':True,'outputs':len(manifest),'data_bytes':sum(r['bytes'] for r in manifest),'full_cell_count':8564,'network_genes':2000},ensure_ascii=False),flush=True)

