"""Frozen CD14 virtual-KO matching, heat statistics, and classical-result summaries.
All conditional comparisons concern a fitted GRN, not patient treatment effects.
Run only through the project's G-drive wrapper.
"""
from pathlib import Path
import os,sys,json,gzip,hashlib,argparse,re,itertools,time,shutil,warnings
BASE=Path(__file__).resolve().parent
assert BASE.drive.upper()=='G:'
sys.path.insert(0,str(BASE/'runtime/ppi_analysis_libraries'))
sys.path.append(str(BASE/'论文推进_2026-10-30/单细胞定位/runtime'))
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import numpy as np,pandas as pd
from scipy.linalg import eigh
from scipy.stats import rankdata,spearmanr
try:
 from threadpoolctl import threadpool_limits
except ImportError:
 from contextlib import nullcontext
 def threadpool_limits(*a,**k):return nullcontext()
OUT=BASE/'虚拟敲除_2026-11-02'
MATCH=OUT/'05_匹配背景';RES=OUT/'06_统计结果'
GENEFILE=OUT/'01_输入与资格/网络1500_低内存固定输入/网络1500_固定基因顺序.tsv'
PATHFILE=BASE/'GEO表达核验_2026-10-29/预处理/KEGG九通路_完整成员.csv'
PRIMARY=['NLRP3','CASP1','IL1B','RELA','NFKB1']
SAMPLES=['A1','A2','A3','B1','B2','B3'];SEEDS=[2026110201,2026110202,2026110203]
MODELS=[f'{s}_{seed}' for s in SAMPLES for seed in SEEDS]
FEATURES=['mean_log1p_fullCPM','detection','log1p_variance','log1p_abs_out_strength','log1p_symmetric_abs_strength']
FROZEN=MATCH/'匹配与共同响应池_冻结.json'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def dump(p,x):
 Path(p).parent.mkdir(parents=True,exist_ok=True)
 Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def save(df,p):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 df.to_csv(p,sep='\t',index=False,encoding='utf-8-sig',na_rep='NA',float_format='%.17g',compression='gzip' if p.suffix=='.gz' else None)
def load(p):return pd.read_csv(p,sep='\t' if '.tsv' in str(p) else ',',encoding='utf-8-sig')
def bh(p):
 p=np.asarray(p,float);assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all()
 ix=np.argsort(p,kind='stable');q=np.minimum.accumulate((p[ix]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1]
 out=np.empty_like(q);out[ix]=np.minimum(q,1);return out
def meta_model(m):s,k=m.split('_');return {'model':m,'sample_id':s,'seed':int(k)}
def modeldir(m):return OUT/'04_模型'/m
def genes():
 g=load(GENEFILE).gene_symbol.astype(str).tolist()
 assert len(g)==1500 and len(set(g))==1500 and set(PRIMARY)<=set(g)
 return g
def matrix_path(m):
 d=modeldir(m);b=d/'WT_有向权重矩阵_float64列优先.bin.gz'
 return b if b.exists() else d/'WT_有向权重矩阵.tsv.gz'
def read_W(m,g):
 p=matrix_path(m);n=len(g)
 if '.bin.gz' in p.name:
  with gzip.open(p,'rb') as f:a=np.frombuffer(f.read(),dtype='<f8').copy()
  assert len(a)==n*n
  w=a.reshape((n,n),order='F')
 else:
  z=pd.read_csv(p,sep='\t',index_col=0)
  assert z.shape==(n,n) and list(z.index)==g and list(z.columns)==g
  w=z.to_numpy(float)
 assert np.isfinite(w).all() and np.max(np.abs(np.diag(w)))<1e-12
 return w
def read_cov(m,g):
 d=pd.read_csv(modeldir(m)/'WT_无KO匹配协变量.csv')
 assert d.gene.tolist()==g
 vals=np.column_stack([d.mean_log1p_fullCPM,d.detection,np.log1p(d.sd_log1p_fullCPM.to_numpy()**2),np.log1p(d.abs_out_strength),np.log1p(d.symmetric_abs_strength)])
 assert np.isfinite(vals).all()
 return d,vals
def source_records():
 ps=[GENEFILE,PATHFILE]
 for m in MODELS:ps += [modeldir(m)/'fit_complete.csv',modeldir(m)/'WT_无KO匹配协变量.csv',matrix_path(m)]
 return [{'path':str(p.relative_to(BASE)),'sha256':sha(p),'bytes':p.stat().st_size} for p in ps]
def verify_frozen():
 assert FROZEN.exists(),'Run --match only after all WT fits and before KO inspection'
 f=json.loads(FROZEN.read_text(encoding='utf-8'))
 for r in f['sources']:
  assert sha(BASE/r['path'])==r['sha256'],r['path']
 for r in f['frozen_table_files']:
  assert sha(MATCH/r['name'])==r['sha256'],r['name']
 return f
def make_match():
 MATCH.mkdir(parents=True,exist_ok=True);RES.mkdir(parents=True,exist_ok=True)
 if FROZEN.exists():
  f=verify_frozen();print('FROZEN_MATCH_ALREADY_EXISTS_AND_UNCHANGED',flush=True);return
 for m in MODELS:
  assert (modeldir(m)/'fit_complete.csv').exists(),m
  assert not list(modeldir(m).glob('classic_*')),'Matching must precede all KO output inspection'
 g=genes();n=len(g);ix={v:i for i,v in enumerate(g)}
 covs=[];allcov=[];wtchecks=[]
 for m in MODELS:
  d,v=read_cov(m,g);covs.append(v)
  w=read_W(m,g)
  out=np.sum(np.abs(w),axis=1);sym=np.sum(np.abs((w+w.T)/2),axis=1)
  eo=float(np.max(np.abs(out-d.abs_out_strength.to_numpy())));es=float(np.max(np.abs(sym-d.symmetric_abs_strength.to_numpy())))
  assert np.allclose(out,d.abs_out_strength.to_numpy(),rtol=1e-9,atol=1e-8) and np.allclose(sym,d.symmetric_abs_strength.to_numpy(),rtol=1e-9,atol=1e-8),m
  wtchecks.append({'model':m,'genes':len(g),'out_strength_max_abs_error':eo,'symmetric_strength_max_abs_error':es,'WT_file':str(matrix_path(m))})
  del w
  dd=d.copy();dd.insert(0,'model',m);allcov.append(dd)
 x=np.mean(covs,axis=0);r=rankdata(x,axis=0,method='average')/n
 covr=rankdata(np.stack(covs),axis=1,method='average')/n
 pooled=pd.DataFrame({'gene':g})
 for j,k in enumerate(FEATURES):pooled[k]=x[:,j];pooled[k+'_percentile']=r[:,j]
 save(pd.DataFrame(wtchecks),MATCH/'WT_18模型_匹配协变量与真实矩阵一致性.tsv')
 save(pooled,MATCH/'WT_18模型等权汇总_五协变量与分位.tsv')
 save(pd.concat(allcov,ignore_index=True),MATCH/'WT_全部18模型_原始匹配协变量.tsv')
 rows=[];selected={};status=[];represent=[];bal=[]
 for target in PRIMARY:
  k=ix[target];delta=np.abs(r-r[k]);dist=np.sqrt((delta*delta).sum(1))
  cand=[j for j in range(n) if g[j] not in PRIMARY]
  ordered=sorted(cand,key=lambda j:(float(dist[j]),g[j]))
  admiss=[j for j in ordered if delta[j].max()<=.20]
  sel=admiss[:99];selected[target]=[g[j] for j in sel]
  eligible=len(sel)>=30;pos={j:a+1 for a,j in enumerate(sel)}
  status.append({'target':target,'available_caliper_controls':len(admiss),'selected_controls':len(sel),'conditional_comparison_eligible_ge30':eligible,'caliper_max_abs_percentile_difference':.20,'maximum_selected_rank_distance':float(max([dist[j] for j in sel],default=np.nan)) if sel else None})
  if eligible:represent.append({'target':target,'control':g[sel[0]]})
  for j in ordered:
   z={'target':target,'control':g[j],'euclidean_percentile_distance':dist[j],'maximum_abs_percentile_difference':delta[j].max(),'passes_all5_caliper':bool(delta[j].max()<=.20),'selected':j in pos,'selected_rank':pos.get(j,0)}
   for a,kf in enumerate(FEATURES):z[kf+'_abs_percentile_difference']=delta[j,a]
   rows.append(z)
  for mi,m in enumerate(MODELS):
   for a,kf in enumerate(FEATURES):
    cr=covr[mi,sel,a] if sel else np.array([])
    bal.append({**meta_model(m),'target':target,'variable':kf,'target_percentile_in_model':covr[mi,k,a],'control_median_percentile_in_model':float(np.median(cr)) if len(cr) else np.nan,'median_absolute_percentile_difference_in_model':float(np.median(np.abs(cr-covr[mi,k,a]))) if len(cr) else np.nan,'maximum_absolute_percentile_difference_in_model':float(np.max(np.abs(cr-covr[mi,k,a]))) if len(cr) else np.nan,'n_controls':len(sel),'matching_was_on_pooled_covariates_not_each_individual_model':True})
 assert len(rows)==5*(n-5)
 save(pd.DataFrame(rows),MATCH/'全部7475控制候选_协变量距离与caliper.tsv')
 save(pd.DataFrame(status),MATCH/'五候选_匹配资格与数量.tsv')
 save(pd.DataFrame(represent,columns=['target','control']),MATCH/'经典法_代表匹配KO.tsv')
 save(pd.DataFrame(bal),MATCH/'全部18模型_匹配协变量平衡诊断.tsv')
 allsel=sorted(set(sum(selected.values(),[])))
 excluded=set(PRIMARY)|set(allsel);response=[v for v in g if v not in excluded]
 assert len(response)>100
 save(pd.DataFrame([{'gene':v,'network_index_0based':j,'in_common_response_pool':v in response,'exclusion_reason':'primary_KO_self' if v in PRIMARY else 'selected_control_KO_self' if v in allsel else ''} for j,v in enumerate(g)]),MATCH/'全部1500基因_共同响应池掩码.tsv')
 save(pd.DataFrame({'gene':response,'network_index_0based':[ix[v] for v in response]}),MATCH/'共同响应池_固定基因.tsv')
 path=load(PATHFILE);terms=path.term_id.drop_duplicates().tolist();assert len(terms)==9
 pathway=[]
 for term in terms:
  pp=path[path.term_id.eq(term)]
  allmembers=set(pp.gene_symbol.astype(str));nm=len(allmembers&set(g));nr=len(allmembers&set(response))
  pathway.append({'term_id':term,'pathway_name':pp.pathway_name.iloc[0],'frozen_unique_symbols':len(allmembers),'network1500_members':nm,'common_response_members':nr,'eligible_response_members_ge10':nr>=10,'members':';'.join(v for v in response if v in allmembers)})
 save(pd.DataFrame(pathway),MATCH/'冻结九KEGG_共同响应池覆盖.tsv')
 shutil.copy2(Path(__file__),MATCH/'匹配前冻结_完整统计源码.py')
 fn=['WT_18模型_匹配协变量与真实矩阵一致性.tsv','WT_18模型等权汇总_五协变量与分位.tsv','全部7475控制候选_协变量距离与caliper.tsv','五候选_匹配资格与数量.tsv','经典法_代表匹配KO.tsv','全部1500基因_共同响应池掩码.tsv','共同响应池_固定基因.tsv','冻结九KEGG_共同响应池覆盖.tsv','匹配前冻结_完整统计源码.py']
 frozen={'status':'Matching frozen after18 WT fits; no KO output inspected','models':MODELS,'primary':PRIMARY,'genes':g,'response_genes':response,'selected_controls':selected,'matching_eligibility':status,'caliper':.20,'max_controls':99,'minimum_controls_for_conditional_rank':30,'minimum_pathway_members':10,'features':FEATURES,'covariate_summary':'equal mean transformed covariates across18, followed by per-variable percentile rank; Euclidean distance; gene-name tie break','sources':source_records(),'frozen_table_files':[{'name':s,'sha256':sha(MATCH/s)} for s in fn],'readout_mask_only_network_unchanged':True,'all_KO_self_mask_before_L1':True,'patient_n':3,'library_n':6,'seeds_per_library':3,'undefined_rule':'Exact zero nonself L1 denominator -> undefined NaN, never epsilon; shared median transparently omits undefined rows. Conditional comparison requires finite target and >=30 originally selected controls that are finite across every one of18 models; no replacement controls.','conditional_P_scope':'Approximate fitted-network matched-KO rank; not patient DE P and not established biological FDR'}
 dump(FROZEN,frozen)
 print('MATCH_FROZEN',json.dumps({'response_genes':len(response),'controls_union':len(allsel),'status':status},ensure_ascii=False),flush=True)
def path_info(f):
 p=load(MATCH/'冻结九KEGG_共同响应池覆盖.tsv');r=f['response_genes']
 M=np.column_stack([np.isin(r,str(v).split(';')) for v in p.members]).astype(float)
 return p,M
def finite_means(a,M):
 isf=np.isfinite(a)
 sums=np.where(isf,a,0.)@M;cnt=isf.astype(float)@M
 return np.divide(sums,cnt,out=np.full_like(sums,np.nan),where=cnt>0),cnt
def heat_one(m,f):
 DDIR=RES/'heat_models'/m;DDIR.mkdir(parents=True,exist_ok=True)
 cp=DDIR/'heat_complete.json';frsha=sha(FROZEN)
 if cp.exists():
  old=json.loads(cp.read_text(encoding='utf-8'));assert old['frozen_match_sha256']==frsha
  print('HEAT_ALREADY_COMPLETE',m,flush=True);return
 t0=time.perf_counter();g=f['genes'];ix={v:i for i,v in enumerate(g)};r=f['response_genes'];ri=np.array([ix[v] for v in r])
 cov,_=read_cov(m,g);mu=cov.mean_log1p_fullCPM.to_numpy(float);sd=cov.sd_log1p_fullCPM.to_numpy(float)
 assert str(matrix_path(m).relative_to(BASE)) in {r['path'] for r in f['sources']},'WT serialization changed after matching freeze'
 W=read_W(m,g);A=(W+W.T)/2
 with threadpool_limits(limits=2):
  lam,V=eigh(A,overwrite_a=True,check_finite=True,driver='evd')
  assert lam[-1]>0
  weights=np.exp(10*(lam/lam[-1]-1))
  H=(V*weights)@V.T
 assert np.isfinite(H).all();hsym=float(np.max(np.abs(H-H.T)))
 factor=np.divide(-mu,sd,out=np.zeros_like(mu),where=sd>0)
 raw=np.abs(factor[:,None]*H*sd[None,:]);np.fill_diagonal(raw,mu)
 assert np.isfinite(raw).all() and (raw>=0).all()
 if m=='A1_2026110201':
  # Genuine float64 computational reference saved BEFORE any float32 source-data conversion.
  assert raw.dtype==np.float64
  np.savez_compressed(DDIR/'heat_全1500KO_原始扰动距离_实现校验float64.npz',distance=raw,ko_genes=np.array(g),response_genes=np.array(g))
 np.savez_compressed(DDIR/'heat_全1500KO_原始扰动距离_float32.npz',distance=raw.astype(np.float32),ko_genes=np.array(g),response_genes=np.array(g),mu_log1p_fullCPM=mu,sd_log1p_fullCPM=sd)
 C=raw[:,ri].copy()
 # ALL KO rows, including the other non-control genes, lose their own response before normalization.
 for j,k in enumerate(ri):C[k,j]=np.nan
 den=np.nansum(C,axis=1)
 # An exactly zero nonself profile is undefined for L1 specificity, not a negative biological effect.
 valid=den>0
 norm=np.divide(C,den[:,None],out=np.full_like(C,np.nan),where=valid[:,None])
 assert np.nanmax(np.abs(np.nansum(norm,axis=1)[valid]-1))<1e-10
 shared=np.nanmedian(norm,axis=0);adjusted=norm-shared[None,:]
 assert np.isfinite(shared).all()
 np.savez_compressed(DDIR/'heat_共同响应_全KO校正profile_float32.npz',row_L1_nonself=norm.astype(np.float32),adjusted_profile=adjusted.astype(np.float32),shared_background=shared,nonself_distance_sum=den,valid_nonzero_profile=valid,ko_genes=np.array(g),response_genes=np.array(r))
 p,M=path_info(f)
 rawscore,cnt=finite_means(C,M);adjs,_=finite_means(adjusted,M)
 records=[]
 for k,gene in enumerate(g):
  for j,row in p.iterrows():
   records.append({**meta_model(m),'KO':gene,'term_id':row.term_id,'pathway_name':row.pathway_name,'common_response_members':int(row.common_response_members),'eligible_pathway_ge10':bool(row.eligible_response_members_ge10),'row_valid_nonzero_nonself':bool(valid[k]),'nonself_distance_sum':den[k],'raw_mean_distance':rawscore[k,j],'shared_adjusted_mean':adjs[k,j],'actual_scored_members_excluding_own_self':int(cnt[k,j])})
 save(pd.DataFrame(records),DDIR/'heat_全部KO_九通路评分.tsv.gz')
 meta={'model':m,'frozen_match_sha256':frsha,'statistics_source_sha256':sha(__file__),'network_source':str(matrix_path(m)),'network_sha256':sha(matrix_path(m)),'covariates_sha256':sha(modeldir(m)/'WT_无KO匹配协变量.csv'),'gene_count':len(g),'common_response_gene_count':len(r),'heat_diffusion_t':10,'symmetrizes_directed_WT':True,'largest_eigenvalue':float(lam[-1]),'heat_symmetry_max_abs_error':hsym,'invalid_exact_zero_nonself_rows':int((~valid).sum()),'self_mask_all_rows_verified':bool(np.isnan(C[ri,np.arange(len(ri))]).all()),'row_L1_sum_max_abs_error':float(np.max(np.abs(np.nansum(norm,axis=1)[valid]-1))) if valid.any() else None,'float64_implementation_reference_saved':m=='A1_2026110201','storage_dtype':'float32 source profiles; genuine before-conversion float64 reference saved only for A1_2026110201; full-depthmu/sd and computational statistics float64','wall_seconds':time.perf_counter()-t0,'official_formula':'H=V exp(10*(lambda/lambda_max-1))Vt; abs((-mu/sd)[:,None]*H*sd[None,:]); diag=mu'}
 dump(cp,meta);print('HEAT_COMPLETE',m,round(meta['wall_seconds'],2),flush=True)
def comparison_rows(df,f,scopekeys,validity):
 p=load(MATCH/'冻结九KEGG_共同响应池覆盖.tsv').set_index('term_id')
 result=[]
 for key,sub in df.groupby(scopekeys+['term_id'],sort=False,dropna=False):
  key=key if isinstance(key,tuple) else (key,);ks=dict(zip(scopekeys+['term_id'],key))
  term=ks['term_id'];ss=sub.set_index('KO')
  for target in PRIMARY:
   selected=f['selected_controls'][target]
   va=validity[(target,term)];controls=va['controls_finite_all18'];eligible_controls=len(controls)>=30
   z={**ks,'target':target,'controls':len(controls),'controls_originally_selected':len(selected),'controls_finite_all18':len(controls),'target_finite_all18':va['target_finite_all18'],'common_response_members':int(p.loc[term,'common_response_members']),'pathway_name':p.loc[term,'pathway_name'],'eligible_controls_ge30':eligible_controls,'eligible_pathway_ge10':bool(p.loc[term,'eligible_response_members_ge10']),'patient_n':3}
   for col,pre in [('shared_adjusted_mean','adjusted'),('raw_mean_distance','raw')]:
    value=float(ss.loc[target,col]);cc=ss.reindex(controls)[col].to_numpy(float)
    ok=eligible_controls and va['target_finite_all18'] and bool(p.loc[term,'eligible_response_members_ge10']) and np.isfinite(value) and np.isfinite(cc).all()
    z.update({pre+'_target_score':value,pre+'_control_median':float(np.nanmedian(cc)) if len(cc) and np.isfinite(cc).any() else np.nan,pre+'_control_q025':float(np.nanquantile(cc,.025)) if len(cc) and np.isfinite(cc).any() else np.nan,pre+'_control_q975':float(np.nanquantile(cc,.975)) if len(cc) and np.isfinite(cc).any() else np.nan,pre+'_excess_over_control_median':value-float(np.nanmedian(cc)) if len(cc) and np.isfinite(cc).any() else np.nan,pre+'_eligible_conditional_comparison':ok,pre+'_upper_conditional_P':float((1+np.sum(cc>=value))/(len(cc)+1)) if ok else np.nan,pre+'_percentile_fraction_controls_strictly_below':float(np.mean(cc<value)) if ok else np.nan,pre+'_P_for_fixed_family_BH':float((1+np.sum(cc>=value))/(len(cc)+1)) if ok else 1.})
   result.append(z)
 return pd.DataFrame(result)
def heat_summary(f):
 files=[RES/'heat_models'/m/'heat_全部KO_九通路评分.tsv.gz' for m in MODELS]
 assert all((p.parent/'heat_complete.json').exists() for p in files)
 d=pd.concat([load(p) for p in files],ignore_index=True)
 assert len(d)==18*1500*9
 save(d,RES/'Heat_全部18模型_全部KO九通路.tsv.gz')
 keys=['sample_id','KO','term_id','pathway_name','common_response_members','eligible_pathway_ge10']
 # skipna=False keeps missing technical results visible rather than dropping failed runs.
 lib=d.groupby(keys,sort=False,dropna=False)[['raw_mean_distance','shared_adjusted_mean']].agg(lambda s:np.median(s.to_numpy())).reset_index()
 glob=lib.groupby(['KO','term_id','pathway_name','common_response_members','eligible_pathway_ge10'],sort=False,dropna=False)[['raw_mean_distance','shared_adjusted_mean']].agg(lambda s:np.median(s.to_numpy())).reset_index()
 save(lib,RES/'Heat_全部6文库_技术中位数_全部KO九通路.tsv.gz')
 save(glob,RES/'Heat_6库中位数_全部KO九通路.tsv.gz')
 validity={};validrows=[]
 for target in PRIMARY:
  for term in d.term_id.drop_duplicates():
   dd=d[d.term_id.eq(term)]
   finite=dd.assign(_finite=np.isfinite(dd.raw_mean_distance)&np.isfinite(dd.shared_adjusted_mean)).groupby('KO')['_finite'].agg(['all','count'])
   tv=bool(finite.loc[target,'all'] and finite.loc[target,'count']==18)
   selected=f['selected_controls'][target]
   keep=[c for c in selected if bool(finite.loc[c,'all']) and finite.loc[c,'count']==18]
   validity[(target,term)]={'target_finite_all18':tv,'controls_finite_all18':keep}
   validrows.append({'target':target,'term_id':term,'target_finite_all18':tv,'original_selected_controls':len(selected),'controls_finite_all18':len(keep),'eligible_ge30_controls':len(keep)>=30,'retained_original_control_symbols':';'.join(keep),'undefined_original_control_symbols':';'.join(c for c in selected if c not in keep),'no_replacement_controls':True})
 save(pd.DataFrame(validrows),RES/'Heat_全部45比较_严格全18模型数学有效性.tsv')
 permodel=comparison_rows(d,f,['model','sample_id','seed'],validity);perlib=comparison_rows(lib,f,['sample_id'],validity);globalc=comparison_rows(glob,f,[],validity)
 for table,scope in [(permodel,['model']), (perlib,['sample_id'])]:
  table['BH45_adjusted_conditional']=np.nan
  for _,ii in table.groupby(scope,sort=False).groups.items():
   assert len(ii)==45;table.loc[ii,'BH45_adjusted_conditional']=bh(table.loc[ii,'adjusted_P_for_fixed_family_BH'])
 assert len(globalc)==45
 globalc['BH45_adjusted_conditional']=bh(globalc.adjusted_P_for_fixed_family_BH)
 both=np.r_[globalc.adjusted_P_for_fixed_family_BH,globalc.raw_P_for_fixed_family_BH]
 q90=bh(both);globalc['BH90_adjusted_and_raw_sensitivity']=q90[:45];globalc['BH90_raw_sensitivity']=q90[45:]
 # Preserve threshold crossing counts as descriptive library consistency, never patient replicates.
 for j,row in globalc.iterrows():
  ll=perlib[perlib.target.eq(row.target)&perlib.term_id.eq(row.term_id)]
  vv=ll.adjusted_excess_over_control_median.to_numpy()
  globalc.loc[j,'libraries_positive_excess']=int(np.sum(vv>0))
  globalc.loc[j,'libraries_finite_excess']=int(np.isfinite(vv).sum())
 save(permodel,RES/'Heat_五候选_18模型_匹配背景比较.tsv')
 save(perlib,RES/'Heat_五候选_6文库_匹配背景比较.tsv')
 save(globalc,RES/'Heat_五候选_主45项匹配比较.tsv')
 # Shared-response similarity before/after correction ONLY for the ten pairs of five fixed candidates per model; not an all-KO global pairwise analysis.
 sim=[]
 for m in MODELS:
  z=np.load(RES/'heat_models'/m/'heat_全1500KO_原始扰动距离_float32.npz')
  a=np.load(RES/'heat_models'/m/'heat_共同响应_全KO校正profile_float32.npz')
  gi={v:i for i,v in enumerate(z['ko_genes'])};r=a['response_genes'].tolist();ri=[gi[v] for v in r]
  for t1,t2 in itertools.combinations(PRIMARY,2):
   for name,matrix in [('raw_common_response',z['distance'][:,ri]),('shared_adjusted',a['adjusted_profile'])]:
    x=matrix[gi[t1]];y=matrix[gi[t2]];good=np.isfinite(x)&np.isfinite(y)
    sim.append({**meta_model(m),'KO1':t1,'KO2':t2,'profile':name,'n_response_genes':int(good.sum()),'Spearman':float(spearmanr(x[good],y[good]).statistic)})
 save(pd.DataFrame(sim),RES/'Heat_五候选之间_共享响应相似性.tsv')
 summary={'models':18,'primary_KO':PRIMARY,'network_genes':1500,'all_KO_pathway_rows':len(d),'primary_pathway_hypotheses':45,'eligible_primary_pathway_comparisons':int(globalc.adjusted_eligible_conditional_comparison.sum()),'BH45_lt05_count':int(((globalc.BH45_adjusted_conditional<.05)&globalc.adjusted_eligible_conditional_comparison).sum()),'response_genes':len(f['response_genes']),'source_matching_sha256':sha(FROZEN),'aggregation':'three technical seeds median within library, then six library median; descriptive of3 patients, not n18','conditional_P_interpretation':'fitted-network matched KO comparison; no clinical direction, treatment reversal or independent validation'}
 dump(RES/'Heat_实际统计摘要.json',summary);print(json.dumps(summary,ensure_ascii=False),flush=True)
def corr_record(x,y,info):
 x=np.asarray(x,float);y=np.asarray(y,float);ok=np.isfinite(x)&np.isfinite(y)
 n=int(ok.sum());rr=float(spearmanr(x[ok],y[ok]).statistic) if n>=3 and np.ptp(x[ok])>0 and np.ptp(y[ok])>0 else np.nan
 k=min(100,n);xx=np.argsort(-x[ok],kind='stable')[:k];yy=np.argsort(-y[ok],kind='stable')[:k];jac=len(set(xx)&set(yy))/len(set(xx)|set(yy)) if k else np.nan
 return {**info,'n_response_genes':n,'Spearman':rr,'top100_Jaccard':jac}
def coords_check(p,g):
 c=pd.read_csv(p);names=c.iloc[:,0].astype(str).tolist();n=len(g)
 assert names==['X_'+v for v in g]+['Y_'+v for v in g],p
 a=c.iloc[:,1:].to_numpy(float);assert a.shape==(2*n,2) and np.isfinite(a).all()
 dist=np.sqrt(((a[:n]-a[n:])**2).sum(1))
 threshold=np.sqrt(np.finfo(float).eps)*np.abs(a).max()
 return dist,float(threshold)
def classic_summary(f):
 g=f['genes'];gi={v:i for i,v in enumerate(g)};response=f['response_genes'];ri=np.array([gi[v] for v in response])
 assert all((modeldir(m)/'ko_complete.csv').exists() for m in MODELS)
 rows=[];primaryrows=[];cross=[];shams=[];fitrows=[];boot=[];profiles={}
 for m in MODELS:
  dd=modeldir(m);complete=pd.read_csv(dd/'ko_complete.csv')
  z=np.load(RES/'heat_models'/m/'heat_全1500KO_原始扰动距离_float32.npz')
  ha=np.load(RES/'heat_models'/m/'heat_共同响应_全KO校正profile_float32.npz')
  assert z['ko_genes'].tolist()==g and ha['response_genes'].tolist()==response
  for _,rec in complete.iterrows():
   ko=str(rec.KO);dr=pd.read_csv(dd/f'classic_{ko}_全部基因.csv.gz').set_index('gene').reindex(g)
   assert dr.index.tolist()==g and dr.distance.notna().all()
   dist,noise=coords_check(dd/f'classic_{ko}_流形坐标.csv.gz',g)
   err=float(np.max(np.abs(dist-dr.distance.to_numpy())))
   assert err<1e-9
   own=np.array([v!=ko for v in g]);dv=dr.distance.to_numpy(float)
   row={**meta_model(m),'KO':ko,'kind':rec.kind,'distance_from_coordinates_max_error':err,'coordinate_noise_threshold':noise,'max_distance':float(dv.max()),'nonself_algorithm_q_lt05':int(((dr['p.adj'].to_numpy()<.05)&own).sum()),'total_genes_reported':len(dr),'nonself_genes':int(own.sum()),'algorithm_q_is_not_patient_DE_FDR':True}
   rows.append(row)
   if ko=='__NUMERICAL_SHAM__':
    shams.append({**row,'all_distances_at_or_below_coordinate_noise':bool((dv<=noise).all()),'algorithm_P_min':float(dr['p.value'].min()),'algorithm_P_max':float(dr['p.value'].max())})
    continue
   if ko not in PRIMARY:continue
   profiles[(m,ko)]=dv
   for j,gg in enumerate(g):
    if gg==ko:continue
    primaryrows.append({**meta_model(m),'KO':ko,'gene':gg,'distance':dv[j],'algorithm_Z':float(dr.iloc[j].Z),'algorithm_FC_NOT_logFC':float(dr.iloc[j].FC),'algorithm_P':float(dr.iloc[j]['p.value']),'algorithm_BH_within_KO':float(dr.iloc[j]['p.adj'])})
   cross.append(corr_record(dv[own],z['distance'][gi[ko],own],{**meta_model(m),'KO':ko,'comparison':'classic_raw_vs_heat_raw_nonself','shared_WT_not_independent_validation':True}))
   cross.append(corr_record(dv[ri],ha['adjusted_profile'][gi[ko]],{**meta_model(m),'KO':ko,'comparison':'classic_raw_vs_heat_shared_adjusted_common_readout','shared_WT_not_independent_validation':True}))
  fit=pd.read_csv(dd/'fit_complete.csv').iloc[0].to_dict();tx=(dd/'CP_官方拟合状态.txt').read_text(encoding='utf-8-sig')
  def num(key):
   match=re.search(r'\$\s*'+key+r'\s*:\s*num\s+([-+0-9.eE]+)',tx);return float(match.group(1)) if match else np.nan
  fit.update({'model':m,'CP_norm_explained_percent':num('norm_percent'),'CP_residual_frobenius':num('fnorm_resid'),'CP_converged':bool(re.search(r'\$\s*conv\s*:\s*logi\s+TRUE',tx)),'CP_convergence_does_not_imply_high_explained_variance':True})
  fitrows.append(fit)
  b=pd.read_csv(dd/'PCR_bootstrap_实际独特细胞数.csv');b.insert(0,'model',m);boot.append(b)
 primary=pd.DataFrame(primaryrows);assert len(primary)==18*5*(len(g)-1)
 primary['BH_all90_primary_nonself_sensitivity']=bh(primary.algorithm_P.to_numpy())
 save(primary,RES/'Classic_全部90主KO_非self基因与全族q敏感性.tsv.gz')
 save(pd.DataFrame(rows),RES/'Classic_全部KO_算法显著数与坐标核验.tsv')
 save(pd.DataFrame(shams),RES/'Classic_WT对WT数值sham核验.tsv')
 save(pd.DataFrame(cross),RES/'Classic_Heat_全部90主KO_相关与top100一致性.tsv')
 save(pd.DataFrame(fitrows),RES/'WT_18模型_CP解释比例与收敛状态.tsv')
 save(pd.concat(boot,ignore_index=True),RES/'WT_全部180bootstrap_独特细胞数量.tsv')
 # Technical repeatability and between-library contextual agreement.
 repeat=[];between=[]
 for method in ['classic_raw','heat_raw','heat_shared_adjusted']:
  for target in PRIMARY:
   bylib={}
   for sample in SAMPLES:
    vectors=[]
    for seed in SEEDS:
     m=f'{sample}_{seed}'
     if method=='classic_raw':v=profiles[(m,target)][ri]
     elif method=='heat_raw':
      a=np.load(RES/'heat_models'/m/'heat_全1500KO_原始扰动距离_float32.npz');v=a['distance'][gi[target],ri]
     else:
      a=np.load(RES/'heat_models'/m/'heat_共同响应_全KO校正profile_float32.npz');v=a['adjusted_profile'][gi[target]]
     vectors.append(v)
    for i,j in itertools.combinations(range(3),2):
     repeat.append(corr_record(vectors[i],vectors[j],{'method':method,'KO':target,'sample_id':sample,'seed1':SEEDS[i],'seed2':SEEDS[j],'replication_unit':'technical_random_seed_not_patient'}))
    bylib[sample]=np.median(np.array(vectors),axis=0)
   for s1,s2 in itertools.combinations(SAMPLES,2):
    between.append(corr_record(bylib[s1],bylib[s2],{'method':method,'KO':target,'sample1':s1,'sample2':s2,'same_phase':s1[0]==s2[0],'replication_unit':'library_context_descriptive;3patients withunknownpairing'}))
 save(pd.DataFrame(repeat),RES/'五候选_同库三随机种子_扰动谱稳定性.tsv')
 save(pd.DataFrame(between),RES/'五候选_跨六库_扰动谱描述性一致性.tsv')
 summary={'WT_models':18,'primary_classic_KO_runs':90,'classic_all_KO_including_controls_and_sham':len(rows),'all_primary_nonself_gene_rows':len(primary),'all_coordinate_checks_max_error':float(pd.DataFrame(rows).distance_from_coordinates_max_error.max()),'all_sham_within_numerical_noise':all(r['all_distances_at_or_below_coordinate_noise'] for r in shams),'CP_norm_explained_percent_min':float(pd.DataFrame(fitrows).CP_norm_explained_percent.min()),'CP_norm_explained_percent_max':float(pd.DataFrame(fitrows).CP_norm_explained_percent.max()),'CP_converged_models':sum(r['CP_converged'] for r in fitrows),'independent_validation':False,'patient_n':3,'source_frozen_match_sha256':sha(FROZEN)}
 dump(RES/'Classic_实际统计摘要.json',summary);print(json.dumps(summary,ensure_ascii=False),flush=True)
def main():
 parser=argparse.ArgumentParser()
 mode=parser.add_mutually_exclusive_group(required=True)
 mode.add_argument('--match',action='store_true');mode.add_argument('--heat',action='store_true');mode.add_argument('--classic',action='store_true')
 parser.add_argument('--model',choices=MODELS);parser.add_argument('--summary-only',action='store_true')
 a=parser.parse_args()
 if a.match:make_match();return
 f=verify_frozen();RES.mkdir(exist_ok=True)
 if a.heat:
  if not a.summary_only:
   for m in ([a.model] if a.model else MODELS):heat_one(m,f)
  if all((RES/'heat_models'/m/'heat_complete.json').exists() for m in MODELS):heat_summary(f)
  else:print('HEAT_PARTIAL_MODELS; summary waits for all18',flush=True)
 else:classic_summary(f)
if __name__=='__main__':main()

