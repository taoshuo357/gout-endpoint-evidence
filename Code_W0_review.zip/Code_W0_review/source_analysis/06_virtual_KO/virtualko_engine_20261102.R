# Pinned official numeric functions; all figures are drawn separately in Python.
BASE <- normalizePath(".",winslash="/",mustWork=TRUE)
OUT <- file.path(BASE,"虚拟敲除_2026-11-02")
.libPaths(c(file.path(OUT,"runtime/R_libraries"),file.path(BASE,"runtime/R_geo_libraries"),.libPaths()))
Sys.setenv(OMP_NUM_THREADS="2",OPENBLAS_NUM_THREADS="2",MKL_NUM_THREADS="2")
suppressPackageStartupMessages(library(Matrix))
RhpcBLASctl::blas_set_num_threads(2);RhpcBLASctl::omp_set_num_threads(2)
SR <- file.path(OUT,"02_方法源审计")
for (f in list.files(file.path(SR,"scTenifoldNet","R"),pattern="\\.R$",full.names=TRUE)) sys.source(f,envir=.GlobalEnv)
for (f in list.files(file.path(SR,"scTenifoldKnk","R"),pattern="\\.R$",full.names=TRUE)) sys.source(f,envir=.GlobalEnv)
args <- commandArgs(trailingOnly=TRUE);mode<-args[1];sampleName<-args[2];seed<-as.integer(args[3])
ID<-paste(sampleName,seed,sep="_");D<-file.path(OUT,"04_模型",ID);dir.create(D,recursive=TRUE,showWarnings=FALSE)
writeLines(as.character(Sys.getpid()),file.path(D,paste0(mode,"_R_pid.txt")))
P<-file.path(OUT,"01_输入与资格","网络1500_低内存固定输入")
genes<-read.delim(file.path(P,"网络1500_固定基因顺序.tsv"),check.names=FALSE,stringsAsFactors=FALSE)$gene_symbol
stopifnot(length(genes)==1500)
primary<-c("NLRP3","CASP1","IL1B","RELA","NFKB1")
stamp<-function(x)cat(format(Sys.time(),"%H:%M:%S"),ID,x,"\n")
savecsv<-function(x,p)write.csv(x,p,row.names=FALSE,fileEncoding="UTF-8")
loadInput<-function() {
 c<-read.delim(gzfile(file.path(P,paste0(sampleName,"_CD14_1500genes_raw_counts.tsv.gz"))),check.names=FALSE,stringsAsFactors=FALSE)
 stopifnot(identical(c[[1]],genes));X<-as.matrix(c[,-1]);rownames(X)<-c[[1]];storage.mode(X)<-"double"
 u<-read.delim(gzfile(file.path(P,paste0(sampleName,"_CD14_full_depth_UMI.tsv.gz"))),check.names=FALSE)
 # Named full-depth columns are checked without assuming ordering silently.
 stopifnot(nrow(u)==ncol(X))
 if ("cell_id"%in%names(u))stopifnot(identical(u$cell_id,colnames(X)))
 uk<-intersect(c("full_depth_UMI","UMI","full_feature_UMI","full33538_feature_UMI"),names(u))
 if(length(uk)!=1)stop(paste("Unknown fullUMI columns",paste(names(u),collapse=",")))
 U<-as.numeric(u[[uk]])
 other<-U-colSums(X);stopifnot(all(other>=0),all(U>0))
 padded<-rbind(X,"__OTHER_UMI__"=other);stopifnot(all(colSums(padded)==U))
 list(counts=X,padded=padded,UMI=U)
}
main<-function() {
 if(mode=="fit") {
  t0<-proc.time()[3];inp<-loadInput()
  XP<-cpmNormalization(inp$padded);X<-XP[genes,,drop=FALSE];rm(XP)
  stopifnot(identical(rownames(X),genes),!"__OTHER_UMI__"%in%rownames(X))
  lg<-log1p(as.matrix(X));mu<-rowMeans(lg);sdv<-sqrt(rowMeans((lg-mu)^2))
  # Observe actual bootstrap sample calls without changing the official function.
  # The wrapper calls base::sample once with the same arguments and returns exactly its result.
  boot_actual<-list()
  assign("sample",function(x,size,replace=FALSE,prob=NULL) {
    ans<-base::sample(x,size,replace,prob)
    if(length(x)==ncol(X)&&length(size)==1&&size==500&&isTRUE(replace)&&identical(as.integer(x),seq_len(ncol(X))))
      boot_actual[[length(boot_actual)+1L]]<<-ans
    ans
  },envir=.GlobalEnv)
  on.exit(if(exists("sample",envir=.GlobalEnv,inherits=FALSE))rm("sample",envir=.GlobalEnv),add=TRUE)
  stamp("PCR_START");set.seed(seed)
  nets<-makeNetworks(X,nNet=10,nCells=500,nComp=3,q=.9,scaleScores=TRUE,symmetric=FALSE,nCores=1,label=ID)
  rm("sample",envir=.GlobalEnv)
  stopifnot(length(boot_actual)==10)
  savecsv(data.frame(network=rep(seq_len(10),each=500),draw=rep(seq_len(500),10),cell_id=unlist(lapply(boot_actual,function(i)colnames(X)[i]))),gzfile(file.path(D,"PCR_bootstrap_实际全部抽样.csv.gz")))
  savecsv(data.frame(network=seq_len(10),draws=500,unique_cells=sapply(boot_actual,function(z)length(unique(z))),available_cells=ncol(X)),file.path(D,"PCR_bootstrap_实际独特细胞数.csv"))
  tp<-proc.time()[3];stamp(paste("PCR_DONE",round(tp-t0,2),"sec"))
  # Atomic directory lock serializes the only high-memory CP stage across two workers.
  lock<-file.path(OUT,"runtime","CP_exclusive.lock");dir.create(dirname(lock),recursive=TRUE,showWarnings=FALSE)
  releaseLock<-function() {
    if(!dir.exists(lock))return(invisible(TRUE))
    resolved<-normalizePath(lock,winslash="/",mustWork=TRUE)
    intended<-normalizePath(file.path(OUT,"runtime"),winslash="/",mustWork=TRUE)
    stopifnot(startsWith(resolved,paste0(intended,"/")),basename(resolved)=="CP_exclusive.lock",
              length(list.files(resolved,all.files=TRUE,no..=TRUE))==0L)
    # Windows R requires recursive=TRUE even for an EMPTY directory.
    # The absolute target, scope, basename and emptiness are all checked above.
    stopifnot(unlink(resolved,recursive=TRUE)==0L,!dir.exists(resolved))
    invisible(TRUE)
  }
  got<-FALSE
  on.exit({if(got&&dir.exists(lock))releaseLock()},add=TRUE)
  while(!dir.create(lock,showWarnings=FALSE))Sys.sleep(.3)
  got<-TRUE;gc();stamp("CP_START")
  originalCP<-cpDecomposition
  assign("cpDecomposition",function(...) {
    ans<-originalCP(...)
    capture.output(str(ans[c("fnorm_resid","norm_percent","conv","num_components","all_resids")],max.level=1),file=file.path(D,"CP_官方拟合状态.txt"))
    if(!is.null(ans$all_resids))savecsv(data.frame(iteration=seq_along(ans$all_resids),residual=ans$all_resids),file.path(D,"CP_全部迭代残差.csv"))
    ans
  },envir=.GlobalEnv)
  on.exit(assign("cpDecomposition",originalCP,envir=.GlobalEnv),add=TRUE)
  td<-tensorDecomposition(nets,K=3,maxIter=1000,maxError=1e-5,nDecimal=3,seed=seed)
  assign("cpDecomposition",originalCP,envir=.GlobalEnv)
  W<-t(td$X);diag(W)<-0;rownames(W)<-colnames(W)<-genes
  stopifnot(all(is.finite(W@x)),all(primary%in%rownames(W)))
  rm(nets,td,lg);gc()
  releaseLock();got<-FALSE;stopifnot(!dir.exists(lock))
  tc<-proc.time()[3];stamp(paste("CP_DONE",round(tc-tp,2),"sec incl_lock"))
  saveRDS(W,file.path(D,"WT_official_pinned.rds"),compress="gzip")
  # CSV stores rounded official WT exactly; rows are regulators, columns are targets.
  wb<-gzfile(file.path(D,"WT_有向权重矩阵_float64列优先.bin.gz"),"wb",compression=3)
  writeBin(as.double(as.matrix(W)),wb,size=8,endian="little");close(wb)
  writeLines(c("shape=1500,1500","dtype=little-endian float64","order=Fortran column-major","rows=regulators","columns=targets","row_and_column_names=network1500 common gene order"),file.path(D,"WT_binary_format.txt"))
  st<-data.frame(gene=genes,mean_log1p_fullCPM=mu,sd_log1p_fullCPM=sdv,mean_fullCPM=rowMeans(X),detection=rowMeans(inp$counts>0),abs_out_strength=as.numeric(rowSums(abs(W))),abs_in_strength=as.numeric(colSums(abs(W))))
  st$symmetric_abs_strength<-as.numeric(rowSums(abs((W+t(W))/2)))
  savecsv(st,file.path(D,"WT_无KO匹配协变量.csv"))
  savecsv(data.frame(sample_id=sampleName,seed=seed,mode=mode,n_genes=length(genes),CD14_cells=ncol(X),nNet=10,bootstrap_draws=500,PCR_seconds=tp-t0,CP_and_lock_seconds=tc-tp,wall_seconds=proc.time()[3]-t0,R_PID=Sys.getpid()),file.path(D,"fit_complete.csv"))
  capture.output(sessionInfo(),file=file.path(D,"R_sessionInfo.txt"));stamp("FIT_COMPLETE")
 } else if(mode=="ko") {
  t0<-proc.time()[3];W<-readRDS(file.path(D,"WT_official_pinned.rds"))
  controls<-read.delim(file.path(OUT,"05_匹配背景","经典法_代表匹配KO.tsv"),stringsAsFactors=FALSE)
  targets<-unique(c(primary,controls$control))
  summary<-list()
  for(g in c("__NUMERICAL_SHAM__",targets)) {
   t1<-proc.time()[3];K<-W
   if(g!="__NUMERICAL_SHAM__")K[g,]<-0
   set.seed(seed);stamp(paste("MA_START",g))
   MA<-manifoldAlignment(W,K,d=2,nCores=2)
   dr<-dRegulation(MA,gKO=if(g=="__NUMERICAL_SHAM__")character(0) else g,empiricalNull=FALSE)
   savecsv(dr,gzfile(file.path(D,paste0("classic_",g,"_全部基因.csv.gz"))))
   savecsv(data.frame(gene=rownames(MA),MA),gzfile(file.path(D,paste0("classic_",g,"_流形坐标.csv.gz"))))
   summary[[g]]<-data.frame(sample_id=sampleName,seed=seed,KO=g,kind=if(g%in%primary)"Primary" else if(g=="__NUMERICAL_SHAM__")"Numerical_sham" else "Matched_representative",seconds=proc.time()[3]-t1,n_genes=nrow(dr),algorithm_BH_lt05=sum(dr$p.adj<.05,na.rm=TRUE),max_distance=max(dr$distance))
   rm(K,MA,dr);gc();stamp(paste("MA_DONE",g))
  }
  savecsv(do.call(rbind,summary),file.path(D,"ko_complete.csv"));stamp("KO_COMPLETE")
 } else if(mode=="reference_heat") {
  inp<-loadInput();W<-readRDS(file.path(D,"WT_official_pinned.rds"));diag(W)<-0
  H<-heatKernel(W,t=10);D0<-hkManifoldAlignment(W,inp$padded,gKO=NULL,t=10,H=H)
  write.table(D0,gzfile(file.path(D,"heat_官方R全1500KO_核验.tsv.gz")),sep="\t",row.names=TRUE,col.names=NA,quote=FALSE)
  stamp("REFERENCE_HEAT_COMPLETE")
 } else stop("mode must be fit, ko, or reference_heat")
}
main()

