from pathlib import Path
import sys,csv,gzip,json,hashlib,shutil
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'runtime/ppi_analysis_libraries'))
import pandas as pd,numpy as np
from scipy import sparse
P=BASE/'虚拟敲除_2026-11-02/01_输入与资格'
Q=P/'网络1500_低内存固定输入';OLD=P/'网络2000_固定输入'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
pool=pd.read_csv(Q/'网络1500_固定基因顺序.tsv',sep='\t');rows=[]
oldg=pd.read_csv(OLD/'网络2000_固定基因顺序.tsv',sep='\t')
forced=oldg[oldg.proposed_reason.ne('equal_library_dispersion_rank')]
ranked=oldg[oldg.proposed_reason.eq('equal_library_dispersion_rank')].sort_values(['suggested_common_pool_rank','gene_symbol'],kind='stable').head(1028)
assert set(pool.gene_symbol)==set(forced.gene_symbol)|set(ranked.gene_symbol)
for s in ['A1','A2','A3','B1','B2','B3']:
 x=sparse.load_npz(Q/(s+'_CD14_1500genes_raw_counts.npz')).tocsr()
 meta=pd.read_csv(P/(s+'_CD14_细胞顺序.tsv.gz'),sep='\t')
 old=sparse.load_npz(OLD/(s+'_CD14_2000genes_raw_counts.npz')).tocsr()
 assert (x-old[pool.network2000_gene_index_0based.to_numpy()]).nnz==0
 with gzip.open(Q/(s+'_CD14_1500genes_raw_counts.tsv.gz'),'rt',encoding='utf-8',newline='') as f:
  r=csv.reader(f,delimiter='\t');header=next(r)
  assert header[0]=='gene_symbol' and header[1:]==meta.cell_id.tolist()
  k=0
  for k,row in enumerate(r,start=1):
   assert row[0]==pool.gene_symbol.iloc[k-1]
   assert np.array_equal(np.asarray(row[1:],dtype=np.int32),x[k-1].toarray().ravel())
  assert k==1500
 assert sha(Q/(s+'_CD14_full_depth_UMI.npy'))==sha(OLD/(s+'_CD14_full_depth_UMI.npy'))
 d=np.load(Q/(s+'_CD14_full_depth_UMI.npy'))
 assert np.array_equal(d,meta.UMI.to_numpy())
 rows.append({'sample_id':s,'all1500_TSV_rows_all_cell_values_equal_NPZ':True,'same472_forced_and1028_original_ranked_set':True,'raw_counts_exact_subset_of2000':True,'full33538_UMI_array_identical_SHA_to2000':True,'full_depth_equals_frozen_original_metadata':True})
 print('1500_STORAGE_CHECKED',s,flush=True)
before=json.loads((Q/'原2000输入_SHA256_修订前.json').read_text(encoding='utf-8'))
assert all(sha(r['path'])==r['sha256'] for r in before)
dump(Q/'网络1500_独立存储与盲态修订核验.json',{'all_checks_passed':True,'all_old2000_source_files_SHA_unchanged':True,'old2000_preserved':True,'no_KO_outcomes_used':True,'gene_pool_selection_equals_rule':True,'cell_count':8564,'per_library':rows})
(Q/'网络1500_请先读.txt').write_text('这是在任何正式KO拟合前、由RAM可用量下降触发的低内存资源修订。原2000池完整保留，472个forced不变，只按同一原预定dispersion名次把其它1528缩为1028，未查看KO或临床结果。六库共8564细胞、原33538-feature UMI总量完全保持。原始整数计数NPZ与gzip TSV均为1500genes×allCD14cells，gene顺序统一；full_depth_UMI.npy与原2000对应文件逐字节SHA相同。若归一化为CPM，分母须使用full33538_UMI，不用selected1500之和。所有TSV行/列和值与NPZ逐值核对通过，原2000目录每份文件SHA保持。root正式分析继续采用500cell、10 PCR networks、3seeds，后续网络推断不在本输入子模块执行。源码实际入口在项目根ko_input_1500_memory_amendment_20261102.py及ko_input_1500_storage_audit_20261102.py；本目录副本供审阅，不应当作独立项目根直接执行。',encoding='utf-8')
shutil.copy2(Path(__file__),Q/Path(__file__).name)
manifest=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(Q.iterdir()) if p.is_file() and p.name!='网络1500_全部输出SHA256.json']
dump(Q/'网络1500_全部输出SHA256.json',manifest)
print('ALL_1500_INPUT_CHECKS_PASS',len(manifest),sum(r['bytes'] for r in manifest),flush=True)

