"""LIANA 2.1.0 official per-library rank aggregation, frozen before real outputs.
Old G analysis is read-only. No stage P values or figures are generated here.
"""
from pathlib import Path
import os,sys,json,csv,time,gc,hashlib,datetime,inspect,importlib.metadata,argparse
E=Path(__file__).resolve().parent;assert E.drive.upper()=='E:'
G=Path('G:/痛风/第二步_靶点预测与疾病交集');O=E/'03_LIANA官方方法';D=E/'runtime/专有LIANAlibs'
for p in reversed([D,G/'runtime/ppi_analysis_libraries',G/'论文推进_2026-10-30/单细胞定位/runtime']):sys.path.insert(0,str(p))
import numpy as np,pandas as pd,anndata as ad,liana as li,scanpy as sc,psutil
from scipy import sparse
SC=G/'论文推进_2026-10-30/单细胞定位'
META=SC/'结果表/全部QC细胞_最终保守注释.csv.gz'
FEATURES=G/'GEO表达核验_2026-10-29/独立队列_GSE211783/预处理/人类基因特征.csv'
RESOURCE=G/'全面验证_2026-11-02/05_调控与通讯/LR_完整consensus输入.tsv'
MAN=SC/'结果表/细胞类型pseudobulk输入清单.csv'
SAMPLES=['A1','A2','A3','B1','B2','B3']
TYPES=['B','CD14 monocytes','CD16 monocytes','Cytotoxic T','DC-like','IL7R+ T','NK','Neutrophil-like']
CONTRACT=O/'真实计算前冻结合同.json'
for p in [O/'逐库结果',O/'图源数据',O/'质量核验']:p.mkdir(exist_ok=True,parents=True)
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def timestamp():return datetime.datetime.now().astimezone().isoformat()
def prepare():
 assert not list((O/'逐库结果').glob('*/*_完成.json'))
 toy=json.loads((O/'官方接口_合成夹具核验.json').read_text(encoding='utf-8'));assert toy['status']=='PASS'
 feat=pd.read_csv(FEATURES);obs=pd.read_csv(META);lr=pd.read_csv(RESOURCE,sep='\t')[['ligand','receptor']].drop_duplicates()
 assert len(feat)==33538 and len(obs)==53940 and len(lr)==4620
 assert feat.source_symbol.notna().all() and not feat.source_symbol.eq('').any()
 m=pd.read_csv(MAN);eligible=m[m.eligible_all6_ge30_cells&(~m.cell_type.isin(['Platelet mixed','Unresolved']))].cell_type.tolist()
 assert set(eligible)==set(TYPES)
 sources=[META,FEATURES,RESOURCE,MAN,Path(__file__).resolve(),*(SC/'预处理'/(s+'_QC_counts.npz') for s in SAMPLES)]
 contract={'created':timestamp(),'question':'Which LR interactions rank strongly in each original library under the official LIANA multi-method aggregation, and how do eligibility/rankings compare with the earlier custom score?','status':'No real official LIANA outcome has been generated','data':'GSE211783 frozen QC/annotation,3patients6libraries; A-B donor crosswalk unverified','input_QC_cells':53940,'original_feature_rows':33538,'raw_sum_duplicate_symbols':True,'unique_symbols':int(feat.source_symbol.nunique()),'celltypes':TYPES,'types_selected_by_existing_minimum_cells_rule_ge30_per_library':True,'normalization':'full33538-feature raw UMI per cell -> duplicate symbol raw count sum -> CP10k -> natural log1p; all features supplied, no LR-only denominator','methods':'Official liana.mt.rank_aggregate, its five default methods (CellPhoneDB,Connectome,log2FC,NATMI,SingleCellSignalR), default robust rank aggregation','LIANA':importlib.metadata.version('liana'),'scanpy':importlib.metadata.version('scanpy'),'anndata':importlib.metadata.version('anndata'),'resource':'Frozen original4620 unique consensus LR pairs supplied as custom resource; no live resource replacement','primary_expr_prop':0.05,'legacy_comparable_sensitivity_expr_prop':0.10,'min_cells':30,'permutation_count':None,'n_perms_None_effect':'No CellPhoneDB permutation P or other cell-label permutation P; specificity aggregate excludes unavailable permutation scores, keeps Connectome/log2FC/NATMI scores. Magnitude scores from four default methods retained.','return_all_lrs':True,'seed':1337,'n_jobs':1,'run_each_library_separately':True,'eligibility':'Retain all original4620x8x8 rows in an independent all-subunit detection audit; do NOT require all6 samples pass. Missing resources/nonexpressed pairs remain explicit and distinguishable from biological negatives.','rank_semantics':'Lower RRA scores rank higher; magnitude_rank and specificity_rank are NOT patient P values; specificity means cell-type-pair specificity, not disease/drug/previous-KO specificity.','comparisons':'Descriptive per-library ranks/availability, phase medians and no P-value phase effect claim; no donor n inflation','prior_primary_results_unchanged':True,'no_new_figures_here':True,'sources':[{'path':str(p),'bytes':p.stat().st_size,'SHA256':sha(p)} for p in sources]}
 dump(CONTRACT,contract);print('FROZEN',sha(CONTRACT),len(lr),eligible,flush=True)
def load_frozen():
 f=json.loads(CONTRACT.read_text(encoding='utf-8'));assert f['LIANA']==li.__version__=='2.1.0'
 for x in f['sources']:
  if x['path'].endswith('.py'):assert sha(x['path'])==x['SHA256'],'Do not change the running analysis source'
 return f

def one(s):
 frozen=load_frozen();od=O/'逐库结果'/s;od.mkdir(exist_ok=True)
 if (od/(s+'_完成.json')).exists():print('SKIP',s,flush=True);return
 t0=time.time();obs=pd.read_csv(META);sub=obs[obs.sample_id.eq(s)].copy();feat=pd.read_csv(FEATURES)
 mat=sparse.load_npz(SC/'预处理'/(s+'_QC_counts.npz')).tocsr();assert mat.shape==(len(sub),33538)
 totals=np.asarray(mat.sum(1)).ravel();assert np.array_equal(totals,sub.UMI.to_numpy()) and np.all(totals>0)
 syms=pd.Index(pd.unique(feat.source_symbol));codes=syms.get_indexer(feat.source_symbol)
 mapper=sparse.csr_matrix((np.ones(len(feat),dtype=np.int32),(np.arange(len(feat)),codes)),shape=(len(feat),len(syms)))
 x=(mat@mapper).tocsr();assert np.array_equal(np.asarray(x.sum(1)).ravel(),totals)
 keep=sub.cell_type.isin(TYPES).to_numpy();removed=sub[~keep].groupby('cell_type',observed=True).size()
 xc=x[keep].astype(np.float32);ot=sub.loc[keep].copy();u=totals[keep]
 n_by_type=ot.groupby('cell_type',observed=True).size();assert set(n_by_type.index)==set(TYPES) and n_by_type.min()>=30
 # Detection fractions before log1p. Counts and normalization retained on full feature universe.
 props=np.stack([np.asarray((xc[ot.cell_type.eq(ct).to_numpy()]>0).mean(0)).ravel() for ct in TYPES])
 norm=(sparse.diags((10000/u).astype(np.float32))@xc).tocsr();norm.data=np.log1p(norm.data)
 # Verify selected values from the independent formula; do not call normalization twice.
 coord=xc.tocoo();take=np.linspace(0,len(coord.data)-1,min(100,len(coord.data)),dtype=int)
 for k in take:
  r,c,v=int(coord.row[k]),int(coord.col[k]),float(coord.data[k])
  assert np.isclose(float(norm[r,c]),np.log1p(v/u[r]*10000),rtol=2e-6,atol=2e-6)
 a=ad.AnnData(norm,obs=ot.set_index('cell_id')[['sample_id','phase','cell_type']],var=pd.DataFrame(index=syms.astype(str)))
 a.obs['cell_type']=pd.Categorical(a.obs.cell_type,categories=TYPES);a.uns['log1p']={'base':None}
 del mat,x,xc,coord,mapper,norm;gc.collect()
 resource=pd.read_csv(RESOURCE,sep='\t')[['ligand','receptor']].drop_duplicates().reset_index(drop=True)
 def entity_info(names):
  present=[];mini=[]
  for nm in names:
   ix=syms.get_indexer(str(nm).split('_'));has=bool((ix>=0).all());present.append(has)
   mini.append(props[:,ix].min(axis=1) if has else np.full(len(TYPES),np.nan))
  return np.asarray(present),np.array(mini).T
 lp,lprops=entity_info(resource.ligand);rp,rprops=entity_info(resource.receptor);mapped=lp&rp
 rows=[]
 for si,source in enumerate(TYPES):
  for ti,target in enumerate(TYPES):
   q=resource.copy();q.insert(0,'target',target);q.insert(0,'source',source)
   q['all_ligand_subunits_mapped']=lp;q['all_receptor_subunits_mapped']=rp
   q['ligand_min_subunit_detection']=lprops[si];q['receptor_min_subunit_detection']=rprops[ti]
   for label,th in [('05',.05),('10',.10)]:q['eligible_expr_prop_'+label]=mapped&(lprops[si]>=th)&(rprops[ti]>=th)
   rows.append(q)
 eligibility=pd.concat(rows,ignore_index=True);assert len(eligibility)==4620*64
 eligibility.to_csv(od/(s+'_全部LR_两阈值资格.tsv.gz'),sep='\t',index=False,compression='gzip')
 summaries=[]
 for label,th in [('05',.05),('10',.10)]:
  print('OFFICIAL_START',s,th,a.shape,'RSS_MiB',round(psutil.Process().memory_info().rss/1024**2),flush=True)
  before=time.time()
  res=li.mt.rank_aggregate(a,groupby='cell_type',resource=resource.copy(),expr_prop=th,min_cells=30,n_perms=None,return_all_lrs=True,seed=1337,n_jobs=1,use_raw=False,inplace=False,verbose=True)
  assert not res.duplicated(['source','target','ligand_complex','receptor_complex']).any()
  assert not any('pval' in c for c in res.columns)
  res.insert(0,'sample_id',s);res['phase']='Acute' if s[0]=='A' else 'Remission'
  keys=['source','target','ligand_complex','receptor_complex'];audit=eligibility.rename(columns={'ligand':'ligand_complex','receptor':'receptor_complex'})
  full=audit.merge(res,on=keys,how='left',validate='1:1',indicator='official_row_status')
  full['sample_id']=s;full['phase']='Acute' if s[0]=='A' else 'Remission'
  assert len(full)==4620*64
  eligible_col='eligible_expr_prop_'+label
  assert full.loc[full[eligible_col],['magnitude_rank','specificity_rank']].notna().all().all()
  # Save complete official matrix and full-universe audit; neither is cross-library intersection gated.
  res.to_csv(od/(s+'_官方原始rank_aggregate_expr'+label+'.tsv.gz'),sep='\t',index=False,compression='gzip')
  full.to_csv(od/(s+'_全资源左连接_官方排名_expr'+label+'.tsv.gz'),sep='\t',index=False,compression='gzip')
  group=full.groupby(['source','target'],observed=True).agg(resource_rows=('ligand_complex','size'),eligible_pairs=(eligible_col,'sum'),official_rows=('magnitude_rank','count')).reset_index();group['sample_id']=s;group['expr_prop']=th
  group.to_csv(od/(s+'_逐细胞类型对_资格计数_expr'+label+'.tsv'),sep='\t',index=False)
  eligible=full[full[eligible_col]].copy();eligible['magnitude_percentile_within_library']=eligible.magnitude_rank.rank(method='average',pct=True)
  eligible.sort_values('magnitude_rank').head(30).to_csv(od/(s+'_表达合格_按官方强度前30_expr'+label+'.tsv'),sep='\t',index=False)
  summaries.append({'expr_prop':th,'official_returned_rows':len(res),'all_original_resource_rows':len(full),'independent_eligible_rows':int(full[eligible_col].sum()),'eligible_missing_official_rows':int(full.loc[full[eligible_col],'magnitude_rank'].isna().sum()),'seconds':time.time()-before,'RSS_MiB_after':psutil.Process().memory_info().rss/1024**2,'P_columns':[]})
  del res,full,audit,group,eligible;gc.collect()
 qc={'sample':s,'source_QC_cells':len(sub),'selected_eight_types_cells':len(ot),'original_features':33538,'unique_symbols':len(syms),'UMI_full_depth_exactly_preserved':True,'normalization_formula_checks':len(take),'UMI_selected_cells_total':int(u.sum()),'celltype_cells':{str(k):int(v) for k,v in n_by_type.items()},'excluded_celltypes':{str(k):int(v) for k,v in removed.items()},'mapped_pairs':int(mapped.sum()),'complete_sources':frozen['sources'],'threshold_results':summaries,'wall_seconds':time.time()-t0,'frozen_contract_SHA256':sha(CONTRACT),'source_SHA256':sha(Path(__file__)),'finished':timestamp()}
 dump(od/(s+'_完成.json'),qc);print('LIBRARY_COMPLETE',s,round(time.time()-t0,1),flush=True)

def summary():
 markers=[O/'逐库结果'/s/(s+'_完成.json') for s in SAMPLES];assert all(p.exists() for p in markers)
 rows=[]
 for p in markers:
  j=json.loads(p.read_text(encoding='utf-8'))
  for r in j['threshold_results']:rows.append({'sample_id':j['sample'],'selected_eight_types_cells':j['selected_eight_types_cells'],**r})
 pd.DataFrame(rows).to_csv(O/'LIANA_六文库两阈值完成汇总.tsv',sep='\t',index=False)
 # Complete eligibility union/intersection numbers and equal-library descriptive network matrices.
 result={}
 for label,th in [('05',.05),('10',.10)]:
  frames=[]
  for s in SAMPLES:
   p=O/'逐库结果'/s/(s+'_全资源左连接_官方排名_expr'+label+'.tsv.gz')
   f=pd.read_csv(p,sep='\t',usecols=['source','target','ligand_complex','receptor_complex','magnitude_rank','specificity_rank','sample_id','phase','eligible_expr_prop_'+label]);frames.append(f)
  f=pd.concat(frames,ignore_index=True);assert len(f)==6*4620*64
  key=['source','target','ligand_complex','receptor_complex'];ek='eligible_expr_prop_'+label
  n=f.groupby(key,observed=True)[ek].sum().rename('libraries_expression_eligible').reset_index();n.to_csv(O/('LIANA_全部LR_合格文库数_expr'+label+'.tsv.gz'),sep='\t',index=False,compression='gzip')
  # Numerical rank summaries only where expression eligibility is explicit; no zero filling.
  valid=f[f[ek]].copy();valid.to_csv(O/('LIANA_六库全部表达合格排名_expr'+label+'.tsv.gz'),sep='\t',index=False,compression='gzip')
  net=valid.groupby(['sample_id','phase','source','target'],observed=True).agg(eligible_pairs=('ligand_complex','size'),magnitude_rank_median=('magnitude_rank','median'),specificity_rank_median=('specificity_rank','median')).reset_index();net.to_csv(O/'图源数据'/('LIANA_全部64方向对逐库网络描述_expr'+label+'.tsv'),sep='\t',index=False)
  result[label]={'expr_prop':th,'all_resource_sample_rows':len(f),'eligible_sample_rows':len(valid),'LR_typepairs_eligible_any_library':int((n.libraries_expression_eligible>0).sum()),'eligible_all6':int(n.libraries_expression_eligible.eq(6).sum()),'some_not_all6':int(n.libraries_expression_eligible.between(1,5).sum()),'phase_tests_performed':False}
 dump(O/'LIANA官方方法_实际完成摘要.json',{'status':'COMPLETED_DESCRIPTIVE_OFFICIAL_METHOD_COMPARISON','finished':timestamp(),'libraries':6,'patients':3,'celltypes':TYPES,'resource_pairs':4620,'method':'LIANA2.1.0 official rank_aggregate,expr_prop.05primary/.10legacy sensitivity, n_permsNone,RRA','results':result,'independent_biological_validation':False,'patient_level_P_values_computed':False,'old_primary_results_changed':False,'A_B_pairing_assumed':False,'all6_LR_eligibility_required':False,'plot_created':False,'frozen_contract_SHA256':sha(CONTRACT)})
 print(json.dumps(result,ensure_ascii=False),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','run','summary']);p.add_argument('--sample',choices=SAMPLES);a=p.parse_args()
 if a.mode=='prepare':prepare()
 elif a.mode=='summary':summary()
 else:
  for s in ([a.sample] if a.sample else SAMPLES):one(s)
  if not a.sample:summary()
