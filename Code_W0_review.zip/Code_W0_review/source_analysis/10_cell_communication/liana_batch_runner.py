from pathlib import Path
import sys,subprocess,time,json,os
E=Path(__file__).resolve().parent;G=Path('G:/痛风/第二步_靶点预测与疾病交集');O=E/'03_LIANA官方方法'
sys.path.insert(0,str(G/'runtime/ppi_analysis_libraries'));import psutil
log=O/'运行日志/六库逐库官方方法.log'
with log.open('w',encoding='utf-8') as f:
 p=subprocess.Popen([sys.executable,str(E/'liana_official_run.py'),'run'],cwd=E,env=os.environ.copy(),stdout=f,stderr=subprocess.STDOUT)
 peak=0;t0=time.time();print('LIANA_BATCH_START',p.pid,flush=True)
 while p.poll() is None:
  try:peak=max(peak,psutil.Process(p.pid).memory_info().rss)
  except psutil.Error:pass
  completed=sorted(str(x.parent.name) for x in (O/'逐库结果').glob('*/*_完成.json'))
  (O/'运行状态.json').write_text(json.dumps({'PID':p.pid,'elapsed_seconds':time.time()-t0,'peak_RSS_bytes_observed':peak,'libraries_complete':completed,'all_serial':True},ensure_ascii=False,indent=2),encoding='utf-8');time.sleep(2)
 result={'returncode':p.returncode,'seconds':time.time()-t0,'peak_RSS_bytes_observed':peak,'log':str(log)}
 (O/'运行日志/六库runner完成.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False),flush=True)
 if p.returncode:raise RuntimeError('Check '+str(log))
