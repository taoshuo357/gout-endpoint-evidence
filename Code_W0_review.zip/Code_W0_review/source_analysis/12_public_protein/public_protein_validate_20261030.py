"""Bounded secondary protein analysis; all contrasts fixed before estimation."""
from pathlib import Path
import sys,json,csv,re,hashlib,collections,math,datetime
BASE=Path(__file__).resolve().parent;OUT=BASE/'论文推进_2026-10-30'/'公开蛋白与临床资源核查'
sys.path.insert(0,str(BASE/'runtime'/'ppi_analysis_libraries'))
import openpyxl,numpy as np,scipy
from scipy import stats
assert (OUT/'蛋白验证_分析合同_先于组差计算.txt').exists()
contract_hash=hashlib.sha256((OUT/'蛋白验证_分析合同_先于组差计算.txt').read_bytes()).hexdigest()
def dump(name,x):(OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False,default=lambda v:float(v) if isinstance(v,np.generic) else str(v)),encoding='utf-8')
def write(name,rows):
    if not rows:return
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def missing(v):return v is None or str(v).strip() in {'#NULL!','#VALUE!','#N/A','#NUM!','#DIV/0!',''}
def number(v):return float(v) if not missing(v) and isinstance(v,(int,float)) and not isinstance(v,bool) else np.nan
def clinicalid(v):
    m=re.fullmatch(r'MLPG-(\d+)',str(v),re.I);return int(m.group(1)) if m else None
def proteinid(v):
    m=re.fullmatch(r'm\s+(\d+)(?:\s+Ser)?',str(v),re.I);return int(m.group(1)) if m else None
def token(k):return hashlib.sha256(('public_Zenodo23181166:'+str(k)).encode()).hexdigest()[:16]
wb=openpyxl.load_workbook(next(OUT.glob('DATOS*.xlsx')),read_only=True,data_only=True);raw=list(wb.active.iter_rows(values_only=True));headers=raw[0]
clinical={clinicalid(r[0]):dict(zip(headers,r)) for r in raw[1:] if clinicalid(r[0]) is not None};wb.close();assert len(clinical)==124
with (OUT/'UniProt_92_assay_gene_map.tsv').open(encoding='utf-8-sig',newline='') as f:gene_map={r['Entry']:r['Gene Names (primary)'] for r in csv.DictReader(f,delimiter='\t')}
candidate=set((BASE/'合并交集_2026-10-29'/'痛风交集_候选基因.txt').read_text(encoding='utf-8-sig').split());assert len(candidate)==397
with (BASE/'论文推进_2026-10-30'/'单细胞定位'/'结果表'/'SC05_12优先靶点细胞来源点图_源数据.csv').open(encoding='utf-8-sig',newline='') as f:hubs=sorted({r['gene_symbol'] for r in csv.DictReader(f)})
panels={};clean=[];assaymap=[];sampling=[];excluded=[]
for tissue,fn,flag in [('SF_cell_lysate','Synovial Cells_NPX para ZENODO.xlsx','LS_protOLINK'),('Serum','Serum_NPX para ZENODO.xlsx','Suero_protOLINK')]:
    wb=openpyxl.load_workbook(OUT/fn,read_only=True,data_only=True);rows=list(wb.active.iter_rows(values_only=True));wb.close()
    assays=list(rows[3][2:94]);uniprot=list(rows[4][2:94]);olink=list(rows[5][2:94]);genes=[gene_map.get(u,'') for u in uniprot];assert len(genes)==92 and all(genes) and len(set(genes))==92
    lods={str(r[1]):np.array([number(v) for v in r[2:94]]) for r in rows if len(r)>1 and str(r[1]) in ['MaxLOD','PlateLOD']};assert len(lods)==2 and np.isfinite(lods['MaxLOD']).all()
    ids=[];values=[];qcs=[];xr=[]
    for excelrow,row in enumerate(rows,1):
        k=proteinid(row[1]) if len(row)>1 else None
        if k is None:continue
        assert k in clinical
        ids.append(k);values.append([number(v) for v in row[2:94]]);qcs.append(str(row[95]));xr.append(excelrow)
    assert len(ids)==len(set(ids)) and set(ids)=={k for k,r in clinical.items() if r.get(flag)==1}
    mat=np.array(values,dtype=float);assert np.isfinite(mat).all() and set(qcs)=={'Pass'}
    inc=np.array([clinical[k].get('INCLUIDOS')==1 and clinical[k].get('EXCLUIDOS')==0 for k in ids]);grp=np.array([int(clinical[k]['GRUPOHUA']) for k in ids]);typ=np.array([int(clinical[k]['Tipo']) for k in ids]);assert set(grp)<={1,2,3}
    for i,k in enumerate(ids):
        if not inc[i]:excluded.append({'tissue':tissue,'sample_token':token(k),'clinical_include_code':clinical[k].get('INCLUIDOS'),'clinical_exclude_code':clinical[k].get('EXCLUIDOS'),'GRUPOHUA':int(grp[i]),'Tipo':int(typ[i]),'reason':'public inclusion/exclusion flag, exact clinical diagnosis reason not established'})
        for j,gene in enumerate(genes):clean.append({'tissue':tissue,'donor_token':token(k),'GRUPOHUA_code':int(grp[i]),'Tipo_code':int(typ[i]),'strict_include':bool(inc[i]),'gene':gene,'assay':assays[j],'UniProt':uniprot[j],'OlinkID':olink[j],'raw_NPX':mat[i,j],'MaxLOD':lods['MaxLOD'][j],'PlateLOD':lods['PlateLOD'][j],'below_MaxLOD':bool(mat[i,j]<lods['MaxLOD'][j]),'QC':'Pass','source_excel_row':xr[i]})
    for j,gene in enumerate(genes):assaymap.append({'tissue':tissue,'assay':assays[j],'UniProt':uniprot[j],'HGNC_symbol_from_UniProt':gene,'OlinkID':olink[j],'in397':gene in candidate,'in12':gene in hubs,'MaxLOD':lods['MaxLOD'][j],'PlateLOD':lods['PlateLOD'][j]})
    for scope,sel in [('all_proteomic',np.ones(len(ids),dtype=bool)),('strict_inclusion',inc)]:
        sampling.append({'tissue':tissue,'selection':scope,'n_unique_donors':int(sel.sum()),'GRUPOHUA1':int(((grp==1)&sel).sum()),'GRUPOHUA2':int(((grp==2)&sel).sum()),'GRUPOHUA3':int(((grp==3)&sel).sum()),'Tipo0':int(((typ==0)&sel).sum()),'Tipo1':int(((typ==1)&sel).sum()),'Tipo2':int(((typ==2)&sel).sum())})
    panels[tissue]={'ids':ids,'raw':mat,'lod':lods,'include':inc,'group':grp,'type':typ,'genes':genes,'assays':assays}
write('蛋白验证_92指标官方基因映射.csv',assaymap);write('蛋白验证_清洁长表_散列供者.csv',clean);write('蛋白验证_样本纳入流程.csv',sampling);write('蛋白验证_排除标记矛盾.csv',excluded)
def bh(values):
    vals=np.array(values,dtype=float);order=np.argsort(vals);out=np.empty(len(vals));ranked=vals[order]*len(vals)/np.arange(1,len(vals)+1);out[order]=np.minimum.accumulate(ranked[::-1])[::-1].clip(0,1);return out
def compare(p,indices,j,policy,contrast):
    matrix=p['raw'];floor=p['lod']['MaxLOD'] if policy=='MaxLOD_floor' else p['lod']['PlateLOD'] if policy=='PlateLOD_floor' else np.full(matrix.shape[1],-np.inf)
    y=np.maximum(matrix[:,j],floor[j]);is1=(p['group']==3) if contrast=='GRUPOHUA3_vs1_2' else (p['type']==1)
    x1=y[indices&is1];x0=y[indices&~is1];v1=np.var(x1,ddof=1);v0=np.var(x0,ddof=1);n1=len(x1);n0=len(x0);se=np.sqrt(v1/n1+v0/n0);md=float(np.mean(x1)-np.mean(x0))
    if se>0:
        df=(v1/n1+v0/n0)**2/((v1/n1)**2/(n1-1)+(v0/n0)**2/(n0-1));crit=stats.t.ppf(.975,df);pv=float(2*stats.t.sf(abs(md/se),df));low=float(md-crit*se);high=float(md+crit*se)
    else:df='';pv='';low='';high=''
    below=p['raw'][:,j]<p['lod']['MaxLOD'][j];b1=float(np.mean(below[indices&is1]));b0=float(np.mean(below[indices&~is1]))
    return {'gene':p['genes'][j],'assay':p['assays'][j],'contrast':contrast,'policy':policy,'n_group3_or_Tipo1':n1,'n_group1_2_or_Tipo0_2':n0,'mean_group3_or_Tipo1':float(np.mean(x1)),'mean_group1_2_or_Tipo0_2':float(np.mean(x0)),'SD_group3_or_Tipo1':float(np.std(x1,ddof=1)),'SD_group1_2_or_Tipo0_2':float(np.std(x0,ddof=1)),'median_group3_or_Tipo1':float(np.median(x1)),'median_group1_2_or_Tipo0_2':float(np.median(x0)),'mean_difference_NPX':md,'SE_difference':float(se),'welch_df':float(df) if df!='' else '', 'CI95_low':low,'CI95_high':high,'P_two_sided_Welch':pv,'test_status':'estimable_Welch' if se>0 else 'not_estimable_constant_after_LOD_floor; conservative_P1_for_BH_only','relative_scale_2pow_MD':float(2**md),'belowMaxLOD_fraction_group3_or_Tipo1':b1,'belowMaxLOD_fraction_group1_2_or_Tipo0_2':b0,'LOD_limited_anygroup50pct':bool(max(b1,b0)>=.5),'in397':p['genes'][j] in candidate,'in12':p['genes'][j] in hubs,'label_boundary':'coded clinical groups; publication dictionary absent'}
p=panels['SF_cell_lysate'];primary=[compare(p,p['include'],j,'MaxLOD_floor','GRUPOHUA3_vs1_2') for j in range(92)]
operational_p=lambda r:r['P_two_sided_Welch'] if r['P_two_sided_Welch']!='' else 1.
q92=bh([operational_p(r) for r in primary]);idx397=[i for i,r in enumerate(primary) if r['in397']];q397=bh([operational_p(primary[i]) for i in idx397]);idx12=[i for i,r in enumerate(primary) if r['in12']];q12=bh([operational_p(primary[i]) for i in idx12])
for i,r in enumerate(primary):r['BH_FDR92']=float(q92[i]);r['BH_FDR_measured397_family']=float(q397[idx397.index(i)]) if i in idx397 else '';r['BH_FDR_measured12_family']=float(q12[idx12.index(i)]) if i in idx12 else '';r['Bonferroni12_sensitivity']=min(1.,12*r['P_two_sided_Welch']) if i in idx12 else ''
write('蛋白验证_主比较_全92蛋白.csv',primary);write('蛋白验证_主比较_冻结397可测蛋白.csv',[primary[i] for i in idx397]);write('蛋白验证_主比较_固定12可测蛋白.csv',[primary[i] for i in idx12])
targetrows=[]
for gene in hubs:
    targetrows.append({'frozen_gene':gene,'in_panel':gene in p['genes'],'status':'measured; coded-group exploratory association' if gene in p['genes'] else 'not measured; no negative inference','assay':p['assays'][p['genes'].index(gene)] if gene in p['genes'] else '','unmeasured_P':'','unmeasured_effect':''})
write('蛋白验证_12靶点完整保留.csv',targetrows)
sens=[]
for tissue,p in panels.items():
    j=p['genes'].index('TNF')
    for policy in ['MaxLOD_floor','raw_NPX','PlateLOD_floor']:
        r=compare(p,p['include'],j,policy,'GRUPOHUA3_vs1_2');r.update(tissue=tissue,selection='strict_inclusion');sens.append(r)
    if tissue=='SF_cell_lysate':
        r=compare(p,np.ones(len(p['ids']),dtype=bool),j,'MaxLOD_floor','GRUPOHUA3_vs1_2');r.update(tissue=tissue,selection='all60_source_paper');sens.append(r)
        r=compare(p,p['include'],j,'MaxLOD_floor','Tipo1_vs0_2');r.update(tissue=tissue,selection='strict_inclusion_Tipo_codes_only');sens.append(r)
write('蛋白验证_TNF预设敏感性与次要比较.csv',sens)
# Pair only included individuals observed in both matrices. No cross-matrix subtraction.
sf=panels['SF_cell_lysate'];ser=panels['Serum'];sid={k:i for i,k in enumerate(sf['ids']) if sf['include'][i]};tid={k:i for i,k in enumerate(ser['ids']) if ser['include'][i]};common=sorted(set(sid)&set(tid));js=sf['genes'].index('TNF');jt=ser['genes'].index('TNF')
paired=[{'donor_token':token(k),'SF_TNF_NPX':float(max(sf['raw'][sid[k],js],sf['lod']['MaxLOD'][js])),'Serum_TNF_NPX':float(max(ser['raw'][tid[k],jt],ser['lod']['MaxLOD'][jt])),'GRUPOHUA_code':int(sf['group'][sid[k]])} for k in common]
write('蛋白验证_TNF配对SF血清_27供者源数据.csv',paired)
x=np.array([r['SF_TNF_NPX'] for r in paired]);y=np.array([r['Serum_TNF_NPX'] for r in paired]);rho,pval=stats.spearmanr(x,y);rng=np.random.default_rng(20261030);boot=[]
for _ in range(5000):
    ix=rng.integers(0,len(common),len(common));v=stats.spearmanr(x[ix],y[ix]).statistic
    if np.isfinite(v):boot.append(v)
lo,hi=np.quantile(boot,[.025,.975]);corr={'n_same_donors':len(common),'Spearman_rho':float(rho),'P_two_sided_unadjusted':float(pval),'CI95_bootstrap_low':float(lo),'CI95_bootstrap_high':float(hi),'bootstrap_unit':'paired donor','bootstrap_replicates':5000,'seed':20261030,'between_matrix_difference_not_interpreted':True}
dump('蛋白验证_TNF配对相关.json',corr)
tnf=next(r for r in primary if r['gene']=='TNF')
summary={'contract_sha256_before_analysis':contract_hash,'software':{'numpy':np.__version__,'scipy':scipy.__version__,'openpyxl':openpyxl.__version__},'primary_comparison':'SF_cell_lysate, GRUPOHUA3 vs1/2, strict clinical include flags, MaxLOD floor','numeric_label_dictionary_verified':False,'actual_diagnosis_labels_not_asserted':True,'fixed12_measured':1,'fixed397_measured':len(idx397),'all_panel_proteins':92,'primary_TNF':tnf,'all92_BH05_count':sum(r['BH_FDR92']<.05 for r in primary),'all92_BH05_not_LODlimited_count':sum(r['BH_FDR92']<.05 and not r['LOD_limited_anygroup50pct'] for r in primary),'candidate397_BH05_count':sum(isinstance(r['BH_FDR_measured397_family'],float) and r['BH_FDR_measured397_family']<.05 for r in primary),'paired_TNF':corr,'new_mRNA_validation':False,'ML_trained':False,'drug_effect_estimated':False}
dump('蛋白验证_结果摘要.json',summary)
print(json.dumps(summary,ensure_ascii=False,indent=2))
