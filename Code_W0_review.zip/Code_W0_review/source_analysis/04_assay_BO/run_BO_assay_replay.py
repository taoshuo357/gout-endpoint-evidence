"""Independent assay tasks: finite-pool historical measured-label replay, all eligible tasks retained."""
from pathlib import Path
import os,sys,json,hashlib,datetime,math,time
E=Path(__file__).resolve().parent;assert E.drive.upper()=='E:'
for p in reversed(['G:/痛风/第二步_靶点预测与疾病交集/runtime/ppi_analysis_libraries','G:/痛风/第二步_靶点预测与疾病交集/论文推进_2026-10-30/单细胞定位/runtime','G:/痛风/第二步_靶点预测与疾病交集/rdkit_runtime']):sys.path.insert(0,p)
import numpy as np,pandas as pd,scipy,sklearn
from scipy.linalg import cho_factor,cho_solve,solve_triangular
from scipy.special import log_ndtr
from scipy.integrate import quad
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Kernel
from rdkit import Chem,rdBase
from rdkit.Chem import rdFingerprintGenerator
O=E/'06_干实验文献与贝叶斯优化/BO实测标签基准';P=O/'全部1064记录_纳入排除与结构审计.tsv';PREFIX='BO_assay_'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def now():return datetime.datetime.now().astimezone().isoformat()
d=pd.read_csv(P,sep='\t',low_memory=False);eligible=d.primary_metadata_eligible.astype(str).str.lower().eq('true');q=d[eligible].copy()
assert len(d)==1064 and len(q)==605 and q.normalized_SMILES.notna().all() and np.isfinite(q.pIC50_computed).all()
rows=[]
for (assay,smi),z in q.groupby(['assay_chembl_id','normalized_SMILES'],sort=True):
 rows.append({'assay_id':assay,'compound_key':hashlib.sha256(smi.encode()).hexdigest()[:16],'normalized_SMILES':smi,'pIC50':float(z.pIC50_computed.median()),'pIC50_min':float(z.pIC50_computed.min()),'pIC50_max':float(z.pIC50_computed.max()),'records':len(z),'documents':';'.join(sorted(set(z.document_chembl_id.dropna().astype(str)))),'activity_ids':';'.join(map(str,sorted(set(z.activity_id)))),'molecule_ids':';'.join(sorted(set(z.molecule_chembl_id.dropna().astype(str)))),'assay_description':str(z.assay_description.iloc[0])})
c=pd.DataFrame(rows).sort_values(['assay_id','compound_key'],kind='stable').reset_index(drop=True)
manifest=[]
for assay,z in c.groupby('assay_id',sort=True):
 raw=q[q.assay_chembl_id.eq(assay)];n=len(z);is_task=n>=20;b=min(n,max(10,min(30,math.ceil(.3*n)))) if is_task else None
 docs=sorted(set(raw.document_chembl_id.dropna().astype(str)))
 manifest.append({'assay_id':assay,'eligible_records':len(raw),'independent_normalized_SMILES':n,'included_task_ge20':is_task,'total_budget_including5initial':b,'documents':';'.join(docs),'n_documents':len(docs),'document_journals':';'.join(sorted(set(raw.document_journal.dropna().astype(str)))),'reported_pIC50_min':float(z.pIC50.min()),'reported_pIC50_max':float(z.pIC50.max()),'reported_label_range':float(z.pIC50.max()-z.pIC50.min()),'assay_description':str(raw.assay_description.iloc[0]),'exclusion_reason_if_small':'' if is_task else 'fewer_than20_distinct_normalized_SMILES'})
m=pd.DataFrame(manifest);tasks=m[m.included_task_ge20].copy();taskids=tasks.assay_id.tolist();assert len(tasks)==8
# Freeze the exact task family and methods before any task strategy is run.
contract={'created':now(),'not_preregistered':True,'purpose':'Assay-stratified sensitivity supplement; original mixed-pool results retained','input_path':str(P.relative_to(E)),'input_SHA256':sha(P),'selection':'All primary_metadata_eligible=True records; within-assay normalized_SMILES median of reported pIC50; include every assay with>=20 independent compounds; no outcome-performance task selection','eligible_records':len(q),'all_eligible_assays':len(m),'all_assay_compound_endpoints':len(c),'task_assays':tasks[['assay_id','independent_normalized_SMILES','total_budget_including5initial','documents']].to_dict(orient='records'),'initial':5,'budget_formula':'min(n,max(10,min(30,ceil(.3*n)))) total evaluations including5 initial','seeds':list(range(20)),'common_initials':'np.random.default_rng(seed).choice(n,5,replace=False) shared across all three methods within each assay; candidate ordering by stable compound_key','strategies':['random','greedy_mean','LogEI'],'features':'Unchanged normalized_SMILES; Morgan radius2 1024bits includeChirality','GP':'Tanimoto fixed kernel; optimizerNone; observed-y normalize_y with population std; alpha=.25^2 in standardized units; posterior same as root fixed GP','LogEI':'Copied stable analytic implementation; z<-10 20-term Mills asymptotic; scaled-integral QA','oracle':'Reported historical within-assay median pIC50; units and source reports uncorrected, source audit separate; not prospective efficacy','metrics':['raw_best_pIC50','normalized_regret=(poolmax-best)/(poolmax-poolmin); zero if constant labels','top5pct_recall:inclusive y>=within-assay95th percentile','top20pct_recall:inclusive y>=within-assay80th percentile'],'ties':'Inclusive quantile thresholds; report actual denominator; score ties choose first stable candidate order','summary':'Per-assay 20-seed endpoint mean and sampleSD; equal-assay-weight descriptive mean across every included task; all three strategies retained','meta_curve':'21 fixed fractional-postinitial-budget points0..1; for each task use latest attained evaluation<=5+fraction*(budget-5), then equal-assay mean; no forward interpolation','independence_boundary':'Within-assay retrospective optimization only; different document IDs or seeds are not proof of cross-study generalization; shared compounds/documents explicitly audited','old_outputs_changed':False,'new_bioefficacy_claimed':False,'new_plots_created':False}
pp=O/(PREFIX+'计算前冻结合同.json')
if pp.exists():
 old=json.loads(pp.read_text(encoding='utf-8'));a={k:v for k,v in old.items() if k!='created'};b={k:v for k,v in contract.items() if k!='created'};assert a==b,'Frozen replay specification changed'
else:dump(pp,contract)
m.to_csv(O/(PREFIX+'全部assay纳入任务清单.tsv'),sep='\t',index=False);c.to_csv(O/(PREFIX+'全部assay内去重端点.tsv'),sep='\t',index=False)
print('FROZEN_TASKS',tasks[['assay_id','independent_normalized_SMILES','total_budget_including5initial','documents']].to_dict(orient='records'),flush=True)
class Tanimoto(Kernel):
 def __init__(self):pass
 def __call__(self,X,Y=None,eval_gradient=False):
  if Y is None:Y=X
  dots=X@Y.T;den=X.sum(1)[:,None]+Y.sum(1)[None,:]-dots
  K=np.divide(dots,den,out=np.zeros_like(dots),where=den>0)
  return (K,np.empty((*K.shape,0))) if eval_gradient else K
 def diag(self,X):return np.ones(len(X))
 def is_stationary(self):return False

def posterior(K,y,obs):
 yy=y[obs];ym=yy.mean();ys=yy.std() or 1.
 A=K[np.ix_(obs,obs)]+(.25**2)*np.eye(len(obs));cf=cho_factor(A,lower=True,check_finite=False)
 a=cho_solve(cf,(yy-ym)/ys,check_finite=False);k=K[np.ix_(obs,np.arange(len(y)))];mu=(k.T@a)*ys+ym
 sol=solve_triangular(cf[0],k,lower=True,check_finite=False);var=np.maximum(1-np.sum(sol*sol,axis=0),1e-14)*ys*ys
 return mu,np.sqrt(var)

def logEI(mu,sd,best):
 z=(mu-best)/np.maximum(sd,1e-15);lp=-.5*z*z-.5*np.log(2*np.pi)
 out=np.empty(len(z));a=z>=0
 out[a]=np.log(sd[a])+np.logaddexp(lp[a],np.log(np.maximum(z[a],1e-300))+log_ndtr(z[a]))
 b=(z<0)&(z>=-10);zz=z[b];term=1+zz*np.exp(log_ndtr(zz)-lp[b]);assert np.all(term>0)
 out[b]=np.log(sd[b])+lp[b]+np.log(term)
 tail=z<-10;u=-z[tail];inv2=(1/u)**2;poly=np.ones(len(u));term=np.ones(len(u))
 for k in range(1,20):term*=-(2*k+1)*inv2;poly+=term
 assert np.all(poly>0)
 out[tail]=np.log(sd[tail])+lp[tail]-2*np.log(u)+np.log(poly)
 return out
qa={'status':'IN_PROGRESS','input_SHA256_before':sha(P),'source_SHA256':sha(Path(__file__)),'LogEI_scaled_integral_checks':[],'official_sklearn_equivalence':[]}
for zz in [-1.,-5.,-10.,-20.,-50.,-100.,-1e4]:
 u=-zz;integ=quad(lambda v:v*np.exp(-v-v*v/(2*u*u)),0,np.inf,epsabs=1e-13,epsrel=1e-13)[0]
 ref=-.5*zz*zz-.5*np.log(2*np.pi)-2*np.log(u)+np.log(integ);got=float(logEI(np.array([zz]),np.array([1.]),0)[0]);err=abs(got-ref);assert err<1e-8
 qa['LogEI_scaled_integral_checks'].append({'z':zz,'absolute_log_error':float(err)})
assert np.all(np.diff(logEI(np.linspace(-10,10,201),np.ones(201),0))>0)
assert np.isfinite(logEI(np.array([-1.,0.,1.]),np.full(3,1e-12),0)).all()
gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=1024,includeChirality=True);rdBase.DisableLog('rdApp.warning')
curves=[];queried=[];initials=[];taskinfo=[];t0=time.time()
for assay in taskids:
 z=c[c.assay_id.eq(assay)].copy().reset_index(drop=True);y=z.pIC50.to_numpy();n=len(z);budget=int(tasks.set_index('assay_id').loc[assay,'total_budget_including5initial']);initial=5
 X=np.vstack([np.array(gen.GetFingerprint(Chem.MolFromSmiles(s))) for s in z.normalized_SMILES]).astype(float);K=Tanimoto()(X)
 top5th=float(np.quantile(y,.95));top20th=float(np.quantile(y,.8));top5=y>=top5th;top20=y>=top20th;rangeY=float(y.max()-y.min())
 taskinfo.append({'assay_id':assay,'n_compounds':n,'budget':budget,'top5pct_inclusive_threshold':top5th,'top5pct_actual_count':int(top5.sum()),'top20pct_inclusive_threshold':top20th,'top20pct_actual_count':int(top20.sum()),'reported_ymin':float(y.min()),'reported_ymax':float(y.max()),'constant_labels':rangeY==0,'documents':str(tasks.set_index('assay_id').loc[assay,'documents'])})
 for seed in range(20):
  start=np.random.default_rng(seed).choice(n,5,replace=False).tolist()
  for j,ix in enumerate(start):initials.append({'assay_id':assay,'seed':seed,'initial_order':j+1,'compound_key':z.compound_key.iloc[ix],'reported_pIC50':float(y[ix])})
  for method in ['random','greedy_mean','LogEI']:
   obs=start.copy();rng=np.random.default_rng(seed+10000)
   for ix in start:queried.append({'assay_id':assay,'seed':seed,'method':method,'evaluation_order':obs.index(ix)+1,'compound_key':z.compound_key.iloc[ix],'revealed_reported_pIC50':float(y[ix]),'is_initial':True})
   for neval in range(initial,budget+1):
    observed=y[obs];best=float(observed.max());nr=(float(y.max())-best)/rangeY if rangeY>0 else 0.
    curves.append({'assay_id':assay,'seed':seed,'method':method,'evaluated_total':neval,'total_budget':budget,'pool_n':n,'fraction_postinitial_budget':(neval-initial)/(budget-initial),'raw_best_pIC50':best,'best_reported_IC50_nM':float(10**(9-best)),'normalized_regret':float(nr),'top5pct_recall':float(top5[obs].sum()/top5.sum()),'top20pct_recall':float(top20[obs].sum()/top20.sum()),'top5pct_denominator':int(top5.sum()),'top20pct_denominator':int(top20.sum()),'initial_shared':neval==5,'last_compound_key':z.compound_key.iloc[obs[-1]],'last_revealed_reported_pIC50':float(observed[-1])})
    if neval==budget:break
    avail=np.setdiff1d(np.arange(n),obs)
    if method=='random':nxt=int(rng.choice(avail))
    else:
     mu,sd=posterior(K,y,obs)
     if seed==0 and method=='LogEI' and neval in [5,budget-1]:
      off=GaussianProcessRegressor(kernel=Tanimoto(),alpha=.25**2,optimizer=None,normalize_y=True).fit(X[obs],y[obs]);om,osd=off.predict(X,return_std=True)
      em=float(np.max(np.abs(mu-om)));es=float(np.max(np.abs(sd-osd)));assert em<1e-8 and es<1e-8
      qa['official_sklearn_equivalence'].append({'assay_id':assay,'observed_n':neval,'max_mean_error':em,'max_std_error':es})
     score=mu if method=='greedy_mean' else logEI(mu,sd,best);assert np.isfinite(score[avail]).all();nxt=int(avail[np.argmax(score[avail])])
    assert nxt not in obs;obs.append(nxt)
    queried.append({'assay_id':assay,'seed':seed,'method':method,'evaluation_order':neval+1,'compound_key':z.compound_key.iloc[nxt],'revealed_reported_pIC50':float(y[nxt]),'is_initial':False})
 print('ASSAY_COMPLETE',assay,'n',n,'budget',budget,'seconds',round(time.time()-t0,2),flush=True)
cur=pd.DataFrame(curves);query=pd.DataFrame(queried);init=pd.DataFrame(initials);info=pd.DataFrame(taskinfo)
# Independent integrity checks across every trajectory.
assert not query.duplicated(['assay_id','seed','method','compound_key']).any()
assert len(cur)==sum((int(b)-4)*60 for b in tasks.total_budget_including5initial)
for key,z in cur.groupby(['assay_id','seed','method']):
 assert np.all(np.diff(z.raw_best_pIC50)>=-1e-12) and np.all(np.diff(z.normalized_regret)<=1e-12)
 assert np.all(np.diff(z.top5pct_recall)>=-1e-12) and np.all(np.diff(z.top20pct_recall)>=-1e-12)
for key,z in cur[cur.initial_shared].groupby(['assay_id','seed']):
 assert len(z)==3 and z.raw_best_pIC50.nunique()==1 and z.top5pct_recall.nunique()==1 and z.top20pct_recall.nunique()==1
end=cur[cur.evaluated_total.eq(cur.total_budget)].copy();assert len(end)==8*20*3
metrics=['raw_best_pIC50','normalized_regret','top5pct_recall','top20pct_recall']
summary=end.groupby(['assay_id','method'],observed=True)[metrics].agg(['mean','std']).reset_index();summary.columns=['_'.join(t).rstrip('_') if isinstance(t,tuple) else t for t in summary.columns];summary=summary.merge(info,on='assay_id',validate='m:1')
meta_seed=end.groupby(['seed','method'],observed=True)[metrics].mean().reset_index();assert len(meta_seed)==60
meta_summary=meta_seed.groupby('method',observed=True)[metrics].agg(['mean','std']).reset_index();meta_summary.columns=['_'.join(t).rstrip('_') if isinstance(t,tuple) else t for t in meta_summary.columns]
meta_summary['equally_weighted_assays']=len(tasks);meta_summary['algorithm_initialization_seeds']=20
# Budget-fraction alignment uses the last available step; never peeks into later observations.
metacurve=[]
for fraction in np.linspace(0,1,21):
 pieces=[]
 for aid,z in cur.groupby('assay_id',sort=False):
  b=int(z.total_budget.iloc[0]);step=5+int(np.floor(fraction*(b-5)+1e-10));w=z[z.evaluated_total.eq(step)].copy();assert len(w)==60;pieces.append(w)
 w=pd.concat(pieces);a=w.groupby(['seed','method'],observed=True)[metrics].mean().reset_index();a.insert(0,'fraction_postinitial_budget',float(fraction));metacurve.append(a)
metacurve=pd.concat(metacurve,ignore_index=True)
for name,df in [('全部逐轮轨迹',cur),('全部查询顺序与揭示标签',query),('共同初始点',init),('各任务真实分母与标签范围',info),('每任务每种子终点',end),('每任务终点_全部策略',summary),('等assay权重_每种子终点',meta_seed),('等assay权重_策略终点汇总',meta_summary),('等assay权重_完整预算进度曲线',metacurve)]:df.to_csv(O/(PREFIX+name+'.tsv'),sep='\t',index=False)
# Shared source documents and compounds do not constitute independent new studies.
selected=c[c.assay_id.isin(taskids)].copy();docpairs=[]
for aid in taskids:
 for doc in str(tasks.set_index('assay_id').loc[aid,'documents']).split(';'):docpairs.append({'assay_id':aid,'document_id':doc})
doc=pd.DataFrame(docpairs);doc['included_assays_in_document']=doc.groupby('document_id').assay_id.transform('nunique');doc.to_csv(O/(PREFIX+'文献与任务重复审计.tsv'),sep='\t',index=False)
shared=selected.groupby(['compound_key','normalized_SMILES'],observed=True).agg(included_assay_count=('assay_id','nunique'),included_assays=('assay_id',lambda s:';'.join(sorted(set(s))))).reset_index();shared.to_csv(O/(PREFIX+'跨任务化合物重叠审计.tsv'),sep='\t',index=False)
qa.update({'status':'PASS','completed':now(),'input_SHA256_after':sha(P),'input_unchanged':sha(P)==contract['input_SHA256'],'all_selected_assays_completed':taskids,'shared_initials_all160_task_seeds':True,'query_without_replacement_all480_runs':True,'monotone_metrics_all480_runs':True,'expected_curve_rows':int(sum((int(b)-4)*60 for b in tasks.total_budget_including5initial)),'actual_curve_rows':len(cur),'all_endpoint_rows':len(end),'no_unqueried_labels_in_GP':True,'per_task_population_labels_used_only_for_evaluation':True})
assert qa['input_unchanged'];dump(O/(PREFIX+'数学与流程核验.json'),qa)
result={'status':'COMPLETED_ALL_ELIGIBLE_ASSAY_TASKS','finished':now(),'task_n':len(tasks),'all_primary_records':len(q),'all_assay_n':len(m),'selected_task_original_records':int(tasks.eligible_records.sum()),'selected_task_assay_compound_endpoints':len(selected),'selected_unique_compounds_across_assays':shared.compound_key.nunique(),'compounds_shared_across_tasks':int(shared.included_assay_count.gt(1).sum()),'task_document_IDs':doc.document_id.nunique(),'documents_reused_across_tasks':int(doc.loc[doc.included_assays_in_document.gt(1),'document_id'].nunique()),'task_details':taskinfo,'all_strategies_meta_equal_assay_weight':meta_summary.to_dict(orient='records'),'no_phase_or_drug_efficacy_P_values':True,'no_cross_study_generalization_claim':True,'shared_chemical_or_patent_family_dependence_not_ruled_out':True,'original_mixed_pool_results_retained':True,'reported_labels_and_units_unchanged':True,'source_provenance_audit_separate':True,'uncertainty_unit':'20 algorithm initializations on8fixed historical assay pools; sampleSD is algorithmic variation, not biological sampling CI','raw_best_meta_caveat':'Raw best pIC50 arithmetic means acrossassays are descriptive; between-assay label calibration is not established. Normalized regret and withinassay percentile recalls compare search efficiency.','software':{'numpy':np.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__,'RDKit':rdBase.rdkitVersion},'seconds':time.time()-t0,'frozen_contract_SHA256':sha(pp),'script_SHA256':sha(Path(__file__))}
dump(O/(PREFIX+'实际完成摘要.json'),result)
(O/(PREFIX+'方法结果边界.txt')).write_text('本模块是全部符合预设规模条件的逐assay历史实测标签oracle回放，作为混合pool的独立任务敏感性补充。所有8任务、3策略、20相同初始种子均保留。每任务在assay内按normalized_SMILES取reported pIC50中位数；没有修改专利单位或原reported values。固定Tanimoto GP与稳定LogEI，已逐值核对官方sklearn并核验极负尾部积分。所有任务预算公式固定，均包含5个初始标签。全家族不按表现选任务，top5/top20采用含边界的分位数阈值且记录实际分母。等权汇总先每assay、再各assay等权；种子SD反映算法初始化变动。任务共享分子、相同来源或专利家族依赖应单独报告；不同documentID不证明独立研究。这里只评价各assay内部检索效率，不是跨研究泛化或新药效，更不是新增临床抗痛风疗效。原混合pool结果保留。\n',encoding='utf-8')
print('RESULT',json.dumps(result,ensure_ascii=False),flush=True)
