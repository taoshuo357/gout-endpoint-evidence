"""A05: all assay tasks and all strategies, conditional historical-oracle replay."""
from pathlib import Path
import sys,os,json,hashlib,subprocess,datetime
E=Path(__file__).resolve().parent;assert E.drive.upper()=='E:'
G=Path('G:/痛风/第二步_靶点预测与疾病交集');sys.path.insert(0,str(G/'runtime/ppi_analysis_libraries'))
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
H=Path('C:/Users/95330/.codex/skills/nature-figure/scripts');sys.path.insert(0,str(H))
from audit_panel_alignment import require_matplotlib_panel_alignment
O=E/'06_干实验文献与贝叶斯优化/BO实测标签基准';F=E/'科研图';S=E/'图源数据';Q=F/'质量核验';N='A05_逐实验BO比较'
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=[O/'BO_assay_每任务每种子终点.tsv',O/'BO_assay_各任务真实分母与标签范围.tsv',O/'BO_assay_实际完成摘要.json',O/'BO_assay_数学与流程核验.json',O/'BO_assay_计算前冻结合同.json']
contract={'question':'Do search gains persist within all prespecified assay tasks when source mixing is avoided?','claim':'Historical within-assay search performance differs by assay and strategy; both optimization policies exceed random on average, with no uniformly best method across endpoints.','archetype':'quantitative grid','backend':'python','size_mm':[183,125],'data':'All8eligible assay tasks;20common initializations;three fixed strategies; no assay or seed removal','panels':{'a':'all strategies, per-assay mean top20percent recall with bootstrap initialization intervals','b':'paired-seed differences versus random for both optimization policies, same8assays'},'metric_display_choice':'Top20percent recall gives5-9inclusive endpoints perassay versus2-4top5percent endpoints; exploratory supplemental display, not replacing the originally reported top5/rawbest/regret metrics','uncertainty':'95percent percentile bootstrap over20algorithm initializations within each fixed task,10000resamples; not biological sampling inference','selection':'all8tasksexactly; fixed assay-ID ascending order; both policy contrasts; all metadata-defined qualifiers retained','font_floor_pt':5,'all_raw_metrics_retained_in_source':True,'no_P_values':True,'no_clinical_or_cross_study_efficacy_claim':True,'exports':['pdf','svg','png300dpi','tiff600dpiLZW']}
p=S/(N+'_绘图前合同.json')
if p.exists():assert json.loads(p.read_text(encoding='utf-8'))==contract
else:dump(p,contract)
end=pd.read_csv(paths[0],sep='\t');info=pd.read_csv(paths[1],sep='\t');run=json.loads(paths[2].read_text(encoding='utf-8'));qa_method=json.loads(paths[3].read_text(encoding='utf-8'))
assert qa_method['status']=='PASS' and len(end)==480 and len(info)==8
assays=sorted(info.assay_id);methods=['random','greedy_mean','LogEI'];metric='top20pct_recall';assert set(end.method)==set(methods)
assert end.groupby(['assay_id','method']).size().eq(20).all() and end.evaluated_total.eq(end.total_budget).all()
end.to_csv(S/(N+'_全部任务种子策略终点_原指标不删.tsv'),sep='\t',index=False)
metrics=['raw_best_pIC50','normalized_regret','top5pct_recall','top20pct_recall'];rows=[];diffrows=[]
for i,assay in enumerate(assays):
 pivot=end[end.assay_id.eq(assay)].pivot(index='seed',columns='method',values=metric).reindex(index=range(20),columns=methods);assert pivot.notna().all().all()
 bootidx=np.random.default_rng(20261103+i).integers(0,20,size=(10000,20))
 for method in methods:
  y=pivot[method].to_numpy();boot=y[bootidx].mean(1)
  row={'assay_id':assay,'method':method,'seed_n':20,'top20pct_mean':float(y.mean()),'bootstrap95_low':float(np.quantile(boot,.025)),'bootstrap95_high':float(np.quantile(boot,.975))}
  base=end[end.assay_id.eq(assay)&end.method.eq(method)]
  for met in metrics:row[met+'_mean']=float(base[met].mean())
  rows.append(row)
 for method in ['greedy_mean','LogEI']:
  y=(pivot[method]-pivot.random).to_numpy();boot=y[bootidx].mean(1)
  diffrows.append({'assay_id':assay,'method':method,'seed_n':20,'paired_mean_difference_pp':float(100*y.mean()),'bootstrap95_low_pp':float(100*np.quantile(boot,.025)),'bootstrap95_high_pp':float(100*np.quantile(boot,.975)),'positive_initializations':int((y>0).sum()),'tied_initializations':int((y==0).sum()),'negative_initializations':int((y<0).sum())})
sumdf=pd.DataFrame(rows).merge(info,on='assay_id',validate='m:1');diff=pd.DataFrame(diffrows).merge(info,on='assay_id',validate='m:1')
sumdf.to_csv(S/(N+'_每任务全部策略_均值与初始化区间.tsv'),sep='\t',index=False);diff.to_csv(S/(N+'_全部任务_两策略对随机的配对差.tsv'),sep='\t',index=False)
assert len(sumdf)==24 and len(diff)==16 and sumdf.groupby('assay_id').method.nunique().eq(3).all()
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Helvetica','DejaVu Sans'],'font.size':7,'axes.titlesize':7.5,'axes.labelsize':6.5,'xtick.labelsize':6,'ytick.labelsize':6,'svg.fonttype':'none','pdf.fonttype':42,'axes.linewidth':.65,'axes.spines.top':False,'axes.spines.right':False,'legend.frameon':False})
fig,axs=plt.subplots(1,2,figsize=(7.2047244094,4.9212598425))
fig.subplots_adjust(left=.185,right=.96,bottom=.255,top=.785,wspace=.52)
colors={'random':'#96a6b2','greedy_mean':'#4b9389','LogEI':'#b9874a'};markers={'random':'o','greedy_mean':'s','LogEI':'D'};display={'random':'Random','greedy_mean':'Greedy mean','LogEI':'LogEI'}
for ax,letter in zip(axs,['a','b']):
 ax.text(-.15,1.08,letter,transform=ax.transAxes,fontsize=9,fontweight='bold',va='bottom');ax.set_ylim(7.65,-.65);ax.set_yticks(range(8));ax.tick_params(axis='y',length=0,pad=5)
 for y in np.arange(.5,7,1):ax.axhline(y,color='#e8edef',lw=.5,zorder=0)
 ax.spines['left'].set_visible(False)
for i,aid in enumerate(assays):
 for method,off in [('random',-.18),('greedy_mean',0),('LogEI',.18)]:
  r=sumdf[sumdf.assay_id.eq(aid)&sumdf.method.eq(method)].iloc[0];v=100*r.top20pct_mean;lo=100*r.bootstrap95_low;hi=100*r.bootstrap95_high
  assert lo<=v<=hi
  axs[0].errorbar(v,i+off,xerr=np.array([[v-lo],[hi-v]]),color=colors[method],marker=markers[method],ms=3.6,lw=.8,capsize=1.5,mew=.4,mec='white',zorder=3)
 for method,off in [('greedy_mean',-.11),('LogEI',.11)]:
  r=diff[diff.assay_id.eq(aid)&diff.method.eq(method)].iloc[0];v=r.paired_mean_difference_pp;lo=r.bootstrap95_low_pp;hi=r.bootstrap95_high_pp
  axs[1].errorbar(v,i+off,xerr=np.array([[v-lo],[hi-v]]),color=colors[method],marker=markers[method],ms=3.8,lw=.85,capsize=1.5,mew=.4,mec='white',zorder=3)
inf=info.set_index('assay_id');labs=[a+'\n'+f'n={int(inf.loc[a,"n_compounds"])}, budget={int(inf.loc[a,"budget"])}' for a in assays]
axs[0].set_yticklabels(labs,fontsize=5.8);axs[1].set_yticklabels([])
axs[0].set(xlim=(0,100),xticks=[0,25,50,75,100],xlabel='Top 20% within-assay recall (%)',title='All three strategies at fixed task budgets')
axs[1].axvline(0,color='#5b6f7d',lw=.8,ls='--',zorder=1)
lo=min(0,float(diff.bootstrap95_low_pp.min()));hi=max(0,float(diff.bootstrap95_high_pp.max()));xmin=10*np.floor((lo-2)/10);xmax=10*np.ceil((hi+2)/10)
axs[1].set(xlim=(xmin,xmax),xlabel='Recall difference versus random (pp)',title='Paired-initialization contrasts')
handles=[Line2D([0],[0],marker=markers[m],color=colors[m],lw=.8,ms=4,label=display[m]) for m in methods]
fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.58,.89),ncol=3,fontsize=6.5,handlelength=1.4,columnspacing=1.8)
fig.text(.055,.966,'Within-assay search gains vary across historical assays',fontsize=10,fontweight='bold',va='top',color='#243f4e')
fig.text(.055,.923,'Eight predefined assay pools; all tasks and three strategies retained; reported potency labels unchanged',fontsize=6.5,color='#576c78',va='top')
means=end.groupby(['assay_id','method'],observed=True)[metrics].mean().groupby('method').mean()
fig.text(.055,.167,'Equal-assay mean top-20% recall: Random 34.95%; Greedy mean 47.81%; LogEI 44.69%.',fontsize=6.3)
fig.text(.055,.127,'Points: mean of 20 shared initializations per assay; bars: 95% paired-seed bootstrap intervals (10,000 resamples).',fontsize=6)
fig.text(.055,.087,'Five shared initial labels; budgets include 10–13 total queries. Inclusive top-20% thresholds retain 5–9 compounds per assay.',fontsize=6)
fig.text(.055,.047,'Historical measured-label oracle replay; no new drug efficacy or cross-study generalization is demonstrated.',fontsize=6,color='#576c78')
fig.text(.055,.017,'Assay species/source uncertainty and between-assay calibration remain limitations; eight document IDs do not prove independence.',fontsize=6,color='#576c78')
fig.canvas.draw();require_matplotlib_panel_alignment(fig,axes=list(axs),strict=True,json_out=str(Q/(N+'_alignment.json')),tolerance_pt=1.5,gutter_tolerance_pt=1.5)
fig.savefig(F/(N+'.pdf'));fig.savefig(F/(N+'.svg'));fig.savefig(F/(N+'.png'),dpi=300);fig.savefig(F/(N+'.tiff'),dpi=600,pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
legend='''A05 | Assay-stratified historical-label replay shows heterogeneous search performance. All eight assays containing at least 20 distinct normalized structures among the frozen metadata-eligible records were included, yielding 258 assay-specific median pIC50 endpoints from 263 records (255 unique structures across tasks). Endpoint labels were reaggregated within assay, and reported potency values were retained. Each of 20 random initializations supplies five identical initial compounds to random selection, greedy posterior mean and LogEI within an assay. Total query budget is min(n,max(10,min(30,ceil(0.3n)))), including initial labels (10–13 evaluations here). Models use the same fixed Morgan/Tanimoto Gaussian process and observation regularization; unqueried labels are hidden from the acquisition policy. a, Mean recall of compounds at or above the within-assay 80th percentile (inclusive, retaining 5–9 compounds). All strategies and all task-specific budgets are shown. b, Paired-initialization recall differences for both optimization policies versus random. Points indicate means across 20 algorithm initializations; bars are 95% percentile bootstrap intervals using 10,000 paired seed resamples within each fixed assay. They quantify initialization variability, not biological sampling confidence or a hypothesis test. Equal-assay endpoint averages are shown descriptively; greedy mean has higher top-20% recall whereas LogEI has higher top-5% recall (46.35% versus 44.48%, random33.44%) and lower normalized regret (0.0624 versus0.0684, random0.0821). Full raw-best, regret, top-5% and top-20% results are retained in source data. The top-20% display is an exploratory supplement with larger per-task denominators and does not replace the original endpoints. Two structures are shared across tasks; the eight assays reference eight distinct document IDs, which do not establish independent patent families or biological studies. Assay organism/source and between-assay label calibration remain limitations. This is retrospective within-assay search evaluation, not new drug efficacy, cross-study prediction validation or prospective experimental discovery.'''
(F/(N+'_English_legend.txt')).write_text(legend,encoding='utf-8')
qa={'source_inputs':{str(p.relative_to(E)):sha(p) for p in paths},'all8assays_retained':True,'all3strategies_retained':True,'paired_contrasts_all16':True,'no_metric_results_deleted':True,'mean_top20percent_equalassay':means[metric].to_dict(),'displayed8task_top20percent_denominators':info.top20pct_actual_count.astype(int).tolist(),'bootstrap_replicates':10000,'biological_independence_claim':False,'visual_inspection':'PENDING','figure_mm':[183,125],'script_SHA256':sha(Path(__file__))}
for k,tool,args in [('source','validate_figure.py',[str(Path(__file__)),'--backend','python']),('font','audit_pdf_text.py',[str(F/(N+'.pdf')),'--min-pt','5']),('collision','audit_figure_collisions.py',[str(F/(N+'.pdf'))])]:
 r=subprocess.run([sys.executable,str(H/tool),*args,'--json'],capture_output=True,text=True,encoding='utf-8',errors='replace',env={**os.environ,'PYTHONPATH':str(G/'runtime/ppi_analysis_libraries')})
 (Q/(N+'_'+k+'.json')).write_text(r.stdout or r.stderr,encoding='utf-8');qa[k+'_returncode']=r.returncode
import pymupdf
from PIL import Image
with pymupdf.open(F/(N+'.pdf')) as pdf:rect=pdf[0].rect;qa['actual_pdf_mm']=[rect.width*25.4/72,rect.height*25.4/72]
assert np.allclose(qa['actual_pdf_mm'],[183,125],atol=.001)
with Image.open(F/(N+'.tiff')) as im:qa['tiff']={'pixels':list(im.size),'dpi':[float(z) for z in im.info.get('dpi',[])],'compression':im.info.get('compression')}
assert qa['tiff']['compression']=='tiff_lzw' and min(qa['tiff']['dpi'])>=599.9
dump(Q/(N+'_QA.json'),qa);print(json.dumps(qa,ensure_ascii=False),flush=True)
