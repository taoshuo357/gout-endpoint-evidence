# Original project source rights

Copyright 2026 the project authors. All rights reserved.

An open-source software licence has not yet been selected or granted for the original project source. This W0 review snapshot is made available for source inspection and reproducibility assessment; its presence in a review archive or repository is not a declaration that it is licensed under MIT, BSD, CC-BY, or another open licence. Permissions for further reuse or redistribution remain to be determined by the authors.

This notice applies only to rights the project authors hold. It does not replace licences or terms attached to third-party software, databases, data records or other material, nor does it restrict rights otherwise provided by law or by the relevant third-party licence. Referenced third-party implementations and installed runtimes are not bundled here.
