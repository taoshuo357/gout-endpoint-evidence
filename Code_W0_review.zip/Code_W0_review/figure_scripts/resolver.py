"""Strict exact-identity ZIP resolver. Project-owned implementation, v0.1-W0-review."""
from pathlib import Path
import os,csv,io,json,zipfile,hashlib,builtins,atexit
ROOT=Path(__file__).resolve().parents[1]
ARCHIVES=ROOT.parent/'Zenodo_upload_22_files'
CACHE=ROOT/'runtime_inputs'
LOG=ROOT/'reproduced_figures/read_receipts'
for p in [CACHE,LOG]:p.mkdir(parents=True,exist_ok=True)
_real_open=builtins.open;_real_io_open=io.open;_real_exists=Path.exists;_real_isfile=Path.is_file
_index={};_events=[];_installed=False
_norm=lambda p:str(p).replace('\\','/').rstrip('/').casefold()
def _sha_bytes(b):return hashlib.sha256(b).hexdigest()
def _local(p):
 n=_norm(p);return n.startswith(_norm(ROOT)+'/') or n==_norm(ROOT) or n.startswith(_norm(ARCHIVES)+'/')
def _project(p):
 n=_norm(p);return n.startswith('e:/痛风/研究深化_2026-11-02/') or n.startswith('g:/痛风/第二步_靶点预测与疾病交集/')
def _runtime(p):
 n=_norm(p);return any(n.startswith(x) for x in ['g:/痛风/第二步_靶点预测与疾病交集/runtime/','g:/痛风/第二步_靶点预测与疾病交集/rdkit_runtime/','g:/痛风/第二步_靶点预测与疾病交集/论文推进_2026-10-30/单细胞定位/runtime/'])
def initialize():
 if _index:return
 for zpath in sorted(ARCHIVES.glob('Fig*_SourceData.zip')):
  with zipfile.ZipFile(zpath) as z:
   matches=[n for n in z.namelist() if n.endswith('input_index.csv')]
   if len(matches)!=1:raise ValueError(f'Expected one input_index.csv: {zpath}')
   for r in csv.DictReader(io.StringIO(z.read(matches[0]).decode('utf-8-sig'))):
    k=_norm(r['original_local_path']);r={**r,'zip_file':str(zpath)}
    if k in _index and _index[k]['SHA256']!=r['SHA256']:raise ValueError('Conflicting exact identity: '+k)
    _index.setdefault(k,r)
 if not _index:raise FileNotFoundError('No SourceData ZIP input indices: '+str(ARCHIVES))
def resolve_input(p,api='read'):
 if hasattr(p,'read') or isinstance(p,int):return p
 if not isinstance(p,(str,bytes,os.PathLike)):return p
 if isinstance(p,bytes):p=os.fsdecode(p)
 initialize();key=_norm(p)
 if _local(p):return Path(p)
 if key not in _index:
  if _project(p) and not _runtime(p):
   _events.append({'api':api,'identity':str(p),'status':'MISSING_FROM_BUNDLE'})
   raise FileNotFoundError('STRICT_BUNDLE_MISSING: '+str(p))
  return p
 r=_index[key];name=Path(str(p).replace('\\','/')).name;dst=CACHE/r['SHA256']/name
 if not _real_isfile(dst):
  with zipfile.ZipFile(r['zip_file']) as z:b=z.read(r['archive_path'])
  if _sha_bytes(b)!=r['SHA256']:raise ValueError('ZIP_SHA256_MISMATCH: '+str(p))
  dst.parent.mkdir(parents=True,exist_ok=True)
  with _real_open(dst,'wb') as f:f.write(b)
 else:
  with _real_open(dst,'rb') as f:
   if _sha_bytes(f.read())!=r['SHA256']:raise ValueError('CACHE_SHA256_MISMATCH: '+str(p))
 _events.append({'api':api,'identity':str(p),'resolved_path':str(dst),'zip_file':r['zip_file'],'archive_path':r['archive_path'],'SHA256':r['SHA256'],'status':'BUNDLE_SHA_VERIFIED'})
 return dst
def _open(file,mode='r',*a,**kw):
 if isinstance(file,(str,bytes,os.PathLike)):
  if any(x in mode for x in 'wax+'):
   if _project(file) and not _local(file):raise PermissionError('NO_LEGACY_WRITE: '+str(file))
  else:file=resolve_input(file,'open')
 return _real_open(file,mode,*a,**kw)
def _io_open(file,mode='r',*a,**kw):
 if isinstance(file,(str,bytes,os.PathLike)):
  if any(x in mode for x in 'wax+'):
   if _project(file) and not _local(file):raise PermissionError('NO_LEGACY_WRITE: '+str(file))
  else:file=resolve_input(file,'io.open/Path.open')
 return _real_io_open(file,mode,*a,**kw)
def install():
 global _installed
 if _installed:return
 initialize()
 import pandas as pd,numpy as np,shutil
 from scipy import sparse
 for obj,name in [(pd,'read_csv'),(np,'load'),(sparse,'load_npz')]:
  original=getattr(obj,name)
  def call(p,*a,__original=original,__name=name,**kw):return __original(resolve_input(p,__name),*a,**kw)
  setattr(obj,name,call)
 original_copy=shutil.copy2
 def copy2(src,dst,*a,**kw):
  if not _local(dst):raise PermissionError('Output copy must remain in release directory: '+str(dst))
  Path(dst).parent.mkdir(parents=True,exist_ok=True)
  return original_copy(resolve_input(src,'shutil.copy2'),dst,*a,**kw)
 shutil.copy2=copy2
 def exists(p):
  if _project(p) and not _local(p) and not _runtime(p):return _norm(p) in _index
  return _real_exists(p)
 def is_file(p):
  if _project(p) and not _local(p) and not _runtime(p):return _norm(p) in _index
  return _real_isfile(p)
 Path.exists=exists;Path.is_file=is_file;builtins.open=_open;io.open=_io_open;_installed=True

def report():
 name=os.environ.get('BUNDLE_SCRIPT','unknown')
 with _real_open(LOG/(name+'.json'),'w',encoding='utf-8') as f:json.dump({'strict_bundle':True,'fallback_to_original_inputs':False,'reads':_events,'known_exact_identities':len(_index)},f,ensure_ascii=False,indent=2)
atexit.register(report)