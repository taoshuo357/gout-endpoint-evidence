"""Workflow and assay-context plates redrawn from complete frozen source tables."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parent));from atlas_style import *
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch,Rectangle
from matplotlib.lines import Line2D
from matplotlib.colors import ListedColormap,TwoSlopeNorm
from matplotlib.gridspec import GridSpec

def reader(p):return pd.read_csv(p,sep='\t' if p.suffix=='.tsv' else ',')
def card(ax,x,y,w,h,text,color=BLUE):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.008,rounding_size=0.012',facecolor=matplotlib.colors.to_rgba(color,.075),edgecolor=color,lw=.7))
 ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=7.2,linespacing=1.35)
def arrow(ax,a,b,color=GREY):ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=7,lw=.75,color=color,shrinkA=1,shrinkB=1))

def workflow():
 fid='F01_Study_architecture';d=E/'01_保守性审计'
 paths=[d/'TF_LR_六映射与最坏包络_完整族检验对照.tsv',d/'LR_全六库规则与阶段阈值模式计数.tsv',d/'KO_99背景与45族_分辨率阈值算例.tsv']
 a,b,c=[reader(p) for p in paths];assert len(c)==45
 fig=plt.figure(figsize=(183/25.4,215/25.4));gs=fig.add_gridspec(3,3,left=.085,right=.975,top=.955,bottom=.08,height_ratios=[.9,.8,1.1],hspace=.65,wspace=.85)
 ax=fig.add_subplot(gs[0,:]);ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off');panel_label(ax,'a','From public molecular data to compound priorities')
 cards=[('Patient cells\n3 patients · 6 libraries',BLUE),('Urate response\n4 donors · 16 samples',TEAL),('Drug response\n10 + 22 cultures',ROSE),('Functional screen\n362,359 SID records',GOLD),('Chemical activity\n544 clean structures',VIOLET)]
 for i,(s,col) in enumerate(cards):
  x=.005+i*.2;card(ax,x,.60,.183,.33,s,col);arrow(ax,(x+.091,.60),(.31 if i<3 else .76,.32),col)
 card(ax,.15,.05,.34,.26,'Cell context and\nfunctional target evidence',TEAL);card(ax,.58,.05,.34,.26,'Activity prediction and\nassay-specific search',VIOLET)
 ax=fig.add_subplot(gs[1,:2]);ax.axis('off');panel_label(ax,'b','Evidence has distinct experimental units')
 rows=[('Gout PBMC atlas','Patient','Cell localization / phase context'),('Urate factorial','Healthy donor','Priming response'),('Drug perturbation','Cell culture / donor','Transcript and secretion response'),('Genetic triangulation','Variant summary','Association and shared-signal evidence'),('Chemical replay','Structure / assay / seed','Prediction and selection performance')]
 for i,(name,unit,role) in enumerate(rows):
  y=.88-i*.18;ax.text(.0,y,name,fontsize=7,va='center',fontweight='bold');ax.text(.40,y,unit,fontsize=7,va='center',color=TEAL);ax.text(.0,y-.07,role,fontsize=6.5,va='center',color=INK)
 ax=fig.add_subplot(gs[1,2]);ax.axis('off');panel_label(ax,'c','Evidence questions')
 for y,t,col in [(.84,'Where is the\npatient signal?',BLUE),(.50,'What does the\nperturbation change?',ROSE),(.16,'Which compound\nshould be measured next?',VIOLET)]:
  ax.text(.03,y,t,fontsize=8,color=col,va='center',fontweight='bold')
 ax=fig.add_subplot(gs[2,0]);panel_label(ax,'d','Mapping sensitivity')
 for kind,col in [('TF',BLUE),('LR',TEAL)]:
  sub=a[a['分析'].eq(kind)];ax.plot(range(7),100*sub['未校正P小于05']/sub['固定检验族数'],marker='o',ms=3,color=col,lw=1,label=kind)
 ax.set(xticks=range(7),xticklabels=['1','2','3','4','5','6','Max'],xlabel='Assumed donor mapping',ylabel='Nominal P < 0.05 (%)',ylim=(0,8));ax.legend(loc='upper left',ncol=2,fontsize=6.5)
 ax=fig.add_subplot(gs[2,1]);panel_label(ax,'e','Detection-pattern coverage')
 # Complete, nonoverlapping partition of the previously eligible combination universe.
 vals=[5556,600,691,6674];assert sum(vals)==13521
 labels=['All six','Acute all 3*','Remission all 3*','Other']
 ax.barh(range(4),vals,color=[BLUE,ROSE,TEAL,GREY],height=.58);ax.set(yticks=range(4),yticklabels=labels,xlim=(0,8500),xticks=[0,4000,8000],xlabel='LR × cell-pair combinations');ax.invert_yaxis()
 for j,v in enumerate(vals):ax.text(v+130,j,f'{v:,}',va='center',fontsize=6.5)
 ax=fig.add_subplot(gs[2,2]);panel_label(ax,'f','Finite-control resolution')
 ax.plot(c.iloc[:,0],c['该组BHq'],color=VIOLET,lw=1.5);ax.axhline(.05,color=GREY,lw=.7,ls='--');ax.set(xlabel='Tests tied at P = 0.01',ylabel='BH q in a 45-test family',xlim=(1,45),ylim=(0,.48),xticks=[1,15,30,45]);ax.text(.98,.96,'Exact mathematical\nillustration',transform=ax.transAxes,ha='right',va='top',fontsize=6.5,color=VIOLET)
 legend='Figure 1 | Public evidence is organized by biological context and experimental unit. a, Source architecture linking patient cell context, an independent healthy-donor urate factorial, compound perturbations, a deposited primary screen and endpoint-clean chemical activities. Counts denote their stated units and are not pooled. b,c, Evidence roles and successive study questions. d, All six hypothetical donor crosswalks and the extra maximum-P envelope in the earlier TF/LR audit; mapping scenarios are not independent patients. e, All 13,521 LR-by-cell-pair combinations exceeding the earlier detection threshold in at least one library, partitioned into four complete categories. The asterisk means the other phase does not pass in all three libraries, not necessarily zero detection. f, The exact illustrative BH family has k P values equal to 0.01 and the remaining P values equal to one; the curve is an arithmetic resolution illustration, not a biological effect or power estimate. The final primary models and full contrast families remain defined separately in Methods.'
 save_figure(fig,fid,'Public evidence architecture and statistical units',{'a':'Public-data source flow','b':'Experimental-unit ledger','c':'Question sequence','d':'All mapping scenarios','e':'Full detection partition','f':'Exact mathematical illustration'},paths,legend,exclude_axes=fig.axes[:3])

if __name__=='__main__':workflow()
