"""Functional main figures: frozen observations, complete comparison families, Python redraw only."""
from atlas_style import *
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, Rectangle
from matplotlib.ticker import MaxNLocator
from pathlib import Path
import argparse
P=E/'07_实测药物与功能验证'; U=P/'01_尿酸刺激独立数据'; A=P/'02_药物扰动公共数据/GSE160430_实际分析'; D=P/'02_药物扰动公共数据/GSE246713_实际分析'; B=P/'03_候选功能证据'; K=P/'05_终点一致性敏感性'; BO=E/'06_干实验文献与贝叶斯优化/BO实测标签基准'; OLDQ=G/'全面验证_2026-11-02/02_公开扰动'
GENES=['NLRP3','CASP1','IL1B','XDH','SLC22A12','ABCG2','SLC2A9','TLR4','RELA','NFKB1','TNF','AKT1']
CONTR=['UA_without_LPS','UA_with_LPS','LPS_within_RPMI_positive_control','UAxLPS']
METHODS=['random','greedy_mean','LogEI'];MC={'random':GREY,'greedy_mean':BLUE,'LogEI':TEAL};ML={'random':'Random','greedy_mean':'Greedy mean','LogEI':'LogEI'}
MAP=json.loads((M/'source_map_functional.json').read_text(encoding='utf-8-sig')) if (M/'source_map_functional.json').exists() else []
def read(p): return pd.read_csv(p,sep='\t',low_memory=False)
def grid(rows=3,cols=2,h=228,left=.13,right=.98,bottom=.13,top=.95,wspace=.65,hspace=.60):
 fig,axs=plt.subplots(rows,cols,figsize=(183/25.4,h/25.4),squeeze=False)
 fig.subplots_adjust(left=left,right=right,bottom=bottom,top=top,wspace=wspace,hspace=hspace)
 return fig,axs.ravel().tolist()
def titles(axes,ts):
 for a,l,t in zip(axes,'abcdefghijk',ts):panel_label(a,l,t)
def off(ax):
 ax.set(xticks=[],yticks=[])
 for s in ax.spines.values():s.set_visible(False)
def note(ax,text,loc=(.02,.98),color=INK):ax.text(*loc,text,transform=ax.transAxes,fontsize=6.5,va='top',color=color)
def heat(fig,ax,v,rows,cols,lim=None,cmap=DIVERGING,colorlabel=None,sig=None,annot=None,rot=0,cbar=True):
 arr=np.asarray(v,dtype=float)
 if lim is None:lim=max(.01,float(np.nanmax(np.abs(arr))))
 im=ax.imshow(arr,cmap=cmap,vmin=-lim if cmap==DIVERGING else 0,vmax=lim,aspect='auto',interpolation='none')
 ax.set(xticks=range(len(cols)),xticklabels=cols,yticks=range(len(rows)),yticklabels=rows)
 ax.tick_params(axis='both',length=0,pad=3);ax.tick_params(axis='x',labelrotation=rot)
 for sp in ax.spines.values():sp.set_visible(False)
 if sig is not None:
  iy,ix=np.where(np.asarray(sig));ax.scatter(ix,iy,s=8,c=INK,marker='o',linewidth=0)
 if annot is not None:
  for iy in range(len(rows)):
   for ix in range(len(cols)):ax.text(ix,iy,annot[iy][ix],ha='center',va='center',fontsize=6.5,color=('white' if abs(arr[iy,ix])>.58*lim else INK))
 if cbar:
  pos=ax.get_position();ca=fig.add_axes([pos.x0,pos.y0-.078,pos.width,.011]);cb=fig.colorbar(im,cax=ca,orientation='horizontal');cb.ax.tick_params(labelsize=6.5,length=2,pad=2);cb.set_label(colorlabel or 'Effect',fontsize=6.5,labelpad=2)
 return im

def volcano(ax,d,x='logFC',p='P.Value',q='adj.P.Val',label_gene=None,gene='gene_symbol'):
 xx=pd.to_numeric(d[x],errors='coerce').to_numpy();pp=pd.to_numeric(d[p],errors='coerce').to_numpy();qq=pd.to_numeric(d[q],errors='coerce').to_numpy()
 good=np.isfinite(xx)&np.isfinite(pp)&(pp>0);assert good.all(),(len(d),int(good.sum()))
 yy=-np.log10(pp);colors=np.where((qq<.05)&(xx>0),ROSE,np.where((qq<.05)&(xx<0),BLUE,'#b7c1ca'))
 ax.scatter(xx,yy,c=colors,s=4,alpha=.65,lw=0,rasterized=True)
 ax.axvline(0,color=GREY,lw=.5);ax.set(xlabel='Expression effect (log2)',ylabel='-log10 nominal P')
 ax.set_ylim(-.2,float(yy.max())*1.12+.3);ax.xaxis.set_major_locator(MaxNLocator(4));ax.yaxis.set_major_locator(MaxNLocator(4))
 if label_gene:
  rr=d[d[gene].eq(label_gene)]
  if len(rr)==1:
   r=rr.iloc[0];xv=float(r[x]);yv=-np.log10(float(r[p]));ax.scatter([xv],[yv],s=23,c=GOLD,edgecolors='white',lw=.6,zorder=5);ax.annotate(label_gene,(xv,yv),xytext=((5 if xv>=0 else -5),4),textcoords='offset points',ha=('left' if xv>=0 else 'right'),fontsize=7,color=INK)

def forest(ax,df,label,eff,low,high,q=None,xlabel='Effect',color=TEAL):
 d=df.reset_index(drop=True);y=np.arange(len(d));v=d[eff].to_numpy(float);lo=d[low].to_numpy(float);hi=d[high].to_numpy(float)
 for i in y:
  co=color if q is None or float(d.iloc[i][q])<.05 else GREY
  ax.errorbar(v[i],i,xerr=[[v[i]-lo[i]],[hi[i]-v[i]]],fmt='o',ms=3.7,color=co,elinewidth=.9,capsize=1.8)
 ax.axvline(0,color=GREY,lw=.6,ls='--');ax.set(yticks=y,yticklabels=d[label].astype(str),ylim=(len(d)-.4,-.6),xlabel=xlabel);ax.tick_params(axis='y',length=0);ax.spines['left'].set_visible(False);ax.xaxis.set_major_locator(MaxNLocator(4))

def finish(fig,id,title,panels,inputs,legend,oldcodes,**extra):
 qa=save_figure(fig,id,title,panels,inputs,legend,**extra)
 MAP[:]=[x for x in MAP if x['new_id']!=id];MAP.append({'new_id':id,'old_codes':oldcodes,'panels':panels,'inputs':[str(x) for x in inputs]});dump(M/'source_map_functional.json',MAP)
 return qa

def f11():
 ps=[U/'成图source与最终审计/IL1B_4条件x4供体_全部观测source.tsv',U/'成图source与最终审计/IL1B_全部4对比_精确FDR族与4供体DiD.tsv',U/'实际模型结果/SymbolGene_UAxLPS_完整结果.tsv',U/'实际模型结果/冻结12candidate_4contrast_完整结果.tsv',U/'完整调控与通路活动/PROGENy_UAxLPS_供体阻断完整结果.tsv']
 obs,ct,genes,tgt,pa=[read(x) for x in ps];assert len(obs)==16 and len(ct)==4 and len(genes)==34495 and len(tgt)==48 and len(pa)==14
 fig,axs=grid(h=226);a,b,c,d,e,f=axs
 # The diagram records the actual factorial design, not a proposed mechanism.
 off(a);a.set(xlim=(0,1),ylim=(0,1))
 a.text(.02,.94,'4 healthy donors',fontsize=9,fontweight='bold',color=INK)
 a.text(.48,.78,'No LPS',ha='center',fontsize=7.5);a.text(.81,.78,'+ LPS',ha='center',fontsize=7.5)
 for j,(txt,co) in enumerate([('RPMI',GREY),('UA',GOLD)]):
  yy=.61-j*.28;a.text(.02,yy,txt,va='center',fontsize=8,color=INK)
  for i in range(2):
   x=.35+i*.33;a.add_patch(Rectangle((x,yy-.085),.27,.17,fc=TEAL if i else BLUE,alpha=.17,ec='none'));a.text(x+.135,yy,'n = 4',ha='center',va='center',fontsize=7.5)
 a.text(.02,.10,'16 matched observations\nDonor-blocked UA × LPS model',fontsize=7.2,color=INK,linespacing=1.35)
 order=['RPMI','UA','RPMI_LPS','UA_LPS'];wide=obs.pivot(index='donor',columns='condition',values='log2_normalized_MMSEQ_expression').reindex(columns=order)
 donorcols=[BLUE,TEAL,GOLD,VIOLET]
 for i,(_,row) in enumerate(wide.iterrows()):
  xx=np.arange(4)+(i-1.5)*.035
  for inds in [[0,1],[2,3]]:b.plot(xx[inds],row.to_numpy()[inds],marker=['o','s','D','^'][i],color=donorcols[i],ms=3.8,lw=.8)
 b.axvline(1.5,color=GREY,lw=.5,ls=':');b.set(xticks=range(4),xticklabels=['RPMI','UA','RPMI\n+ LPS','UA\n+ LPS'],ylabel='IL1B expression (log2)',xlim=(-.35,3.35))
 cc=ct.set_index('contrast').loc[CONTR].reset_index();cc['contrast_label']=['UA, no LPS','UA, + LPS','LPS control','UA × LPS'];forest(c,cc,'contrast_label','log2_expression_effect','CI95_symbol_model_low','CI95_symbol_model_high','BH_symbol_family_34495',xlabel='IL1B effect (log2)')

 volcano(d,genes,label_gene='IL1B');note(d,'34,495 symbols; interaction')
 mat=tgt.pivot(index='gene_symbol',columns='contrast',values='logFC').reindex(index=GENES,columns=CONTR);sig=tgt.pivot(index='gene_symbol',columns='contrast',values='adj.P.Val').reindex(index=GENES,columns=CONTR)<.05
 heat(fig,e,mat,GENES,['UA\nno LPS','UA\n+ LPS','LPS\ncontrol','UA × LPS'],lim=max(1,float(np.abs(mat.to_numpy()).max())),sig=sig,colorlabel='Expression effect (log2)')
 pa=pa.sort_values('feature_id');forest(f,pa,'feature_id','logFC','CI.L','CI.R','BH_all4contrast_family',xlabel='Pathway-score interaction')
 titles(axs,['Factorial monocyte perturbation','Urate-associated IL1B priming','All four IL1B contrasts','Genome-wide interaction','Twelve fixed candidate genes','Complete pathway response'])
 legend='''Fig. 11 | Urate priming depends on the inflammatory context. a, Four-donor UA-by-LPS factorial design in GSE107821. b, All sixteen IL1B observations; colours and shapes identify donors and lines join the same donor within LPS conditions. c, All four frozen contrasts, with marginal 95% moderated intervals; colour marks per-contrast BH qG<0.05 over 34,495 symbols. d, Every eligible symbol in the primary interaction; colours indicate per-contrast BH q<0.05, and the preselected IL1B is marked independently of significance. e, All twelve fixed candidates across the four contrasts; dots denote per-contrast gene-family BH q<0.05. f, All fourteen PROGENy score interactions, with marginal 95% intervals; coloured estimates pass BH over the complete fourteen-by-four pathway family. MMSEQ posterior log-expression was normalized by the recorded official procedure, not treated as integer counts. Healthy donors are independent of the gout patient atlas. All 48 target contrasts and every comparison family are retained.'''
 return finish(fig,'F11_Urate_priming','Urate priming and inflammatory context',dict(zip('abcdef',['factorial design','all16 IL1B observations','all4 effects','all34495 interaction symbols','all12×4 candidates','all14 PROGENy interactions'])),ps,legend,['B01','E09_Fig1_urate_panels'])

def f12():
 ps=[B/'Quercetin_全部15剂量时序_配对logratio_CI_BH.tsv',B/'Quercetin_推断输入_全部50同列logratio.tsv',B/'Quercetin_viability_独立协议_所有重复.tsv',B/'Quercetin_S1_全部作者归一重复_long.tsv',B/'Quercetin_作图协议与统计单位.tsv']
 summ,rat,vi,raw=[read(x) for x in ps[:4]];assert len(summ)==15 and len(rat)==50 and len(vi)==18
 bg=raw[raw.endpoint.eq('bacterial_growth')].copy();assert len(bg)==21
 fig,axs=grid(h=220);a,b,c,d,e,f=axs;off(a);a.set(xlim=(-2.6,4.7),ylim=(-.3,3.6))
 for i,(s,tt,co) in enumerate([('Pre-treatment',-2,VIOLET),('Co-treatment',0,BLUE),('Post-treatment',2,TEAL)]):
  y=2.8-i;a.plot([-2.2,4],[y,y],color=GREY,lw=.8);a.scatter([0],[y],s=25,c=GREY,zorder=3);a.scatter([tt],[y],s=36,c=co,marker='D',zorder=5);a.plot([4,4],[y-.15,y+.15],color=INK,lw=1);a.text(-2.35,y+.25,s,fontsize=7.5,color=co);a.text(4.2,y,'IL-1β',va='center',fontsize=7)
 a.text(-2.2,-.05,'−2 h',ha='center',fontsize=7);a.text(0,-.05,'0',ha='center',fontsize=7);a.text(2,-.05,'+2 h',ha='center',fontsize=7);a.text(4,-.05,'+4 h',ha='center',fontsize=7)
 a.text(-2.2,-.45,'Diamond: quercetin; circle: PAO1',fontsize=6.5,color=INK)
 dose=[20,40,60,80,100];yl=max(1.5,float(summ.ratio_95CI_high_marginal.max())*1.08)
 for ax,(schedule,co,nn) in zip([b,c,d],[('IL1beta_pretreatment',VIOLET,3),('IL1beta_cotreatment',BLUE,4),('IL1beta_posttreatment',TEAL,3)]):
  z=summ[summ.schedule.eq(schedule)].set_index('dose_uM').loc[dose];rr=rat[rat.schedule.eq(schedule)]
  for j,dd in enumerate(dose):
   x=rr[rr.dose_uM.eq(dd)].sort_values('Exp_as_labeled');xx=j+np.linspace(-.12,.12,len(x));ax.scatter(xx,x.treated_over_stimulated_vehicle_ratio,s=12,facecolors='none',edgecolors=co,lw=.65,alpha=.9,zorder=3)
   row=z.loc[dd];v=row.geometric_treated_over_vehicle_ratio;lo=row.ratio_95CI_low_marginal;hi=row.ratio_95CI_high_marginal
   ax.errorbar(j,v,yerr=[[v-lo],[hi-v]],fmt='D',ms=4.2,color=co,mfc=co if row.BH_q_all15<.05 else 'white',mec=co,elinewidth=1,capsize=2,zorder=4)
  ax.axhline(1,color=GREY,lw=.7,ls='--');ax.set(xticks=range(5),xticklabels=dose,xlim=(-.45,4.45),ylim=(0,yl),xlabel='Quercetin (µM)',ylabel='IL-1β / stimulated vehicle');note(ax,f'n = {nn} author Exp columns')
 for ax,df,key,col in [(e,vi,'author_supplied_normalized_value',GOLD),(f,bg,'author_supplied_normalized_value',TEAL)]:
  vals=[];labs=[]
  if ax is e:groups=[('untreated',np.nan)]+[('quercetin',v) for v in dose]
  else:groups=[('untreated',np.nan),('vehicle',np.nan)]+[('quercetin',v) for v in dose]
  for j,(tr,dd) in enumerate(groups):
   subset=df[df.treatment.eq(tr)&(df.dose_uM.eq(dd) if np.isfinite(dd) else df.dose_uM.isna())]
   assert len(subset)==3,(tr,dd,len(subset));v=subset[key].to_numpy(float);ax.scatter(j+np.linspace(-.12,.12,3),v,s=13,c=col,alpha=.8,edgecolors='white',lw=.3);ax.plot([j-.22,j+.22],[v.mean(),v.mean()],color=INK,lw=1.1);labs.append('Unt.' if tr=='untreated' else 'Veh.' if tr=='vehicle' else str(int(dd)))
  ax.axhline(100,color=GREY,lw=.6,ls='--');ax.set(xticks=range(len(groups)),xticklabels=labs,xlabel='Control or quercetin dose (µM)',ylabel='Author-normalized value (%)');ax.tick_params(axis='x',labelrotation=45);ax.set_ylim(bottom=max(0,float(df[key].min())-12),top=float(df[key].max())+12)
 note(e,'Drug-only MTT; separate protocol');note(f,'Separate bacterial-growth assay')
 titles(axs,['Published exposure schedules','Before infection: all five doses','At infection: all five doses','After infection: all five doses','Host-cell viability observations','Bacterial-growth observations'])
 legend='''Fig. 12 | Published quercetin measurements resolve dose and exposure timing. a, Reported THP-1/PAO1 exposure schedules: quercetin two hours before, at, or two hours after infection, with the author four-hour infection protocol. b–d, All fifty within-timing treated-to-stimulated-vehicle ratios across all fifteen comparisons. Open circles are individual author Exp columns; diamonds and bars are geometric ratios and transformed marginal 95% log-ratio t intervals. Filled diamonds indicate BH q<0.05 across all fifteen comparisons. Within-column matching is conditional on the source labels; Exp columns are not paired across schedules. e, All eighteen drug-only MTT observations, including untreated controls. f, All twenty-one separate bacterial-growth observations, including untreated and vehicle controls. Horizontal segments in e,f are descriptive arithmetic means, without hypothesis tests. MTT exposure is inconsistent between source Methods and caption (24 versus 48 h), and neither viability nor bacterial growth is a protocol-matched adjustment of the secretion response. All values derive from the genuine numerical supplementary tables of DOI 10.1371/journal.pone.0237752; no new experiment is represented.'''
 return finish(fig,'F12_Quercetin_function','Quercetin functional responses across exposure schedules',dict(zip('abcdef',['reported exposure setup','all pre-treatment ratios','all co-treatment ratios','all post-treatment ratios','all18 MTT values','all21 bacterial-growth values'])),ps,legend,['B02','E09_Fig2'])

def f13():
 names=['固定12靶点_全部覆盖与效应.tsv','全部映射基因_三个供者配对变化.tsv','全部10877共同基因_健康扰动与疾病阶段方向.tsv','九KEGG_覆盖与两个背景完整检验比较.tsv','全部基因_六样本PCA.tsv']
 ps=[OLDQ/x for x in names]+[A/'主分析_全10_传代阻断_所有基因所有比较_limma.tsv',A/'全部通路与TF_培养级阻断分数模型.tsv',P/'06_跨研究整合/全部12对_完整共同签名_描述性对照.tsv']
 tgt,delta,common,path,pca,arr,fp,cross=[read(p) for p in ps]
 assert len(tgt)==12 and len(common)==10877 and len(pca)==6 and len(cross)==12 and len(arr)==19233*3
 fig,axs=grid(rows=4,h=250,bottom=.12,hspace=.85,wspace=.72);a,b,c,d,e,f,g,h=axs
 tgt=tgt.set_index('gene_symbol').loc[GENES].reset_index();de=delta.set_index('gene_symbol');yy=np.arange(12)
 for i,r in tgt.iterrows():
  v=r.quercetin_log2FC;a.errorbar(v,i,xerr=[[v-r.quercetin_CI_low],[r.quercetin_CI_high-v]],fmt='D',color=INK,ms=3.3,lw=.75,capsize=1.5)
  for k,key in enumerate(['D1_after_minus_before','D2_after_minus_before','D3_after_minus_before']):a.scatter(de.loc[r.gene_symbol,key],i+(k-1)*.13,s=9,c=[BLUE,GOLD,VIOLET][k],zorder=4)
 a.axvline(0,color=GREY,lw=.5,ls='--');a.set(yticks=yy,yticklabels=GENES,ylim=(11.6,-.6),xlabel='After − before effect (log2)');a.tick_params(axis='y',length=0);a.spines['left'].set_visible(False);a.xaxis.set_major_locator(MaxNLocator(4))
 hb=b.hexbin(common.disease_flare_remission_mean_logFC,common.quercetin_after_before_log2FC,gridsize=30,mincnt=1,bins='log',cmap=SEQUENTIAL,linewidths=0,rasterized=False)
 assert abs(float(hb.get_array().sum())-10877)<1e-5
 fixed=common[common.in_fixed12.astype(str).str.lower().eq('true')];b.scatter(fixed.disease_flare_remission_mean_logFC,fixed.quercetin_after_before_log2FC,s=22,facecolors='none',edgecolors=GOLD,lw=.85)
 b.axhline(0,color=GREY,lw=.5);b.axvline(0,color=GREY,lw=.5);b.set(xlabel='Gout-stage context effect (log2)',ylabel='Quercetin effect (log2)');note(b,'n = 10,877\nρ = 0.096')
 # Signed evidence tiles retain different cohort-specific correction families.
 short=['Purine','MAPK','NFκB','PI3K–Akt','Toll-like receptor','NOD-like receptor','IL-17','TNF','Adipocytokine']
 pathvals=np.column_stack([np.where(path.quercetin_Direction.eq('Up'),1,-1)*-np.log10(path.quercetin_q_BH9),np.where(path.disease_Direction.eq('Up'),1,-1)*-np.log10(path.disease_q_BH72)])
 ann=[[f'{float(row.quercetin_q_BH9):.3f}',f'{float(row.disease_q_BH72):.3f}'] for row in path.itertuples()]
 heat(fig,c,pathvals,short,['Quercetin\nBH: 9','Gout stage\nBH: 72'],lim=2.1,annot=ann,cbar=False)
 for k,donor in enumerate(['D1','D2','D3']):
  pp=pca[pca.donor.eq(donor)].copy().set_index('period').loc[['Before','After']];d.plot(pp.PC1,pp.PC2,c=[BLUE,GOLD,VIOLET][k],lw=.8)
  for period,mark in [('Before','o'),('After','^')]:
   rr=pp.loc[period];d.scatter(rr.PC1,rr.PC2,c=[BLUE,GOLD,VIOLET][k],s=26,marker=mark,edgecolors='white',lw=.4);d.annotate(donor+('B' if period=='Before' else 'A'),(rr.PC1,rr.PC2),xytext=((-5,0) if donor=='D1' and period=='Before' else (8,8) if donor=='D2' and period=='Before' else (4,3)),ha=('right' if donor=='D1' and period=='Before' else 'left'),textcoords='offset points',fontsize=6.5)
 d.set(xlabel='PC1 (50.72%)',ylabel='PC2 (21.54%)',xlim=(-35,85),ylim=(-38,50));d.xaxis.set_major_locator(MaxNLocator(4));d.yaxis.set_major_locator(MaxNLocator(4))
 drugs=['Quercetin_minus_DMSO','Myricetin_minus_DMSO','Punicalagin_minus_DMSO'];dl=['Quercetin','Myricetin','Punicalagin']
 t=arr[arr.gene_symbol.isin(GENES)];mat=t.pivot(index='gene_symbol',columns='contrast',values='logFC').reindex(index=GENES,columns=drugs);q=t.pivot(index='gene_symbol',columns='contrast',values='q_BH_all_genes_all_drugs').reindex(index=GENES,columns=drugs)
 im_e=heat(fig,e,mat,GENES,dl,lim=float(np.abs(mat.to_numpy()).max()),sig=q.to_numpy()<.05,cbar=False,rot=25)
 pe=e.get_position();ce=fig.add_axes([pe.x1+.015,pe.y0,.009,pe.height]);be=fig.colorbar(im_e,cax=ce);be.ax.tick_params(labelsize=6.5,length=2,pad=2);be.set_label('Expression effect (log2)',fontsize=6.5,labelpad=3)
 aq=arr[arr.contrast.eq('Quercetin_minus_DMSO')];volcano(f,aq,q='q_BH_all_genes_all_drugs',label_gene='IL1B')
 cc=cross.pivot(index='UA_contrast',columns='drug',values='spearman_logFC_descriptive_noP').reindex(index=CONTR,columns=dl)
 heat(fig,g,cc,['UA, no LPS','UA, + LPS','LPS control','UA × LPS'],dl,lim=.10,annot=[[f'{z:+.3f}' for z in row] for row in cc.to_numpy()],cbar=False,rot=25)
 fp=fp[fp.resource.eq('PROGENy14')&fp.model.eq('主分析_全10_传代阻断')];pm=fp.pivot(index='source',columns='contrast',values='score_difference').reindex(columns=drugs);pq=fp.pivot(index='source',columns='contrast',values='q_BH_all_sources_all3drugs_ifmain').reindex(index=pm.index,columns=drugs)
 assert pm.shape==(14,3)
 heat(fig,h,pm,pm.index,dl,lim=float(np.abs(pm.to_numpy()).max()),sig=pq.to_numpy()<.05,colorlabel='Pathway-score difference',rot=25)
 titles(axs,['Paired human PBMC responses','Complete cross-context signature','Nine predefined pathway tests','Every paired PBMC array','THP-1: twelve candidates × three drugs','THP-1: quercetin genome response','All twelve cross-study comparisons','THP-1: complete pathway responses'])
 legend='''Fig. 13 | Quercetin-associated RNA responses vary across experimental contexts. a–d, GSE13899 comprises three healthy volunteers before and after two weeks of 150 mg/day quercetin, with no placebo arrays. a, All twelve fixed candidates: three donor changes (D1 blue, D2 gold, D3 purple), paired-limma effects and marginal 95% intervals. b, All 10,877 common genes versus the frozen three-patient gout CD14 stage context; hexagons count genes, open circles mark the nine jointly measured fixed targets. c, All nine frozen KEGG tests; warm/cool denotes competitive Up/Down direction and printed values are BH q within the respective 9- and 72-test families. d, All six arrays in the original complete-gene PCA. e,f,h, GSE160430, analysed with the recorded all-ten-culture passage-blocked model: twelve candidates across three drugs, every one of 19,233 genes in the quercetin contrast, and all fourteen PROGENy score contrasts per drug. Filled heatmap dots denote the complete three-drug family q<0.05; f uses the complete gene-by-three-drug family. g, Descriptive Spearman correlations across every four-UA-by-three-drug comparison on 16,246 shared symbols. The colour scale is ±0.10; gene numbers do not constitute donor replicates. No RNA comparison establishes cytokine mediation or gout reversal. All contrasts and all source observations remain available.'''
 return finish(fig,'F13_Quercetin_transcript_context','Context-specific human and culture transcriptional responses',dict(zip('abcdefgh',['all12 paired PBMC targets','all10877 common genes','all9 KEGG tests in both contexts','all6 PBMC arrays','all12×3 THP1 candidates','all19233 quercetin genes','all4×3 cross-study pairs','all14×3 THP1 pathways'])),ps,legend,['Q02A','Q02B','GSE160430','E07_crossstudy12'])

def f14():
 ps=[D/'main_voom_TMM_完整5比较_MGI注释.tsv',D/'sensitivity_logCPM_noTMM_完整5比较_MGI注释.tsv',D/'全部通路与TF_HCOP_培养级完整5比较.tsv',D/'实际全6组设计矩阵.tsv',D/'完整5比较_全基因及globalBH计数.tsv']
 de,sens,act,design,counts=[read(p) for p in ps];assert len(de)==14423*5 and len(sens)==14423*5
 fig,axs=grid(rows=4,h=250,bottom=.12,hspace=.85,wspace=.72);a,b,c,d,e,f,g,h=axs
 groups=['D303N_Untreated','D303N_Dox','D303N_Dox_MCC950','WT_Untreated','WT_Dox','WT_Dox_MCC950'];ns=design[groups].sum().to_numpy();assert ns.sum()==22
 xx=np.arange(6);a.bar(xx,ns,color=[GREY,GOLD,TEAL,GREY,GOLD,TEAL],width=.67);a.set(xticks=xx,xticklabels=['D303N\nbasal','D303N\nDox','D303N\n+MCC','WT\nbasal','WT\nDox','WT\n+MCC'],ylabel='Independent cultures',ylim=(0,5.2),yticks=[0,2,4]);a.tick_params(axis='x',labelrotation=0)
 for i,n in enumerate(ns):a.text(i,n+.15,str(int(n)),ha='center',fontsize=7)
 sel=de[de.contrast.isin(['MCC950_D303N','MCC950_WT','DrugByGenotype'])];xl=max(float(sel.logFC.abs().max()),.1)*1.05;yl=-np.log10(sel['P.Value'].min())*1.08
 for ax,con in zip([b,c,d],['MCC950_D303N','MCC950_WT','DrugByGenotype']):
  z=de[de.contrast.eq(con)];volcano(ax,z,q='q_BH_all_genes_all5contrasts',gene='mouse_gene_symbol_MGI');ax.set(xlim=(-xl,xl),ylim=(-.2,yl));rr=counts.set_index('contrast').loc[con];note(ax,f"{int(rr.global5_q05)} genes\n(global q < 0.05)")
 paths=act[act.model.eq('main_voom_TMM')&act.resource.eq('PROGENy14')];pi=paths[paths.contrast.eq('DrugByGenotype')].sort_values('source_human_label');assert len(pi)==14
 forest(e,pi,'source_human_label','score_difference','CI.L','CI.R','q_BH_all_sources_all5contrasts',xlabel='Drug-by-genotype score effect')
 cons=['MCC950_D303N','MCC950_WT','DrugByGenotype','DoxInduction_D303N','DoxInduction_WT'];pm=paths.pivot(index='source_human_label',columns='contrast',values='score_difference').reindex(index=pi.source_human_label,columns=cons);pq=paths.pivot(index='source_human_label',columns='contrast',values='q_BH_all_sources_all5contrasts').reindex(index=pm.index,columns=cons)
 im_f=heat(fig,f,pm,pm.index,['D303N\nDrug','WT\nDrug','Drug × G','D303N\nDox','WT\nDox'],lim=float(np.abs(pm.to_numpy()).max()),sig=pq.to_numpy()<.05,cbar=False,rot=0)
 pf=f.get_position();cf=fig.add_axes([pf.x0,pf.y0-.046,pf.width,.011]);bf=fig.colorbar(im_f,cax=cf,orientation='horizontal');bf.ax.tick_params(labelsize=6.5,length=2,pad=2);bf.set_label('Pathway-score difference',fontsize=6.5,labelpad=2)
 tf=act[act.model.eq('main_voom_TMM')&act.contrast.eq('DrugByGenotype')&act.resource.str.contains('CollecTRI')];assert len(tf)==541,len(tf)
 volcano(g,tf,x='score_difference',p='P.Value',q='q_BH_all_sources_all5contrasts');g.set_xlabel('TF-score interaction');note(g,'541 orthologue-mapped TFs')
 mm=de[de.contrast.eq('DrugByGenotype')].merge(sens[sens.contrast.eq('DrugByGenotype')],on='gene_id',suffixes=('_main','_sens'),validate='one_to_one');assert len(mm)==14423
 h.scatter(mm.logFC_main,mm.logFC_sens,s=4,c=np.where(mm.q_BH_all_genes_all5contrasts_main<.05,ROSE,'#b7c1ca'),alpha=.6,lw=0,rasterized=True);lo=min(mm.logFC_main.min(),mm.logFC_sens.min());hi=max(mm.logFC_main.max(),mm.logFC_sens.max());h.plot([lo,hi],[lo,hi],ls='--',color=GREY,lw=.8);h.set(xlabel='TMM/voom interaction (log2)',ylabel='No-TMM sensitivity (log2)');note(h,'All 14,423 shared genes')
 titles(axs,['Six-group engineered-cell design','MCC950 in D303N cultures','MCC950 in WT cultures','Direct drug-by-genotype interaction','All fourteen pathway interactions','Every pathway × contrast','Complete TF interaction family','Input-processing sensitivity'])
 legend='''Fig. 14 | NLRP3 genotype conditions the MCC950 transcriptional response. a, All twenty-two independent engineered Nlrp3-null mouse macrophage cultures, grouped by inducible human WT or D303N NLRP3, doxycycline and MCC950 exposure. b–d, Every one of 14,423 eligible genes in the two drug contrasts and their direct interaction; red/blue marks pass BH across all 14,423-by-five tests. All panels use common axes and retain every gene. e, All fourteen PROGENy interactions, with marginal 95% intervals and colour for BH q<0.05 across fourteen-by-five tests. f, Complete fourteen-pathway-by-five-contrast score differences; dots use that same seventy-test family. g, All 541 mapped transcription factors in the interaction; the TF-by-five family is separate from the pathway family. Human prior labels were transferred through the frozen support-qualified reciprocal-unique HCOP mapping. h, All 14,423 gene interactions in the fixed alternative no-TMM processing model, with primary-family hits highlighted; the diagonal is identity, not a fitted line. The six-group model, both induction contrasts, all orthology records and both processing outputs are preserved. The exact normalization stage of the deposited fractional DRAGEN matrix is unresolved, and the engineered transgene does not constitute patient target engagement.'''
 return finish(fig,'F14_MCC950_genotype','Genotype-specific MCC950 transcriptional response',dict(zip('abcdefgh',['all22 cultures in6groups','all14423 D303N genes','all14423 WT genes','all14423 direct interaction genes','all14 pathways withCI','all14×5 pathway contrasts','all541 TF interactions','all14423 processing sensitivity pairs'])),ps,legend,['B03','E09_Fig3'])

def f20():
 ps=[K/'endpointclean_fixedsplit_calibration_test_全部逐值.tsv',K/'old_vs_endpointclean_完整误差覆盖汇总.tsv',K/'UQ_全部固定覆盖水平_描述性.tsv',K/'固定旧训练分区_冻结49预测.tsv',K/'共同旧test_两模型同真值_配对逐化合物.tsv',K/'endpoint_clean_全部化合物_继承旧骨架分区.tsv',K/'移除16条DPPH_全部原记录.tsv',K/'old547_fixedsplit_calibration_test_全部逐值.tsv',K/'全部547化合物_原清洁端点与分区变动.tsv']
 pred,metrics,uq,cand,paired,comp,removed=[read(p) for p in ps[:7]];test=pred[pred.partition.eq('test')];cal=pred[pred.partition.eq('calibration')];cand=cand[cand.model.eq('clean_fixedsplit')].copy()
 assert len(test)==131 and len(cal)==89 and len(comp)==544 and len(cand)==49 and len(paired)==131 and len(removed)==16
 fig,axs=grid(rows=4,h=250,bottom=.12,hspace=.85,wspace=.70);a,b,c,d,e,f,g,h=axs
 off(a);a.set(xlim=(0,1),ylim=(0,1))
 boxes=[(.03,.82,.94,.14,'1,064 deposited XO-labelled records',GREY),(.03,.58,.94,.14,'605 primary → 589 endpoint-clean rows',BLUE),(.03,.34,.94,.14,'544 normalized structures',TEAL)]
 for x,y,w,hh,txt,co in boxes:a.add_patch(Rectangle((x,y),w,hh,fc=co,alpha=.17,ec='none'));a.text(x+w/2,y+hh/2,txt,ha='center',va='center',fontsize=7.5)
 for y1,y2 in [(.82,.72),(.58,.48)]:a.annotate('',xy=(.5,y2),xytext=(.5,y1),arrowprops=dict(arrowstyle='->',color=INK,lw=.8))
 a.text(.03,.18,'16 DPPH rows excluded; partitions retained',fontsize=6.5)
 a.text(.03,.025,'Train 324   |   Calibrate 89   |   Test 131',fontsize=7,fontweight='bold',color=INK)
 b.scatter(test.pIC50_median,test.predicted_pIC50,s=14,c=BLUE,alpha=.65,edgecolors='white',lw=.25,rasterized=True)
 lo=min(test.pIC50_median.min(),test.predicted_pIC50.min())-.2;hi=max(test.pIC50_median.max(),test.predicted_pIC50.max())+.2;b.plot([lo,hi],[lo,hi],c=GREY,lw=.8,ls='--');b.set(xlim=(lo,hi),ylim=(lo,hi),xlabel='Observed pIC50',ylabel='Predicted pIC50');note(b,'n = 131; R² = 0.542\nRMSE = 0.790; baseline 1.180')
 c.scatter(test.observation_std,(test.predicted_pIC50-test.pIC50_median).abs(),s=12,c=TEAL,alpha=.65,lw=0);c.set(xlabel='Predicted observation SD',ylabel='Absolute held-out error');c.yaxis.set_major_locator(MaxNLocator(4));c.xaxis.set_major_locator(MaxNLocator(4))
 uc=uq[uq.model_evaluation.eq('clean_own_retainedtest')].sort_values('nominal_Gaussian_observation_coverage');assert len(uc)==4
 for col,co,lab,mark in [('test_molecule_empirical_coverage',BLUE,'Molecules','o'),('test_whole_scaffold_empirical_coverage',TEAL,'Whole scaffolds','s')]:d.plot(uc.nominal_Gaussian_observation_coverage,uc[col],c=co,lw=1,marker=mark,ms=4,label=lab)
 d.plot([.45,1],[.45,1],c=GREY,ls='--',lw=.7);d.set(xlim=(.45,1),ylim=(.45,1.03),xlabel='Nominal Gaussian coverage',ylabel='Empirical coverage',xticks=[.5,.7,.9]);d.legend(loc='lower right',fontsize=6.5,handlelength=1.2)
 mr=metrics[metrics.comparison.eq('clean_retained_test_clean_truth')].iloc[0]
 for mode,marker in [('raw90','o'),('calibrated90','s')]:
  width=mr[mode+'_mean_width']
  for pop,co in [('molecule',BLUE),('whole_scaffold',TEAL)]:e.scatter(width,mr[mode+'_'+pop+'_coverage'],s=32,c=co,marker=marker,edgecolors='white',lw=.5)
 e.axhline(.9,color=GREY,lw=.65,ls='--');e.set(xlim=(2.9,3.95),ylim=(.88,1.02),xlabel='Mean 90% interval width (pIC50)',ylabel='Empirical coverage');e.text(3.18,.882,'Calibrated',ha='center',fontsize=6.5);e.text(3.68,.882,'Raw',ha='center',fontsize=6.5)
 sc=f.scatter(cand.prediction_mean_pIC50,cand.latent_std_pIC50,c=cand.nearest_training_Tanimoto,cmap=SEQUENTIAL,vmin=0,vmax=1,s=23,edgecolors=BLUE,lw=.35);f.set(xlabel='Predicted candidate activity (pIC50)',ylabel='Latent posterior SD')
 po=f.get_position();ca=fig.add_axes([po.x0,po.y0-.046,po.width,.011]);cb=fig.colorbar(sc,cax=ca,orientation='horizontal');cb.ax.tick_params(labelsize=6.5,length=2);cb.set_label('Nearest-training Tanimoto',fontsize=6.5,labelpad=2)
 co=cand.sort_values(['prediction_mean_pIC50','original_pubchem_cid'],ascending=[False,True]).reset_index(drop=True);ranks=np.arange(1,50);v=co.prediction_mean_pIC50.to_numpy();ll=co.calibrated90_low.to_numpy();hh=co.calibrated90_high.to_numpy()
 g.errorbar(ranks,v,yerr=[v-ll,hh-v],fmt='o',ms=2.5,color=BLUE,ecolor='#acbfc9',elinewidth=.4,capsize=0);g.set(xlabel='Candidate rank by predicted mean',ylabel='Predicted pIC50 with 90% interval',xlim=(0,50),xticks=[1,10,20,30,40,49]);g.yaxis.set_major_locator(MaxNLocator(4))
 h.scatter(paired.old_error_vs_clean_truth.abs(),paired.absolute_error_change_clean_minus_old,s=13,c=ROSE,alpha=.68,lw=0);h.axhline(0,color=GREY,lw=.65,ls='--');h.set(xlabel='Old-model absolute error',ylabel='Change in absolute error')
 titles(axs,['Endpoint-resolved label collection','Independent scaffold holdout','Prediction error and uncertainty','Coverage at every nominal level','Raw versus calibrated intervals','Candidate novelty and uncertainty','Complete prospective ranking queue','Paired endpoint-cleaning sensitivity'])
 legend='''Fig. 20 | Endpoint-resolved prediction quantifies uncertainty in a historical xanthine-oxidase-labelled chemical library. a, Record-level endpoint correction preserves the inherited scaffold partitions: 324 training, 89 calibration and 131 retained test structures. Sixteen explicitly DPPH records were excluded in the fixed sensitivity, leaving 589 records and 544 normalized structures. b,c, All 131 endpoint-clean held-out predictions and errors from the fixed Morgan/Tanimoto Gaussian process. The diagonal in b is identity; the comparison baseline is the training mean. d, Every retained nominal Gaussian coverage level, evaluated over both molecules and all members of each of forty-four test scaffolds. e, Raw and separately scaffold-calibrated 90% interval coverage and mean width; blue denotes molecule coverage and teal whole-scaffold coverage, with circle/square for raw/calibrated. Calibration uses forty-four independent calibration scaffolds. f,g, All forty-nine frozen candidates without exact activity labels in the curated library. f distinguishes latent uncertainty from observation intervals and colours nearest-training similarity. g displays all mean-ranked candidates with calibrated observation intervals; full identities are supplied in source tables. h, Paired changes in absolute error for old and cleaned models on exactly the same clean test truth. All observations, original labels, endpoint exclusions and changed candidate forecasts remain traceable. The plots represent historical-label prediction and a candidate queue, not newly measured inhibition.'''
 return finish(fig,'F20_Chemical_prediction_uncertainty','Chemical prediction, calibration and candidate uncertainty',dict(zip('abcdefgh',['endpoint cleaning counts and fixed split','all131 held-out compounds','all131 residual/uncertainty pairs','all4 nominal coverage levels','raw/cal90 coverage width','all49 candidate novelty values','all49 calibrated forecasts','all131 paired cleaning effects'])),ps,legend,['A04_a','A04_b','E09_Fig4_GP_UQ'])

def f21():
 ps=[E/'09_整篇论文与组图_2026-11-03/图源数据/Fig5_Assay_resolved_search_每任务全部策略_均值与初始化区间.tsv',E/'09_整篇论文与组图_2026-11-03/图源数据/Fig5_Assay_resolved_search_全部任务_两策略对随机的配对差.tsv',BO/'BO_assay_每任务每种子终点.tsv',BO/'BO_assay_等assay权重_完整预算进度曲线.tsv',BO/'BO_assay_每任务终点_全部策略.tsv',BO/'BO_assay_各任务真实分母与标签范围.tsv',BO/'BO_20种子三策略_全部逐轮轨迹.tsv',BO/'BO_assay_全部逐轮轨迹.tsv']
 sm,di,end,cur,summ,meta,mixed,allcur=[read(p) for p in ps];assert len(end)==8*3*20 and end.assay_id.nunique()==8 and mixed.seed.nunique()==20
 aids=sorted(meta.assay_id.unique());labs=[x.replace('CHEMBL','') for x in aids];fig,axs=grid(rows=4,h=250,bottom=.12,hspace=.85,wspace=.70);a,b,c,d,e,f,g,h=axs
 for j,method in enumerate(METHODS):
  z=sm[sm.method.eq(method)].set_index('assay_id').loc[aids];y=np.arange(8)+(j-1)*.22;v=z.top20pct_mean.to_numpy()*100;lo=z.bootstrap95_low.to_numpy()*100;hi=z.bootstrap95_high.to_numpy()*100
  a.errorbar(v,y,xerr=[v-lo,hi-v],fmt='o',ms=3.4,color=MC[method],elinewidth=.75,capsize=1.3,label=ML[method])
 a.set(yticks=range(8),yticklabels=labs,ylim=(7.6,-.6),xlim=(-3,103),xlabel='Top-20% recall (%)');a.tick_params(axis='y',length=0);a.spines['left'].set_visible(False)
 for j,method in enumerate(['greedy_mean','LogEI']):
  z=di[di.method.eq(method)].set_index('assay_id').loc[aids];y=np.arange(8)+(j-.5)*.24;v=z.paired_mean_difference_pp.to_numpy();lo=z.bootstrap95_low_pp.to_numpy();hi=z.bootstrap95_high_pp.to_numpy()
  b.errorbar(v,y,xerr=[v-lo,hi-v],fmt='o',ms=3.4,c=MC[method],elinewidth=.75,capsize=1.3)
 b.axvline(0,color=GREY,lw=.65,ls='--');b.set(yticks=range(8),yticklabels=labs,ylim=(7.6,-.6),xlabel='Paired advantage over random (pp)');b.tick_params(axis='y',length=0);b.spines['left'].set_visible(False)
 for ax,metric,titlelabel,maxval,fmt in [(c,'top5pct_recall_mean','Top-5% recall',1.0,'.0%'),(d,'normalized_regret_mean','Normalized regret',float(summ.normalized_regret_mean.max()),'.3f')]:
  mm=summ.pivot(index='assay_id',columns='method',values=metric).reindex(index=aids,columns=METHODS)
  anns=[[format(z,fmt) for z in row] for row in mm.to_numpy()];heat(fig,ax,mm,labs,[ML[m].replace(' ','\n') for m in METHODS],lim=maxval,cmap=SEQUENTIAL,annot=anns,cbar=False)
 for method in METHODS:
  z=cur[cur.method.eq(method)];gr=z.groupby('fraction_postinitial_budget').top5pct_recall;xx=np.asarray(sorted(gr.groups));me=gr.mean().reindex(xx).to_numpy();lo=gr.quantile(.25).reindex(xx).to_numpy();hi=gr.quantile(.75).reindex(xx).to_numpy()
  e.plot(xx,100*me,c=MC[method],lw=1.2);e.fill_between(xx,100*lo,100*hi,color=MC[method],alpha=.17,lw=0)
 e.set(xlabel='Fraction of post-initial query budget',ylabel='Equal-assay top-5% recall (%)',xlim=(0,1));e.xaxis.set_major_locator(MaxNLocator(4));e.yaxis.set_major_locator(MaxNLocator(4))
 for j,method in enumerate(METHODS):
  z=end[end.method.eq(method)]
  for i,aid in enumerate(aids):
   rr=z[z.assay_id.eq(aid)].sort_values('seed');y=i+(j-1)*.22;offs=np.linspace(-.05,.05,len(rr));f.scatter(rr.raw_best_pIC50,y+offs,s=6,c=MC[method],alpha=.23,lw=0,rasterized=True);f.scatter(rr.raw_best_pIC50.mean(),y,s=18,c=MC[method],edgecolors='white',lw=.35)
 f.set(yticks=range(8),yticklabels=labs,ylim=(7.6,-.6),xlabel='Best queried historical pIC50');f.tick_params(axis='y',length=0);f.spines['left'].set_visible(False);f.xaxis.set_major_locator(MaxNLocator(4))
 for method in METHODS:
  z=mixed[mixed.method.eq(method)];gr=z.groupby('evaluated_total').top5pct_recall;xx=np.asarray(sorted(gr.groups));me=gr.mean().reindex(xx).to_numpy();lo=gr.quantile(.25).reindex(xx).to_numpy();hi=gr.quantile(.75).reindex(xx).to_numpy()
  g.plot(xx,100*me,c=MC[method],lw=1.2);g.fill_between(xx,100*lo,100*hi,color=MC[method],alpha=.17,lw=0)
 g.set(xlabel='Total queried compounds',ylabel='Mixed-pool top-5% recall (%)',xlim=(10,40));note(g,'17/17 top hits share one assay')
 off(h);zz=meta.set_index('assay_id').loc[aids];rows=[[lab,str(int(r.n_compounds)),str(int(r.budget)),str(int(r.top5pct_actual_count)),str(int(r.top20pct_actual_count))] for lab,(_,r) in zip(labs,zz.iterrows())]
 tab=h.table(cellText=rows,colLabels=['Assay','Pool','Queries','Top5','Top20'],cellLoc='center',colLoc='center',bbox=[-.07,.03,1.08,.95],colWidths=[.30,.15,.19,.17,.19]);tab.auto_set_font_size(False);tab.set_fontsize(6.5)
 for (ri,ci),cell in tab.get_celld().items():cell.set_linewidth(.3);cell.set_edgecolor('#d5dde3');cell.set_facecolor('#edf3f6' if ri==0 else 'white');cell.get_text().set_color(INK)
 titles(axs,['All eight assay-specific searches','Paired initialization differences','Strongest-hit recovery by assay','Residual regret by assay','Budget-dependent recovery','Every seed-level best activity','Mixed-assay reference trajectory','Fixed task sizes and hit denominators'])
 fig.legend([Line2D([0],[0],marker='o',color=MC[m],lw=1,ms=3.6) for m in METHODS],[ML[m] for m in METHODS],loc='lower center',bbox_to_anchor=(.54,.015),ncol=3,fontsize=7,handlelength=1.5,columnspacing=1.6)
 legend='''Fig. 21 | Assay-resolved search exposes task- and endpoint-dependent gains. All eight frozen eligible ChEMBL assays annotated to xanthine oxidase, all three policies and all twenty common initializations are retained. a, Top-20% recall means and 95% paired-seed bootstrap intervals. b, Both policy advantages over random with the original 10,000-resample paired-initialization intervals. c,d, Complete per-assay top-5% recall and normalized-regret means. e, Equal-assay top-5% recall across the complete normalized post-initial budget; lines and ribbons summarize the twenty original initialization trajectories by mean and interquartile range. f, All 480 assay-by-policy-by-seed terminal best activities, with means marked; activities remain within their assay context. g, The earlier 324-compound mixed-assay, forty-query reference benchmark, retaining every seed and policy. All seventeen top-5% members of that mixed pool share one patent assay, so this diagnostic does not establish cross-assay recovery. h, Every fixed task pool, total query budget and inclusive hit denominator. Within-assay tasks begin with five shared compounds and use ten to thirteen total queries; the older mixed pool begins with ten. Initialization variability is computational rather than biological replication. All queried historical labels, raw-best activities, regrets, both recall definitions and exact query histories remain in source data; no new chemical assay or prospective discovery was measured.'''
 return finish(fig,'F21_Bayesian_search','Assay-resolved Bayesian search and historical reference',dict(zip('abcdefgh',['all8 assay top20 recalls','all16 paired advantages','all8×3 top5 recalls','all8×3 regrets','complete equal-assay progress','all480 raw best endpoints','all mixed-pool20seed3policy histories','all8 fixed task denominators'])),ps,legend,['A05','A04_c','E09_Fig5'])

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--fig',nargs='+',default=['F11','F12','F13','F14','F20','F21']);args=parser.parse_args()
 for fid in args.fig:globals()[fid.lower()]()

