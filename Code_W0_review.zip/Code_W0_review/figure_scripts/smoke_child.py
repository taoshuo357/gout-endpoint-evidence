import sys,os,runpy
from pathlib import Path
import resolver
resolver.install()
name=sys.argv[1]
os.environ['BUNDLE_SCRIPT']=name
sys.argv=[str(Path(__file__).parent/name)]
runpy.run_path(sys.argv[0],run_name='__main__')
