"""Complete single-cell main-figure plates redrawn from frozen numerical sources."""
from pathlib import Path
import sys,json,hashlib,functools,string
from atlas_style import *
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.colors import Normalize,TwoSlopeNorm
from matplotlib.ticker import MaxNLocator
SC=G/'论文推进_2026-10-30/单细胞定位/结果表'
DB=G/'论文推进_2026-10-30/单细胞稳健性_第二轮'
TF=G/'全面验证_2026-11-02/05_调控与通讯'
EXT=G/'全面验证_2026-11-02/01_外部队列'
ES=E/'图源数据'
SAMPLES=['A1','A2','A3','B1','B2','B3']
TYPES=['B','CD14 monocytes','CD16 monocytes','Cytotoxic T','DC-like','IL7R+ T','NK','Neutrophil-like']
TLAB=['B','CD14 mono.','CD16 mono.','Cytotoxic T','DC-like','IL7R+ T','NK','Neut-like']
SHORT={'CD14 monocytes':'CD14 mono.','CD16 monocytes':'CD16 mono.','Cytotoxic T':'Cytotoxic T','Neutrophil-like':'Neut-like','Platelet mixed':'Platelet mix','Megakaryocyte/platelet':'Platelet','IL7R+ T':'IL7R+ T','Cycling immune':'Cycling'}
GENES=['NLRP3','CASP1','IL1B','XDH','SLC22A12','ABCG2','SLC2A9','TLR4','RELA','NFKB1','TNF','AKT1']
PTH={'KEGG:00230':'Purine','KEGG:04621':'NOD-like receptor','KEGG:04668':'TNF','KEGG:04064':'NFκB','KEGG:04620':'Toll-like receptor','KEGG:04066':'HIF-1','KEGG:04151':'PI3K–AKT','KEGG:04010':'MAPK','KEGG:04657':'IL-17','KEGG:04920':'Adipocytokine'}
@functools.lru_cache(maxsize=35)
def read(p):
 p=Path(p);return pd.read_csv(p,sep='\t' if '.tsv' in p.name else ',')
def short(x):return SHORT.get(str(x),str(x))
def figmm(h):
 f=plt.figure(figsize=(183/25.4,h/25.4));f.set_dpi(300);return f
def axmm(fig,x,y,w,h,label=None,title=None):
 H=fig.get_figheight()*25.4;W=fig.get_figwidth()*25.4;a=fig.add_axes([x/W,y/H,w/W,h/H])
 if label is not None:panel_label(a,label,title)
 return a
def clean(a):
 for s in a.spines.values():s.set_visible(False)
 a.tick_params(length=0,pad=2)
def colorbar(fig,im,rect,label,ticks=None):
 rect=list(rect)
 if rect[0]>=173:rect[0]-=2.5
 c=axmm(fig,*rect);cb=fig.colorbar(im,cax=c)
 if ticks is not None:cb.set_ticks(ticks)
 cb.ax.tick_params(labelsize=6.5,length=2,pad=2);cb.outline.set_visible(False)
 cb.set_label(label,fontsize=6.5,labelpad=3);return c
def heat(a,d,rows,cols,vmin=None,vmax=None,cmap=None,xrot=90,rowsize=6.5):
 ar=np.ma.masked_invalid(np.asarray(d,float));cm=(cmap or SEQUENTIAL).copy();cm.set_bad('#e5e8eb')
 im=a.imshow(ar,aspect='auto',interpolation='nearest',vmin=vmin,vmax=vmax,cmap=cm)
 a.set(xticks=np.arange(len(cols)),xticklabels=cols,yticks=np.arange(len(rows)),yticklabels=rows)
 a.tick_params(axis='x',labelrotation=xrot,labelsize=6.5)
 if xrot:
  for t in a.get_xticklabels():t.set_ha('right');t.set_rotation_mode('anchor')
 a.tick_params(axis='y',labelsize=rowsize);clean(a);return im
def dot(a,d,genes,types,vmax=None):
 q=d.copy();q['x']=pd.Categorical(q.gene_symbol,categories=genes,ordered=True).codes;q['y']=pd.Categorical(q.cell_type,categories=types,ordered=True).codes
 assert (q[['x','y']]>=0).all().all() and len(q)==len(genes)*len(types)
 im=a.scatter(q.x,q.y,s=q.fraction_detected*36,c=q.mean_logCP10k,cmap=SEQUENTIAL,vmin=0,vmax=vmax,edgecolors='none')
 a.set(xlim=(-.7,len(genes)-.3),ylim=(len(types)-.4,-.65),xticks=range(len(genes)),xticklabels=genes,yticks=range(len(types)),yticklabels=[short(t) for t in types])
 a.tick_params(axis='x',labelrotation=90);clean(a);a.set_axisbelow(True);a.grid(axis='y',color='#eef1f3',lw=.4)
 return im

def umap(a,d,col,*,colors=None,cmap=None,annotate=False):
 if cmap:
  im=a.scatter(d.UMAP1,d.UMAP2,c=d[col],cmap=cmap,s=.6,linewidths=0,rasterized=True)
 else:
  if colors is None:colors={v:plt.get_cmap('tab20')(i%20) for i,v in enumerate(sorted(d[col].unique(),key=str))}
  a.scatter(d.UMAP1,d.UMAP2,c=d[col].map(colors).tolist(),s=.65,linewidths=0,rasterized=True)
  im=None
 if annotate:
  for v,q in d.groupby(col):
   x,y=q[['UMAP1','UMAP2']].median();a.text(x,y,str(v),ha='center',va='center',fontsize=6.5,fontweight='bold',color=INK)
 a.set(xlim=(d.UMAP1.min()-1,d.UMAP1.max()+1),ylim=(d.UMAP2.min()-1,d.UMAP2.max()+1),xticks=[],yticks=[])
 for s in a.spines.values():s.set_visible(False)
 return im

def f06():
 fid='F06_Single_cell_quality_and_atlas';d=read(SC/'全部QC细胞_最终保守注释.csv.gz');q=read(SC/'QC四联图_全部提交细胞源数据.csv.gz');mark=read(SC/'SC03_保守细胞类型marker点图_源数据.csv')
 assert len(d)==53940 and len(q)==55212 and len(mark)==520
 ann=d[['cell_type','plot_order','plot_color']].drop_duplicates().sort_values('plot_order');types=ann.cell_type.tolist();cc=dict(zip(ann.cell_type,ann.plot_color))
 fig=figmm(257);axs=[];ex=[]
 # All-cell QC, no downsampling.
 a=axmm(fig,15,214,31,27,'a','Library complexity');axs.append(a)
 groups=[np.log10(q.loc[q.sample_id.eq(s),'UMI'].to_numpy()) for s in SAMPLES]
 vp=a.violinplot(groups,positions=np.arange(6),showmedians=True,showextrema=False,widths=.86)
 for i,b in enumerate(vp['bodies']):b.set_facecolor(ROSE if i<3 else TEAL);b.set_alpha(.65);b.set_edgecolor('none')
 vp['cmedians'].set_color(INK);vp['cmedians'].set_linewidth(.6)
 a.set(xticks=range(6),xticklabels=SAMPLES,ylabel='log10(UMIs / cell)');a.yaxis.set_major_locator(MaxNLocator(3))
 b=axmm(fig,58,214,31,27,'b','Detected genes');axs.append(b)
 im=b.scatter(np.log10(q.UMI),q.genes,c=q.mito_fraction*100,cmap=SEQUENTIAL,s=.5,linewidths=0,rasterized=True,vmin=0,vmax=100)
 b.axvline(np.log10(500),c=GREY,ls='--',lw=.5);b.axhline(200,c=GREY,ls='--',lw=.5);b.axhline(6000,c=GREY,ls='--',lw=.5)
 b.set(xlabel='log10(UMIs)',ylabel='Genes / cell');nice_axes(b,3)
 c=axmm(fig,101,214,31,27,'c','Mitochondrial UMIs');axs.append(c)
 c.hist(q.mito_fraction*100,bins=60,color=BLUE,alpha=.75,linewidth=0);c.axvline(20,color=ROSE,lw=.7,ls='--');c.set(xlabel='Mitochondrial UMIs (%)',ylabel='Cells');nice_axes(c,3)
 e=axmm(fig,144,214,31,27,'d','QC retention');axs.append(e)
 counts=q.groupby('sample_id').retained.agg(['sum','size']).reindex(SAMPLES);e.bar(range(6),counts['sum'],color=[ROSE]*3+[TEAL]*3);e.bar(range(6),counts['size']-counts['sum'],bottom=counts['sum'],color='#dbe1e5')
 e.set(xticks=range(6),xticklabels=SAMPLES,ylabel='Cells');e.yaxis.set_major_locator(MaxNLocator(3))
 e.text(.5,-.47,'53,940 / 55,212 cells retained',transform=e.transAxes,ha='center',fontsize=6.5)
 # Explicit quantitative key for the mitochondrial colour encoding in b.
 cbq=axmm(fig,58,251,31,1.2);qcb=fig.colorbar(im,cax=cbq,orientation='horizontal');qcb.outline.set_visible(False);qcb.set_ticks([0,50,100]);qcb.set_ticklabels(['0%','50%','100%']);qcb.ax.tick_params(length=1,labelsize=6.5,pad=1);ex.append(cbq)
 e1=axmm(fig,15,142,64,55,'e','23 Leiden clusters');axs.append(e1);umap(e1,d,'leiden_0_6',annotate=True)
 f=axmm(fig,105,142,64,55,'f','13 cell types');axs.append(f);umap(f,d,'cell_type',colors=cc)
 g=axmm(fig,15,77,64,49,'g','Broad immune lineages');axs.append(g)
 broad=sorted(d.broad_lineage.unique());bc={t:c for t,c in zip(broad,[BLUE,ROSE,TEAL,GOLD,VIOLET,GREEN,GREY])};umap(g,d,'broad_lineage',colors=bc)
 g.legend(handles=[Line2D([],[],marker='o',color='none',markerfacecolor=bc[t],markeredgewidth=0,label=t,markersize=3) for t in broad],loc='lower left',bbox_to_anchor=(0,-.18),ncol=3,columnspacing=.6,handletextpad=.3,fontsize=6.5)
 h=axmm(fig,105,77,64,49,'h','Genes per retained cell');axs.append(h);im2=umap(h,d,'genes',cmap=SEQUENTIAL);ex.append(colorbar(fig,im2,(173,78,2.5,47),'Detected genes'))
 # Full 40-marker matrix. No subset is chosen for a cleaner annotation map.
 genes=mark.gene_symbol.drop_duplicates().tolist();i=axmm(fig,27,22,143,37,'i','Marker support for every annotation');axs.append(i)
 im3=dot(i,mark,genes,types);ex.append(colorbar(fig,im3,(174,22,2.5,37),'Mean log1p(CP10k)'))
 handles=[Line2D([],[],marker='o',color='none',markerfacecolor=cc[t],markeredgewidth=0,label=short(t),markersize=3) for t in types]
 fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.546),ncol=5,columnspacing=.75,handletextpad=.3,fontsize=6.5)
 # Size key retains the detection fraction scale used in all dot maps.
 fig.text(.58,.252,'Detected:',fontsize=6.5,color=INK)
 fig.legend(handles=[Line2D([],[],marker='o',ls='',color=INK,markersize=np.sqrt(36*p),label=f'{p:.0%}') for p in [.1,.5,1]],loc='center left',bbox_to_anchor=(.65,.252),ncol=3,columnspacing=.55,handletextpad=.25,fontsize=6.5)
 fig.text(.15,.006,'Dot area: fraction detected   ·   3 patients, 6 libraries; original coordinates and all cells retained',fontsize=6.5,color=INK)
 legend='Figure 6 | A patient-derived single-cell atlas with complete quality-control and annotation evidence. a–d, All 55,212 submitted cells: per-library log10 UMI distributions (violin medians), detected genes versus UMIs (colour: mitochondrial fraction), mitochondrial UMI distribution and retained/excluded cell counts. Fixed thresholds were 200–6,000 detected genes, at least 500 UMIs and mitochondrial fraction at most20%; 53,940 cells remained. e–h, The unchanged embedding of every retained cell, coloured by23 clusters,13 conservative annotations, broad lineage and detected genes. No embedding is resampled or recomputed. i, All40 predefined markers across all13 annotations; dot area is the observed detection fraction and colour the mean log1p counts per10,000 UMIs. The six captures represent three patients; unresolved A-to-B patient matching is handled in later sensitivity panels. These panels provide cell context rather than cell-level disease significance.'
 return save_figure(fig,fid,'Patient single-cell atlas and annotation',{'a':'All-cell UMI complexity','b':'All55212cell UMI–gene QC','c':'Full mitochondrial distribution','d':'Six-library QC retention','e':'All53940cells/23clusters','f':'All53940cells/13annotations','g':'All53940cells/broadlineages','h':'All53940cells/nGenes','i':'All520marker/type observations'},[SC/'全部QC细胞_最终保守注释.csv.gz',SC/'QC四联图_全部提交细胞源数据.csv.gz',SC/'SC03_保守细胞类型marker点图_源数据.csv'],legend,row_groups=[['a','b','c','d'],['e','f'],['g','h']],column_groups=[],axes=axs,exclude_axes=ex,old_figure_mapping=['Fig6/SC01','Fig7/SC02','Fig8/SC03','currentFig1 cell context'])

def f07():
 fid='F07_Library_context_and_target_localization';d=read(SC/'全部QC细胞_最终保守注释.csv.gz');comp=read(SC/'细胞类型_逐文库构成比例.csv');tg=read(SC/'SC05_12优先靶点细胞来源点图_源数据.csv');pr=read(SC/'SC06_通路表达秩评分点热图_源数据.csv')
 ann=d[['cell_type','plot_order','plot_color']].drop_duplicates().sort_values('plot_order');types=ann.cell_type.tolist();cc=dict(zip(ann.cell_type,ann.plot_color));fig=figmm(250);axs=[];ex=[]
 for k,s in enumerate(SAMPLES):
  x=15+(k%3)*55;y=191-(k//3)*49;a=axmm(fig,x,y,43,34,string.ascii_lowercase[k],s+' · n='+f'{d.sample_id.eq(s).sum():,}');axs.append(a)
  a.scatter(d.UMAP1,d.UMAP2,c='#e2e7eb',s=.42,linewidths=0,rasterized=True)
  z=d[d.sample_id.eq(s)];a.scatter(z.UMAP1,z.UMAP2,c=ROSE if k<3 else TEAL,s=.65,linewidths=0,rasterized=True)
  a.set(xlim=(d.UMAP1.min()-1,d.UMAP1.max()+1),ylim=(d.UMAP2.min()-1,d.UMAP2.max()+1),xticks=[],yticks=[])
  for sp in a.spines.values():sp.set_visible(False)
 g=axmm(fig,15,96,153,29,'g','Library composition');axs.append(g)
 cm=comp.pivot(index='sample_id',columns='cell_type',values='fraction').reindex(index=SAMPLES,columns=types).fillna(0)
 bottom=np.zeros(6)
 for t in types:g.bar(range(6),cm[t]*100,bottom=bottom,color=cc[t],width=.72,label=short(t));bottom+=cm[t].to_numpy()*100
 g.set(xticks=range(6),xticklabels=SAMPLES,ylabel='Cells (%)',ylim=(0,100));g.set_yticks([0,50,100])
 fig.legend(handles=[Patch(facecolor=cc[t],label=short(t),edgecolor='none') for t in types],loc='upper center',bbox_to_anchor=(.5,.374),ncol=5,columnspacing=.7,handlelength=.8,handletextpad=.35,fontsize=6.5)
 h=axmm(fig,27,23,66,49,'h','12 candidate targets');axs.append(h);im=dot(h,tg,GENES,types);ex.append(colorbar(fig,im,(95,23,2.2,49),'Mean log1p(CP10k)'))
 prows=[t for t in types if t in pr.cell_type.unique()];cols=pr.signature.drop_duplicates().tolist();pv=pr.pivot(index='cell_type',columns='signature',values='mean_UCell_score').loc[prows,cols]
 i=axmm(fig,126,23,41,49,'i','Nine rank-based programs');axs.append(i);ip=heat(i,pv,[short(t) for t in prows],[PTH.get(t,t.replace('KEGG:','')) for t in cols],vmin=0,vmax=float(pv.to_numpy().max()));ex.append(colorbar(fig,ip,(173,23,2.2,49),'Mean UCell score'))
 fig.text(.35,.309,'Detected:',fontsize=6.5,color=INK)
 fig.legend(handles=[Line2D([],[],marker='o',ls='',color=INK,markersize=np.sqrt(36*p),label=f'{p:.0%}') for p in [.1,.5,1]],loc='center left',bbox_to_anchor=(.43,.309),ncol=3,columnspacing=.55,handletextpad=.25,fontsize=6.5)
 fig.text(.08,.008,'Library panels share the unchanged embedding. Dot area: detection fraction. Program rows retain all eligible cell classes.',fontsize=6.5,color=INK)
 legend='Figure 7 | Library heterogeneity and the cellular origins of candidate genes. a–f, Each source library on the same complete53,940-cell embedding; the highlighted capture is overlaid on all other retained cells. The six plots use the same limits and original coordinates. g, All13 conservative cell-type proportions in every capture, with original capture denominators. h, All12 prespecified candidates across all13 annotations (156 observations), with detection fraction encoded by area and mean log1p(CP10k) by colour. i, All81 eligible cell-class–program values for the nine pre-existing rank-based gene sets. Colours are expression scores rather than measured pathway activity. Samples A1–A3 were collected during flare and B1–B3 during remission; biological replication is three patients, with the A/B crosswalk unresolved. Library abundance and cell-level detection do not constitute independent disease tests.'
 return save_figure(fig,fid,'Library context and target localization',{**{string.ascii_lowercase[k]:'Unchanged embedding of capture '+s for k,s in enumerate(SAMPLES)},'g':'All78composition entries','h':'All156target/type entries','i':'All81program/type entries'},[SC/'全部QC细胞_最终保守注释.csv.gz',SC/'细胞类型_逐文库构成比例.csv',SC/'SC05_12优先靶点细胞来源点图_源数据.csv',SC/'SC06_通路表达秩评分点热图_源数据.csv'],legend,row_groups=[['a','b','c'],['d','e','f']],column_groups=[],axes=axs,exclude_axes=ex,old_figure_mapping=['FigS8/SC04','Fig9/SC05','FigS9/SC06','FigS12/SC07'])

def f08a():
 fid='F08_A_Doublet_and_threshold_sensitivity';hist=read(DB/'源数据/SD01_完整分数直方图_所有细胞与模拟样本.csv');model=read(DB/'结果表/六文库_模型阈值与预测率.csv');st=read(DB/'结果表/文库预测率_固定细胞组成标准化.csv');tp=read(DB/'结果表/13类细胞_逐文库双细胞预测分布.csv');loc=read(DB/'结果表/NLRP3_IL1B_等文库权重定位_每子集至少30细胞.csv');thr=read(DB/'源数据/SD03_全部阈值逐文库预测百分比.csv');cx=read(DB/'源数据/SD03_CD14单核细胞_逐文库表达折线源数据.csv')
 assert len(hist)==600 and len(tp)==78 and len(thr)==30 and len(cx)==72
 fig=figmm(249);axs=[];ex=[]
 for k,s in enumerate(SAMPLES):
  a=axmm(fig,17+(k%3)*54,207-(k//3)*47,40,29,string.ascii_lowercase[k],s+' score distribution');axs.append(a)
  z=hist[hist.sample_id.eq(s)]
  for pop,col in [('Observed',BLUE),('Simulated doublets',GOLD)]:
   u=z[z.population.eq(pop)]
   if len(u)==0:u=z[z.population.str.contains('Simulated')]
   a.step((u.bin_left+u.bin_right)/2,u.density,where='mid',color=col,lw=.85,label='Observed' if pop=='Observed' else 'Simulated')
  th=float(model.set_index('sample_id').loc[s,'automatic_threshold']);a.axvline(th,color=ROSE,ls='--',lw=.65)
  a.set(xlim=(0,1),xlabel='Scrublet score',ylabel='Density');a.xaxis.set_major_locator(MaxNLocator(3));a.yaxis.set_major_locator(MaxNLocator(3))
 axs[0].legend(loc='upper right',handlelength=1,handletextpad=.3,fontsize=6.5)
 g=axmm(fig,17,95,40,40,'g','Composition-standardized flags');axs.append(g)
 s0=st.set_index('sample_id').loc[SAMPLES]
 g.plot(range(6),s0.observed_flagged_fraction*100,'o-',color=BLUE,lw=.8,ms=3,label='Observed');g.plot(range(6),s0.same_celltype_weight_flagged_fraction*100,'s--',color=GOLD,lw=.8,ms=3,label='Fixed composition')
 g.set(xticks=range(6),xticklabels=SAMPLES,ylabel='Flagged cells (%)');g.legend(loc='upper left',bbox_to_anchor=(-.05,1.03),fontsize=6.5,handlelength=.7)
 types=read(SC/'全部QC细胞_最终保守注释.csv.gz')[['cell_type','plot_order']].drop_duplicates().sort_values('plot_order').cell_type.tolist()
 m=tp.pivot(index='cell_type',columns='sample_id',values='predicted_fraction').reindex(index=types,columns=SAMPLES)*100;n=tp.pivot(index='cell_type',columns='sample_id',values='n_cells').reindex(index=types,columns=SAMPLES)
 h=axmm(fig,89,95,29,40,'h','Flags in all 13 annotations');axs.append(h)
 mm=m.mask(n<30);im=heat(h,mm,[short(t) for t in types],SAMPLES,vmin=0,vmax=float(m.max().max()),xrot=0);ex.append(colorbar(fig,im,(120,95,2,40),'Flagged (%)'))
 for iy,ix in zip(*np.where((n<30).to_numpy())):h.text(ix,iy,'×',ha='center',va='center',fontsize=6.5,color=INK)
 schemes=['Automatic','Score ≥0.15','Score ≥0.20','Score ≥0.25','Score ≥0.30'];actual=thr.scheme.drop_duplicates().tolist()
 order=sorted(actual,key=lambda x:0 if 'Auto' in x else float(str(x).split()[-1]) if str(x).split()[-1].replace('.','',1).isdigit() else 1)
 i=axmm(fig,148,95,23,40,'i','Complete cutoff grid');axs.append(i);tmat=thr.pivot(index='scheme',columns='sample_id',values='fraction').loc[order,SAMPLES]
 imt=heat(i,tmat,[s.replace('Score >=','≥').replace('Score ≥','≥').replace('Cutoff ','') for s in order],SAMPLES,vmin=0,vmax=float(tmat.max().max()),xrot=0);ex.append(colorbar(fig,imt,(174,95,2,40),'Flagged (%)'))
 # Automatic-filter localization: full existing cell-class values for both genes.
 lv=loc.copy();sub=lv.subset.drop_duplicates().tolist();columns=[(g,s) for g in ['NLRP3','IL1B'] for s in sub];mat=lv.pivot(index='cell_type',columns=['gene','subset'],values='mean_logCP10k').reindex(index=[t for t in types if t in lv.cell_type.unique()],columns=pd.MultiIndex.from_tuples(columns))
 j=axmm(fig,35,22,43,48,'j','Localization before/after flags');axs.append(j)
 il=heat(j,mat,[short(t) for t in mat.index],[g+'\n'+('All' if 'All ' in s else 'Unflagged') for g,s in columns],vmin=0,vmax=float(mat.max().max()),xrot=0);ex.append(colorbar(fig,il,(81,22,2,48),'Mean log1p(CP10k)'))
 cm=cx.copy();cm['row']=cm.gene+' · '+cm.sample_id;rows=[g+' · '+s for g in ['NLRP3','IL1B'] for s in SAMPLES];co=cm.scheme.drop_duplicates().tolist();cv=cm.pivot(index='row',columns='scheme',values='CD14_mean_logCP10k').loc[rows,co]
 k=axmm(fig,127,22,44,48,'k','CD14 expression under every cutoff');axs.append(k)
 ci=heat(k,cv,rows,[str(s).replace('All fixed QC cells','All').replace('Score cutoff ','').replace('Score >=','≥').replace('Score ≥','≥') for s in co],vmin=0,vmax=float(cv.max().max()),xrot=90);ex.append(colorbar(fig,ci,(174,22,2,48),'Mean log1p(CP10k)'))
 fig.text(.09,.008,'Exploratory computational sensitivity: fixed scores and annotations; grey cells have fewer than 30 original cells.',fontsize=6.5,color=INK)
 legend='Figure 8 | Cell-quality sensitivity and the stability of inflammatory-gene localization (Part1). a–f, Complete observed and simulated Scrublet-score histograms for every library, with the original automatic cutoff marked. All600 stored histogram bins are retained. g, Original flagged fractions and fractions standardized to identical cell-type weights. The curves connect library identifiers, not patients over time. h, All13 annotations across six libraries; cells with fewer than30 captured cells are marked grey, with every count and percentage retained in the source. i, Every automatic or exploratory cutoff and all30 library-level flagged percentages. j, NLRP3 and IL1B localization for all fixed QC cells and the hypothetical unflagged subset, using all48 recorded cell-class/gene/subset entries; unavailable estimates remain grey. k, All72 CD14 expression observations across the six schemes and six captures. The four fixed score cutoffs were exploratory after the original A3 diagnostic and are not validated doublet probabilities. No new filtering, embedding, disease test or knockout is performed in this redraw.'
 return save_figure(fig,fid,'Cell-quality sensitivity and inflammatory localization (Part 1)',{**{string.ascii_lowercase[k]:'Full score distributions '+s for k,s in enumerate(SAMPLES)},'g':'Six paired composition-standardized summaries','h':'All78type/library flag percentages','i':'All30cutoff/library flag percentages','j':'All48localization entries','k':'All72CD14threshold observations'},[DB/'源数据/SD01_完整分数直方图_所有细胞与模拟样本.csv',DB/'结果表/六文库_模型阈值与预测率.csv',DB/'结果表/文库预测率_固定细胞组成标准化.csv',DB/'结果表/13类细胞_逐文库双细胞预测分布.csv',DB/'结果表/NLRP3_IL1B_等文库权重定位_每子集至少30细胞.csv',DB/'源数据/SD03_全部阈值逐文库预测百分比.csv',DB/'源数据/SD03_CD14单核细胞_逐文库表达折线源数据.csv'],legend,row_groups=[['a','b','c'],['d','e','f']],column_groups=[],axes=axs,exclude_axes=ex,old_figure_mapping=['FigS15/SD01','FigS16/SD02','FigS17/SD03'])

def f08b():
 fid='F08_B_Phase_and_source_context';xp=SC.parent/'探索扩展_细胞类型阶段比较/九通路_细胞类型保守阶段比较.csv';x=read(xp);exg=read(EXT/'结果/固定12靶点_两对比结果.csv');exp=read(EXT/'结果/九条冻结通路_两对比_CAMERA.csv');dup=read(EXT/'跨系列文库_逐字节重复审计.csv')
 wp=G/'GEO表达核验_2026-10-29/独立队列_GSE211783/表达结果/供者汇总_TMM_logCPM.csv';w=read(wp);gp=SC/'预定义定位基因.csv';annot=read(gp);gene_map=annot.drop_duplicates('source_symbol').set_index('source_symbol').gene_id
 assert len(x)==72 and len(exg)==24 and len(exp)==18
 fig=figmm(235);axs=[];cbs=[]
 rows=[t for t in TYPES if t in x.cell_type.unique()];terms=x.term_id.drop_duplicates().tolist();a=axmm(fig,33,177,136,37,'l','Cell-type phase associations: all 72 tests');axs.append(a)
 x=x.copy();x['signed_q']=-np.log10(x.q_nine_across_celltypes)*x.direction.map({'Up':1,'Down':-1})
 pv=x.pivot(index='cell_type',columns='term_id',values='signed_q').loc[rows,terms];mx=float(np.abs(pv).max().max());mx=max(mx,.01)
 ip=heat(a,pv,[short(t) for t in rows],[PTH.get(t,t) for t in terms],vmin=-mx,vmax=mx,cmap=DIVERGING);cbs.append(colorbar(fig,ip,(173,177,2,37),'Signed −log10(q)'))
 for ri,t in enumerate(rows):
  for ci,k in enumerate(terms):
   v=x[(x.cell_type==t)&(x.term_id==k)].iloc[0]
   if not bool(v.direction_same_all6):a.text(ci,ri,'?',ha='center',va='center',fontsize=6.5)
   elif v.q_nine_across_celltypes<.05:a.text(ci,ri,'*',ha='center',va='center',fontsize=6.5)
 # Historical whole-PBMC panel from the same six captures, all24 observations.
 wg=['NLRP3','CASP1','IL1B','TNF'];wm=w.set_index('gene_id').reindex([gene_map[g] for g in wg])[SAMPLES]
 b=axmm(fig,33,119,60,28,'m','Whole-PBMC expression in the same cohort');axs.append(b);im=heat(b,wm,wg,SAMPLES,xrot=0);cbs.append(colorbar(fig,im,(96,119,2,28),'TMM log2CPM'))
 # Cross-series identity diagram is numerical source provenance, not another biological experiment.
 f=axmm(fig,120,119,50,28,'n','Three exact shared libraries');axs.append(f);f.set(xlim=(0,1),ylim=(-.8,2.8));f.axis('off')
 pairs=dup[['old_sample','new_sample']].drop_duplicates().sort_values('old_sample')
 for iy,(_,rr) in enumerate(pairs.iterrows()):
  y=2-iy;f.text(.02,y,rr.old_sample,fontsize=7,ha='left',va='center',color=TEAL);f.text(.98,y,rr.new_sample,fontsize=7,ha='right',va='center',color=TEAL);f.annotate('',xy=(.75,y),xytext=(.25,y),arrowprops={'arrowstyle':'<->','lw':.75,'color':GREY})
 f.text(.5,-.75,'Matrix + barcodes: identical SHA256',ha='center',va='center',fontsize=6.5,color=INK)
 # Existing GSE217561 observations are shown with their original design and overlap status.
 contrasts=['IG_vs_HC','Advanced_vs_HC'];gc=exg.pivot(index='gene_symbol',columns='contrast',values='logFC').reindex(index=GENES,columns=contrasts);gq=exg.pivot(index='gene_symbol',columns='contrast',values='q_fixed12_two_contrasts').reindex(index=GENES,columns=contrasts)
 c=axmm(fig,32,28,28,59,'o','12-gene effects');axs.append(c);mxg=max(float(np.abs(gc).max().max()),.01);ic=heat(c,gc,GENES,['IG−HC','Adv−HC'],vmin=-mxg,vmax=mxg,cmap=DIVERGING,xrot=0);cbs.append(colorbar(fig,ic,(63,28,2,59),'log2 fold change'))
 d=axmm(fig,92,28,27,59,'p','Full 24-test q family');axs.append(d);iq=heat(d,gq,GENES,['IG−HC','Adv−HC'],vmin=0,vmax=1,cmap=SEQUENTIAL,xrot=0)
 for ri in range(12):
  for ci in range(2):
   v=gq.iloc[ri,ci]
   if np.isfinite(v):d.text(ci,ri,f'{v:.2f}',ha='center',va='center',fontsize=6.5,color='white' if v>.65 else INK)
 e=axmm(fig,151,28,20,59,'q','Nine programs');axs.append(e);pe=exp.copy();pe['signed_q']=-np.log10(pe.q_exploratory18_across_contrasts)*pe.Direction.map({'Up':1,'Down':-1});ep=pe.pivot(index='pathway_name',columns='contrast',values='signed_q').reindex(columns=contrasts);mxe=max(float(np.abs(ep).max().max()),.01)
 ie=heat(e,ep,[s.replace(' signaling pathway','').replace(' signalling pathway','').replace(' signaling','') for s in ep.index],['IG−HC','Adv−HC'],vmin=-mxe,vmax=mxe,cmap=DIVERGING,xrot=0);cbs.append(colorbar(fig,ie,(174,28,2,59),'Signed −log10(q)'))
 fig.text(.07,.035,'GSE217561 is a related source with shared captures; its comparisons are not independent replication.',fontsize=6.5,color=INK)
 legend='Figure 8 | Disease-stage associations and cross-series source identity (Part2, continued). l, All72 cell-type–pathway phase associations from the original eight-cell-class by nine-program family, with signed −log10 of the full-family BH q. Asterisks require q<0.05 and direction agreement across every unverified A/B mapping; question marks denote direction disagreement. m, All24 whole-PBMC log2CPM observations for NLRP3, CASP1, IL1B and TNF from the same six captures; this is a legacy summary of the existing cohort. n, GSE211783 captures B1/B2/B3 match GSE217561 GS1/GS2/GR3, respectively, for both compressed matrix and barcode SHA256. o,p, All12 candidate expression effects in both original GSE217561 contrasts and their24-test candidate-family q values. q, The full nine-program by two-contrast family with its original18-test adjustment. IG denotes intercritical gout; Adv denotes advanced gout; HC denotes the deposited healthy-control group. These cross-sectional data provide related-source context with shared libraries, not an independent patient validation or treatment comparison. The first and continued plates replace all relevant legacy plots without changing the original models.'
 return save_figure(fig,fid,'Disease-stage associations and source identity (Part 2)',{'l':'All72celltype/program tests','m':'All24legacyPBMC observations','n':'All3exactshared library pairs','o':'All24related-source gene effects','p':'All24candidate q values','q':'All18related-source pathway tests'},[xp,wp,gp,EXT/'跨系列文库_逐字节重复审计.csv',EXT/'结果/固定12靶点_两对比结果.csv',EXT/'结果/九条冻结通路_两对比_CAMERA.csv'],legend,row_groups=[['b','c'],['d','e','f']],column_groups=[],exemptions=[{'panels':['d','e','f'],'checks':['panel-width'],'reason':'The continued plate uses unequal heatmap widths for12-gene effects, the matching q matrix and nine pathway labels; top and bottom edges remain equal and all labels retain the same6.5pt font.'}],axes=axs,exclude_axes=cbs,old_figure_mapping=['FigS13/EX01','FigS7 whole-PBMC summary','Fig01_GSE217561_fixed12_expression','Fig02_GSE217561_frozen_pathways'])

def f09():
 fid='F09_Regulatory_footprints';old=read(TF/'TF_全部细胞类型阶段检验.tsv');ol=read(TF/'TF_全部逐文库活性.tsv');show=read(TF/'TF_图中20调控子展示选择.tsv');new=read(ES/'A02_官方调控足迹与RNA支持_a.tsv');rna=read(ES/'A02_官方调控足迹与RNA支持_b.tsv');pp=read(ES/'A02_官方调控足迹与RNA支持_c.tsv');st=read(ES/'A02_官方调控足迹与RNA支持_c_full_pathway_stability.tsv');compare=read(E/'02_decoupler官方方法/旧逐库分数差与新contrast足迹_描述性并列.tsv')
 assert len(old)==3684 and len(new)==548 and len(rna)==30 and len(pp)==84
 fig=figmm(240);axs=[];ex=[]
 # Old display selection is retained, while the official full548 family is explicitly shown.
 genes=show.sort_values('display_rank').TF.tolist();oa=old.pivot(index='TF',columns='cell_type',values='acute_minus_remission_activity').reindex(index=genes,columns=TYPES)
 a=axmm(fig,20,158,66,64,'a','Regulon differences across cell types');axs.append(a);mx=float(np.nanmax(np.abs(oa)));im=heat(a,oa,genes,TLAB,vmin=-mx,vmax=mx,cmap=DIVERGING);ex.append(colorbar(fig,im,(89,158,2,64),'Acute − remission activity proxy'))
 cd=old[old.cell_type.eq('CD14 monocytes')].copy();sel=cd.assign(abs_effect=cd.acute_minus_remission_activity.abs()).sort_values(['abs_effect','TF'],ascending=[False,True]).head(8).TF.tolist();ul=ol[(ol.cell_type=='CD14 monocytes')&ol.TF.isin(sel)]
 b=axmm(fig,119,158,51,64,'b','Individual CD14 library scores');axs.append(b)
 for iy,t in enumerate(sel):
  for phase,col in [('Acute',ROSE),('Remission',TEAL)]:
   z=ul[(ul.TF==t)&(ul.phase==phase)].sort_values('sample_id');b.scatter(z.ULM_t_activity,np.full(len(z),iy)+np.linspace(-.14,.14,len(z)),s=10,color=col,edgecolors='none');b.plot([z.ULM_t_activity.mean()]*2,[iy-.22,iy+.22],color=col,lw=1)
 b.set(yticks=range(8),yticklabels=sel,ylim=(7.7,-.7),xlabel='ULM activity proxy');b.axvline(0,color=GREY,ls='--',lw=.55);b.legend(handles=[Line2D([],[],marker='o',color=ROSE,ls='',label='Acute',ms=3),Line2D([],[],marker='o',color=TEAL,ls='',label='Remission',ms=3)],loc='upper center',bbox_to_anchor=(.5,-.15),ncol=2,fontsize=6.5)
 c=axmm(fig,20,88,66,43,'c','All 548 official regulon footprints');axs.append(c)
 y=-np.log10(new.full8type_q_max);c.scatter(new.conditional_gene_r_median,y,c=GREY,s=5,alpha=.6,linewidths=0,rasterized=True);hits=new[new.full8type_q05_maps.eq(6)]
 for _,rr in hits.iterrows():c.scatter(rr.conditional_gene_r_median,-np.log10(rr.full8type_q_max),s=20,c=GOLD if rr.TF=='PAX3' else BLUE,edgecolor='white',linewidth=.4)
 for _,rr in hits.iterrows():
  off={'MYC':(5,-3),'EGR1':(-30,15),'PAX3':(20,20),'SP1':(-34,-8),'JUN':(18,3)}[rr.TF]
  c.annotate(rr.TF,(rr.conditional_gene_r_median,-np.log10(rr.full8type_q_max)),xytext=off,textcoords='offset points',fontsize=6.5,ha='left',va='center',arrowprops={'arrowstyle':'-','color':GREY,'lw':.4})
 c.axhline(-np.log10(.05),color=GREY,ls='--',lw=.6);c.axvline(0,color=GREY,lw=.5,ls=':');c.set(xlabel='Median regulon association (r)',ylabel='−log10(maximum mapping q)');nice_axes(c,4)
 order=hits.sort_values('score_median').TF.tolist();rmat=rna.pivot(index='TF',columns='sample_id',values='TF_RNA_detection_fraction').loc[order,SAMPLES]*100
 d=axmm(fig,119,94,51,31,'d','Source-TF RNA detection');axs.append(d);ir=heat(d,rmat,order,SAMPLES,vmin=0,vmax=100,xrot=0);ex.append(colorbar(fig,ir,(174,94,2,31),'Detected cells (%)'))
 for iy in range(5):
  for ix in range(6):
   v=rmat.iloc[iy,ix];d.text(ix,iy,f'{v:.2f}' if order[iy]=='PAX3' else f'{v:.0f}',ha='center',va='center',fontsize=6.5,color='white' if v>55 else INK)
 d.text(.5,-.38,'PAX3: 4 UMI in all 8,564 CD14 cells',ha='center',transform=d.transAxes,fontsize=6.5,color=INK)
 paths=st.pathway.tolist();pm=pp.pivot(index='pathway',columns='pairing_id',values='conditional_gene_r');pm.columns=pm.columns.astype(str);pm=pm.loc[paths,['123','132','213','231','312','321']]
 e=axmm(fig,28,20,58,43,'e','All 14 pathway footprints / six mappings');axs.append(e);mp=float(np.max(np.abs(pm)));ie=heat(e,pm,paths,pm.columns.tolist(),vmin=-mp,vmax=mp,cmap=DIVERGING,xrot=0);ex.append(colorbar(fig,ie,(89,20,2,43),'Pathway association (r)'))
 co=compare[compare.cell_type.eq('CD14 monocytes')].merge(new[['TF','conditional_gene_r_median']],on='TF',validate='one_to_one');assert len(co)==548
 f=axmm(fig,119,20,51,43,'f','Same genes, different model quantities');axs.append(f);f.scatter(co.acute_minus_remission_activity,co.conditional_gene_r_median,s=5,c=TEAL,alpha=.55,linewidths=0,rasterized=True);f.axhline(0,color=GREY,lw=.5,ls=':');f.axvline(0,color=GREY,lw=.5,ls=':');f.set(xlabel='Library-score contrast',ylabel='Official contrast association (r)');nice_axes(f,4)
 fig.text(.11,.009,'Six patient-mapping scenarios are sensitivity analyses, not six new patient groups.',fontsize=6.5,color=INK)
 legend='Figure 9 | Regulatory programs across cell types and model definitions. a, The same original20 displayed TFs across all eight eligible cell types, using the pre-existing maximum-absolute-contrast display rule; all3,684 tests remain in the source. b, Every library score for the original eight largest absolute CD14 proxy contrasts, with phase means; captures are not connected as verified patient pairs. c, All548 eligible official CD14 regulon footprints, with conditional association r=t/sqrt(t²+background-gene-count−2) and the maximum full-family q over all six mapping scenarios. The five all-mapping regulon hits remain highlighted. d, All30 source-TF RNA detection measurements; PAX3 contributes only four observed UMI, qualifying the shared-regulon interpretation. e, All14 official pathway footprints in every mapping, without selecting only positive pathways. f, All548 shared TFs compared by the previous library-score contrast and the official contrast-footprint association; these quantities are related summaries of the same data, not independent validation. Scores represent inferred expression programs. Complete raw P, q families, coverage and mapping sensitivities are preserved.'
 return save_figure(fig,fid,'Regulatory footprints and source-RNA support',{'a':'All160display-selectedTF/type values','b':'All48originaldisplayTF/library scores','c':'Complete548officialTFfamily','d':'All30source-RNA observations','e':'All84pathway/mapping observations','f':'All548sharedTFmethod comparisons'},[TF/'TF_全部细胞类型阶段检验.tsv',TF/'TF_全部逐文库活性.tsv',TF/'TF_图中20调控子展示选择.tsv',ES/'A02_官方调控足迹与RNA支持_a.tsv',ES/'A02_官方调控足迹与RNA支持_b.tsv',ES/'A02_官方调控足迹与RNA支持_c.tsv',ES/'A02_官方调控足迹与RNA支持_c_full_pathway_stability.tsv',E/'02_decoupler官方方法/旧逐库分数差与新contrast足迹_描述性并列.tsv'],legend,row_groups=[['a','b']],column_groups=[],axes=axs,exclude_axes=ex,old_figure_mapping=['R01_转录因子调控子与供者级变化','A02_官方调控足迹与RNA支持'])

def f10():
 fid='F10_Cell_communication';net=read(ES/'A03_官方LIANA通讯结构与阶段检出_两阶段全部64方向.tsv');on=read(TF/'LR_通讯潜力网络汇总.tsv');ot=read(TF/'LR_全部合格文库级阶段检验.tsv');pairs=read(TF/'LR_图中候选关联14配体受体.tsv');cand=read(ES/'A03_官方LIANA通讯结构与阶段检出_全部阶段限制检出候选.tsv');dots=read(ES/'A03_官方LIANA通讯结构与阶段检出_候选逐文库全部点.tsv');shown=read(ES/'A03_官方LIANA通讯结构与阶段检出_展示候选与明确选择规则.tsv')
 assert len(net)==128 and len(on)==128 and len(ot)==5556 and len(cand)==100 and len(dots)==72
 fig=figmm(250);axs=[];ex=[]
 nv=(float(net.priority.min()),float(net.priority.max()));ov=(0,float(on.mean_total_score.max()))
 for k,(data,phase,source_col,target_col,value,lim,title) in enumerate([(net,'Acute','source','target','priority',nv,'LIANA: acute'),(net,'Remission','source','target','priority',nv,'LIANA: remission'),(on,'Acute','sender','receiver','mean_total_score',ov,'Coexpression: acute'),(on,'Remission','sender','receiver','mean_total_score',ov,'Coexpression: remission')]):
  x=32+(k%2)*86;y=193-(k//2)*72;a=axmm(fig,x,y,49,41,string.ascii_lowercase[k],title);axs.append(a)
  hm=data[data.phase.eq(phase)].pivot(index=source_col,columns=target_col,values=value).loc[TYPES,TYPES];im=heat(a,hm,TLAB,TLAB,vmin=lim[0],vmax=lim[1],xrot=90)
  if k%2==1:ex.append(colorbar(fig,im,(173,y,2,41),'−log10(rank)' if k<2 else 'Total potential'))
 e=axmm(fig,21,65,54,31,'e','All 5,556 coexpression tests');axs.append(e);xx=np.log1p((ot.Acute_mean+ot.Remission_mean)/2);e.hexbin(xx,ot.acute_minus_remission_log1p_score,gridsize=24,mincnt=1,cmap=SEQUENTIAL,linewidths=0);e.axhline(0,color=ROSE,ls='--',lw=.65);e.set(xlabel='log1p(mean potential)',ylabel='Acute − remission log1p score');nice_axes(e,3)
 # Existing fourteen-pair library context, using the complete storedscore array.
 npz=TF/'LR_完整评分数组.npz';z=np.load(npz,allow_pickle=False);pair_order=pairs.sort_values('rank').pair_id.tolist();pair_idx={p:i for i,p in enumerate(z['pairs'])};scores=z['scores'];values=np.asarray([scores[:,:,pair_idx[p],:].mean(axis=(0,1)) for p in pair_order]);assert values.shape==(14,6)
 derived=pd.DataFrame(values,index=pair_order,columns=SAMPLES).rename_axis('pair_id').reset_index();source_table(fid,'Original14Pairs_all6library_means.tsv',derived)
 f=axmm(fig,121,65,49,31,'f','Candidate-linked pairs / libraries');axs.append(f);iff=heat(f,np.log1p(values),[p.replace(' -> ','→') for p in pair_order],SAMPLES,vmin=0,vmax=float(np.log1p(values).max()),xrot=0);ex.append(colorbar(fig,iff,(174,65,2,31),'log1p(mean potential)'))
 g=axmm(fig,21,12,54,30,'g','All 100 phase-restricted candidates');axs.append(g)
 for phase,col in [('Acute',ROSE),('Remission',TEAL)]:
  vv=np.sort(cand.loc[cand.phase.eq(phase),'phase_median_priority'].to_numpy());g.step(vv,np.arange(1,len(vv)+1)/len(vv),where='post',color=col,lw=1,label=phase+' (n='+str(len(vv))+')');g.scatter(vv,np.arange(1,len(vv)+1)/len(vv),s=3,c=col,linewidths=0)
 g.set(xlabel='Phase-median LIANA priority',ylabel='Empirical cumulative fraction',ylim=(0,1.03));g.legend(loc='lower right',fontsize=6.5,handlelength=1);nice_axes(g,3)
 h=axmm(fig,133,12,37,30,'h','Original 12 displayed candidates');axs.append(h)
 shown=shown.sort_values('display_row') if 'display_row' in shown.columns else shown.reset_index(drop=True)
 h.set(xticks=range(6),xticklabels=SAMPLES,yticks=range(12),ylim=(11.55,-.55),xlim=(-.5,5.5));labels=[];lab=dict(zip(TYPES,TLAB))
 for i,rr in shown.iterrows():
  ix=int(rr['display_row']) if 'display_row' in rr else i
  receptor=str(rr.receptor_complex);labels.append(str(rr.ligand_complex)+'→'+receptor+('†' if receptor=='ACTR2' else '')+' | '+lab.get(rr.source,rr.source)+'→'+lab.get(rr.target,rr.target))
  dd=dots[dots.display_row.eq(ix)].set_index('sample_id').reindex(SAMPLES)
  for j,s in enumerate(SAMPLES):
   if bool(dd.loc[s,'eligible']):h.scatter(j,ix,s=float(dd.loc[s,'priority'])*6,c=ROSE if rr.phase=='Acute' else TEAL,linewidths=0)
   else:h.scatter(j,ix,s=8,c=GREY,marker='x',linewidths=.55)
 h.set_yticklabels(labels,fontsize=6.5);clean(h)
 fig.text(.49,.019,'h: dot area = LIANA priority',fontsize=6.5,color=INK)
 fig.legend(handles=[Line2D([],[],marker='o',ls='',color=INK,markersize=np.sqrt(6*p),label=str(p)) for p in [2,4]],loc='center left',bbox_to_anchor=(.74,.019),ncol=2,columnspacing=.8,handletextpad=.3,fontsize=6.5)
 fig.text(.09,.005,'† ACTR2 is ARP2 in this resource. Detection restrictions and coexpression ranks are descriptive hypotheses.',fontsize=6.5,color=INK)
 legend='Figure 10 | Complete cell-type communication maps and source-resolved detection hypotheses. a,b, Every64 directed sender–receiver combination for official LIANA priorities in acute and remission captures, on the same complete-range scale. c,d, The original RNA-coexpression potential summaries for all64 combinations per phase, retained as a different scoring definition with its own shared scale. e, Every5,556 expression-eligible combination from the old all-six-library family, displayed by complete hexagonal aggregation; no disease-phase significance is inferred. f, The original14 candidate-linked ligand–receptor annotations in all six libraries; values are log1p of the mean potential over all64 type combinations. g, Every79 acute-restricted and21 remission-restricted candidate from the official5% minimum-subunit expression rule, encoded as complete empirical distributions of their phase-median priorities. h, All72 source-library detection marks for the original six highest-ranked candidates per phase, with sender/receiver identities and dot area proportional to the recorded LIANA priority. Crosses denote below-threshold detection, not biological absence. ACTR2 is ARP2 (P61160), not ACVR2A; its unchanged resource entry is flagged rather than interpreted as an activin receptor. The earlier potential score and official rank aggregation use different eligibility definitions and are not interchangeable physical-signalling measurements. These are six captures from three patients, not six independent patient groups.'
 return save_figure(fig,fid,'Cell-type communication structure and library consistency',{'a':'All64Acute officialrank summaries','b':'All64Remission officialrank summaries','c':'All64Acute originalcoexpression summaries','d':'All64Remission originalcoexpression summaries','e':'All5556originaleligibletests','f':'All84originalcandidate/library observations','g':'All100officialrestrictedcandidates','h':'All72originaldisplaylibrarymarks'},[ES/'A03_官方LIANA通讯结构与阶段检出_两阶段全部64方向.tsv',TF/'LR_通讯潜力网络汇总.tsv',TF/'LR_全部合格文库级阶段检验.tsv',TF/'LR_图中候选关联14配体受体.tsv',npz,ES/'A03_官方LIANA通讯结构与阶段检出_全部阶段限制检出候选.tsv',ES/'A03_官方LIANA通讯结构与阶段检出_候选逐文库全部点.tsv',ES/'A03_官方LIANA通讯结构与阶段检出_展示候选与明确选择规则.tsv'],legend,row_groups=[['a','b'],['c','d']],column_groups=[],axes=axs,exclude_axes=ex,old_figure_mapping=['R02_配体受体通讯潜力与文库一致性','A03_官方LIANA通讯结构与阶段检出'])

if __name__=='__main__':
 funcs={'F06':f06,'F07':f07,'F08_A':f08a,'F08_B':f08b,'F09':f09,'F10':f10}
 for key in (sys.argv[1:] or list(funcs)):funcs[key]()
