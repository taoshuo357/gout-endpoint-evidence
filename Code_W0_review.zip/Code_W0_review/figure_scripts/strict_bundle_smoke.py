from pathlib import Path
import os,sys,json,subprocess,hashlib,importlib.metadata as md
R=Path(__file__).resolve().parents[1];D=R/'figure_scripts';O=R/'reproduced_figures';O.mkdir(exist_ok=True)
NAMES=['plot_root_contexts.py', 'atlas_network_structure_ko.py', 'draw_root_assays.py', 'draw_singlecell_atlas.py', 'draw_functional_main.py', 'draw_screen_audit.py']
env={**os.environ,'BUNDLE_SMOKE_FAST':'1','PYTHONDONTWRITEBYTECODE':'1','MPLCONFIGDIR':str(R/'runtime_cache/matplotlib'),'PYTHONIOENCODING':'utf-8'}
results=[]
for name in NAMES:
 try:
  p=subprocess.run([sys.executable,str(D/'smoke_child.py'),name],cwd=D,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=int(os.environ.get('BUNDLE_MODULE_TIMEOUT','300')))
  (O/(name+'.log')).write_text(p.stdout+'\n'+p.stderr,encoding='utf-8');results.append({'script':name,'exit_code':p.returncode,'stdout_tail':p.stdout[-1000:],'stderr_tail':p.stderr[-2500:]})
 except subprocess.TimeoutExpired as ex:results.append({'script':name,'exit_code':'TIMEOUT','stderr_tail':str(ex)})
versions={}
for n in ['numpy','pandas','matplotlib','scipy','networkx','rdkit','Pillow']:
 try:versions[n]=md.version(n)
 except Exception:versions[n]='unavailable'
receipts=[]
for p in (O/'read_receipts').glob('*.json'):
 j=json.loads(p.read_text(encoding='utf-8'));receipts.append({'script':p.stem,**j})
missing=[r for j in receipts for r in j['reads'] if r['status']!='BUNDLE_SHA_VERIFIED']
contracts=list((O/'Metadata').glob('*_contract.json'));ok=all(x['exit_code']==0 for x in results) and len(contracts)==24 and not missing
report={'version':'v0.1-W0-review','scope':'Figure redraw only,not source statistical-analysis reproduction','strict_bundle_pass':ok,'fallback_to_original_data':False,'private_skill_implementation_included':False,'new_model_fits':False,'script_results':results,'exported_plates':len(contracts),'required_plates':24,'missing_exact_inputs':missing,'read_receipts':receipts,'code_map':json.loads((R/'provenance/figure_script_portability_map.json').read_text(encoding='utf-8')),'dependencies':versions,'smoke_formats':'PDF/SVG/100dpiPNG;default exporter also supports PNG300/TIFF600','public_portability_status':'review-only:author license and clean-environment installation remain to verify','output_root':str(O)}
(R/'publicity_readiness.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'strict_bundle_pass':ok,'plates':len(contracts),'results':[(x['script'],x['exit_code']) for x in results],'missing':len(missing)}),flush=True)
