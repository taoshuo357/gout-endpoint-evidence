"""Eight source-complete network, genetic, structure and virtual-knockout figures.
All input observations are frozen real outputs; only layout and display change.
"""
from pathlib import Path
import os,sys,json,hashlib,re,textwrap
G=Path(r'G:/痛风/第二步_靶点预测与疾病交集');E=Path(r'E:/痛风/研究深化_2026-11-02');O=Path(__file__).resolve().parents[1]/'reproduced_figures'
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap,ListedColormap,BoundaryNorm
from matplotlib.collections import LineCollection
from matplotlib.lines import Line2D
from matplotlib.patches import Circle
from matplotlib.ticker import MaxNLocator
import networkx as nx
import atlas_style as S
BLUE='#547AA5';TEAL='#4A9B8E';ROSE='#C9778C';GOLD='#CA9C55';PURPLE='#9684B5';GRAY='#B4BBC1';DARK='#263849';LIGHT='#EDF1F4'
if hasattr(S,'COLORS'):
 for k in ['BLUE','TEAL','ROSE','GOLD','PURPLE','GRAY','DARK','LIGHT']:
  if k.lower() in S.COLORS:globals()[k]=S.COLORS[k.lower()]
DARK=S.COLORS['ink'];PURPLE=S.COLORS['violet']
CMAP=LinearSegmentedColormap.from_list('atlas_sequential',['#F7FAFC',BLUE,'#244E72'])
DIV=LinearSegmentedColormap.from_list('atlas_diverging',[BLUE,'#FAFAFA',ROSE])
CHEM=G/'生信扩展_2026-11-02/结果表';PPI=G/'下一步_PPI与富集_2026-10-29';KO=G/'虚拟敲除_2026-11-02/图源数据';GEN=G/'论文推进_2026-10-30/遗传验证推进_第二轮';KD=G/'全面验证_2026-11-02/04_遗传补强';DOCK=G/'全面验证_2026-11-02/06_对接与MD/tables';XO=E/'07_实测药物与功能验证/08_实测结构参照'
GENES=['NLRP3','CASP1','IL1B','XDH','SLC22A12','ABCG2','SLC2A9','TLR4','RELA','NFKB1','TNF','AKT1'];PRIMARY=['NLRP3','CASP1','IL1B','RELA','NFKB1']
inputs=[];SOURCE_MAP={}
def read(p,**kw):
 p=Path(p);inputs.append(p)
 return pd.read_csv(p,sep='\t' if '.tsv' in p.name else ',',low_memory=False,**kw)
def make(h=240,rows=3,cols=2,left=.13,right=.97,bottom=.075,top=.95,wspace=.6,hspace=.7):
 global inputs;inputs=[]
 fig=plt.figure(figsize=(183/25.4,h/25.4));gs=fig.add_gridspec(rows,cols,left=left,right=right,bottom=bottom,top=top,wspace=wspace,hspace=hspace)
 axes=[fig.add_subplot(gs[i,j]) for i in range(rows) for j in range(cols)]
 return fig,axes

def label(ax,i,title):S.panel_label(ax,chr(97+i),'\n'.join(textwrap.wrap(title,31,break_long_words=False)))
def short(x,n=29):
 x=str(x)
 return x if len(x)<=n else x[:n-1].rstrip()+'…'
def heat(ax,z,xlabels,ylabels,cmap=CMAP,vmin=None,vmax=None,aspect='auto',cbarlabel=None,fig=None):
 z=np.asarray(z,dtype=float);masked=np.ma.masked_invalid(z);cmap=cmap.copy();cmap.set_bad('#DDE2E6')
 im=ax.imshow(masked,aspect=aspect,cmap=cmap,vmin=vmin,vmax=vmax,interpolation='nearest')
 ax.set_xticks(range(len(xlabels)),xlabels,rotation=90,ha='right',rotation_mode='anchor');ax.set_yticks(range(len(ylabels)),ylabels);ax.tick_params(length=0,pad=2)
 for sp in ax.spines.values():sp.set_visible(False)
 if cbarlabel:
  colorbar(fig,ax,im,cbarlabel)
 return im

def colorbar(fig,ax,im,label):
 cax=ax.inset_axes([1.04,.12,.035,.72]);cb=fig.colorbar(im,cax=cax);cb.set_label(label,fontsize=6.5);cb.ax.tick_params(labelsize=6.5,length=2);return cb

def strip(ax,d,x,value,color=BLUE,order=None):
 order=order or list(dict.fromkeys(d[x]));jitter=np.linspace(-.18,.18,max(d.groupby(x).size()))
 for i,g in enumerate(order):
  vals=pd.to_numeric(d.loc[d[x].eq(g),value],errors='coerce').to_numpy();v=vals[np.isfinite(vals)];off=np.linspace(-.17,.17,len(v))
  ax.scatter(i+off,v,s=8,alpha=.55,c=color,edgecolors='none',rasterized=len(d)>1000)
  if len(v):ax.plot([i-.22,i+.22],[np.median(v)]*2,color=DARK,lw=1.1)
 ax.set_xticks(range(len(order)),[short(g,15) for g in order],rotation=35,ha='right',rotation_mode='anchor');ax.set_xlim(-.6,len(order)-.4)

def done(fig,axes,fid,title,legend,mapping,exclude=None):
 paths=list(dict.fromkeys(inputs));SOURCE_MAP[fid]={'title':title,'old_figures':mapping,'inputs':[str(p) for p in paths],'panel_count':len(axes),'new_inference':False}
 (O/'source_map_network_structure_ko.json').write_text(json.dumps(SOURCE_MAP,ensure_ascii=False,indent=2),encoding='utf-8')
 return S.save_figure(fig,fid,title,{chr(97+i):a.get_title(loc='left') for i,a in enumerate(axes)},paths,legend,exclude_axes=exclude,axes=axes)

def draw_F02():
 fig,ax=make(250,3,3,left=.14,right=.90,bottom=.09,top=.95,wspace=.85,hspace=.85)
 d=read(CHEM/'Chem_104结构全描述符与PCA.tsv');s=read(CHEM/'Network_完整数据库组合计数.tsv');de=read(CHEM/'Network_逐库剔除完整计数.tsv');v=read(G/'论文推进_2026-10-30/交集Venn/venn_counts.tsv')
 names=['TCMSP','SwissTargetPrediction','PharmMapper','STITCH'];s=s[s.scope.eq('All compound-target edges')].sort_values('edge_count',ascending=False)
 assert len(d)==104 and len(s)==13
 # All nonempty observed source combinations: compact presence matrix aligned with bars.
 pos=np.arange(len(s));ax[0].bar(pos,s.edge_count,color=[TEAL if r.databases.count(';')+r.databases.count('|')>0 or sum(int(r[n]) for n in names)>1 else BLUE for _,r in s.iterrows()],width=.78)
 ax[0].set(xlabel='Database-presence combination',ylabel='Recorded edges',xticks=[])
 low=ax[0].get_ylim()[1]*.18
 for j,n in enumerate(names):
  yy=-(j+1)*low/2
  for i,r in enumerate(s.to_dict('records')):ax[0].scatter(i,yy,s=10,c=DARK if int(r[n]) else '#DFE4E8',clip_on=False)
 ax[0].set_ylim(-low*2.2,ax[0].get_ylim()[1]);ax[0].set_yticks([0,2000,4000]);ax[0].text(.02,-.18,'T / S / P / ST presence rows',transform=ax[0].transAxes,fontsize=6.5)
 label(ax[0],0,'Source combinations')
 yy=np.arange(len(de));ax[1].barh(yy,de.genes,color=GRAY,height=.67,label='All genes');ax[1].barh(yy,de.gout_genes,color=TEAL,height=.67,label='Gout overlap');ax[1].set_yticks(yy,[short(x,19) for x in de.scenario]);ax[1].invert_yaxis();ax[1].set_xlabel('Genes after source deletion');ax[1].legend(fontsize=6.5,loc='lower right',frameon=True,facecolor='white',edgecolor='none',framealpha=.95);label(ax[1],1,'Source dependence')
 cats=['compound_only','intersection','disease_only'];bottom=np.zeros(len(v))
 for k,c in zip(cats,[BLUE,TEAL,GRAY]):
  ax[2].bar(range(len(v)),v[k],bottom=bottom,label={'compound_only':'Compound only','intersection':'Shared','disease_only':'Gout only'}[k],color=c,width=.58);bottom+=v[k]
 ax[2].set_xticks(range(len(v)),['Primary','Restricted'],rotation=0);ax[2].set_ylabel('Target-set membership count');ax[2].legend(fontsize=6.5,loc='upper right',frameon=True,facecolor='white',edgecolor='none',framealpha=.95);label(ax[2],2,'Target-set intersections')
 herbs=list(dict.fromkeys(d.source_herbs));pal=[BLUE,ROSE,TEAL,PURPLE,GOLD,GRAY]
 for h,c in zip(herbs,pal):
  z=d[d.source_herbs.eq(h)];ax[3].scatter(z.PC1,z.PC2,s=14,c=c,alpha=.8,label=herb_en(h).replace(';',' / '),edgecolor='white',linewidth=.25)
 ax[3].set(xlabel='Descriptor PC1',ylabel='Descriptor PC2');ax[3].legend(fontsize=6.5,loc='upper left',bbox_to_anchor=(0,-.20),handlelength=.6,borderaxespad=.2,frameon=False);label(ax[3],3,'All 104 structures')
 sc=ax[4].scatter(d.MW,d.cLogP,c=d.TPSA,cmap=CMAP,s=17,edgecolor='white',linewidth=.3);ax[4].axvline(500,ls='--',lw=.7,c=GRAY);ax[4].axhline(5,ls='--',lw=.7,c=GRAY);ax[4].set(xlabel='Molecular weight',ylabel='Calculated logP');cb=colorbar(fig,ax[4],sc,'TPSA (Å²)');label(ax[4],4,'Property coverage')
 desc=['MW','cLogP','TPSA','HBD','HBA','RotB','Fsp3','Rings','AromaticRings'];z=(d[desc]-d[desc].mean())/d[desc].std(ddof=1)
 vp=ax[5].violinplot([z[c].values for c in desc],positions=range(len(desc)),showextrema=False,widths=.8)
 for b in vp['bodies']:b.set_facecolor(BLUE);b.set_edgecolor('none');b.set_alpha(.65)
 ax[5].scatter(range(len(desc)),z.median(),s=10,c=DARK,zorder=4);ax[5].axhline(0,lw=.6,c=GRAY);ax[5].set_xticks(range(len(desc)),['MW','cLogP','TPSA','HBD','HBA','RotB','Fsp3','Rings','AromR'],rotation=90,ha='right',rotation_mode='anchor');ax[5].set_ylabel('Sample-standardized descriptor');label(ax[5],5,'Complete descriptor profiles')
 mt=read(CHEM/'Chem_结构靶点谱Mantel_全部来源情景.tsv');ys=np.arange(len(mt));ax[6].axvline(0,c=GRAY,lw=.6);ax[6].hlines(ys,0,mt.Mantel_Spearman_r,color=GRAY,lw=1);ax[6].scatter(mt.Mantel_Spearman_r,ys,c=BLUE,s=20);ax[6].set_yticks(ys,['All','−TCMSP','−SwissTarget','−PharmMapper','−STITCH']);ax[6].invert_yaxis();ax[6].set_xlabel('Mantel structural / target ρ');label(ax[6],6,'All source-deletion scenarios')
 ax[6].text(0,-.29,'Ro5 ≤ 1: 98 / 104\nRo5 = 0: 84 / 104\nVeber = 0: 96 / 104',transform=ax[6].transAxes,fontsize=6.5,ha='left',va='top')
 sim=read(CHEM/'Chem_全部结构相似度.tsv');order=d.sort_values('chemical_order').compound_id.tolist();mat=pd.DataFrame(np.eye(104),index=order,columns=order)
 for r in sim.itertuples():mat.loc[r.compound_a,r.compound_b]=r.Tanimoto;mat.loc[r.compound_b,r.compound_a]=r.Tanimoto
 im=heat(ax[7],mat.values,[],[],fig=fig);ax[7].set(xlabel='All compounds, clustered order',ylabel='Same 104 compounds');cb=colorbar(fig,ax[7],im,'Tanimoto');label(ax[7],7,'Full structural similarity')
 pairs=read(CHEM/'Chem_全部可测化合物对_结构与靶点相似.tsv');mt=read(CHEM/'Chem_结构靶点谱Mantel_全部来源情景.tsv')
 hb=ax[8].hexbin(pairs.Tanimoto,pairs.target_Jaccard,gridsize=22,mincnt=1,cmap=CMAP,linewidths=.1);ax[8].set(xlim=(0,1),ylim=(0,1),xlabel='Structural Tanimoto',ylabel='Target-profile Jaccard');cb=colorbar(fig,ax[8],hb,'Pairs');label(ax[8],8,'All 5,253 recorded pairs')
 legend='Figure 2 | Chemical and evidence-source coverage. All 104 compounds, every observed database-presence combination, both frozen target intersections, all nine descriptor distributions and every calculable structural/target-profile pair are retained. Source counts and calculated physicochemical heuristics are descriptive; they are not calibrated affinity or measured ADMET. The full 104×104 structural matrix uses the frozen chemical order. Pair density aggregates all 5,253 pairs among 103 compounds with recorded targets; the zero-record compound remains in the chemistry panels. Full five-scenario Mantel results accompany the source data.'
 return done(fig,ax,'F02','Chemical space and evidence sources',legend,{'C01':'d,e,f,g','C02':'g,h,i','N01':'a,b','FigS10':'c'})

def draw_F03():
 fig,ax=make(250,3,2,left=.21,right=.975,bottom=.07,top=.95,wspace=.95,hspace=.65)
 nodes=read(PPI/'PPI_397主分析_节点指标.csv');edges=read(PPI/'PPI_功能关联700_主边表.csv');top=read(PPI/'PPI_主网络前20拓扑候选.csv');ranks=read(PPI/'PPI_拓扑排名敏感性.csv');en=read(PPI/'富集_绘图与敏感性比较45项.csv')
 H=nx.Graph();H.add_nodes_from(nodes.gene_symbol);H.add_weighted_edges_from(edges[['gene_A','gene_B','score']].itertuples(index=False,name=None))
 giant=max(nx.connected_components(H),key=len);pos=nx.spring_layout(H.subgraph(giant),seed=20261104,iterations=120,weight='weight',scale=.90)
 remaining=sorted(set(H)-set(giant))
 for j,g in enumerate(remaining):
  theta=2*np.pi*j/max(1,len(remaining));pos[g]=np.array([1.05*np.cos(theta),1.05*np.sin(theta)])
 col=[TEAL if x in GENES else '#CBD8E3' for x in H];sizes=[10 if x in GENES else 2.5 for x in H];nx.draw_networkx_edges(H,pos,ax=ax[0],width=.16,alpha=.19,edge_color=GRAY);nx.draw_networkx_nodes(H,pos,ax=ax[0],node_size=sizes,node_color=col,linewidths=0)
 # Direct names of the fixed candidates; all unlabelled nodes remain drawn.
 for side in [-1,1]:
  names=sorted([g for g in GENES if g in pos and (pos[g][0]>=0)==(side==1)],key=lambda g:pos[g][1]);ys=np.linspace(-.9,.9,len(names))
  for g,y in zip(names,ys):ax[0].annotate(g,xy=pos[g],xytext=(side*1.18,y),ha='left' if side>0 else 'right',fontsize=6.5,arrowprops={'arrowstyle':'-','lw':.4,'color':GRAY})
 ax[0].set(xlim=(-1.7,1.7),ylim=(-1.15,1.15));ax[0].axis('off');label(ax[0],0,'Complete functional network')
 top=top.sort_values('degree');rr=ranks.set_index('gene_symbol').reindex(top.gene_symbol);yy=np.arange(20);ax[1].barh(yy,top.degree,color=BLUE,height=.65,label='Primary');ax[1].scatter(rr.strict_degree,yy,c=ROSE,s=13,label='Restricted');ax[1].set_yticks(yy,top.gene_symbol);ax[1].set_xlabel('Functional-network degree');ax[1].legend(fontsize=6.5,loc='lower right');label(ax[1],1,'All 20 ranked candidates')
 for a,(source,title) in zip(ax[2:5],[('GO:BP','Biological processes'),('GO:MF','Molecular functions'),('KEGG','KEGG pathways')]):
  z=en[en.source.eq(source)].copy();z=z.sort_values('main_q_sourceBH',ascending=False);y=np.arange(len(z));assert (z[['main_q_sourceBH','strict_q_sourceBH']]>0).all().all();main=-np.log10(z.main_q_sourceBH);strict=-np.log10(z.strict_q_sourceBH)
  a.plot(np.vstack([main,strict]),np.vstack([y,y]),c=GRAY,lw=.7);a.scatter(main,y,s=14,c=BLUE,label='Primary');a.scatter(strict,y,s=12,c=TEAL,marker='s',label='Restricted');display=[short(t,28) for t in z.term_name];duplicates={t for t in display if display.count(t)>1};display=[(short(name,17)+' ['+tid.split(':')[-1]+']') if label in duplicates else label for name,tid,label in zip(z.term_name,z.term_id,display)];a.set_yticks(y,display);a.set_xlabel('−log10 source-family BH q');a.xaxis.set_major_locator(MaxNLocator(4));label(a,list(ax).index(a),title)
  if source=='GO:BP':a.legend(fontsize=6.5,loc='lower right')
 ann=read(G/'关键靶点与通路筛选_2026-10-29/炎症候选8节点_5通路注释矩阵.csv');path=list(dict.fromkeys(ann.pathway));gn=list(dict.fromkeys(ann.gene_symbol));z=ann.pivot(index='gene_symbol',columns='pathway',values='main_annotation_hit').reindex(index=gn,columns=path).astype(float)
 heat(ax[5],z.values,[{'NOD样受体信号通路':'NOD-like','NF-κB信号通路':'NF-κB','TNF信号通路':'TNF','Toll样受体信号通路':'Toll-like','PI3K-Akt信号通路':'PI3K–AKT'}.get(x,x) for x in path],gn,cmap=ListedColormap(['#F1F4F6',TEAL]),vmin=0,vmax=1);label(ax[5],5,'Inflammatory pathway annotations')
 legend='Figure 3 | Candidate functional associations and annotations. The full mapped 393-node STRING functional network and all its frozen high-confidence edges are shown; labels identify the fixed twelve candidates rather than filtering other nodes. The twenty previously ranked candidates are displayed with restricted-source degree sensitivity. Every one of the previously specified 45 GO/KEGG terms is retained, with primary and restricted source-family BH values. The full inflammatory-candidate pathway annotation matrix is descriptive membership, not inferred activity or protein binding. Complete statistical families remain in the source data.'
 return done(fig,ax,'F03','Functional networks and pathway annotations',legend,{'Fig3':'a','FigS2':'b','FigS3':'c','FigS4':'d','Fig4':'e','FigS11':'f'})


def herb_en(x):
 return str(x).replace('桃儿七','Taoerqi').replace('威灵仙','Weilingxian').replace('甘草','Gancao')
def draw_F04():
 fig,ax=make(250,4,2,left=.17,right=.90,bottom=.065,top=.955,wspace=.72,hspace=.95)
 d=read(CHEM/'Network_104乘12_全部候选关联.tsv');chem=read(CHEM/'Chem_104结构全描述符与PCA.tsv');pairs=read(CHEM/'Network_全部5356成分对_覆盖互补.tsv');herb=read(CHEM/'Network_药材至候选基因_成分数.tsv');path=read(CHEM/'Network_候选至5通路_完整注释.tsv')
 order=chem.sort_values('chemical_order').compound_id.tolist();z=d.pivot(index='compound_id',columns='gene',values='recorded_qualified_sources').reindex(index=order,columns=GENES).astype(float)
 im=heat(ax[0],z.values,GENES,[],cmap=CMAP,vmin=0,vmax=max(1,float(z.max().max())));ax[0].set_yticks(np.arange(0,104,8),np.array(order)[::8]);ax[0].set_ylabel('All 104 compounds');colorbar(fig,ax[0],im,'Recorded sources');label(ax[0],0,'Full candidate association map')
 herbs=list(dict.fromkeys(herb.herb));paths=list(dict.fromkeys(path.pathway));H=herb.pivot(index='gene',columns='herb',values='distinct_compounds').reindex(index=GENES,columns=herbs).fillna(0);P=path.pivot(index='gene',columns='pathway',values='annotated').reindex(index=GENES,columns=paths).fillna(0)
 ax[1].imshow(H.to_numpy(float),extent=(-.5,len(herbs)-.5,11.5,-.5),aspect='auto',cmap=CMAP,interpolation='nearest')
 for i,g in enumerate(GENES):
  for j,h in enumerate(herbs):
   count=int(H.loc[g,h]);ax[1].text(j,i,str(count),fontsize=6.5,ha='center',va='center',color='white' if count>H.max().max()/2 else DARK)
  for j,pathid in enumerate(paths):
   if bool(P.loc[g,pathid]):ax[1].scatter(len(herbs)+j,i,s=15,c=TEAL,marker='s')
 labels=[herb_en(h) for h in herbs]+[{'KEGG:04621':'NOD-like','KEGG:04064':'NF-κB','KEGG:04668':'TNF','KEGG:04620':'Toll-like','KEGG:04151':'PI3K–AKT'}.get(v,'No selected pathway') for v in paths]
 ax[1].set_xticks(range(len(labels)),labels,rotation=90,ha='right',rotation_mode='anchor');ax[1].set_yticks(range(12),GENES);ax[1].set_xlim(-.5,len(labels)-.5);ax[1].set_ylim(11.5,-.5);ax[1].axvline(len(herbs)-.5,c=GRAY,lw=.6);ax[1].tick_params(length=0);label(ax[1],1,'Complete herb / pathway links')
 hb=ax[2].hexbin(pairs.Tanimoto,pairs.union_candidate_count,gridsize=(22,11),mincnt=1,cmap=CMAP,linewidth=.1);ax[2].set(xlim=(0,1),ylim=(-.5,12.5),xlabel='Structural Tanimoto',ylabel='Pair candidate union');colorbar(fig,ax[2],hb,'Pairs');label(ax[2],2,'All 5,356 compound pairs')
 pairs['best_single']=pairs[['a_candidate_count','b_candidate_count']].max(axis=1);ct=pairs.groupby(['best_single','union_candidate_count','gain_over_best_single']).size().reset_index(name='n')
 sc=ax[3].scatter(ct.best_single,ct.union_candidate_count,s=5+ct.n*.12,c=ct.gain_over_best_single,cmap=CMAP,vmin=0,vmax=4,edgecolor='white',lw=.3);ax[3].plot([0,12],[0,12],ls='--',lw=.7,c=GRAY);ax[3].set(xlim=(-1.5,12.5),ylim=(-1.5,12.5),xlabel='Better single-compound coverage',ylabel='Two-compound coverage');colorbar(fig,ax[3],sc,'Coverage gain');label(ax[3],3,'Coverage complementarity')
 null=G/'全面验证_2026-11-02/03_匹配背景与置换';n=read(null/'基因网络_全部29997随机结果.tsv');c=read(null/'Curveball_4链_全部随机结果.tsv');tests=read(null/'Curveball_4链_全部九项统计与BH.tsv')
 families=['Uniform','Degree matched','Degree breadth source matched'];col=[GRAY,BLUE,TEAL]
 for a,key,obs,title,ylab in [(ax[4],'induced_edges',30,'Within-set connectivity','Functional-association edges'),(ax[5],'harmonic_efficiency',.6515151515151515,'Network proximity','Mean reciprocal path length')]:
  arr=[n.loc[n.family.eq(f),key].to_numpy(float) for f in families];assert all(len(x)==9999 for x in arr)
  vp=a.violinplot(arr,positions=range(3),showextrema=False,widths=.78)
  for body,color in zip(vp['bodies'],col):body.set(facecolor=color,edgecolor='none',alpha=.65)
  for i,x in enumerate(arr):a.scatter(i,np.median(x),s=12,c='white',edgecolor=DARK,lw=.6,zorder=5);a.plot([i,i],np.quantile(x,[.025,.975]),c=DARK,lw=.8)
  a.axhline(obs,c=ROSE,lw=1.2,ls='--');a.set_xticks(range(3),['Uniform','Degree','Degree +\nsource + breadth']);a.set_ylabel(ylab);label(a,list(ax).index(a),title)
 for a,key,obs,title,xlabel in [(ax[6],'maximum_union',10,'Maximum pair coverage','Maximum union across 5,356 pairs')]:
  vals=c[key].to_numpy(float);bins=np.arange(vals.min()-.5,vals.max()+1.5,1) if key=='maximum_union' else np.arange(vals.min()-2.5,vals.max()+7.5,5)
  a.hist(vals,bins=bins,color=BLUE,edgecolor='white',lw=.35);a.axvline(obs,c=ROSE,lw=1.2,ls='--');a.set(xlabel=xlabel,ylabel='Randomized matrices');label(a,list(ax).index(a),title)
 hb=ax[7].hexbin(c.pairs_union_ge8,c.maximum_gain,gridsize=(20,7),mincnt=1,cmap=CMAP,linewidths=.1);ax[7].scatter([94],[4],s=42,c=ROSE,marker='*',edgecolor='white',lw=.5);ax[7].set(xlabel='Pairs covering at least 8 candidates',ylabel='Maximum gain over best single');colorbar(fig,ax[7],hb,'Randomized matrices');label(ax[7],7,'Complete pair-reference metrics')
 legend='Figure 4 | Complete recorded candidate associations and matched-reference network checks. All 104×12 source-count cells, all 5,356 unordered pairs and all recorded herb/candidate/pathway links are retained. The relationship matrix shows numeric herb-linked compound counts and binary pathway annotations as separate encodings; these are different quantities. The six gene-network tests use all 9,999 draws per reference family; dashed lines identify the frozen observations. Compound references use the latest four-chain 10,000-matrix exact-degree Curveball analysis. All nine tests share BH correction: gene-network q=0.00015; maximum pair-union q=0.48066; count of pairs covering at least eight candidates q=0.02057; maximum gain q=0.77932. Reference intervals are central empirical ranges, not sampling confidence intervals. Point area in panel d is proportional to the number of pairs sharing those coverage coordinates. Coverage complementarity is a set property, not measured drug synergy.'
 return done(fig,ax,'F04','Candidate coverage and matched network references',legend,{'N02':'a','N04':'b','N03':'c,d','N05_匹配背景与网络置换':'e,f,g,h; latest four-chain references'})

def draw_F15():
 fig,ax=make(240,3,2,left=.17,right=.90,bottom=.075,top=.95,wspace=.7,hspace=.78)
 old=read(G/'论文推进_2026-10-30/论文稿与图表目录/12优先靶点_遗传与表达图源数据.tsv').set_index('gene_symbol').reindex(GENES);aud=read(GEN/'全部24基因组织_固定家族审计.tsv');wald=read(GEN/'图源_3个合格单cis_Wald_24家族校正.tsv');reg=read(GEN/'图源_19区域默认PP0至PP4.tsv');sens=read(GEN/'图源_19区域先验与sdY敏感性_受限合法先验.tsv');kd=read(KD/'原24加新增4_全部28组合比较.tsv')
 features=['MAGMA_gene_association','GTEx_coloc','kidney_coloc','missense_LD098','immune_ABC_target']
 z=old[features].apply(pd.to_numeric,errors='coerce');heat(ax[0],z.values,['Gene\nassoc.','GTEx\ncoloc','Kidney\ncoloc','Missense\nLD','Immune\nABC'],GENES,cmap=ListedColormap([LIGHT,BLUE]),vmin=0,vmax=1);ax[0].tick_params(axis='x',labelrotation=0);[t.set_ha('center') for t in ax[0].get_xticklabels()];label(ax[0],0,'Published target-evidence annotations')
 order=['NLRP3','SLC2A9','TLR4'];w=wald.set_index('gene').reindex(order);y=np.arange(3)
 for i,g in enumerate(order):
  r=w.loc[g];ax[1].errorbar(r.wald_OR,i,xerr=[[r.wald_OR-r.wald_OR_CI_low],[r.wald_OR_CI_high-r.wald_OR]],fmt='o',c=ROSE if g=='SLC2A9' else BLUE,ms=4,capsize=2,lw=1)
 ax[1].axvline(1,c=GRAY,lw=.7,ls='--');ax[1].set_xscale('log');ax[1].set_yticks(y,order);ax[1].set(xlabel='Gout odds ratio per\nprocessed-expression unit',xlim=(.88,1.82));ax[1].set_xticks([.9,1,1.2,1.5,1.8],['0.9','1','1.2','1.5','1.8']);ax[1].minorticks_off();label(ax[1],1,'All qualified single-cis estimates')
 tissues=['BLUEPRINT_monocyte','GTEx_whole_blood','GTEx_kidney_cortex'];z=kd.pivot(index='gene',columns='tissue',values='PP_H4').reindex(index=GENES,columns=tissues)
 im=heat(ax[2],z.values,['Monocyte','Blood','Kidney'],GENES,vmin=0,vmax=1);colorbar(fig,ax[2],im,'PP4');label(ax[2],2,'All 28 planned tissue comparisons')
 renal=['XDH','SLC22A12','ABCG2','SLC2A9']
 for j,(t,c) in enumerate(zip(tissues,[BLUE,TEAL,ROSE])):
  r=kd[kd.tissue.eq(t)].set_index('gene').reindex(renal);p=pd.to_numeric(r.eqtl_min_p,errors='coerce');valid=p.notna()&(p>0);ax[3].scatter(np.arange(4)[valid]+(j-1)*.2,-np.log10(p[valid]),s=18,c=c,label=['Monocyte','Blood','Kidney'][j])
 ax[3].axhline(-np.log10(5e-8),lw=.7,ls='--',c=GRAY);ax[3].set_xticks(range(4),renal,rotation=35,ha='right',rotation_mode='anchor');ax[3].set_ylabel('−log10 minimum cis-eQTL P');ax[3].legend(fontsize=6.5,loc='upper left',bbox_to_anchor=(0,-.35),ncol=3,columnspacing=.6,handlelength=.6);label(ax[3],3,'Exposure association strength')
 r=reg.copy();r['label']=r.gene+' / '+r.tissue.str.replace('BLUEPRINT_monocyte','M').str.replace('GTEx_whole_blood','B');r=r.sort_values(['tissue','gene']);y=np.arange(len(r));left=np.zeros(len(r))
 for k,c in zip(['PP.H0.abf','PP.H1.abf','PP.H2.abf','PP.H3.abf','PP.H4.abf'],['#E9EDF0','#C2CCD4',PURPLE,BLUE,TEAL]):
  ax[4].barh(y,r[k],left=left,color=c,height=.75,label=k.split('.')[1]);left+=r[k].to_numpy(float)
 ax[4].set_yticks(y,r.label,fontsize=6.5);ax[4].set(xlim=(0,1),xlabel='Regional posterior probability');ax[4].legend(fontsize=6.5,ncol=3,loc='lower center',bbox_to_anchor=(.5,-.39),columnspacing=.8,handlelength=.8);label(ax[4],4,'All 19 testable regions')
 keys=[(a,b) for a,b in zip(r.gene,r.tissue)];rows=[]
 for g,t in keys:
  q=sens[sens.gene.eq(g)&sens.tissue.eq(t)];vals=pd.to_numeric(q['PP.H4.abf'],errors='coerce');rows.append((vals.min(),vals.max(),float(r[(r.gene==g)&(r.tissue==t)]['PP.H4.abf'].iloc[0])))
 for i,(lo,hi,point) in enumerate(rows):ax[5].plot([lo,hi],[i,i],c=GRAY,lw=1.8);ax[5].scatter(point,i,c=TEAL,s=12,zorder=4)
 ax[5].set_yticks(y,[]);ax[5].set(xlim=(0,1),xlabel='PP4 across fixed prior / sdY settings');label(ax[5],5,'Shared-signal sensitivity')
 legend='Figure 15 | Genetic triangulation of the fixed candidates. Published gene-level annotations are shown for all twelve candidates. The three qualified single-cis Wald estimates use first-order 95% intervals and a twenty-four-comparison correction; their exposure units are the processed expression units supplied by the source. Tissue evaluation retains all original twenty-four gene–tissue comparisons and four prespecified kidney additions; unplanned kidney cells and unavailable regional estimates are not zero evidence. All nineteen testable blood/monocyte regions retain the complete H0–H4 posterior decomposition and all fixed valid prior/sdY settings. Regional association and an odds-ratio estimate do not alone establish colocalized expression-mediated causality. The outcome is European gout GWAS GCST90428600, excluding 23andMe.'
 return done(fig,ax,'F15','Genetic association and regional shared-signal support',legend,{'Fig10':'a','FigS18':'b,c,e,f','G04_肾皮质新增背景与原两组织遗传证据比较':'c,d'})

def draw_trace(ax,frame,cmap):
 xyz=frame[['x','y','z']].to_numpy(float);xyz=xyz-xyz.mean(axis=0);_,_,vt=np.linalg.svd(xyz,full_matrices=False);xy=xyz@vt[:2].T
 seg=np.stack([xy[:-1],xy[1:]],axis=1);lc=LineCollection(seg,cmap=cmap,norm=matplotlib.colors.Normalize(0,100),linewidths=1.15,alpha=.95);lc.set_array((frame.pLDDT.to_numpy()[:-1]+frame.pLDDT.to_numpy()[1:])/2);ax.add_collection(lc)
 # Equal physical x/y units without allowing axes geometry to shrink.
 ratio=(ax.get_position().height*ax.figure.get_figheight())/(ax.get_position().width*ax.figure.get_figwidth());span=max(np.ptp(xy[:,0]),np.ptp(xy[:,1])/ratio);mid=(xy.min(axis=0)+xy.max(axis=0))/2;ax.set(xlim=(mid[0]-span*.57,mid[0]+span*.57),ylim=(mid[1]-span*ratio*.57,mid[1]+span*ratio*.57));ax.set_aspect('auto');ax.axis('off')
 # A calibrated 10 Å projected distance bar, not a crystallographic annotation.
 x=mid[0]-span*.43;y=mid[1]-span*ratio*.44;ax.plot([x,x+10],[y,y],color=DARK,lw=1.4);ax.text(x+5,y-span*.04,'10 Å',ha='center',va='top',fontsize=6.5)
 return lc

def draw_F16():
 fig,ax=make(250,4,2,left=.155,right=.90,bottom=.055,top=.955,wspace=.72,hspace=.68)
 summ=read(CHEM/'Protein_12靶点结构汇总.tsv').set_index('gene').reindex(GENES);res=read(CHEM/'Protein_全部残基置信度与坐标.tsv')
 mat=np.full((12,int(summ.sequence_length.max())),np.nan)
 for i,g in enumerate(GENES):
  z=res[res.gene.eq(g)];mat[i,z.residue.to_numpy(int)-1]=z.pLDDT
 pc=LinearSegmentedColormap.from_list('confidence',['#d6a35d','#ead6b2','#81b3c5','#2a6994'])
 im=ax[0].imshow(np.ma.masked_invalid(mat),aspect='auto',cmap=pc,vmin=0,vmax=100,interpolation='nearest');ax[0].set_yticks(range(12),GENES);ax[0].set_xlabel('Canonical amino-acid position');colorbar(fig,ax[0],im,'pLDDT');label(ax[0],0,'All 7,861 model residues')
 y=np.arange(12);ax[1].barh(y,summ.pLDDT_ge90_fraction,color=BLUE,height=.58,label='pLDDT ≥ 90');ax[1].scatter(summ.PDB_chain_span_union_fraction,y,c=ROSE,s=15,label='PDB chain spans');ax[1].set_yticks(y,GENES);ax[1].invert_yaxis();ax[1].set(xlim=(0,1.08),xlabel='Sequence fraction');ax[1].legend(loc='upper left',bbox_to_anchor=(0,-.25),fontsize=6.5,ncol=1);label(ax[1],1,'Confidence and experiment coverage')
 for a,g in zip(ax[2:6],['NLRP3','CASP1','IL1B','AKT1']):
  z=res[res.gene.eq(g)].sort_values('residue');draw_trace(a,z,pc);label(a,list(ax).index(a),g+' · full canonical Cα trace')
 cont=read(XO/'全部两位点_按残基组分最短接触.tsv');z=cont[cont.partner_category.eq('protein')].copy();z['name']=z.partner_label_comp_id+z.partner_auth_seq_id.astype(str);order=list(dict.fromkeys(z.name));ys={g:i for i,g in enumerate(order)}
 for sid,c,mark in zip(list(dict.fromkeys(z.site_id)),[TEAL,ROSE],['o','s']):
  q=z[z.site_id.eq(sid)];ax[6].scatter(q.minimum_distance_A,[ys[g]+(-.10 if mark=='o' else .10) for g in q.name],c=c,s=16,marker=mark,label='Site C' if mark=='o' else 'Site L')
 ax[6].axvline(4,ls='--',c=GRAY,lw=.7);ax[6].set_yticks(range(len(order)),order);ax[6].invert_yaxis();xmin=min(z.minimum_distance_A.min()-.15,2);ax[6].set(xlim=(xmin,4.18),xlabel='Minimum ligand–residue distance (Å)');ax[6].legend(fontsize=6.5,loc='lower left');label(ax[6],6,'Measured quercetin–XO contacts')
 atoms=read(XO/'3NVY_全部沉积原子_含occupancy与分类.tsv');lig=atoms[(atoms.label_comp_id=='QUE')&(atoms.label_asym_id=='J')&(atoms.type_symbol!='H')];site=z[z.site_id.eq('QUE_labelJ_authC_1356')];ids=set(site.partner_auth_seq_id.astype(str));prot=atoms[(atoms.category=='protein')&(atoms.auth_asym_id=='C')&(atoms.auth_seq_id.astype(str).isin(ids))&(atoms.type_symbol!='H')]
 assert len(lig)==22
 # Display the deposited ligand and complete contacted-residue heavy atoms, projected together.
 xycol=['Cartn_x','Cartn_y','Cartn_z'];origin=lig[xycol].mean().to_numpy(float);q=lig[xycol].to_numpy(float)-origin;p=prot[xycol].to_numpy(float)-origin;_,_,vt=np.linalg.svd(q,full_matrices=False);q2=q@vt[:2].T;p2=p@vt[:2].T
 ax[7].scatter(p2[:,0],p2[:,1],s=7,c=BLUE,alpha=.18,edgecolors='none');ax[7].scatter(q2[:,0],q2[:,1],s=23,c=ROSE,edgecolor='white',lw=.4,zorder=4)
 dist=np.linalg.norm(q[:,None,:]-q[None,:,:],axis=2)
 for i in range(22):
  for j in range(i):
   if 1.1<dist[i,j]<1.75:ax[7].plot(q2[[i,j],0],q2[[i,j],1],c=ROSE,lw=1,zorder=3)
 ax[7].set(xlabel='Crystal-coordinate projection (Å)',ylabel='Same projection (Å)');ax[7].set_aspect('equal',adjustable='datalim');ax[7].xaxis.set_major_locator(MaxNLocator(4));ax[7].yaxis.set_major_locator(MaxNLocator(4));label(ax[7],7,'Deposited XO binding-site geometry')
 legend='Figure 16 | Public structural context and an experimental ligand reference. All twelve exact canonical AlphaFold DB models and all 7,861 residues are represented; experimental PDB coverage is the union of linked chain spans, which can include unresolved residues. Four full Cα traces are shown in spatial principal-axis projections with a common absolute confidence scale; projection is only a display transform, not a trajectory or new prediction. Two independently occupied QUE sites in experimental bovine-XO structure PDB3NVY retain all fourteen protein-residue contacts per site within 4 Å. The contact-site image uses deposited heavy-atom coordinates from site C, with all heavy atoms of the contacted protein residues and all 22 ligand heavy atoms. Ligand line connections are displayed from 1.1–1.75 Å geometric adjacency. Neither local model confidence nor crystal contact distance establishes human potency.'
 return done(fig,ax,'F16','Protein confidence and experimental ligand geometry',legend,{'P01':'a,b','P02':'c,d,e,f','new_experimental_3NVY_reference':'g,h'})

def draw_F17():
 fig,ax=make(250,4,2,left=.15,right=.86,bottom=.06,top=.955,wspace=.67,hspace=.85)
 poses=read(DOCK/'docking_all_poses.csv');summ=read(DOCK/'docking_top_pose_summary.csv');contacts=read(DOCK/'docking_top_pose_geometric_contacts.csv');md=read(DOCK/'MD_all_frames_metrics.csv');rmsf=read(DOCK/'MD_all_residue_RMSF.csv')
 order=summ.ligand_id.tolist();names=summ.name.str.replace(' (reference)','',regex=False).str.replace('Unlabelled control','Property control',regex=False).tolist()
 for i,g in enumerate(order):
  z=poses[poses.ligand_id.eq(g)];off=np.linspace(-.20,.20,len(z));ax[0].scatter(i+off,z.score_kcal_mol,s=10,c=BLUE if i else GOLD,alpha=.55,edgecolors='none')
 ax[0].set_xticks(range(5),names,rotation=90,ha='right',rotation_mode='anchor');ax[0].set_ylabel('Vina score (kcal per mol)');label(ax[0],0,'All 135 docked poses')
 refall=poses[poses.ligand_id.eq('reference_IQO')].copy();ref=refall[refall['rank'].eq(1)]
 for j,seed in enumerate(sorted(refall.seed.unique())):
  r=refall[refall.seed.eq(seed)];ax[1].scatter(j+np.linspace(-.09,.09,len(r)),r.reference_RMSD_A_fixed_frame_symmetry,s=10,c=GRAY,alpha=.7);first=r[r['rank'].eq(1)];ax[1].scatter([j],first.reference_RMSD_A_fixed_frame_symmetry,s=27,c=[BLUE,TEAL,GOLD][j],edgecolor='white',lw=.4,zorder=5)
 ax[1].axhline(2,c=ROSE,ls='--',lw=.7);ax[1].set_xticks(range(3),['Seed 1','Seed 2','Seed 3']);ax[1].set_ylabel('Fixed-frame symmetry RMSD (Å)');ax[1].set_ylim(0,float(refall.reference_RMSD_A_fixed_frame_symmetry.max())*1.18);label(ax[1],1,'All 27 reference pose records')
 top=poses[poses['rank'].eq(1)]
 for i,g in enumerate(order):
  vals=top.loc[top.ligand_id.eq(g),'score_kcal_mol'].to_numpy(float);ax[2].scatter(i+np.linspace(-.13,.13,len(vals)),vals,s=21,c=TEAL if i else GOLD,edgecolor='white',lw=.4)
 ax[2].set_xticks(range(5),names,rotation=90,ha='right',rotation_mode='anchor');ax[2].set_ylabel('Top-pose Vina score (kcal per mol)');label(ax[2],2,'All 15 seeded top poses')
 # Restore the original measured crystal / rank-1 reference overlay from exact SDF coordinates.
 from rdkit import Chem
 import shutil
 structure_root=DOCK.parent;crystalpath=structure_root/'prepared/IQO_crystal_reference.sdf';posepath=structure_root/'docking'/('reference_IQO_seed'+str(int(ref.seed.iloc[0]))+'.sdf')
 import io
 mols=[next(Chem.ForwardSDMolSupplier(io.BytesIO(path.read_bytes()),removeHs=True)) for path in [crystalpath,posepath]];assert all(m is not None for m in mols)
 xyz=mols[0].GetConformer().GetPositions();origin=xyz.mean(0);_,_,vt=np.linalg.svd(xyz-origin,full_matrices=False);coordinate_rows=[];bond_rows=[]
 for m,path,color,name in zip(mols,[crystalpath,posepath],[GRAY,BLUE],['Crystal IQO','Redocked seed 1']):
  point=m.GetConformer().GetPositions();xy=(point-origin)@vt[:2].T
  for b in m.GetBonds():
   a,c=b.GetBeginAtomIdx(),b.GetEndAtomIdx();ax[3].plot(xy[[a,c],0],xy[[a,c],1],c=color,lw=.8,alpha=.75);bond_rows.append({'structure':name,'atom_a':a,'atom_b':c,'bond_order':b.GetBondTypeAsDouble()})
  ax[3].scatter(xy[:,0],xy[:,1],s=7,c=color,label=name)
  for i,a in enumerate(m.GetAtoms()):coordinate_rows.append({'structure':name,'atom_index':i,'element':a.GetSymbol(),'crystal_frame_x_A':point[i,0],'crystal_frame_y_A':point[i,1],'crystal_frame_z_A':point[i,2],'projected_axis1_A':xy[i,0],'projected_axis2_A':xy[i,1]})
  inputs.append(path);shutil.copy2(path,S.S/'F17'/path.name)
 coords=S.source_table('F17','IQO_fixedframe_display_coordinates.tsv',pd.DataFrame(coordinate_rows));bonds=S.source_table('F17','IQO_exact_bond_graph.tsv',pd.DataFrame(bond_rows));inputs.extend([coords,bonds])
 ax[3].set_aspect('equal',adjustable='datalim');ax[3].set(xlabel='Crystal principal axis 1 (Å)',ylabel='Crystal principal axis 2 (Å)');ax[3].legend(fontsize=6.5,loc='upper left',bbox_to_anchor=(0,-.28));label(ax[3],3,'Unaligned crystal / pose overlay')
 colors=[BLUE,TEAL,ROSE]
 for seed,c in zip(sorted(md.seed.unique()),colors):
  z=md[md.seed.eq(seed)].sort_values('production_time_ps');lab='Seed '+str(seed)[-2:];ax[4].plot(z.production_time_ps,z.pLDDT_ge90_CA_RMSD_A,c=c,lw=.85,label=lab);ax[4].plot(z.production_time_ps,z.all_CA_RMSD_A_after_core_alignment,c=c,lw=.65,ls='--',alpha=.65);ax[5].plot(z.production_time_ps,z.CA_Rg_A,c=c,lw=.85,label=lab)
 ax[4].set(xlabel='Apo production time (ps)',ylabel='Cα RMSD after core alignment (Å)');ax[4].legend(fontsize=6.5,loc='upper left');label(ax[4],4,'Apo AKT1 · core and all residues')
 ax[5].set(xlabel='Apo production time (ps)',ylabel='Cα radius of gyration (Å)');label(ax[5],5,'Apo AKT1 · compactness')
 for seed,c in zip(sorted(rmsf.seed.unique()),colors):
  z=rmsf[rmsf.seed.eq(seed)].sort_values('residue');ax[6].plot(z.residue,z.CA_RMSF_A_core_aligned,c=c,lw=.65,alpha=.7)
 confidence=rmsf.drop_duplicates('residue').sort_values('residue');low=confidence.loc[confidence.AF_pLDDT.lt(70),'residue'].to_numpy(int)
 if len(low):
  for block in np.split(low,np.where(np.diff(low)>1)[0]+1):ax[6].axvspan(block[0]-.5,block[-1]+.5,facecolor=LIGHT,alpha=.7,zorder=0,lw=0)
 ax[6].set(xlabel='AKT1 residue',ylabel='Core-aligned Cα RMSF (Å)');label(ax[6],6,'All apo residue fluctuations')
 # Separate shared time axes preserve the original units of energy and temperature.
 aT=ax[7];aE=aT.twinx()
 for seed,c in zip(sorted(md.seed.unique()),colors):
  z=md[md.seed.eq(seed)].sort_values('production_time_ps');aT.plot(z.production_time_ps,z.temperature_K,c=c,lw=.55,alpha=.75);aE.plot(z.production_time_ps,z.potential_energy_kJ_mol,c=c,lw=.55,ls='--',alpha=.55)
 aT.set(xlabel='Apo production time (ps)',ylabel='Temperature (K)');aE.set_ylabel('Potential energy (kJ per mol)',fontsize=6.5,labelpad=3);aE.tick_params(labelsize=6.5);label(aT,7,'Apo run-state records')
 legend='Figure 17 | Controlled docking and separate apo simulation records. All five ligands, three seeds and 135 Vina poses are retained; reference redocking retains all 27 fixed-frame symmetry-aware RMSDs, with three rank-1 records highlighted; all fifteen seeded top-pose scores are displayed. The overlay uses exact crystal and first-seed rank-1 IQO coordinates without any pose alignment. Full geometric-contact tables remain with the source data. Contact count is geometric and is not hydrogen-bond classification. The lower panels show all three 200-ps apo AKT1 runs and all saved frames/residues. Solid versus dashed RMSD curves denote confident-core versus all-residue metrics; light-grey RMSF bands mark initial model pLDDT below 70. Temperature is solid and potential energy dashed on separately labelled axes. These apo trajectories do not contain docked ligands and therefore do not evaluate ligand-complex stability.'
 return done(fig,ax,'F17','Controlled docking and apo simulation diagnostics',legend,{'D01_controlled_docking':'a,b,c,d','D02_three_seed_apo_MD':'e,f,g,h'},exclude=[aE])

def draw_F18():
 global inputs;inputs=[]
 fig=plt.figure(figsize=(183/25.4,250/25.4));gs=fig.add_gridspec(6,2,left=.16,right=.90,bottom=.065,top=.955,wspace=.9,hspace=1.0,height_ratios=[1.35,1.35,1,1,1,1])
 ax=[fig.add_subplot(gs[0,0]),fig.add_subplot(gs[0,1]),fig.add_subplot(gs[1,0]),fig.add_subplot(gs[1,1]),fig.add_subplot(gs[2:6,0]),fig.add_subplot(gs[2:4,1]),fig.add_subplot(gs[4:6,1])]
 a=read(KO/'K01_单核细胞输入与候选资格_a.tsv');b=read(KO/'K01_单核细胞输入与候选资格_b.tsv');c=read(KO/'K01_单核细胞输入与候选资格_c.tsv');d=read(KO/'K01_单核细胞输入与候选资格_d.tsv')
 z=a.pivot(index='gene',columns='library',values='fraction_detected').reindex(index=GENES);im=heat(ax[0],z.T.to_numpy(),GENES,z.columns,vmin=0,vmax=1);colorbar(fig,ax[0],im,'Detected fraction');label(ax[0],0,'All fixed targets in CD14 cells')
 ax[1].bar(range(len(b)),b.CD14_cells,color=[ROSE if str(x).lower().startswith('acute') else TEAL for x in b.phase],width=.65);ax[1].set_xticks(range(len(b)),b.library);ax[1].set_ylabel('CD14 monocytes');label(ax[1],1,'All six input libraries')
 ax[2].barh(range(len(c)),c.gene_count,color=[GRAY,BLUE,TEAL,GOLD],height=.65);ax[2].set_yticks(range(len(c)),['Input symbols','Detected in each library','Structural filters','Fixed network']);ax[2].invert_yaxis();ax[2].set_xlabel('Genes');label(ax[2],2,'Recorded network eligibility')
 y=np.arange(len(d));ax[3].barh(y,d.common_measurable_members,color=GRAY,height=.65,label='Measurable');ax[3].barh(y,d.members_retained_in_network1500,color=TEAL,height=.38,label='Network');ax[3].set_yticks(y,[short(x,17) for x in d.display_name]);ax[3].invert_yaxis();ax[3].set_xlabel('Pathway genes');ax[3].legend(fontsize=6.5,loc='lower right');label(ax[3],3,'All nine pathway coverages')
 wide=read(KO/'K02_经典虚拟敲除的模型响应_a_全部1500x5_宽表.tsv').set_index('gene');top=read(KO/'K02_经典虚拟敲除的模型响应_a_top40展示顺序.tsv');zz=wide.reindex(top.gene)[PRIMARY];assert np.allclose(zz.max(axis=1),top.max_median_share_percent,rtol=1e-10);vmax=np.nanmax(wide[PRIMARY].to_numpy(float))
 im=heat(ax[4],zz.to_numpy(),PRIMARY,top.gene,cmap=CMAP,vmin=0,vmax=vmax);colorbar(fig,ax[4],im,'Median non-self response share (%)');label(ax[4],4,'Frozen response ordering')
 # The complete matrix is rendered as a companion strip, never replaced by the labelled forty.
 inset=ax[4].inset_axes([-.46,0,.11,1]);inset.imshow(np.ma.masked_invalid(wide[PRIMARY].to_numpy(float)),aspect='auto',cmap=CMAP,vmin=0,vmax=vmax,interpolation='nearest');inset.set_xticks([]);inset.set_yticks([]);inset.set_title('All\n1,500',fontsize=6.5,pad=4)
 out=read(KO/'K02_经典虚拟敲除的模型响应_b_固定WT模型展示出边.tsv');fullout=read(KO/'K02_经典虚拟敲除的模型响应_b_NLRP3全部1500出边与展示标识.tsv');out=out.sort_values('absolute_WT_weight');yy=np.arange(len(out));ax[5].barh(yy,out.WT_outgoing_weight,color=[ROSE if x<0 else BLUE for x in out.WT_outgoing_weight],height=.65);ax[5].set_yticks(yy,out.target_gene);ax[5].axvline(0,c=GRAY,lw=.7);ax[5].set_xlabel('Fixed WT outgoing weight');label(ax[5],5,'Frozen NLRP3 outgoing edges')
 count=read(KO/'K02_经典虚拟敲除的模型响应_c_全部模型主KO与代表对照计数.tsv')
 for j,(role,col) in enumerate([('Primary',BLUE),('Matched control',ROSE)]):
  z=count[count.role.eq(role)]
  if z.empty and j==1:z=count[~count.role.eq('Primary')]
  for i,g in enumerate(PRIMARY):
   v=z[z.target.eq(g)].nonself_algorithm_q_lt05.to_numpy(float);ax[6].scatter(i+(j-.5)*.28+np.linspace(-.045,.045,len(v)),v,s=12,c=col,alpha=.6,edgecolors='none',label=role if i==0 else None)
 ax[6].set_xticks(range(5),PRIMARY,rotation=40,ha='right',rotation_mode='anchor');ax[6].set_ylabel('Algorithm-selected non-self genes');ax[6].legend(fontsize=6.5,loc='upper left');label(ax[6],6,'All 180 target/reference models')
 legend='Figure 18 | Virtual-knockout inputs and complete fitted-model responses. The input comprises 8,564 CD14 cells across six libraries from three patients. All twelve candidate detection profiles, all eligibility stages and all nine frozen pathway coverages are retained. The classical response strip contains all 1,500 genes against all five knockout targets; the adjacent labelled matrix uses the previously frozen forty-gene maximum-response ordering, without a probability filter. Colour shows the library-median non-self L1 response share. All 1,500 fixed WT NLRP3 outgoing weights are preserved in source data; the ten previously chosen non-zero edges are displayed. All primary and representative matched-control model counts are shown across the eighteen library/seed contexts. Algorithm-level gene q values and technical seeds do not constitute patient-level knockout experiments.'
 return done(fig,ax,'F18','Virtual-knockout inputs and network responses',legend,{'K01':'a,b,c,d','K02':'e,f,g'},exclude=[inset])

def draw_F19():
 fig,ax=make(250,4,2,left=.16,right=.90,bottom=.065,top=.955,wspace=.85,hspace=1.1)
 spec=read(KO/'K03_完整45比较图源.tsv');match=read(KO/'K03_匹配精度图源.tsv');counts=read(KO/'K03_匹配数量图源.tsv');path=read(KO/'K03_九通路覆盖图源.tsv')
 terms=list(dict.fromkeys(spec.term_id));names=spec.drop_duplicates('term_id').set_index('term_id').reindex(terms).pathway_name.tolist();z=spec.pivot(index='target',columns='term_id',values='adjusted_excess_over_control_median').reindex(index=PRIMARY,columns=terms);lim=np.nanmax(np.abs(z.to_numpy(float)))
 im=heat(ax[0],z.to_numpy(),[short(n,12) for n in names],PRIMARY,cmap=DIV,vmin=-lim,vmax=lim);colorbar(fig,ax[0],im,'Excess over matched median');label(ax[0],0,'All 45 conditional comparisons')
 vars=list(dict.fromkeys(match.variable));v=match.pivot(index='target',columns='variable',values='maximum_abs_pooled_percentile_gap').reindex(index=PRIMARY,columns=vars);im=heat(ax[1],v.to_numpy(),['Expression','Detection','Variance','Out-strength','Total strength'],PRIMARY,vmin=0,vmax=.2);colorbar(fig,ax[1],im,'Maximum percentile gap');label(ax[1],1,'All matched covariates')
 cc=counts.set_index('target').reindex(PRIMARY);y=np.arange(5);ax[2].bar(y,cc.available_caliper_controls,color=LIGHT,width=.65,label='Within caliper');ax[2].bar(y,cc.selected_controls,color=TEAL,width=.42,label='Selected');ax[2].axhline(30,c=GRAY,ls='--',lw=.7);ax[2].set_xticks(y,PRIMARY,rotation=35,ha='right',rotation_mode='anchor');ax[2].set_ylabel('Reference genes');ax[2].legend(fontsize=6.5,loc='upper right');label(ax[2],2,'Complete reference eligibility')
 y=np.arange(len(path));ax[3].barh(y,path.network1500_members,color=GRAY,height=.65,label='Network');ax[3].barh(y,path.common_response_members,color=BLUE,height=.38,label='Response pool');ax[3].set_yticks(y,[short(x,18) for x in path.pathway_name]);ax[3].invert_yaxis();ax[3].set_xlabel('Pathway members');ax[3].legend(fontsize=6.5,loc='lower right');label(ax[3],3,'Common response-pool coverage')
 data=[read(KO/('K04_跨种子文库与算法敏感性_'+c+'.tsv')) for c in 'abcd'];palette=[BLUE,TEAL,ROSE,GOLD,PURPLE]
 for a,dd,title in zip(ax[4:7],data[:3],['Technical-seed repeatability','Cross-library contextual agreement','Classical versus heat approximation']):
  for g,c in zip(PRIMARY,palette):
   z=dd[dd.KO.eq(g)];ok=np.isfinite(z.Spearman)&np.isfinite(z.top100_Jaccard);axlabel=g if a is ax[4] else None;a.scatter(z.loc[ok,'Spearman'],z.loc[ok,'top100_Jaccard'],s=13,c=c,alpha=.65,edgecolor='white',lw=.2,label=axlabel)
  a.set(xlim=(-1.03,1.03),ylim=(-.03,1.03),xlabel='Response-profile Spearman',ylabel='Top-100 Jaccard');label(a,list(ax).index(a),title)
 ax[4].legend(fontsize=6.5,loc='lower left',ncol=2,columnspacing=.5,handlelength=.7)
 d=data[3];pp=d.pivot(index=['model','KO1','KO2'],columns='profile',values='Spearman');assert len(pp)==180
 for g,c in zip(PRIMARY,palette):
  z=pp.loc[pp.index.get_level_values('KO1')==g];ok=np.isfinite(z.raw_common_response)&np.isfinite(z.shared_adjusted);ax[7].scatter(z.loc[ok,'raw_common_response'],z.loc[ok,'shared_adjusted'],s=12,c=c,alpha=.55,edgecolor='white',lw=.2)
 ax[7].plot([-1,1],[-1,1],ls='--',c=GRAY,lw=.7);ax[7].set(xlim=(-1.03,1.03),ylim=(-1.03,1.03),xlabel='Raw between-target Spearman',ylabel='Shared-adjusted Spearman');label(ax[7],7,'All paired shared-response checks')
 legend='Figure 19 | Conditional pathway specificity and model sensitivity. All forty-five target/pathway comparisons are retained under the fixed matched-reference analysis, together with every matching covariate, all candidate reference counts and all nine pathway coverages. No comparison passes the BH45 criterion (minimum q=0.3375). Technical-seed, between-library and classical/heat comparisons display both Spearman and top-100 Jaccard for every finite recorded pair. Undefined correlations remain missing in the source tables and are not assigned zero. The last panel pairs the 180 raw/shared-adjusted between-target correlations from all 360 records. These are technical/contextual sensitivity checks on shared input networks, not additional biological cohorts or observed gene-knockout responses.'
 return done(fig,ax,'F19','Matched specificity and virtual-perturbation sensitivity',legend,{'K03':'a,b,c,d','K04':'e,f,g,h'})

if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('--figures',nargs='*',default=['F02','F03','F04','F15','F16','F17','F18','F19']);args=parser.parse_args()
 # Keep prior mapping entries when one figure is regenerated after visual inspection.
 mp=O/'source_map_network_structure_ko.json'
 if mp.exists():SOURCE_MAP.update(json.loads(mp.read_text(encoding='utf-8')))
 for fid in args.figures:
  print('DRAW',fid,flush=True);globals()['draw_'+fid]()

