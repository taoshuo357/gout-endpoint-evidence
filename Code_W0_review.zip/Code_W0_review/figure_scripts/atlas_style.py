"""Project-owned public matplotlib exporter, v0.1-W0-review. No private QC imports."""
from pathlib import Path
import sys,os,json,hashlib,inspect
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.transforms import ScaledTranslation
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.ticker import MaxNLocator
from resolver import resolve_input
ROOT=Path(__file__).resolve().parents[1]
E=Path('E:/痛风/研究深化_2026-11-02');G=Path('G:/痛风/第二步_靶点预测与疾病交集')
O=ROOT/'reproduced_figures';F=O;S=O/'Source_Data';Q=O/'QA';M=O/'Metadata'
for p in [O,S,Q,M]:p.mkdir(parents=True,exist_ok=True)
COLORS={'blue': '#3974a7', 'teal': '#218d91', 'rose': '#c75e70', 'gold': '#bc8d36', 'grey': '#a7b1b9', 'gray': '#a7b1b9', 'ink': '#24394b', 'light': '#e5eaee', 'violet': '#82679e', 'green': '#4b9568', 'acute': '#c75e70', 'remission': '#218d91', 'control': '#647f95', 'up': '#c75e70', 'down': '#3974a7'}
C=COLORS
BLUE=C['blue'];TEAL=C['teal'];ROSE=C['rose'];GOLD=C['gold'];GREY=C['grey'];GRAY=GREY;INK=C['ink'];VIOLET=C['violet'];GREEN=C['green']
DIVERGING=LinearSegmentedColormap.from_list('atlas_signed',[BLUE,'#fafafa',ROSE])
SEQUENTIAL=LinearSegmentedColormap.from_list('atlas_sequential',['#f1f6f6','#86c1c2','#146d75'])
plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'], 'font.size': 7.2, 'axes.titlesize': 8, 'axes.titleweight': 'normal', 'axes.labelsize': 7.2, 'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5, 'legend.fontsize': 6.5, 'legend.title_fontsize': 7, 'figure.titlesize': 10, 'axes.linewidth': 0.55, 'axes.edgecolor': '#83919c', 'axes.spines.top': False, 'axes.spines.right': False, 'xtick.major.width': 0.55, 'ytick.major.width': 0.55, 'xtick.major.size': 2.6, 'ytick.major.size': 2.6, 'xtick.major.pad': 2.5, 'ytick.major.pad': 2.5, 'legend.frameon': False, 'svg.fonttype': 'none', 'pdf.fonttype': 42, 'savefig.facecolor': 'white', 'figure.facecolor': 'white', 'axes.facecolor': 'white'})
def sha(p):return hashlib.sha256(Path(resolve_input(p,'sha')).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False,default=str),encoding='utf-8')
def panel_label(ax,label,title=None):
 trans=ax.transAxes+ScaledTranslation(-10/72,7/72,ax.figure.dpi_scale_trans)
 ax.text(0,1,str(label),transform=trans,ha='right',va='bottom',fontweight='bold',fontsize=10.5,clip_on=False)
 if title:ax.set_title(title,loc='left',pad=9,fontsize=8)
 return ax
letter=panel_label
def new_figure(nrows=2,ncols=3,height_mm=205,width_mm=183,**kw):
 fig,axs=plt.subplots(nrows,ncols,figsize=(width_mm/25.4,height_mm/25.4),squeeze=False,**kw);fig.subplots_adjust(left=.09,right=.98,top=.95,bottom=.08,hspace=.62,wspace=.52);return fig,axs
def nice_axes(ax,n=4):ax.xaxis.set_major_locator(MaxNLocator(n));ax.yaxis.set_major_locator(MaxNLocator(n))
def source_table(fid,name,df):
 p=S/fid;p.mkdir(parents=True,exist_ok=True);target=p/name
 if target.suffix=='.json':dump(target,df)
 else:df.to_csv(target,sep='\t' if target.suffix=='.tsv' else ',',index=False)
 return target
def save_figure(fig,id,title,panels,inputs,legend,**kwargs):
 base=F/str(id);fig.canvas.draw();formats=['pdf','svg','png']
 for ext in formats:fig.savefig(str(base)+'.'+ext,**({'dpi':100 if os.environ.get('BUNDLE_SMOKE_FAST')=='1' else 300} if ext=='png' else{}))
 if os.environ.get('BUNDLE_SMOKE_FAST')!='1':fig.savefig(str(base)+'.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'});formats.append('tiff')
 records=[]
 for x in inputs:
  p=Path(resolve_input(x,'export-input-audit'));records.append({'original_identity':str(x),'resolved':str(p),'bytes':p.stat().st_size,'SHA256':sha(p)})
 contract={'id':id,'title':title,'panels':panels,'physical_size_mm':[fig.get_figwidth()*25.4,fig.get_figheight()*25.4],'inputs':records,'legend':legend,'version':'v0.1-W0-review','new_model_fits':False,'formats':formats,'private_QC':'not bundled;this exporter does not claim private collision/alignment QC'}
 dump(M/(str(id)+'_contract.json'),contract);(F/(str(id)+'_legend.txt')).write_text(legend,encoding='utf-8');plt.close(fig);print('EXPORTED '+str(id),flush=True);return contract
