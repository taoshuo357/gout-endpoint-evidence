"""Complete exact-identity functional-screen audit, redrawn from frozen tables."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parent));from atlas_style import *
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch
B=E/'07_实测药物与功能验证/04_NLRP3功能筛选';I=B/'身份扩展'
paths=[B/'NCGC主筛_完整分母与原方覆盖.json',B/'原方候选104_功能筛选覆盖与全部结局.tsv',I/'77ActiveCID_独立去重_全部原CID结局.tsv',I/'Level2_匹配ActiveCID_全部原始SID结局.tsv',I/'Level2_匹配对_原CID全部SID与结局.tsv',B/'phase4精确命中_全字段两浓度与状态.tsv',I/'ChEMBL3475_完整结构与父体审计.tsv']
st=json.loads(paths[0].read_text(encoding='utf-8-sig'));orig,cids,sids,links,dose,audit=[pd.read_csv(p,sep='\t') for p in paths[1:]]
assert len(orig)==104 and len(cids)==77 and len(sids)==83 and len(audit)==3475 and len(dose)==62
fig,axs=plt.subplots(4,2,figsize=(183/25.4,250/25.4));fig.subplots_adjust(left=.145,right=.97,top=.95,bottom=.065,hspace=1.15,wspace=.78)
ax=axs[0,0];panel_label(ax,'a','All deposited screen outcomes')
keys=['Inactive','Active','Inconclusive'];vals=[st['outcomes'][x] for x in keys]
ax.barh(range(3),vals,color=[GREY,TEAL,GOLD]);ax.set(yticks=range(3),yticklabels=keys,xlabel='Substance IDs (log10)',xscale='log',xlim=(1000,700000));ax.invert_yaxis();ax.set_xticks([1000,10000,100000],['1k','10k','100k']);ax.minorticks_off()
for i,v in enumerate(vals):ax.text(v*1.06,i,f'{v:,}',va='center',fontsize=6.5)
ax=axs[0,1];panel_label(ax,'b','Coverage of all 104 candidates')
covered=orig.measured_coverage.astype(str).str.lower().isin(['true','1','yes','tested','measured'])
if covered.sum()!=18:covered=orig.screen_rows.fillna(0).astype(float).gt(0)
assert covered.sum()==18
mat=covered.to_numpy().reshape(8,13);ax.imshow(mat,cmap=ListedColormap(['#e5eaee',TEAL]),aspect='auto',vmin=0,vmax=1);ax.set(xticks=[0,6,12],xticklabels=['1','7','13'],yticks=[0,7],yticklabels=['1','8'],xlabel='Candidate index within row',ylabel='Input-order row')
ax.text(.5,-.43,'18 tested: all Inactive; 86 without exact records',transform=ax.transAxes,ha='center',fontsize=6.5)
ax=axs[1,0];panel_label(ax,'c','Identity expansion and record counts')
counts=[59,77,74,118,125];labs=['Exact CID','Parent CID','Parents','ChEMBL','Links'];ax.bar(range(5),counts,color=[BLUE,TEAL,TEAL,VIOLET,GREY]);ax.set(xticks=range(5),xticklabels=labs,ylabel='Distinct identities or links',ylim=(0,145));ax.tick_params(axis='x',rotation=35)
for i,v in enumerate(counts):ax.text(i,v+3,str(v),ha='center',fontsize=6.5)
ax=axs[1,1];panel_label(ax,'d','All 77 CID outcome histories')
order=cids.CID_PubChem.astype(int).tolist();tab=pd.crosstab(sids['Activity Outcome'],sids.CID.astype(int)).reindex(index=['Active','Inactive','Inconclusive'],columns=order,fill_value=0)
ax.imshow(tab.to_numpy()>0,cmap=ListedColormap(['#e5eaee',TEAL]),vmin=0,vmax=1,aspect='auto',interpolation='nearest');ax.set(yticks=range(3),yticklabels=tab.index,xticks=[0,24,49,76],xticklabels=[1,25,50,77],xlabel='CID, sorted in frozen input order')
conf=[x for x in order if tab.loc['Active',x]>0 and tab.loc['Inactive',x]>0]
ax.text(.5,-.43,'Two mixed histories: CID 71478 and 12303047',transform=ax.transAxes,ha='center',fontsize=6.5)
ax=axs[2,0];panel_label(ax,'e','All 74 normalized parent identities')
parent=links.groupby('parent_full_InChIKey').molecule_chembl_id.nunique().sort_index();assert len(parent)==74
ax.scatter(np.arange(1,75),parent.to_numpy(),s=12,c=TEAL,edgecolors='white',lw=.4);ax.set(xlabel='Normalized parent index',ylabel='Distinct ChEMBL records',xticks=[1,25,50,74]);ax.yaxis.set_major_locator(MaxNLocator(integer=True))
ax=axs[2,1];panel_label(ax,'f','Both deposited concentration readouts')
x=dose['inflammasome-p1_alphalisa-Activity at 11.50 uM_numeric'];y=dose['inflammasome-p1_alphalisa-Activity at 57.50 uM_numeric'];valid=x.notna()&y.notna();ax.scatter(x[valid],y[valid],s=15,c=ROSE,alpha=.65,edgecolors='white',lw=.4);lo=min(x[valid].min(),y[valid].min())-5;hi=max(x[valid].max(),y[valid].max())+5;ax.plot([lo,hi],[lo,hi],c=GREY,lw=.7,ls='--');ax.set(xlim=(lo,hi),ylim=(lo,hi),xlabel='11.5 µM: deposited activity (%)',ylabel='57.5 µM: deposited activity (%)');ax.text(.05,.95,f'{int(valid.sum())} paired SID rows',transform=ax.transAxes,va='top',fontsize=6.5)
ax=axs[3,0];panel_label(ax,'g','All 3,475 structure records')
ct=audit.normalization_status.value_counts();keys=['OK','MISSING_OR_INVALID_STRUCTURE','SOURCE_KEY_STRUCTURE_MISMATCH_EXCLUDED'];vv=[int(ct.get(k,0)) for k in keys];ax.barh(range(3),vv,color=[TEAL,GREY,ROSE]);ax.set(yticks=range(3),yticklabels=['Passed','Missing / invalid','Key mismatch'],xlabel='Records (log10)',xscale='log',xlim=(1,8000));ax.invert_yaxis();ax.set_xticks([1,10,100,1000],['1','10','100','1k']);ax.minorticks_off()
for i,v in enumerate(vv):ax.text(v*1.08,i,f'{v:,}',va='center',fontsize=6.5)
ax=axs[3,1];panel_label(ax,'h','Normalization flags in the full audit')
cols=['parent_changed_full_key','multiple_organic_fragments_sensitivity_flag','stereo_loss_single_fragment_flag'];labs=['Parent key changed','Multiple organic parts','Single-part stereo loss'];vv=[]
for col in cols:vv.append(int(audit[col].astype(str).str.lower().isin(['true','1','1.0']).sum()))
ax.barh(range(3),vv,color=[BLUE,VIOLET,GOLD]);ax.set(yticks=range(3),yticklabels=labs,xlabel='Flagged records',xlim=(0,max(vv)*1.3));ax.invert_yaxis()
for i,v in enumerate(vv):ax.text(v+max(vv)*.03,i,str(v),va='center',fontsize=6.5)
legend='Figure 22 | Full-screen denominators and chemical identity define the functional evidence. a, All 362,359 deposited substance-ID outcomes in the primary IL-1β AlphaLISA screen (362,051 unique CIDs). b, All 104 original candidate CIDs in frozen input order: 18 have exact measured records, all reported Inactive, and 86 have no exact record. c, Identity expansion links 59 exact active CIDs to 77 active CIDs after parent normalization, 74 normalized parents, 118 ChEMBL records and 125 identity links; these are different counting units. d, All original SID outcomes associated with the 77 CIDs, retaining two Active/Inactive conflicts. e, Distinct linked ChEMBL records for every normalized parent. f, All available paired 11.5/57.5-µM deposited response readouts in the 62 original exact-identity SID rows; negative source response values are preserved. These are two concentration measurements, not fitted potency curves; the additional 18 parent-expanded CIDs have concise outcomes rather than complete paired readouts. g, Complete identity audit of 3,475 source records. h, Recorded normalization flags; flags may overlap. Parent normalization is an identity sensitivity, not independent biological replication. The primary assay does not by itself establish direct NLRP3 binding, counterscreen clearance, clinical approval or therapeutic safety.'
save_figure(fig,'F22_Full_screen_and_identity','Functional-screen denominators and identity-sensitive evidence',dict(zip('abcdefgh',['Full outcome denominator','Original104 coverage','Identity units','All77 outcome histories','All74 parents','All paired dose readouts','Full3475 audit','Full audit flags'])),paths,legend)
