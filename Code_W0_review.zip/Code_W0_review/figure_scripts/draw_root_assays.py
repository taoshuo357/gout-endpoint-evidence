"""Complete public array and protein evidence, arranged as Figure 5A/B main plates."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parent));from atlas_style import *
from matplotlib.colors import ListedColormap
from matplotlib.lines import Line2D

def rd(p):return pd.read_csv(p,sep='\t' if p.suffix=='.tsv' else ',')
def arrays():
 g=G/'GEO表达核验_2026-10-29';paths=[g/'预处理/原始芯片_扫描与提取元数据.csv',g/'表达结果/PCA_样本坐标.csv',g/'表达结果/样本相关矩阵.csv',g/'12优先靶点_表达核验.csv']+[g/'表达结果'/(s+'_全部编码基因.csv') for s in ['AG_HC','IG_HC','AG_IG']]
 design,pca,corr,targ,*full=[rd(x) for x in paths];assert len(targ)==12 and len(pca)==12
 fig=plt.figure(figsize=(183/25.4,245/25.4));gs=fig.add_gridspec(3,6,left=.11,right=.92,top=.95,bottom=.085,height_ratios=[.8,.85,1.25],hspace=.64,wspace=2.8)
 ax=fig.add_subplot(gs[0,:3]);panel_label(ax,'a','Study groups and scan dates');design['scan_day']=design.scan_date.str.split().str[0];ct=pd.crosstab(design.group,design.scan_day).reindex(['HC','IG','AG']).fillna(0)
 ax.imshow(ct,cmap=SEQUENTIAL,vmin=0,vmax=6,aspect='auto');ax.set(yticks=range(3),yticklabels=['Healthy','Intercritical','Acute'],xticks=range(len(ct.columns)),xticklabels=ct.columns,xlabel='Recorded scan date');ax.tick_params(axis='x',rotation=35)
 for i in range(3):
  for j in range(len(ct.columns)):ax.text(j,i,str(int(ct.iloc[i,j])),ha='center',va='center',fontsize=7.5,color=INK)
 ax=fig.add_subplot(gs[0,3:]);panel_label(ax,'b','All twelve arrays')
 for group,col in [('HC',GREY),('IG',TEAL),('AG',ROSE)]:
  z=pca[pca.group.eq(group)];ax.scatter(z.PC1,z.PC2,s=27,c=col,edgecolors='white',lw=.5,label=group+' ('+str(len(z))+')')
 ax.set(xlabel='PC1 (42.4%)',ylabel='PC2 (23.7%)');ax.legend(loc='upper left',fontsize=6.5)
 limx=max(np.nanmax(abs(x.logFC)) for x in full)*1.05;limy=max(np.nanmax(-np.log10(np.maximum(x['P.Value'],np.nextafter(0,1)))) for x in full)*1.06
 for i,(d,ctitle) in enumerate(zip(full,['Acute vs healthy','Intercritical vs healthy','Acute vs intercritical'])):
  ax=fig.add_subplot(gs[1,i*2:(i+1)*2]);panel_label(ax,chr(99+i),ctitle)
  x=d.logFC.to_numpy();y=-np.log10(np.maximum(d['P.Value'].to_numpy(),np.nextafter(0,1)));q=d.q_all_three_contrasts.to_numpy();col=np.where(q<.05,np.where(x>0,ROSE,BLUE),'#c3cbd1');ax.scatter(x,y,c=col,s=2,lw=0,alpha=.6,rasterized=True);ax.axvline(0,color=GREY,lw=.6);ax.set(xlim=(-limx,limx),ylim=(-.1,limy),xlabel='Effect (log2)',ylabel='−log10 nominal P' if i==0 else '')
 ax=fig.add_subplot(gs[2,:3]);panel_label(ax,'f','All candidate effect intervals')
 for k,(co,col,lab) in enumerate([('AG_HC',ROSE,'Acute / healthy'),('IG_HC',TEAL,'Intercritical / healthy'),('AG_IG',BLUE,'Acute / intercritical')]):
  for j,row in targ.iterrows():
   v,lo,hi=[row[co+s] for s in ['_logFC','_CI.L','_CI.R']]
   if np.isfinite([v,lo,hi]).all():ax.errorbar(v,j+(k-1)*.22,xerr=[[v-lo],[hi-v]],fmt='o',ms=2.7,lw=.7,capsize=1,color=col,label=lab if j==0 else None)
 ax.axvline(0,lw=.6,c=GREY);ax.set(yticks=range(12),yticklabels=targ.gene_symbol,xlabel='Expression effect (log2)');ax.invert_yaxis();ax.legend(loc='upper center',bbox_to_anchor=(.5,-.14),ncol=1,fontsize=6.5)
 ax=fig.add_subplot(gs[2,3:]);panel_label(ax,'g','Full sample correlation map')
 mat=corr.set_index('sample_id');v=mat.to_numpy();im=ax.imshow(v,cmap=SEQUENTIAL,vmin=np.nanmin(v),vmax=np.nanmax(v),aspect='auto');labels=[str(x)[-2:] for x in mat.index];ax.set(xticks=range(12),xticklabels=labels,yticks=range(12),yticklabels=labels,xlabel='GSM sample suffix',ylabel='GSM sample suffix');ax.tick_params(axis='both',labelsize=6.5)
 cb=fig.colorbar(im,ax=ax,fraction=.038,pad=.04);cb.set_label('Pearson r',fontsize=6.5)
 legend='Figure 5 | Public transcript and protein evidence retains the original assay context. Part 1, microarray evidence. a,b, GSE160170 contains six healthy controls (HC), three intercritical samples (IG) and three acute samples (AG); all samples and recorded scan dates are shown. c–e, All retained coding genes in the three original contrasts, with common plotting limits and colors determined by the recorded three-contrast BH correction. f, All twelve predefined targets in all three contrasts, using original marginal 95% intervals; no candidate is removed according to direction or significance. g, Complete twelve-sample correlation matrix. Sample suffixes identify GSM4861833–GSM4861844. These are exploratory associations from the original array design; scan and extraction metadata and the existing same-day, age and leave-one-out sensitivities are retained in Source Data. No new cohort or hypothesis test was introduced during figure reconstruction.'
 save_figure(fig,'F05A_Array_design_and_target_effects','Public array design and full target effects',dict(zip('abcdefg',['Scan-date composition','All-sample PCA','Acute–healthy whole gene family','Intercritical–healthy whole family','Acute–intercritical whole family','All target confidence intervals','All sample correlations'])),paths,legend)

def proteins():
 g=G/'论文推进_2026-10-30/公开蛋白与临床资源核查';paths=[g/'蛋白验证_样本纳入流程.csv',g/'固定12靶点_蛋白面板覆盖.tsv',g/'蛋白验证_主比较_全92蛋白.csv',g/'蛋白验证_TNF配对SF血清_27供者源数据.csv',g/'蛋白验证_TNF预设敏感性与次要比较.csv',g/'蛋白验证_清洁长表_散列供者.csv',g/'蛋白验证_结果摘要.json']
 flow,cov,pr,pair,se,long=[rd(p) for p in paths[:-1]];stats=json.loads(paths[-1].read_text(encoding='utf-8-sig'))
 strict=long[long.strict_include.astype(bool)];assert pr.shape[0]==92 and len(pair)==27 and len(se)==8
 fig,axs=plt.subplots(3,2,figsize=(183/25.4,240/25.4));fig.subplots_adjust(left=.12,right=.975,top=.95,bottom=.095,hspace=.64,wspace=.82)
 ax=axs[0,0];panel_label(ax,'h','Sample counts by group code')
 types=['SF_cell_lysate','Serum'];counts=[]
 for tissue in types:counts.append(strict[strict.tissue.eq(tissue)].drop_duplicates('donor_token').GRUPOHUA_code.value_counts().reindex([1,2,3],fill_value=0).to_numpy())
 for i,(t,col) in enumerate(zip(['SF cells','Serum'],[TEAL,GOLD])):ax.bar(np.arange(3)+(i-.5)*.30,counts[i],width=.28,color=col,label=t)
 ax.set(xticks=range(3),xticklabels=['Code 1','Code 2','Code 3'],ylabel='Unique donors');ax.legend(fontsize=6.5)
 ax=axs[0,1];panel_label(ax,'i','All twelve target assays')
 fixed=['NLRP3','CASP1','IL1B','XDH','SLC22A12','ABCG2','SLC2A9','TLR4','RELA','NFKB1','TNF','AKT1'];tab=cov.pivot(index='fixed_gene',columns='tissue',values='protein_assay_available').reindex(fixed)
 ax.imshow(tab.astype(float),cmap=ListedColormap(['#e6ecef',TEAL]),vmin=0,vmax=1,aspect='auto');ax.set(yticks=range(12),yticklabels=fixed,xticks=range(len(tab.columns)),xticklabels=['Serum' if 'serum' in str(s).lower() else 'SF cells' for s in tab.columns])
 ax=axs[1,0];panel_label(ax,'j','All 92 protein associations')
 x=pr.mean_difference_NPX.to_numpy();y=-np.log10(np.maximum(pr.P_two_sided_Welch.to_numpy(),np.nextafter(0,1)));lod=pr.LOD_limited_anygroup50pct.astype(bool).to_numpy();ax.scatter(x[~lod],y[~lod],s=15,c=TEAL,lw=.5,edgecolors='white',label='Not LOD limited');ax.scatter(x[lod],y[lod],s=15,facecolors='none',edgecolors=GREY,lw=.7,label='LOD limited');ax.set(xlabel='Code 3 − codes 1/2 (NPX)',ylabel='−log10 nominal P');ax.axvline(0,c=GREY,lw=.6);ax.legend(loc='upper right',fontsize=6.5)
 ax=axs[1,1];panel_label(ax,'k','Detection in both coded groups')
 ax.scatter(pr.belowMaxLOD_fraction_group1_2_or_Tipo0_2,pr.belowMaxLOD_fraction_group3_or_Tipo1,s=16,c=TEAL,alpha=.7,edgecolors='white',lw=.4);ax.plot([0,1],[0,1],c=GREY,lw=.7,ls='--');ax.set(xlabel='Fraction below LOD: codes 1/2',ylabel='Fraction below LOD: code 3',xlim=(-.04,1.04),ylim=(-.04,1.04));ax.set_xticks([0,.5,1]);ax.set_yticks([0,.5,1])
 ax=axs[2,0];panel_label(ax,'l','All 27 paired TNF observations')
 for code,col in [(1,BLUE),(2,TEAL),(3,ROSE)]:
  z=pair[pair.GRUPOHUA_code.eq(code)];ax.scatter(z.Serum_TNF_NPX,z.SF_TNF_NPX,c=col,s=20,edgecolors='white',lw=.5,label='Code '+str(code))
 ax.set(xlabel='Serum TNF (NPX)',ylabel='SF-cell TNF (NPX)');ax.legend(loc='upper right',fontsize=6.5);ax.text(.5,-.24,'Spearman rho = 0.109; 27 donors',transform=ax.transAxes,ha='center',fontsize=6.5)
 ax=axs[2,1];panel_label(ax,'m','All TNF processing checks')
 labs=['SF · MaxLOD','SF · Raw','SF · PlateLOD','SF · All donors','SF · Tipo codes','Serum · MaxLOD','Serum · Raw','Serum · PlateLOD']
 for i,row in se.iterrows():
  v,lo,hi=[row[x] for x in ['mean_difference_NPX','CI95_low','CI95_high']]
  ax.errorbar(v,i,xerr=[[v-lo],[hi-v]],fmt='o',ms=3,lw=.8,capsize=1.5,c=VIOLET if i<5 else GOLD)
 ax.axvline(0,c=GREY,lw=.6);ax.set(yticks=range(8),yticklabels=labs,xlabel='TNF difference (NPX)');ax.invert_yaxis()
 legend='Figure 5 | Public transcript and protein evidence retains the original assay context (continued). Part 2, protein evidence. h, All strictly included donor counts by deposited clinical code and specimen. Codes are retained because the diagnostic dictionary was not verified. i, Coverage of all twelve targets in both protein panels; teal means an assay exists and grey means it was not measured. j, All 92 protein effects from the frozen coded-group contrast, with detection-limited assays distinguished. k, Below-MaxLOD fractions for all 92 assays in both compared groups. l, All 27 donors with paired serum and synovial-cell (SF-cell) TNF observations; the existing Spearman correlation is descriptive across specimen matrices. m, All eight prespecified TNF contrast/processing sensitivities, showing original marginal 95% intervals. The source tables retain all correction families, sample inclusion flags and censoring rules. These public protein observations do not establish a new treatment cohort or substitute for matched RNA validation.'
 save_figure(fig,'F05B_Public_protein_coverage','Public protein-panel coverage and complete observations',dict(zip('hijklm',['Coded donor composition','All twelve assay coverage','All protein effects','Detection fractions','All paired TNF observations','All processing sensitivities'])),paths,legend)
if __name__=='__main__':arrays();proteins()
