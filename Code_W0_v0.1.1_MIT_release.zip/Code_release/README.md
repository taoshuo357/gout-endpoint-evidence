# Endpoint-resolved gout evidence: W0 baseline code

Author: Taoshuo Yang. Proposed version: **v0.1.1-W0-release**. Scientific snapshot: 5 November 2026; scoped MIT licensing/documentation patch prepared 26 November 2026. This locally prepared payload is not proof that a tag, release or DOI has been published.

This package preserves the original analysis snapshots and public figure layer; numerical code is unchanged. Project-authored code is MIT (LICENSE; LICENSING_SCOPE.md). Third-party software and data retain their terms (THIRD_PARTY_NOTICES.md; licensing/). No installed runtime, private skill implementation, source-data ZIP, private clinical data or patient workbook is bundled.

## Execution

source_analysis/ contains historical statistical/model snapshots with original path and upstream-dependency assumptions; configure these explicitly. figure_scripts/ redraws frozen outputs, without fitting new models. Extract the code ZIP so that Code_release/ and the separately obtained Zenodo_upload_22_files/ directory are siblings. Install figure_scripts/requirements.txt, then run `python strict_bundle_smoke.py` from figure_scripts/. Reads use exact archived identity and SHA256; old E:/G: paths are labels, not fallback inputs. Outputs stay inside Code_release/runtime_inputs and Code_release/reproduced_figures. Historical six modulewise strict-bundle checks covered 24 W0 plates; those were separate module runs, not a newly executed end-to-end statistical reproduction.

The original 22 data archives are outside MIT and any blanket CC BY grant. Some members have explicit attribution/NC/ShareAlike conditions; others require source-specific clarification and are marked HOLD_PENDING_SOURCE_TERMS. licensing/DATA_MEMBER_RIGHTS.tsv gives exact per-member actions; AUTHOR_OUTPUTS_PUBLIC_LIST.tsv lists author metadata/numerical results. Code availability alone does not establish that every input needed for a complete strict-bundle redraw is publicly downloadable.

## Baseline and later manuscript scope

This is W0 only, not the full release for two later manuscripts. It excludes E15-E18 measured-label curation/new models, E16 graph/source extraction, E17 diffusion benchmarks and E18 enrichment/immune/GP-tier extensions. licensing/A_B_EXTENSION_ASSETS_AND_GAPS.tsv lists the additional release scope and shared-source boundaries. Reuse of the same labels/GEO matrices/graph is a shared resource, not independent replication or two new datasets.

Repository target: https://github.com/taoshuo357/gout-endpoint-evidence . Historical reserved data DOI 10.5281/zenodo.23969076 is not attested here as a published archive; a current public record must be observed first. These files create no DOI or remote tag. Clean-environment installation and cross-platform/Linux reproduction have not been tested; no CI result is asserted and no package installation was performed for this licensing patch. CITATION.cff records the supplied sole author and no fabricated affiliation/DOI. Author affiliation, funding and competing-interest declarations remain pending; no statement of absence is inferred.
